"""Прототип мира доброго сна: парящие острова. Тот же алгоритм потом переносится в Java (SkyIslands).
python3 proto_islands.py [seed] -> /home/claude/islands_*.png (вид от игрока, карта сверху)
Детерминирован: остров = функция (seed, ячейка), блок = функция (seed, x, y, z)."""
import sys, math
import numpy as np
from PIL import Image
from scipy.ndimage import zoom

SEED = int(sys.argv[1]) if len(sys.argv) > 1 else 7
N = 256          # размер участка по X и Z
H = 190          # высота
CELL = 56        # шаг сетки островов

AIR, GRASS, DIRT, STONE, LEAF, LOG, WATER, VINE, MARBLE, LANTERN, LEAF2, MOSS, ROOF, CRYSTAL, FLOWER, WINDOW = range(16)
COLORS = {GRASS: (88, 150, 52), DIRT: (112, 78, 52), STONE: (150, 146, 160), LEAF: (214, 120, 196), LEAF2: (236, 160, 220),
          LOG: (96, 66, 52), WATER: (150, 200, 255), VINE: (48, 100, 44), MARBLE: (232, 226, 240), LANTERN: (255, 214, 130),
          MOSS: (70, 120, 60), ROOF: (110, 96, 190), CRYSTAL: (196, 120, 255), FLOWER: (214, 160, 255), WINDOW: (255, 226, 150)}

rng_g = np.random.default_rng(SEED)

def hrand(*a):
    h = SEED * 0x9E3779B1
    for v in a:
        h = (h ^ (int(v) & 0xFFFFFFFF)) * 0x85EBCA6B & 0xFFFFFFFFFFFF
        h ^= h >> 13
    return ((h * 0xC2B2AE35) & 0xFFFFFFFF) / 0xFFFFFFFF

def noise2(seed, scale):
    r = np.random.default_rng(seed)
    g = r.random((max(2, N // scale + 2), max(2, N // scale + 2)))
    z = zoom(g, (N / (g.shape[0] - 1) * 1.0, N / (g.shape[1] - 1) * 1.0), order=3)[:N, :N]
    return (z - z.mean()) / (z.std() + 1e-6)

NZ_A = noise2(SEED + 1, 24)
NZ_B = noise2(SEED + 2, 8)
NZ_C = noise2(SEED + 3, 40)

grid = np.zeros((N, N, H), np.uint8)   # [x, z, y]

def put(x, y, z, b, only_air=True):
    if 0 <= x < N and 0 <= z < N and 0 <= y < H:
        if not only_air or grid[x, z, y] == AIR:
            grid[x, z, y] = b

def islands():
    out = []
    for cx in range(-1, N // CELL + 2):
        for cz in range(-1, N // CELL + 2):
            if hrand(cx, cz, 1) < 0.18:
                continue
            x = cx * CELL + CELL * (0.2 + 0.6 * hrand(cx, cz, 2))
            z = cz * CELL + CELL * (0.2 + 0.6 * hrand(cx, cz, 3))
            big = hrand(cx, cz, 4)
            r = 9 + 16 * hrand(cx, cz, 5) ** 1.3 + (10 if big > 0.93 else 0)
            y = 56 + 50 * hrand(cx, cz, 6)
            out.append(dict(x=x, z=z, r=r, y=int(y), t=r * (0.9 + 0.7 * hrand(cx, cz, 7)), key=(cx, cz), big=big > 0.93))
    return out

ISL = islands()
_big = max(range(len(ISL)), key=lambda k: ISL[k]['r'])
ISL[_big].update(r=max(ISL[_big]['r'], 30), big=True, y=62, t=44)
for _k, _i in enumerate(ISL):
    if _k != _big: _i['big'] = False

def build_island(i):
    cx, cz, r, y0, t = i["x"], i["z"], i["r"], i["y"], i["t"]
    xs = range(max(0, int(cx - r * 1.4)), min(N, int(cx + r * 1.4) + 1))
    zs = range(max(0, int(cz - r * 1.4)), min(N, int(cz + r * 1.4) + 1))
    tops = {}
    for x in xs:
        for z in zs:
            ang = math.atan2(z - cz, x - cx)
            wob = 1.0 + 0.22 * NZ_A[x % N, z % N] * 0.6 + 0.1 * math.sin(ang * 3 + i["key"][0]) + 0.08 * math.sin(ang * 5 + i["key"][1])
            d = math.hypot(x - cx, z - cz) / (r * wob)
            if d >= 1:
                continue
            top = y0 + int(round(1.6 * NZ_C[x % N, z % N] * (1 - d)))
            depth = t * 1.55 * (1 - d * d) ** 0.75
            depth += 3.0 * NZ_B[x % N, z % N] * (1 - d) + 5.0 * max(0, NZ_A[(x + 9) % N, (z + 5) % N]) * d
            depth = max(2, depth)
            bot = int(top - depth)
            tops[(x, z)] = top
            for y in range(max(0, bot), top + 1):
                if y == top:
                    b = GRASS
                elif y >= top - 3:
                    b = DIRT
                else:
                    b = STONE
                    if (NZ_A[(x + 3) % N, (z + 7) % N] > 0.35 and (y > top - 9 or y < bot + 4) and hrand(x, y, z) > 0.35) or hrand(x, y, z) > 0.965:
                        b = MOSS
                grid[x, z, y] = b
            if d > 0.78 and bot > 2:                      # лианы свисают с края
                if hrand(x, z, 11) < 0.35:
                    ln = int(3 + 9 * hrand(x, z, 12))
                    for k in range(1, ln):
                        put(x, int(top - 1 - k) if False else bot - k + 1, z, VINE)
    return tops

def crystal(x, y, z, h, up=True):
    for k in range(h):
        yy = y + k if up else y - k
        put(x, yy, z, CRYSTAL, False)
        if k < h // 2:
            for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                if hrand(x + dx, yy, z + dz) > 0.5:
                    put(x + dx, yy, z + dz, CRYSTAL, False)

def tree(x, z, y, big=False, seed=0):
    th = int((14 if big else 5) + (6 if big else 3) * hrand(x, z, 21))
    w = 2 if big else 1
    for k in range(th):
        for dx in range(w):
            for dz in range(w):
                put(x + dx, y + 1 + k, z + dz, LOG, False)
    rr = (8 if big else 3.6) + (2 if big else 1.2) * hrand(x, z, 22)
    cy = y + th
    for dx in range(-int(rr) - 2, int(rr) + 3):
        for dy in range(-int(rr * 0.6) - 1, int(rr * 0.8) + 2):
            for dz in range(-int(rr) - 2, int(rr) + 3):
                e = (dx / rr) ** 2 + (dy / (rr * 0.7)) ** 2 + (dz / rr) ** 2
                if e < 1 and hrand(x + dx, y + dy, z + dz) > 0.12:
                    put(x + dx, cy + dy, z + dz, LEAF if hrand(x + dx, cy + dy, z + dz) > 0.35 else LEAF2)

def pagoda(x, z, y, s=4):
    for tier in range(3):
        w = s - tier
        yy = y + 1 + tier * 4
        for dx in range(-w, w + 1):
            for dz in range(-w, w + 1):
                edge = max(abs(dx), abs(dz)) == w
                for k in range(3):
                    if edge and (abs(dx) == w and abs(dz) == w or k == 0 and False):
                        put(x + dx, yy + k, z + dz, MARBLE)
                    elif edge and (dx + dz) % 2 == 0 and k < 2:
                        put(x + dx, yy + k, z + dz, MARBLE)
                put(x + dx, yy + 3, z + dz, ROOF if max(abs(dx), abs(dz)) <= w + 0 else AIR)
        for dx in range(-w - 1, w + 2):
            for dz in range(-w - 1, w + 2):
                if max(abs(dx), abs(dz)) == w + 1:
                    put(x + dx, yy + 3, z + dz, ROOF)
    put(x, y + 13, z, LANTERN); put(x, y + 14, z, MARBLE); put(x, y + 15, z, MARBLE)

def cone(x, y, z, r, mat=ROOF, top=MARBLE):
    k = 0
    while r >= 0:
        for dx in range(-r, r + 1):
            for dz in range(-r, r + 1):
                if dx * dx + dz * dz <= r * r + r and (dx * dx + dz * dz >= (r - 1) ** 2 or r <= 1):
                    put(x + dx, y + k, z + dz, mat if r > 0 else top, False)
        r -= 1; k += 1
    for j in range(5):
        put(x, y + k + j, z, LANTERN if j == 4 else top, False)
    return y + k + 5

def tower(x, z, y, w, h, roof=True, win=True):
    for dx in range(-w, w + 1):
        for dz in range(-w, w + 1):
            e = max(abs(dx), abs(dz)) == w
            for k in range(h):
                if e or k % 8 == 7:
                    put(x + dx, y + 1 + k, z + dz, MARBLE, False)
                else:
                    put(x + dx, y + 1 + k, z + dz, AIR, False)
    if win:
        for k in range(3, h - 2, 6):                      # окна: тёплые арочки по четырём сторонам
            for sgn in (-1, 1):
                for j in range(3):
                    put(x + sgn * w, y + 1 + k + j, z, WINDOW, False)
                    put(x, y + 1 + k + j, z + sgn * w, WINDOW, False)
    if roof:
        for dx in range(-w - 1, w + 2):
            for dz in range(-w - 1, w + 2):
                if max(abs(dx), abs(dz)) == w + 1:
                    put(x + dx, y + h, z + dz, MARBLE, False)
        return cone(x, y + h + 1, z, w + 1)
    return y + h

def castle(x, z, y):
    # крепостная стена с угловыми башенками и аркой ворот
    R = 24
    for dx in range(-R, R + 1):
        for dz in range(-R, R + 1):
            if max(abs(dx), abs(dz)) == R:
                for k in range(1, 8):
                    gate = (dz == R and abs(dx) <= 3 and k < 6 - (abs(dx) // 2))
                    if not gate and (k < 6 or (dx + dz) % 2 == 0):
                        put(x + dx, y + k, z + dz, MARBLE, False)
    for sx in (-R, R):
        for sz in (-R, R):
            tower(x + sx, z + sz, y, 3, 12)
    # дорожка к воротам
    for k in range(R + 4):
        for dx in range(-1, 2):
            put(x + dx, y, z + k, MARBLE, False)
    # главная крепость: ярусы, боковые башни, центральный шпиль
    for (ox, oz, w, h) in ((0, 0, 11, 16), (0, 0, 8, 30)):
        tower(x + ox, z + oz, y, w, h, roof=False, win=True)
    for (ox, oz, w, h) in ((-13, 0, 4, 26), (13, 0, 4, 26), (0, -13, 4, 30), (-8, 11, 3, 20), (8, 11, 3, 20)):
        tower(x + ox, z + oz, y, w, h)
    top = tower(x, z, y + 30, 5, 20, roof=False)
    for dx in range(-6, 7):
        for dz in range(-6, 7):
            if max(abs(dx), abs(dz)) == 6:
                put(x + dx, y + 50, z + dz, MARBLE, False)
    t = cone(x, y + 51, z, 6)
    for k in range(18):
        put(x, y + 51 + 7 + 6 + k, z, MARBLE, False) if False else None
    for k in range(t - y, t - y + 22):
        put(x, y + k, z, MARBLE, False)
    for k in range(6):
        put(x, y + t - y + 22 + k, z, CRYSTAL, False)
    # арочные контрфорсы между башнями
    for ang in range(0, 360, 90):
        for k in range(14):
            for sd in (-1, 1):
                px = x + int(round(math.cos(math.radians(ang)) * (8 + k * 0.5)))
                pz = z + int(round(math.sin(math.radians(ang)) * (8 + k * 0.5)))
                put(px, y + 14 + k, pz, MARBLE)

def waterfall(x, z, y_top, y_bot):
    for y in range(max(0, y_bot), y_top + 1):
        for dx in (-1, 0, 1):
            put(x + dx, y, z, WATER, False)

# ---- сборка
tops_by_isl = []
for i in ISL:
    tops_by_isl.append(build_island(i))

for idx, i in enumerate(ISL):
    tops = tops_by_isl[idx]
    if not tops:
        continue
    cx, cz, r = i["x"], i["z"], i["r"]
    # декор: деревья по ключу ячейки
    n_trees = int(r * r / 55)
    for k in range(n_trees):
        a = hrand(i["key"][0], i["key"][1], 100 + k) * 6.283
        d = r * 0.7 * math.sqrt(hrand(i["key"][0], i["key"][1], 200 + k))
        x, z = int(cx + d * math.cos(a)), int(cz + d * math.sin(a))
        if (x, z) in tops and not (i["big"] and d < 9):
            tree(x, z, tops[(x, z)], big=False)
    if idx % 5 == 2 and r > 12:                       # огромное цветущее дерево
        x, z = int(cx), int(cz)
        if (x, z) in tops:
            tree(x, z, tops[(x, z)], big=True)
    elif idx % 4 == 1 and r > 11:
        x, z = int(cx), int(cz)
        if (x, z) in tops:
            pagoda(x, z, tops[(x, z)], 4)
    if i["big"] and (int(cx), int(cz)) in tops:
        castle(int(cx), int(cz), tops[(int(cx), int(cz))])
    # водопад с края
    if hrand(i["key"][0], i["key"][1], 300) < 0.7:
        a = hrand(i["key"][0], i["key"][1], 301) * 6.283
        best = None
        for d in np.linspace(r * 1.3, 0, 40):
            x, z = int(cx + d * math.cos(a)), int(cz + d * math.sin(a))
            if (x, z) in tops:
                best = (x, z); break
        if best:
            x, z = best
            waterfall(x, z, tops[(x, z)], int(tops[(x, z)] - 28 - 36 * hrand(i["key"][0], i["key"][1], 302)))

# ---- цветы, кристаллы
for idx, i in enumerate(ISL):
    tops = tops_by_isl[idx]
    for (x, z), top in tops.items():
        r1 = hrand(x, z, 50)
        if r1 < 0.05 and grid[x, z, top + 1] == AIR:
            put(x, top + 1, z, FLOWER)
        elif r1 > 0.995:
            crystal(x, top + 1, z, 2 + int(3 * hrand(x, z, 51)), True)
    # висящие кристаллы с днища
    for (x, z), top in tops.items():
        if hrand(x, z, 52) > 0.985:
            col = grid[x, z]; nz = np.nonzero(col)[0]
            if len(nz):
                crystal(x, int(nz[0]) - 1, z, 3 + int(6 * hrand(x, z, 53)), False)

# ---- мосты между близкими островами
def bridge(a, b, ta, tb):
    dx, dz = b['x'] - a['x'], b['z'] - a['z']
    L = math.hypot(dx, dz); ux, uz = dx / L, dz / L
    p0 = (a['x'] + ux * a['r'] * 0.8, a['z'] + uz * a['r'] * 0.8); p1 = (b['x'] - ux * b['r'] * 0.8, b['z'] - uz * b['r'] * 0.8)
    def hy(p, tops, isl):
        for rr in (0, 2, 4):
            c = (int(p[0] - ux * rr), int(p[1] - uz * rr))
            if c in tops: return tops[c]
        return isl['y']
    y0, y1 = hy(p0, ta, a), hy(p1, tb, b)
    n = int(math.hypot(p1[0] - p0[0], p1[1] - p0[1]) * 1.5)
    for s_ in range(n + 1):
        t = s_ / max(1, n)
        px, pz = p0[0] + (p1[0] - p0[0]) * t, p0[1] + (p1[1] - p0[1]) * t
        py = y0 + (y1 - y0) * t + 3.5 * math.sin(math.pi * t)
        for w in (-2, -1, 0, 1, 2):
            x, z = int(round(px - uz * w)), int(round(pz + ux * w))
            put(x, int(round(py)), z, MARBLE if abs(w) < 2 else (MARBLE), False)
            if abs(w) == 2:
                put(x, int(round(py)) + 1, z, MARBLE, False)
                if s_ % 6 == 0:
                    put(x, int(round(py)) + 2, z, MARBLE, False); put(x, int(round(py)) + 3, z, LANTERN, False)
        if s_ % 5 == 2:                                  # арочная опора вниз
            for k in range(1, 7):
                put(int(round(px)), int(round(py)) - k, int(round(pz)), MARBLE)

pairs = []
for a_i in range(len(ISL)):
    near = sorted(range(len(ISL)), key=lambda b_: math.hypot(ISL[a_i]['x'] - ISL[b_]['x'], ISL[a_i]['z'] - ISL[b_]['z']))[1:3]
    for b_i in near:
        A, B = ISL[a_i], ISL[b_i]
        gap = math.hypot(A['x'] - B['x'], A['z'] - B['z']) - A['r'] - B['r']
        if (min(a_i, b_i), max(a_i, b_i)) in pairs or gap > 34 or gap < 4 or abs(A['y'] - B['y']) > 24:
            continue
        pairs.append((min(a_i, b_i), max(a_i, b_i)))
        bridge(A, B, tops_by_isl[a_i], tops_by_isl[b_i])

# ---- рендер
def render(cam, look, W=800, Hh=450, fov=70, name="islands_view", sun_dir=(0.8, 0.12, -0.4)):
    cam = np.array(cam, float); look = np.array(look, float)
    fw = look - cam; fw /= np.linalg.norm(fw)
    up = np.array([0, 1.0, 0]); rt = np.cross(fw, up); rt /= np.linalg.norm(rt); up2 = np.cross(rt, fw)
    f = (Hh / 2) / math.tan(math.radians(fov) / 2)
    ys, xs = np.mgrid[0:Hh, 0:W]
    dirs = fw[None, None, :] + ((xs - W / 2 + 0.5) / f)[..., None] * rt + (-(ys - Hh / 2 + 0.5) / f)[..., None] * up2
    dirs /= np.linalg.norm(dirs, axis=2, keepdims=True)
    P = W * Hh
    d = dirs.reshape(P, 3)
    col = np.zeros((P, 3)); hit = np.zeros(P, bool)
    tmax = 300.0
    t = np.zeros(P)
    pal = np.zeros((16, 3)); 
    for k, v in COLORS.items(): pal[k] = v
    # небо: градиент по высоте луча
    sd = np.array(sun_dir, float); sd /= np.linalg.norm(sd)
    sky_up = np.clip(d[:, 1], -0.3, 1.0)
    top_c = np.array([92, 70, 190.0]); mid_c = np.array([220, 130, 190.0]); hor_c = np.array([255, 170, 110.0])
    s = np.clip(sky_up / 0.55, 0, 1)[:, None]
    low = np.clip((0.12 - sky_up) / 0.4, 0, 1)[:, None]
    sky = hor_c * (1 - np.clip(sky_up / 0.18, 0, 1))[:, None] + mid_c * np.clip(sky_up / 0.18, 0, 1)[:, None]
    sky = sky * (1 - s) + top_c * s
    sky = sky * (1 - low) + np.array([200, 150, 220.0]) * low
    sun = (d @ sd) > 0.9975
    sky[sun] = [255, 246, 210]
    glow = np.clip((d @ sd - 0.9) / 0.1, 0, 1)[:, None] * np.array([120, 70, 20.0])
    sky = sky + glow
    col[:] = sky
    step = 0.45
    prev = np.floor(cam[None, :] + d * 0.0).astype(int)
    active = np.arange(P)
    for it in range(int(tmax / step)):
        t[active] += step
        pos = cam[None, :] + d[active] * t[active][:, None]
        ix = np.floor(pos[:, 0]).astype(int); iz = np.floor(pos[:, 2]).astype(int); iy = np.floor(pos[:, 1]).astype(int)
        inb = (ix >= 0) & (ix < N) & (iz >= 0) & (iz < N) & (iy >= 0) & (iy < H)
        blk = np.zeros(len(active), np.uint8)
        blk[inb] = grid[ix[inb], iz[inb], iy[inb]]
        h = blk != AIR
        if h.any():
            idx = active[h]
            b = blk[h]
            c = pal[b].copy()
            # затенение: верх светлее, если сверху воздух
            ab = np.zeros(len(idx), bool)
            ok = inb[h]
            iyy = iy[h]; ixx = ix[h]; izz = iz[h]
            up_air = np.ones(len(idx), bool)
            m = ok & (iyy + 1 < H)
            up_air[m] = grid[ixx[m], izz[m], iyy[m] + 1] == AIR
            light = np.where(up_air, 1.0, 0.62)
            # низ островов темнее
            nz = (d[idx, 1] > 0.2)
            light = np.where(nz & ~up_air, 0.5, light)
            tex = 0.88 + 0.24 * ((ixx * 7 + iyy * 13 + izz * 17) % 5) / 5.0
            c = c * (light * tex)[:, None]
            if True:
                em = (b == LANTERN) | (b == WATER) | (b == WINDOW) | (b == CRYSTAL)
                c[em] = pal[b[em]]
            fogk = np.clip(t[idx] / 260.0, 0, 1)[:, None] ** 1.5
            c = c * (1 - fogk) + np.array([230, 170, 215.0]) * fogk
            col[idx] = c
            hit[idx] = True
            keep = np.ones(len(active), bool); keep[h] = False
            active = active[keep]
        if len(active) == 0:
            break
        # лучи вышли за пределы далеко: прекращаем
        far = t[active] > tmax
        if far.any():
            active = active[~far]
        if len(active) == 0:
            break
    # море облаков внизу
    img = col.reshape(Hh, W, 3)
    if RING:
        img = overlay_ring(img, cam, fw, rt, up2, f, W, Hh)
    Image.fromarray(np.clip(img, 0, 255).astype(np.uint8)).save(f"/home/claude/{name}.png")

RING = False

def overlay_ring(img, cam, fw, rt, up2, f, W, Hh):
    """Кольцо и луч как в SkyRing.java (DIST 320, азимут 32, возвышение 36, радиус 70, лента 8) + фонарики."""
    az, el, D = math.radians(32), math.radians(31), 320.0
    C = cam + D * np.array([math.cos(el) * math.cos(az), math.sin(el), math.cos(el) * math.sin(az)])
    n = np.array([0.16, 1.0, 0.10]); n /= np.linalg.norm(n)
    a = np.array([1.0, 0, 0]); u = a - n * (a @ n); u /= np.linalg.norm(u); v = np.cross(n, u)
    layer = np.zeros((Hh, W, 3)); alpha = np.zeros((Hh, W))
    def proj(p):
        d = p - cam; z = d @ fw
        if z <= 1: return None
        return W / 2 + f * (d @ rt) / z, Hh / 2 - f * (d @ up2) / z
    rng = np.random.default_rng(3)
    for R, half, k in ((78, 9, 0.7), (106, 2.4, 0.6)):
        for _ in range(26000):
            th = rng.random() * 6.2832; rr = R + (rng.random() * 2 - 1) * half
            line = 0.4 + 0.6 * abs(math.sin((rr - R) * 1.9))
            p = C + rr * (math.cos(th) * u + math.sin(th) * v)
            q = proj(p)
            if q and 0 <= q[0] < W and 0 <= q[1] < Hh:
                x, y = int(q[0]), int(q[1]); alpha[y, x] = max(alpha[y, x], k * line); layer[y, x] = (232, 216, 255)
    for yy in np.linspace(C[1] - 330, C[1] + 160, 600):
        q = proj(np.array([C[0], yy, C[2]]))
        if q and 0 <= q[0] < W - 3 and 0 <= q[1] < Hh:
            x, y = int(q[0]), int(q[1]); alpha[y, x - 1:x + 2] = np.maximum(alpha[y, x - 1:x + 2], 0.45); layer[y, x - 1:x + 2] = (240, 228, 255)
    for i in range(40):
        p = cam + np.array([(rng.random() * 2 - 1) * 90, rng.random() * 80 - 30, 20 + rng.random() * 90])
        q = proj(p)
        if q and 1 <= q[0] < W - 2 and 1 <= q[1] < Hh - 2:
            x, y = int(q[0]), int(q[1]); alpha[y - 1:y + 2, x - 1:x + 1] = 0.95; layer[y - 1:y + 2, x - 1:x + 1] = (255, 190, 90)
    from scipy.ndimage import gaussian_filter
    glow = gaussian_filter(alpha, 2.0) * 1.6
    out = img * (1 - np.clip(alpha, 0, 1)[..., None]) + layer * np.clip(alpha, 0, 1)[..., None]
    out = out + np.array([60, 40, 90.0]) * np.clip(glow, 0, 1)[..., None] * 0.5
    return out

def topmap():
    img = np.zeros((N, N, 3))
    for x in range(N):
        for z in range(N):
            col = grid[x, z]
            nz = np.nonzero(col)[0]
            if len(nz):
                b = col[nz[-1]]
                img[z, x] = np.array(COLORS.get(b, (200, 200, 200))) * (0.5 + 0.5 * nz[-1] / H)
            else:
                img[z, x] = (70, 50, 110)
    Image.fromarray(np.clip(img, 0, 255).astype(np.uint8)).resize((768, 768), Image.NEAREST).save("/home/claude/islands_map.png")

if __name__ == "__main__":
    topmap()
    bi = ISL[_big]
    print("castle at", bi['x'], bi['z'], bi['y'])
    render((bi['x'] - 55, bi['y'] + 70, bi['z'] - 105), (bi['x'], bi['y'] + 38, bi['z']), name="islands_view1", fov=58, sun_dir=(0.8, 0.1, -0.5))
    render((bi['x'] + 90, bi['y'] + 40, bi['z'] - 40), (bi['x'], bi['y'] + 35, bi['z']), name="islands_view3", fov=60, sun_dir=(-0.3, 0.1, -0.9))
    render((200, 110, 40), (80, 80, 160), name="islands_view2", sun_dir=(-0.7, 0.1, 0.5))
    RING = True
    hc = (128, 128)
    render((52, 88, 40), (52 + 60, 100, 40 + 38), name="islands_view4", fov=66, sun_dir=(0.95, 0.12, 0.2))
    print(len(ISL), "islands")
