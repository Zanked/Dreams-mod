#!/usr/bin/env python3
"""Текстура небесного кита: assets/dreams/textures/entity/sky_whale.png (256x256).

Почти белая, серая по тону: цвет кита (бело-голубой, лавандовый, золотой) приходит из вершин модели и умножается на неё.
Раскладка (см. WhaleGeometry): тело U = обход вокруг (0 = брюхо, 0.25 = правый бок, 0.5 = спина, 0.75 = левый бок),
V = от носа (0) до хвоста (0.745). Нижняя полоса V 0.75..1: грудной плавник (U 0.02..0.48) и хвостовая лопасть (U 0.52..0.98).
Нужны numpy и Pillow.  Запуск: python3 gen_whale.py
"""
import os
import numpy as np
from PIL import Image

N = 256
rng = np.random.default_rng(7)
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                   "src/main/resources/assets/dreams/textures/entity/sky_whale.png")

img = np.zeros((N, N), dtype=np.float32)
yy, xx = np.mgrid[0:N, 0:N].astype(np.float32)
U = (xx + 0.5) / N
V = (yy + 0.5) / N

# ---------------------------------------------------------------- тело
body = V < 0.75
s = np.clip(V / 0.745, 0, 1)                       # 0 нос, 1 хвост
cosu = np.cos(2 * np.pi * U)                       # +1 брюхо, -1 спина
L = 0.60 + 0.40 * (0.5 + 0.5 * cosu)               # спина темнее, брюхо светлее
L = L * (0.92 + 0.08 * np.sin(s * np.pi))          # голова и середина чуть ярче хвоста

# горловые борозды: параллельные линии вдоль брюха на голове
belly_d = np.minimum(U, 1 - U)                     # расстояние от центра брюха по U
groove = (np.abs(np.sin(belly_d * 2 * np.pi * 14)) < 0.13) & (belly_d < 0.17) & (s < 0.50)
L = np.where(groove, L * 0.72, L)

# световые струйки по бокам (текут к хвосту)
flank = np.exp(-((np.minimum(np.abs(U - 0.25), np.abs(U - 0.75))) / 0.11) ** 2)
streak = 0.5 + 0.5 * np.sin(2 * np.pi * (U * 9 + 0.45 * np.sin(s * 11) + s * 2.0))
L = L + 0.20 * flank * np.clip(streak - 0.55, 0, 1) * 2.2

# звёздная россыпь по спине и бокам
stars = np.zeros((N, N), dtype=np.float32)
dens = np.clip(0.4 + 0.6 * (0.5 - 0.5 * cosu), 0, 1)
for _ in range(900):
    x = rng.integers(0, N); y = rng.integers(0, int(0.745 * N))
    if rng.random() < dens[y, x]:
        r = rng.choice([0, 0, 1])
        stars[max(0, y - r):y + r + 1, max(0, x - r):x + r + 1] = rng.uniform(0.7, 1.0)
L = np.maximum(L, 0.9 * stars + 0.1 * L)

# рот: тонкая тёмная линия вдоль головы по обе стороны, загибается вверх к глазу
for side in (0.30, 0.70):
    for yi in range(0, int(0.30 * N)):
        sv = yi / (0.745 * N)
        u_line = side + (-0.025 if side < 0.5 else 0.025) * np.sin(sv * 4.0) - (0.06 if side < 0.5 else -0.06) * max(0, sv - 0.17) * 3
        xi = int(u_line * N) % N
        for dx in (-1, 0, 1):
            L[yi, (xi + dx) % N] = min(L[yi, (xi + dx) % N], 0.40 if dx == 0 else 0.62)

# глаза: тёмные овалы с бликом
for ucen in (0.25, 0.75):
    cxp, cyp = ucen * N, 0.125 * 0.745 * N
    d2 = ((xx - cxp) / 5.0) ** 2 + ((yy - cyp) / 4.0) ** 2
    L = np.where(d2 < 1.0, 0.10, L)
    d3 = ((xx - (cxp + 1.4)) / 1.5) ** 2 + ((yy - (cyp - 1.2)) / 1.2) ** 2
    L = np.where(d3 < 1.0, 1.0, L)
    L = np.where((d2 >= 1.0) & (d2 < 1.9), np.minimum(L, 0.55), L)   # мягкий тёмный ободок

# дыхало
d = ((xx - 0.5 * N) / 4.0) ** 2 + ((yy - 0.20 * 0.745 * N) / 2.2) ** 2
L = np.where(d < 1.0, 0.30, L)

img = np.where(body, L, img)

# ---------------------------------------------------------------- плавники и лопасти
fin = ~body
ev = np.clip((V - 0.76) / 0.22, 0, 1)              # 0 передняя кромка, 1 задняя
edge = np.exp(-(np.minimum(ev, 1 - ev) / 0.07) ** 2)
span = np.where(U < 0.5, (U - 0.02) / 0.46, (U - 0.52) / 0.46)   # 0 у корня, 1 у кончика
span = np.clip(span, 0, 1)
veins = 0.5 + 0.5 * np.sin(2 * np.pi * (ev * 7 + 0.9 * span + 0.3 * np.sin(span * 9)))
F = 0.62 + 0.20 * span + 0.16 * np.clip(veins - 0.55, 0, 1) * 2.0 + 0.30 * edge
F = np.clip(F, 0, 1)
img = np.where(fin, F, img)
# ровная заливка щели между телом и полосой, чтобы не тянуло цвет при фильтрации
img[190:196, :] = np.where(img[190:196, :] > 0, img[190:196, :], 0.7)

img = np.clip(img, 0, 1)
rgb = np.stack([img * 0.97, img * 0.99, img], axis=-1)   # чуть холодный белый; основной цвет даст тон кита
out = np.zeros((N, N, 4), dtype=np.uint8)
out[..., :3] = (rgb * 255).astype(np.uint8)
out[..., 3] = 255
os.makedirs(os.path.dirname(OUT), exist_ok=True)
Image.fromarray(out, "RGBA").save(OUT)
print("saved", OUT)
