"""Этап 14: внешний вид города Иной стороны. Нужны Pillow, numpy, scipy.
Запуск: python3 gen_city.py src/main/resources/assets/dreams [--preview папка]

Делает:
  textures/block/city_*.png   кирпич, брусчатка, бордюр, балка, двери, окна, земля, асфальт (32x32, бесшовные)
  textures/block/prop_*.png   металл фонаря, линза, сетка забора, светофор, гидрант, бочка, мусорный бак, барьер
  textures/block/car_{a,b,c,d}.png  атласы машин 256x256 (борта, капот, крыша, лобовое, колесо)
  models/block/*.json, blockstates/*.json для всех новых блоков (кубы, фонарь, светофор, забор, машины, мелочь)
Все модели собраны из боксов (без поворотов элементов), поэтому одинаково выглядят во всех версиях.
"""
import os, sys, json, math
import numpy as np
from PIL import Image
from scipy.ndimage import zoom

S = 32
args = [a for a in sys.argv[1:] if not a.startswith("--")]
ROOT = args[0] if args else "src/main/resources/assets/dreams"
PREVIEW = sys.argv[sys.argv.index("--preview") + 1] if "--preview" in sys.argv else None
TEX = os.path.join(ROOT, "textures", "block")
MOD = os.path.join(ROOT, "models", "block")
BST = os.path.join(ROOT, "blockstates")
for d in (TEX, MOD, BST):
    os.makedirs(d, exist_ok=True)

# ------------------------------------------------------------ инструменты
def tnoise(gy, gx, seed, size=S):
    r = np.random.default_rng(seed)
    g = r.random((gy, gx))
    z = zoom(g, (size / gy, size / gx), order=3, mode="grid-wrap", grid_mode=True)[:size, :size]
    return (z - z.min()) / max(1e-6, z.max() - z.min())

def fbm(seed, size=S, octs=((3, 3, 1.0), (6, 6, 0.6), (12, 12, 0.35), (24, 24, 0.2))):
    acc = np.zeros((size, size)); tot = 0
    for i, (gy, gx, w) in enumerate(octs):
        acc += tnoise(gy, gx, seed * 31 + i, size) * w; tot += w
    a = acc / tot
    return (a - a.min()) / max(1e-6, a.max() - a.min())

def save_rgb(name, arr):
    Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8), "RGB").save(os.path.join(TEX, name + ".png"))

def save_rgba(name, arr):
    Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8), "RGBA").save(os.path.join(TEX, name + ".png"))

def vor(n, seed, size=S):
    """Бесшовная диаграмма Вороного: расстояние до ближайшей и второй точки, индекс ближайшей."""
    r = np.random.default_rng(seed)
    pts = r.random((n, 2)) * size
    yy, xx = np.mgrid[0:size, 0:size].astype(float)
    d1 = np.full((size, size), 1e9); d2 = np.full((size, size), 1e9); idx = np.zeros((size, size), int)
    for k, (py, px) in enumerate(pts):
        best = np.full((size, size), 1e9)
        for oy in (-size, 0, size):
            for ox in (-size, 0, size):
                d = np.hypot(yy - (py + oy), xx - (px + ox))
                best = np.minimum(best, d)
        upd1 = best < d1
        d2 = np.where(upd1, d1, np.minimum(d2, best))
        idx = np.where(upd1, k, idx)
        d1 = np.where(upd1, best, d1)
    return d1, d2, idx

def shade(img, f):
    return img * f[..., None]

OUT_TEX = {}

# ------------------------------------------------------------ кубы
def make_brick(name, seed, base, soot=0.0, blood=0.0, tone=1.0):
    r = np.random.default_rng(seed)
    img = np.zeros((S, S, 3))
    mortar = np.array([44, 30, 31.0])
    pal = np.array(base, float)
    blot = fbm(seed + 5)
    for row in range(8):
        off = 0 if row % 2 == 0 else 4
        for k in range(4):
            x0 = (k * 8 + off) % S
            col = pal[r.integers(len(pal))] * (0.82 + 0.34 * r.random()) * tone
            chip = r.random() < 0.12
            for dy in range(3):
                for dx in range(7):
                    x = (x0 + dx) % S; y = row * 4 + dy
                    f = 1.0
                    if dy == 0: f *= 1.14
                    if dy == 2: f *= 0.80
                    if dx == 6: f *= 0.86
                    if dx == 0: f *= 1.05
                    if chip and dx > 3 and dy == 2: f *= 0.5
                    img[y, x] = col * f
            for dy in range(4):                      # раствор: правый стык
                img[row * 4 + dy, (x0 + 7) % S] = mortar * (0.8 + 0.4 * r.random())
        for x in range(S):                           # раствор: низ ряда
            img[row * 4 + 3, x] = mortar * (0.8 + 0.4 * r.random())
    img *= (0.86 + 0.28 * r.random((S, S, 1)))
    img *= (0.62 + 0.76 * blot)[..., None]
    if soot > 0:                                     # копоть: тёмные потёки сверху вниз
        for _ in range(7):
            x = r.integers(0, S); w = r.integers(1, 3); h = r.integers(8, 28); y0 = r.integers(0, S)
            for t in range(h):
                a = soot * (1 - t / h)
                for dx in range(w):
                    img[(y0 + t) % S, (x + dx) % S] *= (1 - 0.55 * a)
    if blood > 0:
        for _ in range(int(3 + 4 * blood)):
            x = r.integers(0, S); h = r.integers(6, 22); y0 = r.integers(0, S - 4)
            for t in range(h):
                a = 1 - t / h
                px = (x + (1 if t % 7 == 6 else 0)) % S
                c = np.array([92, 10, 12.0]) * (0.7 + 0.5 * r.random())
                img[(y0 + t) % S, px] = img[(y0 + t) % S, px] * (1 - 0.8 * a) + c * (0.8 * a)
            for dx in range(-2, 3):                  # лужица у начала потёка
                px = (x + dx) % S
                img[y0 % S, px] = img[y0 % S, px] * 0.35 + np.array([100, 12, 14.0]) * 0.65
    save_rgb(name, img)
    OUT_TEX[name] = img

def make_cobble(name, seed, blood=False):
    r = np.random.default_rng(seed)
    d1, d2, idx = vor(22, seed)
    edge = d2 - d1
    pal = np.array([[84, 52, 48], [72, 46, 44], [96, 60, 52], [66, 44, 46], [88, 58, 56.0]])
    col = pal[idx % len(pal)] * (0.8 + 0.4 * r.random(22))[idx % 22][..., None]
    rad = 3.4
    f = 1.12 - 0.5 * np.clip(d1 / (rad * 1.6), 0, 1)
    img = col * f[..., None]
    gap = edge < 1.3
    img = np.where(gap[..., None], np.array([22, 14, 16.0]) * (0.8 + 0.4 * r.random((S, S, 1))), img)
    img *= (0.84 + 0.32 * r.random((S, S, 1)))
    n = fbm(seed + 9)
    img *= (0.6 + 0.8 * n)[..., None]
    if blood:
        m = fbm(seed + 13) > 0.62
        img = np.where(m[..., None], img * 0.45 + np.array([88, 8, 10.0]) * 0.55, img)
    save_rgb(name, img)

def make_asphalt(name, seed):
    r = np.random.default_rng(seed)
    n = fbm(seed)
    img = np.zeros((S, S, 3)) + np.array([46, 38, 40.0])
    img *= (0.7 + 0.6 * n)[..., None]
    sp = r.random((S, S))
    img = np.where((sp > 0.93)[..., None], img * 1.7, img)
    img = np.where((sp < 0.05)[..., None], img * 0.55, img)
    # трещины: блуждание
    for _ in range(3):
        x, y = r.integers(0, S), r.integers(0, S)
        for _ in range(r.integers(14, 30)):
            img[y % S, x % S] = np.array([14, 10, 12.0])
            x += r.integers(-1, 2); y += r.choice([-1, 1]) if r.random() < 0.7 else 0
            if r.random() < 0.5: x += r.choice([-1, 1])
    img *= (0.9 + 0.2 * r.random((S, S, 1)))
    save_rgb(name, img)

def make_curb(name, seed):
    r = np.random.default_rng(seed)
    n = fbm(seed)
    img = np.zeros((S, S, 3)) + np.array([92, 80, 78.0])
    img *= (0.68 + 0.64 * n)[..., None]
    img *= (0.9 + 0.2 * r.random((S, S, 1)))
    # плиты 16x16 со швами
    for k in (0, 16):
        img[k, :] *= 0.45; img[:, k] *= 0.45
        img[(k + 1) % S, :] *= 1.12; img[:, (k + 1) % S] *= 1.12
    # пятна ржавчины и потёки
    for _ in range(4):
        x = r.integers(0, S); h = r.integers(5, 14); y0 = r.integers(0, S)
        for t in range(h):
            img[(y0 + t) % S, x % S] = img[(y0 + t) % S, x % S] * 0.6 + np.array([90, 40, 24.0]) * 0.4 * (1 - t / h)
    save_rgb(name, img)

def make_dirt(name, seed):
    r = np.random.default_rng(seed)
    n = fbm(seed)
    img = np.zeros((S, S, 3)) + np.array([58, 38, 34.0])
    img *= (0.6 + 0.8 * n)[..., None]
    img *= (0.84 + 0.32 * r.random((S, S, 1)))
    for _ in range(26):                              # камешки
        x, y = r.integers(0, S), r.integers(0, S)
        c = np.array([88, 66, 62.0]) * (0.7 + 0.5 * r.random())
        img[y, x] = c; img[y, (x + 1) % S] = c * 0.8
    for _ in range(14):                              # сухая трава
        x, y = r.integers(0, S), r.integers(0, S)
        c = np.array([86, 66, 36.0]) * (0.6 + 0.5 * r.random())
        for t in range(r.integers(2, 5)):
            img[(y - t) % S, (x + (t // 2)) % S] = c
    save_rgb(name, img)

def make_beam(name, seed):
    r = np.random.default_rng(seed)
    n = fbm(seed)
    img = np.zeros((S, S, 3)) + np.array([54, 46, 48.0])
    img *= (0.7 + 0.6 * n)[..., None]
    img[0:3, :] *= 1.35; img[3:4, :] *= 0.55          # верхняя полка
    img[29:32, :] *= 1.2; img[28:29, :] *= 0.55       # нижняя полка
    img[14:18, :] *= 0.82                             # стенка
    rust = fbm(seed + 3) > 0.68
    img = np.where(rust[..., None], img * 0.4 + np.array([126, 58, 26.0]) * 0.6 * (0.7 + 0.5 * n[..., None]), img)
    for y in (1, 30):                                 # заклёпки
        for x in (3, 11, 19, 27):
            img[y, x] = np.array([128, 112, 108.0]); img[y, x + 1] = np.array([30, 24, 26.0])
    for _ in range(4):                                # потёки
        x = r.integers(0, S); h = r.integers(6, 16); y0 = r.integers(3, 16)
        for t in range(h):
            img[(y0 + t) % S, x] = img[(y0 + t) % S, x] * 0.55 + np.array([110, 44, 20.0]) * 0.45 * (1 - t / h)
    img *= (0.9 + 0.2 * r.random((S, S, 1)))
    save_rgb(name, img)

def make_door(name, seed, right):
    """Половинка двустворчатой двери. right=True: ручка у левого края (стык створок)."""
    r = np.random.default_rng(seed)
    n = fbm(seed)
    img = np.zeros((S, S, 3)) + np.array([62, 50, 50.0])
    img *= (0.72 + 0.56 * n)[..., None]
    # рамка 3 px сверху/снизу, 2 px по краям; панели внутри
    img[0:3, :] *= 0.55; img[29:32, :] *= 0.55
    outer = slice(0, 3) if right is False else slice(29, 32)
    img[:, outer] *= 0.55
    for (y0, y1) in ((5, 14), (17, 27)):              # две панели
        img[y0:y1, 5:27] *= 1.18
        img[y0, 5:27] *= 1.25; img[y1 - 1, 5:27] *= 0.6
        img[y0:y1, 5] *= 1.2; img[y0:y1, 26] *= 0.6
    hx = 4 if right else 27                            # ручка у стыка
    img[14:19, hx:hx + 2] = np.array([146, 128, 112.0])
    img[14:19, hx + (1 if right else -1)] = np.array([30, 24, 24.0])
    rust = fbm(seed + 3) > 0.66
    img = np.where(rust[..., None], img * 0.45 + np.array([120, 54, 24.0]) * 0.55, img)
    for _ in range(3):
        x = r.integers(3, 29); h = r.integers(5, 12); y0 = r.integers(3, 18)
        for t in range(h):
            img[(y0 + t) % S, x] = img[(y0 + t) % S, x] * 0.5 + np.array([96, 12, 14.0]) * 0.5 * (1 - t / h)
    img *= (0.9 + 0.2 * r.random((S, S, 1)))
    save_rgb(name, img)

def glass_pane(img, x0, y0, x1, y1, seed, curtain=False):
    r = np.random.default_rng(seed)
    h, w = y1 - y0, x1 - x0
    for yy in range(h):
        for xx in range(w):
            t = yy / max(1, h - 1)
            c = np.array([20, 24, 32.0]) * (1.0 + 0.5 * (1 - t))
            if (xx + yy * 1) % 9 == 0 or (xx + yy) % 9 == 1:
                c = c * 2.0                           # блик
            if curtain:
                c = np.array([74, 14, 18.0]) * (0.7 + 0.5 * abs(math.sin(xx * 0.9)))
            img[y0 + yy, x0 + xx] = [*c, 255]

def make_windows():
    fr = np.array([54, 38, 36.0])
    def base(seed):
        a = np.zeros((S, S, 4))
        n = fbm(seed)
        for y in range(S):
            for x in range(S):
                a[y, x, :3] = fr * (0.7 + 0.7 * n[y, x]); a[y, x, 3] = 255
        return a
    # a: целое, 4 стекла
    a = base(1)
    panes = [(3, 3, 15, 15), (17, 3, 29, 15), (3, 17, 15, 29), (17, 17, 29, 29)]
    for i, p in enumerate(panes):
        glass_pane(a, *p, seed=10 + i)
    # трещина
    for k in range(10):
        a[5 + k, 20 + (k // 2) % 4, :3] = [120, 110, 110]
    a[2, :, :3] *= 1.3; a[29:31, :, :3] *= 0.7
    save_rgba("city_window_a", a)
    # b: разбитое
    b = base(2)
    for i, p in enumerate(panes):
        if i in (0, 3):
            glass_pane(b, *p, seed=20 + i)
            # остатки стекла по углам, дыра с зубцами
            x0, y0, x1, y1 = p
            for yy in range(y0 + 2, y1):
                for xx in range(x0 + 2, x1):
                    if (xx - x0) + (yy - y0) > 6 + ((xx * 3 + yy * 5) % 4) and (x1 - xx) + (y1 - yy) > 6 + ((xx + yy * 3) % 4):
                        b[yy, xx] = [0, 0, 0, 0]
        else:
            for yy in range(p[1], p[3]):
                for xx in range(p[0], p[2]):
                    b[yy, xx] = [0, 0, 0, 0]
            for k in range(5):                         # осколки по краю
                b[p[1] + k, p[0] + (k % 2)] = [30, 34, 44, 255]
                b[p[3] - 1 - k, p[2] - 1 - (k % 3)] = [30, 34, 44, 255]
    save_rgba("city_window_b", b)
    # c: занавеска (красная) и мутное стекло
    c = base(3)
    for i, p in enumerate(panes):
        glass_pane(c, *p, seed=30 + i, curtain=(i in (0, 1)))
    save_rgba("city_window_c", c)
    # перекрестие рамы поверх всех
    for t in (a, b, c):
        pass
    for name, arr in (("city_window_a", a), ("city_window_b", b), ("city_window_c", c)):
        arr[15:17, :, :3] = fr * 1.1; arr[15:17, :, 3] = 255
        arr[:, 15:17, :3] = fr * 1.1; arr[:, 15:17, 3] = 255
        arr[0:3, :, :3] = fr * 1.3; arr[0:3, :, 3] = 255
        arr[29:32, :, :3] = fr * 0.8; arr[29:32, :, 3] = 255
        arr[:, 0:2, :3] = fr; arr[:, 0:2, 3] = 255
        arr[:, 30:32, :3] = fr; arr[:, 30:32, 3] = 255
        save_rgba(name, arr)

def build_cubes():
    brick_pal = [[118, 50, 40], [104, 44, 36], [130, 60, 46], [92, 38, 34], [110, 56, 44]]
    make_brick("city_brick", 101, brick_pal, soot=0.35)
    make_brick("city_brick_dark", 102, [[78, 34, 32], [68, 30, 30], [88, 40, 36], [60, 28, 30]], soot=0.7, tone=0.9)
    make_brick("city_brick_blood", 103, brick_pal, soot=0.4, blood=1.0)
    make_cobble("city_cobble", 111)
    make_cobble("city_cobble_blood", 112, blood=True)
    make_asphalt("city_asphalt", 113)
    make_curb("city_curb", 114)
    make_dirt("city_dirt", 115)
    make_beam("city_beam", 116)
    make_door("city_door_l", 117, right=False)
    make_door("city_door_r", 118, right=True)
    make_windows()


# ------------------------------------------------------------ JSON-помощники
def wjson(path, obj):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)

FACES = ("down", "up", "north", "south", "west", "east")

def elem(frm, to, tex="#t", only=None, tex_by=None, uv_by=None):
    """Бокс. only: какие грани рисовать; tex_by/uv_by: свои текстура/UV для граней."""
    faces = {}
    for f in FACES:
        if only is not None and f not in only:
            continue
        d = {"texture": (tex_by or {}).get(f, tex)}
        if uv_by and f in uv_by:
            d["uv"] = [round(float(v), 4) for v in uv_by[f]]
        faces[f] = d
    return {"from": [float(v) for v in frm], "to": [float(v) for v in to], "faces": faces}

def write_model(name, textures, elements, render_type=None):
    m = {"textures": textures, "elements": elements}
    if render_type:
        m["render_type"] = render_type
    wjson(os.path.join(MOD, name + ".json"), m)

def write_cube(name, tex, cutout=False):
    m = {"parent": "minecraft:block/cube_all", "textures": {"all": "dreams:block/" + tex}}
    if cutout:
        m["render_type"] = "minecraft:cutout"
    wjson(os.path.join(MOD, name + ".json"), m)
    wjson(os.path.join(BST, name + ".json"), {"variants": {"": {"model": "dreams:block/" + name}}})

def write_facing_state(name, model_fmt=None, model=None):
    """facing=north/east/south/west -> y 0/90/180/270."""
    v = {}
    for i, d in enumerate(("north", "east", "south", "west")):
        e = {"model": "dreams:block/" + (model or name)}
        if i:
            e["y"] = 90 * i
        v["facing=" + d] = e
    wjson(os.path.join(BST, name + ".json"), {"variants": v})

def write_plain_state(name, model=None):
    wjson(os.path.join(BST, name + ".json"), {"variants": {"": {"model": "dreams:block/" + (model or name)}}})

# ------------------------------------------------------------ текстуры мелочи
def metal_tex(name, seed, base=(40, 34, 36), rust=0.62, stripes=False):
    r = np.random.default_rng(seed)
    n = fbm(seed)
    img = np.zeros((S, S, 3)) + np.array(base, float)
    img *= (0.7 + 0.6 * n)[..., None]
    ru = fbm(seed + 3) > rust
    img = np.where(ru[..., None], img * 0.4 + np.array([116, 52, 24.0]) * 0.6, img)
    img *= (0.9 + 0.2 * r.random((S, S, 1)))
    for k in range(S):                               # лёгкий вертикальный блик по столбу
        if k % 16 in (6, 7):
            img[:, k] *= 1.18
    save_rgb(name, img)

def make_lens(name, seed, lit=True):
    r = np.random.default_rng(seed)
    img = np.zeros((S, S, 3))
    yy, xx = np.mgrid[0:S, 0:S].astype(float)
    d = np.hypot(yy - 15.5, xx - 15.5) / 22.0
    if lit:
        c0 = np.array([255, 214, 150.0]); c1 = np.array([214, 96, 44.0])
        t = np.clip(d, 0, 1)[..., None]
        img = c0 * (1 - t) + c1 * t
        for k in range(0, S, 8):                     # рифление линзы
            img[:, k:k + 1] *= 0.86
            img[k:k + 1, :] *= 0.86
        img *= (0.94 + 0.12 * r.random((S, S, 1)))
    else:
        img[:] = np.array([26, 24, 28.0]) * (0.7 + 0.6 * fbm(seed)[..., None])
        for k in range(12):                          # трещина
            img[6 + k, 10 + k // 2] = [90, 84, 84]
        img[10:20, 18:26] = [8, 6, 8]
    save_rgb(name, img)

def make_mesh(name):
    a = np.zeros((S, S, 4))
    wire = np.array([104, 88, 88, 255.0])
    for y in range(S):
        for x in range(S):
            if (x + y) % 8 in (0, 1) or (x - y) % 8 in (0, 1):
                a[y, x] = wire * (0.8 + 0.4 * ((x * 7 + y * 3) % 5) / 5.0)
    a[0:2, :] = [70, 60, 62, 255]; a[30:32, :] = [70, 60, 62, 255]      # шины сверху/снизу
    save_rgba(name, a)

def make_signal(name):
    img = np.zeros((S, S, 3)) + np.array([20, 18, 20.0])
    r = np.random.default_rng(5)
    img *= (0.8 + 0.4 * r.random((S, S, 1)))
    yy, xx = np.mgrid[0:S, 0:S].astype(float)
    for cy, col in ((6, (240, 36, 30)), (16, (70, 44, 10)), (26, (10, 56, 24))):
        d = np.hypot(yy - cy, xx - 15.5)
        ring = d < 5.2
        img[ring] = np.array([8, 8, 8.0])
        lens = d < 4.2
        c = np.array(col, float) * (1.0 - 0.35 * np.clip(d / 4.2, 0, 1))[..., None]
        img = np.where(lens[..., None], c, img)
        vis = (np.abs(xx - 15.5) < 6.5) & (yy < cy - 3.5) & (yy > cy - 5.5)
        img[vis] = np.array([40, 36, 38.0])
    save_rgb(name, img)

def make_paint(name, seed, base, stripe=None, rust=0.6, soot=0.0):
    r = np.random.default_rng(seed)
    n = fbm(seed)
    img = np.zeros((S, S, 3)) + np.array(base, float)
    img *= (0.66 + 0.7 * n)[..., None]
    if stripe is not None:
        for y in range(S):
            for x in range(S):
                if ((x + y) // 6) % 2 == 0:
                    img[y, x] = np.array(stripe, float) * (0.7 + 0.5 * n[y, x])
    ru = fbm(seed + 3) > rust
    img = np.where(ru[..., None], img * 0.45 + np.array([112, 50, 22.0]) * 0.55, img)
    img *= (0.88 + 0.24 * r.random((S, S, 1)))
    for _ in range(3):
        x = r.integers(0, S); h = r.integers(6, 16); y0 = r.integers(0, S)
        for t in range(h):
            img[(y0 + t) % S, x] = img[(y0 + t) % S, x] * 0.5 + np.array([92, 10, 12.0]) * 0.5 * (1 - t / h)
    img *= (1 - soot)
    save_rgb(name, img)

def build_prop_textures():
    metal_tex("prop_metal", 201)
    metal_tex("prop_metal_dark", 202, base=(26, 22, 24), rust=0.74)
    make_lens("prop_lens", 203, True)
    make_lens("prop_lens_dead", 204, False)
    make_mesh("prop_mesh")
    make_signal("prop_signal")
    make_paint("prop_hydrant", 205, (128, 34, 28), rust=0.64)
    make_paint("prop_barrel", 206, (72, 66, 48), rust=0.5)
    make_paint("prop_bin", 207, (34, 50, 42), rust=0.62)
    make_paint("prop_barrier", 208, (150, 140, 128), stripe=(136, 28, 24), rust=0.8)

# ------------------------------------------------------------ модели мелочи
TM = {"t": "dreams:block/prop_metal", "particle": "dreams:block/prop_metal"}
TD = {"t": "dreams:block/prop_metal_dark", "m": "dreams:block/prop_metal", "particle": "dreams:block/prop_metal_dark"}

def pole(y0=0, y1=16):
    return elem((6.5, y0, 6.5), (9.5, y1, 9.5), "#t")

def build_lamps():
    t = {"t": "dreams:block/prop_metal_dark", "l": "dreams:block/prop_lens", "particle": "dreams:block/prop_metal_dark"}
    td = dict(t); td["l"] = "dreams:block/prop_lens_dead"
    # основание с фланцем
    write_model("city_lamp_base", t, [
        elem((4, 0, 4), (12, 2, 12), "#t"),
        elem((5, 2, 5), (11, 4.5, 11), "#t"),
        pole(0, 16),
    ])
    write_model("city_lamp_pole", t, [
        pole(0, 16),
        elem((6, 5, 6), (10, 6.5, 10), "#t"),            # хомут
    ])
    # верх: столб + рука к улице (север)
    top = [
        pole(0, 14),
        elem((6, 14, 6), (10, 15.5, 10), "#t"),
        elem((7, 12.5, 0), (9, 14.5, 6.5), "#t"),       # рука
        elem((7.25, 11, 4.5), (8.75, 12.5, 6.5), "#t"),  # подкос ступенями
        elem((7.25, 9.5, 5.5), (8.75, 11, 6.5), "#t"),
    ]
    write_model("city_lamp_top", t, top)
    def head(tt, name):
        write_model(name, tt, [
            elem((7, 12.5, 9), (9, 14.5, 16), "#t"),                   # рука из соседней клетки
            elem((7.25, 11, 8.5), (8.75, 12.5, 10), "#t"),             # подвес
            elem((3.5, 9.5, 1.5), (12.5, 12.5, 13.5), "#t"),           # корпус
            elem((3, 12.5, 1), (13, 13.5, 14), "#t"),                  # козырёк
            elem((4.5, 9.0, 2.5), (11.5, 9.6, 12.5), "#l", only=("down",), uv_by={"down": (0, 0, 16, 16)}),
            elem((4.5, 9.4, 2.5), (11.5, 9.6, 12.5), "#t", only=("up", "north", "south", "west", "east")),
        ])
    head(t, "city_lamp_head")
    head(td, "city_lamp_head_dead")
    for n in ("city_lamp_top", "city_lamp_head", "city_lamp_head_dead"):
        write_facing_state(n)
    write_plain_state("city_lamp_base"); write_plain_state("city_lamp_pole")
    # светофор: висит на конце руки, линзы смотрят вдоль руки (север/юг)
    ts = {"t": "dreams:block/prop_metal_dark", "s": "dreams:block/prop_signal", "particle": "dreams:block/prop_metal_dark"}
    write_model("city_signal_head", ts, [
        elem((7, 12.5, 8), (9, 14.5, 16), "#t"),
        elem((7.25, 11, 7.5), (8.75, 12.5, 9), "#t"),
        elem((5, 1.5, 5), (11, 11.5, 11), "#t", tex_by={"north": "#s", "south": "#s"},
             uv_by={"north": (0, 0, 16, 16), "south": (0, 0, 16, 16)}),
        elem((4.5, 11.5, 4.5), (11.5, 12.5, 11.5), "#t"),
    ])
    write_facing_state("city_signal_head")

def build_fence():
    t = {"t": "dreams:block/prop_metal_dark", "m": "dreams:block/prop_mesh", "particle": "dreams:block/prop_metal_dark"}
    ct = "minecraft:cutout"
    write_model("city_fence_post_low", t, [elem((7, 0, 7), (9, 16, 9), "#t")], ct)
    write_model("city_fence_post_up", t, [elem((7, 0, 7), (9, 14, 9), "#t"), elem((6.5, 14, 6.5), (9.5, 16, 9.5), "#t")], ct)
    side_low = [
        elem((7.5, 0, 0), (8.5, 16, 7), "#m", only=("east", "west"), uv_by={"east": (0, 0, 7, 16), "west": (0, 0, 7, 16)}),
        elem((7, 0, 0), (9, 1.5, 7), "#t"),
    ]
    side_up = [
        elem((7.5, 0, 0), (8.5, 16, 7), "#m", only=("east", "west"), uv_by={"east": (0, 0, 7, 16), "west": (0, 0, 7, 16)}),
        elem((7, 14, 0), (9, 16, 7), "#t"),
    ]
    write_model("city_fence_side_low", t, side_low, ct)
    write_model("city_fence_side_up", t, side_up, ct)
    for kind in ("low", "up"):
        parts = [{"apply": {"model": f"dreams:block/city_fence_post_{kind}"}}]
        for d, y in (("north", 0), ("east", 90), ("south", 180), ("west", 270)):
            ap = {"model": f"dreams:block/city_fence_side_{kind}"}
            if y:
                ap["y"] = y
            parts.append({"when": {d: "true"}, "apply": ap})
        wjson(os.path.join(BST, f"city_fence_{kind}.json"), {"multipart": parts})

def build_small_props():
    # гидрант
    th = {"t": "dreams:block/prop_hydrant", "particle": "dreams:block/prop_hydrant"}
    write_model("city_hydrant", th, [
        elem((4, 0, 4), (12, 2, 12), "#t"),
        elem((5, 2, 5), (11, 10, 11), "#t"),
        elem((4, 10, 4), (12, 11.5, 12), "#t"),
        elem((5.5, 11.5, 5.5), (10.5, 13.5, 10.5), "#t"),
        elem((7, 13.5, 7), (9, 14.5, 9), "#t"),
        elem((2.5, 5, 6.5), (13.5, 8, 9.5), "#t"),
        elem((6, 4, 1.5), (10, 8, 5), "#t"),
    ])
    write_plain_state("city_hydrant")
    # бочка (восьмигранная призма из двух боксов + обручи)
    tb = {"t": "dreams:block/prop_barrel", "m": "dreams:block/prop_metal_dark", "particle": "dreams:block/prop_barrel"}
    write_model("city_barrel", tb, [
        elem((4, 0, 3), (12, 14, 13), "#t"),
        elem((3, 0, 4), (13, 14, 12), "#t"),
        elem((3.2, 2, 3.7), (12.8, 3.5, 12.3), "#m"),
        elem((3.7, 2, 3.2), (12.3, 3.5, 12.8), "#m"),
        elem((3.2, 10.5, 3.7), (12.8, 12, 12.3), "#m"),
        elem((3.7, 10.5, 3.2), (12.3, 12, 12.8), "#m"),
        elem((5, 14, 5), (11, 14.5, 11), "#m"),
    ])
    write_plain_state("city_barrel")
    # мусорный бак (дверца-крышка к улице: север)
    tn = {"t": "dreams:block/prop_bin", "m": "dreams:block/prop_metal_dark", "particle": "dreams:block/prop_bin"}
    write_model("city_bin", tn, [
        elem((1, 2, 2), (15, 11, 14), "#t"),
        elem((0.5, 11, 1.5), (15.5, 12.5, 14.5), "#m"),
        elem((1, 12.5, 2.5), (15, 13.5, 8), "#m"),
        elem((2, 0, 3), (4, 2, 5), "#m"), elem((12, 0, 3), (14, 2, 5), "#m"),
        elem((2, 0, 11), (4, 2, 13), "#m"), elem((12, 0, 11), (14, 2, 13), "#m"),
    ])
    write_facing_state("city_bin")
    # дорожный барьер: две доски на ножках, вдоль оси X (север/юг), поворот по facing
    tr = {"t": "dreams:block/prop_barrier", "m": "dreams:block/prop_metal_dark", "particle": "dreams:block/prop_barrier"}
    write_model("city_barrier", tr, [
        elem((0, 9, 7), (16, 13, 9), "#t"),
        elem((0, 4, 7), (16, 7, 9), "#t"),
        elem((1, 0, 6.5), (3, 13, 9.5), "#m"),
        elem((13, 0, 6.5), (15, 13, 9.5), "#m"),
    ])
    write_facing_state("city_barrier")

def build_all_but_cars():
    build_cubes()
    build_prop_textures()
    # кубы
    for n in ("city_brick", "city_brick_dark", "city_brick_blood", "city_cobble", "city_cobble_blood",
              "city_asphalt", "city_curb", "city_dirt", "city_beam", "city_door_l", "city_door_r"):
        write_cube(n, n)
    for n in ("city_window_a", "city_window_b", "city_window_c"):
        write_cube(n, n, cutout=True)
    build_lamps()
    build_fence()
    build_small_props()

# ------------------------------------------------------------ машины
# Машина 4x2 блока (длина 64, ширина 32 единицы модели), два яруса: корпус и низкая кабина.
# Система координат машины: X 0..32 слева направо (если смотреть по ходу), Y 0..24, L 0..64 от багажника к капоту.
# Клетка (w, u, h): w 0/1 слева направо, u 0..3 от багажника к капоту, h 0/1 ярус. cell id: нижний u*2+w, верхний 8+(u-1)*2+w.
ATLAS = 256
R_RIGHT = (0, 0); R_LEFT = (0, 48); R_TOP = (128, 0); R_FRONT = (0, 96); R_REAR = (64, 96)
R_WHEEL = (0, 144); R_TIRE = (16, 144); R_UNDER = (24, 144)

CAB_STAIRS = [(16, 18, 15), (18, 20, 17), (20, 22, 19), (22, 24, 21), (24, 26, 23), (26, 36, 24),
              (36, 38, 23), (38, 40, 21), (40, 42, 19), (42, 44, 17), (44, 46, 15)]

def cab_top(L):
    for a, b, t in CAB_STAIRS:
        if a <= L < b:
            return t
    return 13

CAR_VARIANTS = {
    "a": dict(body=(124, 40, 32), glass=(20, 24, 30), rust=0.56, soot=0.0, blood=True, stripe=False, lit=False),
    "b": dict(body=(60, 68, 86), glass=(18, 22, 28), rust=0.60, soot=0.05, blood=False, stripe=False, lit=False),
    "c": dict(body=(156, 132, 52), glass=(20, 24, 28), rust=0.60, soot=0.0, blood=False, stripe=True, lit=True),
    "d": dict(body=(34, 30, 30), glass=(14, 16, 20), rust=0.46, soot=0.0, blood=False, stripe=False, lit=False),
}

def cars_paint(var, seed):
    v = CAR_VARIANTS[var]
    r = np.random.default_rng(seed)
    body = np.array(v["body"], float)
    glass = np.array(v["glass"], float)

    def surf(h, w, s, rust):
        n = fbm(s, size=max(h, w))[:h, :w]
        img = np.zeros((h, w, 3)) + body
        img *= (0.72 + 0.56 * n)[..., None]
        ru = fbm(s + 5, size=max(h, w))[:h, :w] > rust
        img = np.where(ru[..., None], img * 0.4 + np.array([112, 52, 24.0]) * 0.6, img)
        img *= (0.92 + 0.16 * r.random((h, w, 1)))
        return img

    def rect(img, x0, y0, x1, y1, c, f=1.0):
        x0, y0 = max(0, int(x0)), max(0, int(y0)); x1, y1 = min(img.shape[1], int(x1)), min(img.shape[0], int(y1))
        if x1 > x0 and y1 > y0:
            img[y0:y1, x0:x1] = np.array(c, float) * f

    def glassfill(img, x0, y0, x1, y1):
        x0, y0 = int(x0), int(y0); x1, y1 = int(x1), int(y1)
        for yy in range(max(0, y0), min(img.shape[0], y1)):
            for xx in range(max(0, x0), min(img.shape[1], x1)):
                t = (yy - y0) / max(1, y1 - y0)
                c = glass * (1.0 + 0.7 * (1 - t))
                if (xx + yy) % 11 in (0, 1):
                    c = c * 2.2
                img[yy, xx] = c

    def drips(img, count, col, maxh):
        H, W = img.shape[:2]
        for _ in range(count):
            x = r.integers(0, W); y0 = r.integers(0, H // 2); h = r.integers(4, maxh)
            for t in range(h):
                if y0 + t < H:
                    img[y0 + t, x] = img[y0 + t, x] * 0.5 + np.array(col, float) * 0.5 * (1 - t / h)

    atlas = np.zeros((ATLAS, ATLAS, 3)) + np.array([20, 18, 20.0])

    # --- борт (профиль направо: перед справа) 128x48
    side = surf(48, 128, seed + 1, v["rust"])
    Yp = lambda y: 2 * (24 - y)
    Xp = lambda L: 2 * L
    rect(side, 0, Yp(5), 128, Yp(3), body, 0.45)                    # порог
    rect(side, 0, Yp(13) - 1, 128, Yp(13), body, 1.25)              # линия пояса
    for L in (21.5, 32.0, 45.5):                                    # стыки дверей
        rect(side, Xp(L), Yp(12.5), Xp(L) + 1, Yp(4), body, 0.35)
    for L in (29.0, 42.0):                                          # ручки
        rect(side, Xp(L), Yp(10.6), Xp(L) + 4, Yp(10.0), (170, 160, 150))
    if v["stripe"]:                                                 # шашечки такси
        for k in range(0, 128, 4):
            rect(side, k, Yp(9), k + 2, Yp(7.5), (12, 12, 12) if (k // 4) % 2 == 0 else (230, 226, 210))
            rect(side, k + 2, Yp(9), k + 4, Yp(7.5), (230, 226, 210) if (k // 4) % 2 == 0 else (12, 12, 12))
    # кабина: стёкла по профилю ступеней
    for px in range(128):
        L = px / 2.0
        yt = cab_top(L)
        if yt > 13:
            rect(side, px, Yp(yt), px + 1, Yp(13), body, 0.95)       # стойки
            inpane = (19.5 <= L < 30.5) or (33.5 <= L < 43.5)
            if inpane:
                ytop = yt - 1.0
                if ytop > 14.5:
                    rect(side, px, Yp(ytop), px + 1, Yp(14.5), glass)
    for L0, L1 in ((19.5, 30.5), (33.5, 43.5)):                      # блики на стёклах
        for px in range(int(Xp(L0)), int(Xp(L1))):
            for py in range(int(Yp(23)), int(Yp(14.5))):
                if 0 <= py < 48 and (px + py) % 13 in (0, 1) and (side[py, px] < 60).all():
                    side[py, px] = side[py, px] * 2.4
    for c in (11, 53):                                              # арки колёс
        cx, cy = Xp(c), Yp(4)
        for py in range(48):
            for px in range(128):
                if math.hypot(px - cx, py - cy) < 11.5:
                    side[py, px] = np.array([12, 10, 10.0])
    if v["blood"]:
        drips(side, 5, (96, 10, 12), 18)
        rect(side, Xp(36), Yp(12), Xp(41), Yp(11), (88, 8, 10))
    right = side.copy()
    left = side[:, ::-1].copy()                                     # борт с другой стороны: зеркало, перед слева
    left = left * 0.94
    atlas[R_RIGHT[1]:R_RIGHT[1] + 48, R_RIGHT[0]:R_RIGHT[0] + 128] = right
    atlas[R_LEFT[1]:R_LEFT[1] + 48, R_LEFT[0]:R_LEFT[0] + 128] = left

    # --- крыша 64x128: X -> px 2X, L -> row 2(64-L)
    top = surf(128, 64, seed + 2, v["rust"] + 0.04)
    Tp = lambda L: 2 * (64 - L)
    rect(top, 6, Tp(62), 58, Tp(62) + 1, body, 0.5)                 # шов капота
    rect(top, 32, Tp(60), 33, Tp(48), body, 0.7)                    # выступ капота
    rect(top, 6, Tp(16), 58, Tp(16) + 1, body, 0.5)                 # шов багажника
    glassfill(top, 8, Tp(46), 56, Tp(36))                           # лобовое
    glassfill(top, 8, Tp(26), 56, Tp(16))                           # заднее
    rect(top, 8, Tp(36), 56, Tp(26), body, 1.12)                    # крыша светлее
    rect(top, 0, Tp(64), 64, Tp(62), (60, 56, 56))                  # бамперы сверху
    rect(top, 0, Tp(2), 64, Tp(0), (60, 56, 56))
    if v["blood"]:
        rect(top, 20, Tp(40), 34, Tp(37), (80, 8, 10))
    atlas[R_TOP[1]:R_TOP[1] + 128, R_TOP[0]:R_TOP[0] + 64] = top

    # --- перед 64x48: u = 2(32-X), v = 2(24-Y)
    fr = surf(48, 64, seed + 3, v["rust"])
    Ux = lambda X: 2 * (32 - X)
    glassfill(fr, Ux(29), Yp(24), Ux(3), Yp(14))                    # лобовое
    rect(fr, Ux(31), Yp(13), Ux(1), Yp(8), body, 1.0)
    rect(fr, Ux(31), Yp(8), Ux(1), Yp(2), (58, 54, 56))             # бампер
    rect(fr, Ux(31), Yp(8) , Ux(1), Yp(8) + 1, (150, 144, 140))
    rect(fr, Ux(21), Yp(10), Ux(11), Yp(6), (14, 12, 14))           # решётка
    for k in range(0, 20, 3):
        rect(fr, Ux(21) + k, Yp(10), Ux(21) + k + 1, Yp(6), (70, 64, 64))
    for xa, xb in ((3, 9), (23, 29)):                               # фары
        rect(fr, Ux(xb), Yp(11), Ux(xa), Yp(8), (232, 212, 156) if v["lit"] else (122, 112, 92))
    rect(fr, Ux(20), Yp(5.5), Ux(12), Yp(3), (150, 140, 112))       # номер
    rect(fr, Ux(31), Yp(13), Ux(1), Yp(13) - 1, body, 0.5)
    if v["blood"]:
        drips(fr, 3, (96, 10, 12), 10)
    atlas[R_FRONT[1]:R_FRONT[1] + 48, R_FRONT[0]:R_FRONT[0] + 64] = fr

    # --- зад 64x48: u = 2X
    rr = surf(48, 64, seed + 4, v["rust"])
    Ux2 = lambda X: 2 * X
    glassfill(rr, Ux2(3), Yp(24), Ux2(29), Yp(14))
    rect(rr, Ux2(1), Yp(8), Ux2(31), Yp(2), (58, 54, 56))
    for xa, xb in ((3, 8), (24, 29)):
        rect(rr, Ux2(xa), Yp(11), Ux2(xb), Yp(8), (170, 24, 22))
    rect(rr, Ux2(12), Yp(5.5), Ux2(20), Yp(3), (150, 140, 112))
    rect(rr, Ux2(1), Yp(13) - 1, Ux2(31), Yp(13), body, 0.5)
    atlas[R_REAR[1]:R_REAR[1] + 48, R_REAR[0]:R_REAR[0] + 64] = rr

    # --- колесо 16x16 (пиксельный круг) + шина + низ
    wh = np.zeros((16, 16, 3)) + np.array([14, 14, 14.0])
    for py in range(16):
        for px in range(16):
            d = math.hypot(px - 7.5, py - 7.5)
            if d < 8.0:
                wh[py, px] = np.array([20, 20, 22.0])
            if d < 5.2:
                wh[py, px] = np.array([96, 92, 90.0]) * (0.8 + 0.4 * r.random())
            if d < 2.2:
                wh[py, px] = np.array([52, 50, 50.0])
    for k in range(5):
        a = k * 2 * math.pi / 5
        wh[int(7.5 + 3.6 * math.sin(a)), int(7.5 + 3.6 * math.cos(a))] = [30, 28, 28]
    atlas[R_WHEEL[1]:R_WHEEL[1] + 16, R_WHEEL[0]:R_WHEEL[0] + 16] = wh
    atlas[R_TIRE[1]:R_TIRE[1] + 8, R_TIRE[0]:R_TIRE[0] + 8] = np.array([16, 16, 16.0]) * (0.8 + 0.4 * r.random((8, 8, 1)))
    atlas[R_UNDER[1]:R_UNDER[1] + 8, R_UNDER[0]:R_UNDER[0] + 8] = np.array([18, 16, 16.0])

    if v["soot"] > 0 or var == "d":
        pass
    out = np.clip(atlas * (1.0 - v["soot"]), 0, 255)
    save_rgb("car_" + var, out)

def car_boxes():
    """(X0,X1,Y0,Y1,L0,L1,kind, extra). kind: body | wheel (extra=(c, x0))."""
    B = []
    B.append((1, 31, 3, 13, 2, 62, "body", None))
    B.append((1, 31, 2, 8, 62, 64, "body", None))
    B.append((1, 31, 2, 8, 0, 2, "body", None))
    for a, b, top in CAB_STAIRS:
        B.append((3, 29, 13, top, a, b, "body", None))
    for c in (11, 53):
        for (xa, xb) in ((0, 4), (28, 32)):
            B.append((xa, xb, 2, 6, c - 4, c + 4, "wheel", (c, 0)))
            B.append((xa, xb, 1, 7, c - 3, c + 3, "wheel", (c, 0)))
            B.append((xa, xb, 0, 8, c - 2, c + 2, "wheel", (c, 0)))
    return B

def cell_id(u, w, h):
    return u * 2 + w if h == 0 else 8 + (u - 1) * 2 + w

ALL_CELLS = [(u, w, 0) for u in range(4) for w in range(2)] + [(u, w, 1) for u in (1, 2) for w in range(2)]

def car_cell_elements(u, w, h):
    cx0, cx1 = 16 * w, 16 * w + 16
    cy0, cy1 = 16 * h, 16 * h + 16
    cl0, cl1 = 16 * u, 16 * u + 16
    els = []
    S2 = 2.0
    for (X0, X1, Y0, Y1, L0, L1, kind, extra) in car_boxes():
        x0, x1 = max(X0, cx0), min(X1, cx1)
        y0, y1 = max(Y0, cy0), min(Y1, cy1)
        l0, l1 = max(L0, cl0), min(L1, cl1)
        if x0 >= x1 or y0 >= y1 or l0 >= l1:
            continue
        has = {
            "west": cx0 <= X0 < cx1, "east": cx0 < X1 <= cx1,
            "down": cy0 <= Y0 < cy1, "up": cy0 < Y1 <= cy1,
            "south": cl0 <= L0 < cl1, "north": cl0 < L1 <= cl1,
        }
        frm = (x0 - cx0, y0 - cy0, 16 - (l1 - cl0))
        to = (x1 - cx0, y1 - cy0, 16 - (l0 - cl0))
        faces = {}
        tex = "#car"
        def uvp(px0, py0, px1, py1):
            return [px0 / 16.0, py0 / 16.0, px1 / 16.0, py1 / 16.0]
        for f, ok in has.items():
            if not ok:
                continue
            if kind == "body":
                if f == "west":
                    rx, ry = R_LEFT
                    uv = uvp(rx + S2 * (64 - l1), ry + S2 * (24 - y1), rx + S2 * (64 - l0), ry + S2 * (24 - y0))
                elif f == "east":
                    rx, ry = R_RIGHT
                    uv = uvp(rx + S2 * l0, ry + S2 * (24 - y1), rx + S2 * l1, ry + S2 * (24 - y0))
                elif f == "north":
                    rx, ry = R_FRONT
                    uv = uvp(rx + S2 * (32 - x1), ry + S2 * (24 - y1), rx + S2 * (32 - x0), ry + S2 * (24 - y0))
                elif f == "south":
                    rx, ry = R_REAR
                    uv = uvp(rx + S2 * x0, ry + S2 * (24 - y1), rx + S2 * x1, ry + S2 * (24 - y0))
                elif f == "up":
                    rx, ry = R_TOP
                    uv = uvp(rx + S2 * x0, ry + S2 * (64 - l1), rx + S2 * x1, ry + S2 * (64 - l0))
                else:
                    rx, ry = R_UNDER
                    uv = uvp(rx, ry, rx + 8, ry + 8)
            else:
                c, _ = extra
                rx, ry = R_WHEEL
                if f in ("west", "east"):
                    a0 = S2 * ((c + 4) - l1) if f == "west" else S2 * (l0 - (c - 4))
                    a1 = S2 * ((c + 4) - l0) if f == "west" else S2 * (l1 - (c - 4))
                    uv = uvp(rx + a0, ry + S2 * (8 - y1), rx + a1, ry + S2 * (8 - y0))
                else:
                    rx, ry = R_TIRE
                    uv = uvp(rx, ry, rx + 8, ry + 8)
            faces[f] = {"uv": [round(q, 5) for q in uv], "texture": tex}
        if faces:
            els.append({"from": [round(q, 4) for q in frm], "to": [round(q, 4) for q in to], "faces": faces})
    return els

def build_cars():
    for i, var in enumerate(CAR_VARIANTS):
        cars_paint(var, 300 + i * 17)
    for (u, w, h) in ALL_CELLS:
        cid = cell_id(u, w, h)
        els = car_cell_elements(u, w, h)
        wjson(os.path.join(MOD, f"car_cell_{cid}.json"), {"textures": {"car": "dreams:block/car_a", "particle": "dreams:block/car_a"}, "elements": els})
        for var in CAR_VARIANTS:
            wjson(os.path.join(MOD, f"car_{var}_{cid}.json"), {
                "parent": f"dreams:block/car_cell_{cid}",
                "textures": {"car": f"dreams:block/car_{var}", "particle": f"dreams:block/car_{var}"}})
    for var in CAR_VARIANTS:
        vs = {}
        for d_i, d in enumerate(("north", "east", "south", "west")):
            for (u, w, h) in ALL_CELLS:
                cid = cell_id(u, w, h)
                e = {"model": f"dreams:block/car_{var}_{cid}"}
                if d_i:
                    e["y"] = 90 * d_i
                vs[f"cell={cid},facing={d}"] = e
        wjson(os.path.join(BST, f"city_car_{var}.json"), {"variants": vs})

if __name__ == "__main__":
    build_all_but_cars()
    build_cars()
    print("all ok")
