package com.example.dreams.client;

import com.example.dreams.DreamConfig;
import com.example.dreams.Dreams;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/**
 * Летающие медузы мира доброго сна (только клиент): светящийся полупрозрачный колокол, который пульсирует и
 * подталкивает медузу вверх, и длинные щупальца, колышущиеся волной. Привязаны к миру (плитка 420x420 вокруг игрока),
 * плывут медленно, разного размера и цвета. Рисуются тем же слоем, что киты (entityTranslucentEmissive).
 */
@EventBusSubscriber(modid = Dreams.MODID, bus = EventBusSubscriber.Bus.GAME, value = Dist.CLIENT)
public final class SkyJellies {

    private SkyJellies() {}

    private static final ResourceLocation TEX = ResourceLocation.fromNamespaceAndPath(Dreams.MODID, "textures/entity/sky_jelly.png");
    private static final int COUNT = 18;
    private static final double TILE = 420.0;
    private static final int RINGS = 7;        // колокол: параллели от макушки до края
    private static final int SIDES = 16;       // колокол: меридианы
    private static final int SEG = 10;         // сегментов у щупальца
    private static final int[][] COLORS = {{255, 150, 225}, {140, 225, 255}, {205, 165, 255}, {255, 205, 150}, {170, 255, 220}};

    private static double hash(int i, int k) {
        long h = (i * 0x9E3779B97F4A7C15L) ^ (k * 0xD6E8FEB86659FD93L);
        h ^= h >>> 32; h *= 0xff51afd7ed558ccdL; h ^= h >>> 29;
        return (h >>> 11) * (1.0 / (1L << 53));
    }

    private static PoseStack.Pose pose;
    private static VertexConsumer vc;
    private static int cr, cg, cb;

    private static void vtx(double x, double y, double z, float u, float v, int a) {
        vc.addVertex(pose, (float) x, (float) y, (float) z).setColor(cr, cg, cb, a).setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY).setLight(LightTexture.FULL_BRIGHT).setNormal(pose, 0f, 1f, 0f);
    }

    /** Четырёхугольник с обеих сторон: a, b, c, d по кругу. */
    private static void quad(double[] a, double[] b, double[] c, double[] d, float u0, float v0, float u1, float v1, int alpha) {
        vtx(a[0], a[1], a[2], u0, v0, alpha);
        vtx(b[0], b[1], b[2], u1, v0, alpha);
        vtx(c[0], c[1], c[2], u1, v1, alpha);
        vtx(d[0], d[1], d[2], u0, v1, alpha);
        vtx(d[0], d[1], d[2], u0, v1, alpha);
        vtx(c[0], c[1], c[2], u1, v1, alpha);
        vtx(b[0], b[1], b[2], u1, v0, alpha);
        vtx(a[0], a[1], a[2], u0, v0, alpha);
    }

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
        if (!SkyRing.inDreamWorld() || !DreamConfig.CLIENT.goodVisuals.get() || !DreamConfig.CLIENT.jellyModel.get()) return;
        Minecraft mc = Minecraft.getInstance();
        Vec3 cam = event.getCamera().getPosition();
        pose = event.getPoseStack().last();
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
        RenderType rt = RenderType.entityTranslucentEmissive(TEX);
        vc = buf.getBuffer(rt);
        double time = System.nanoTime() / 50_000_000.0;

        float fogStart = RenderSystem.getShaderFogStart();
        float fogEnd = RenderSystem.getShaderFogEnd();
        RenderSystem.setShaderFogStart(Math.max(fogStart, 260f));   // слегка тонут в дымке, но не пропадают
        RenderSystem.setShaderFogEnd(Math.max(fogEnd, 420f));

        for (int i = 0; i < COUNT; i++) {
            double ox = hash(i, 1) * TILE, oz = hash(i, 2) * TILE;
            double drift = time * 0.0035 + i * 2.1;
            double dx = Mth.positiveModulo(ox - cam.x + TILE / 2, TILE) - TILE / 2 + Math.sin(drift) * 14.0;
            double dz = Mth.positiveModulo(oz - cam.z + TILE / 2, TILE) - TILE / 2 + Math.cos(drift * 0.8) * 14.0;
            double hd = Math.sqrt(dx * dx + dz * dz);
            if (hd < 16.0 || hd > 170.0) continue;
            double fade = Mth.clamp((170.0 - hd) / 60.0, 0.0, 1.0) * Mth.clamp((hd - 16.0) / 12.0, 0.0, 1.0);
            if (fade <= 0.03) continue;
            double size = 1.8 + 6.2 * hash(i, 3) * hash(i, 3);          // радиус колокола; редкие большие
            double period = 38.0 + 22.0 * hash(i, 4);                   // тиков на один толчок
            double phase = time / period * Math.PI * 2 + i * 1.3;
            double beat = 0.5 + 0.5 * Math.sin(phase);                  // 1 = колокол сжат, толчок вверх
            double cy = 52.0 + 78.0 * hash(i, 5) + Math.sin(time * 0.006 + i) * 5.0 + beat * 0.5 * size * 0.3 - cam.y;
            int[] col = COLORS[i % COLORS.length];
            cr = col[0]; cg = col[1]; cb = col[2];
            drawJelly(dx, cy, dz, size, beat, time, i, (int) (255 * fade));
        }
        mc.renderBuffers().bufferSource().endBatch(rt);
        RenderSystem.setShaderFogStart(fogStart);
        RenderSystem.setShaderFogEnd(fogEnd);
        vc = null;
        pose = null;
    }

    private static void drawJelly(double cx, double cy, double cz, double R, double beat, double time, int id, int alpha) {
        double H = R * 0.85;
        double radMul = 1.0 - 0.16 * beat;                  // сжатие колокола при толчке
        double hMul = 1.0 + 0.10 * beat;
        double[][] ringR = new double[RINGS + 1][SIDES + 1];
        double[] ringY = new double[RINGS + 1];
        for (int j = 0; j <= RINGS; j++) {
            double phi = (Math.PI / 2) * (j / (double) RINGS);
            ringY[j] = H * hMul * Math.cos(phi) - (j == RINGS ? 0.08 * R * beat : 0.0);
            for (int i = 0; i <= SIDES; i++) {
                double th = i * Math.PI * 2 / SIDES;
                double scallop = j == RINGS ? 1.0 + 0.07 * Math.sin(th * 5 + time * 0.09 + id) : 1.0;
                ringR[j][i] = R * Math.sin(phi) * radMul * scallop;
            }
        }
        // колокол
        for (int j = 0; j < RINGS; j++) {
            for (int i = 0; i < SIDES; i++) {
                double t0 = i * Math.PI * 2 / SIDES, t1 = (i + 1) * Math.PI * 2 / SIDES;
                double[] a = {cx + ringR[j][i] * Math.cos(t0), cy + ringY[j], cz + ringR[j][i] * Math.sin(t0)};
                double[] b = {cx + ringR[j][i + 1] * Math.cos(t1), cy + ringY[j], cz + ringR[j][i + 1] * Math.sin(t1)};
                double[] c = {cx + ringR[j + 1][i + 1] * Math.cos(t1), cy + ringY[j + 1], cz + ringR[j + 1][i + 1] * Math.sin(t1)};
                double[] d = {cx + ringR[j + 1][i] * Math.cos(t0), cy + ringY[j + 1], cz + ringR[j + 1][i] * Math.sin(t0)};
                float u0 = (float) i / SIDES * 2f, u1 = (float) (i + 1) / SIDES * 2f;
                float v0 = (float) j / RINGS * 0.75f, v1 = (float) (j + 1) / RINGS * 0.75f;
                quad(a, b, c, d, u0, v0, u1, v1, (int) (alpha * 0.72));
            }
        }
        // тонкие щупальца с края
        int n = 8;
        for (int k = 0; k < n; k++) {
            double th = k * Math.PI * 2 / n + id;
            double len = R * (2.4 + 1.6 * hash(id * 31 + k, 6));
            double rimR = ringR[RINGS][0] * 0.96;
            tentacle(cx, cy + ringY[RINGS], cz, th, rimR, len, R * 0.07, time, id * 7 + k, alpha, 0.9);
        }
        // толстые ротовые лопасти из центра
        for (int k = 0; k < 4; k++) {
            double th = k * Math.PI / 2 + 0.7 + id;
            tentacle(cx, cy + ringY[RINGS] * 0.6, cz, th, R * 0.18, R * 1.7, R * 0.17, time, id * 11 + k + 50, alpha, 0.8);
        }
    }

    /** Щупальце-лента: две скрещенные плоскости, волна бежит сверху вниз. */
    private static void tentacle(double bx, double by, double bz, double th, double r0, double len, double w0,
                                 double time, int seed, int alpha, double aMul) {
        double cth = Math.cos(th), sth = Math.sin(th);
        double[] prevC = null, prevT = null;
        double[] pa = new double[3], pb = new double[3], pc = new double[3], pd = new double[3];
        double[][] left = new double[SEG + 1][3], right = new double[SEG + 1][3], front = new double[SEG + 1][3], back = new double[SEG + 1][3];
        for (int s = 0; s <= SEG; s++) {
            double t = s / (double) SEG;
            double wave = Math.sin(time * 0.07 - t * 4.2 + seed * 1.37) * 0.20 * len * t;
            double wave2 = Math.cos(time * 0.055 - t * 3.1 + seed * 0.9) * 0.14 * len * t;
            double rad = r0 * (1.0 - 0.35 * t);
            double px = bx + rad * cth + (-sth) * wave + cth * wave2;
            double py = by - t * len;
            double pz = bz + rad * sth + cth * wave + sth * wave2;
            double w = w0 * (1.0 - 0.55 * t) + 0.02;
            // плоскость 1: ширина по касательной; плоскость 2: по радиусу
            left[s] = new double[]{px + sth * w, py, pz - cth * w};
            right[s] = new double[]{px - sth * w, py, pz + cth * w};
            front[s] = new double[]{px + cth * w, py, pz + sth * w};
            back[s] = new double[]{px - cth * w, py, pz - sth * w};
        }
        for (int s = 0; s < SEG; s++) {
            float v0 = 0.75f + 0.25f * (s / (float) SEG), v1 = 0.75f + 0.25f * ((s + 1) / (float) SEG);
            int a = (int) (alpha * aMul);
            quad(left[s], right[s], right[s + 1], left[s + 1], 0f, v0, 1f, v1, a);
            quad(front[s], back[s], back[s + 1], front[s + 1], 0f, v0, 1f, v1, a);
        }
    }
}
