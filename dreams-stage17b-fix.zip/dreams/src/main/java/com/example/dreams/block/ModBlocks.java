package com.example.dreams.block;

import com.example.dreams.Dreams;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Блоки кошмара. Предметов нет: в мир они попадают только как фейк, видимый одному игроку.
 * Прочность подобрана под оригиналы, чтобы ломание не рассинхронизировалось.
 * lightLevel работает только на клиенте сновидца (фейк-блок): лёгкое красное свечение.
 */
public class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(Dreams.MODID);

    public static final DeferredBlock<Block> VEINED_STONE = BLOCKS.registerSimpleBlock("veined_stone",
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_RED).strength(1.5f, 6.0f).sound(SoundType.STONE));

    public static final DeferredBlock<Block> ROTTEN_PLANKS = BLOCKS.registerSimpleBlock("rotten_planks",
            BlockBehaviour.Properties.of().mapColor(MapColor.WOOD).strength(2.0f, 3.0f).sound(SoundType.WOOD));

    public static final DeferredBlock<Block> ASHEN_DIRT = BLOCKS.registerSimpleBlock("ashen_dirt",
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_GRAY).strength(0.5f).sound(SoundType.GRAVEL));

    /** Стена с глазами (вместо камня): анимированная текстура, глаза моргают и бегают. */
    public static final DeferredBlock<Block> EYE_STONE = BLOCKS.registerSimpleBlock("eye_stone",
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_RED).strength(1.5f, 6.0f).sound(SoundType.STONE)
                    .lightLevel(state -> 4));

    // ---- этап 8: Иная сторона. Металл: шаги по ним на клиенте звучат как по ржавому железу. ----

    /** Ржавая пластина (вместо камня, досок, брёвен). */
    public static final DeferredBlock<Block> RUST_PLATE = BLOCKS.registerSimpleBlock("rust_plate",
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_ORANGE).strength(1.5f, 6.0f).sound(SoundType.METAL)
                    .lightLevel(state -> 2));

    /** Ржавая пластина в крови. */
    public static final DeferredBlock<Block> RUST_BLOODY = BLOCKS.registerSimpleBlock("rust_bloody",
            BlockBehaviour.Properties.of().mapColor(MapColor.CRIMSON_NYLIUM).strength(1.5f, 6.0f).sound(SoundType.METAL)
                    .lightLevel(state -> 3));

    /** Решётка над багровой бездной (вместо земли, песка, гравия). Анимированная, светится. */
    public static final DeferredBlock<Block> RUST_GRATE = BLOCKS.registerSimpleBlock("rust_grate",
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BROWN).strength(0.5f).sound(SoundType.CHAIN)
                    .lightLevel(state -> 5));

    // ---- этап 9: печати ритуала. Фейк в воздухе, без коллизии: проходишь насквозь, но ПКМ по ним работает. ----

    /** Непогашенная печать: красный светящийся столб с рунами. */
    public static final DeferredBlock<Block> SEAL = BLOCKS.registerSimpleBlock("seal",
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_RED).noCollission().noOcclusion()
                    .strength(-1.0f, 3600000.0f).lightLevel(state -> 12));

    /** Погашенная печать: холодный, тусклый столб. */
    public static final DeferredBlock<Block> SEAL_DONE = BLOCKS.registerSimpleBlock("seal_done",
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_LIGHT_BLUE).noCollission().noOcclusion()
                    .strength(-1.0f, 3600000.0f).lightLevel(state -> 3));

    /** Пульсирующая плоть (вместо земли). */
    public static final DeferredBlock<Block> FLESH = BLOCKS.registerSimpleBlock("flesh",
            BlockBehaviour.Properties.of().mapColor(MapColor.CRIMSON_NYLIUM).strength(0.5f).sound(SoundType.SLIME_BLOCK)
                    .lightLevel(state -> 2));

    // ---- добрый сон: мир, который видит только сновидец (фейк-блоки). Формы коллизий совпадают с оригиналами. ----

    /** Облачный камень (вместо камня, булыжника, терракоты): жемчужный мрамор с золотыми прожилками. */
    public static final DeferredBlock<Block> CLOUD_STONE = BLOCKS.registerSimpleBlock("cloud_stone",
            BlockBehaviour.Properties.of().mapColor(MapColor.SNOW).strength(1.5f, 6.0f).sound(SoundType.AMETHYST)
                    .lightLevel(state -> 3));

    /** Мягкий светящийся мох (вместо земли, травы, песка, гравия). */
    public static final DeferredBlock<Block> DREAM_MOSS = BLOCKS.registerSimpleBlock("dream_moss",
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_LIGHT_GREEN).strength(0.5f).sound(SoundType.MOSS)
                    .lightLevel(state -> 4));

    /** Медовые доски (вместо досок и брёвен). */
    public static final DeferredBlock<Block> HONEY_PLANKS = BLOCKS.registerSimpleBlock("honey_planks",
            BlockBehaviour.Properties.of().mapColor(MapColor.GOLD).strength(2.0f, 3.0f).sound(SoundType.WOOD)
                    .lightLevel(state -> 5));

    /** Лепестковая листва (вместо листвы): розово-белая, тёплое свечение. */
    public static final DeferredBlock<Block> DREAM_LEAVES = BLOCKS.registerSimpleBlock("dream_leaves",
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PINK).strength(0.2f).sound(SoundType.CHERRY_LEAVES)
                    .lightLevel(state -> 9));

    /** Звенящая плитка (вместо земли под ногами на поляне). Анимированная. */
    public static final DeferredBlock<Block> CHIME_TILE = BLOCKS.registerSimpleBlock("chime_tile",
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_LIGHT_BLUE).strength(0.5f).sound(SoundType.AMETHYST)
                    .lightLevel(state -> 6));

    /** Та же плитка, когда по ней ступили или она показывает ноту мелодии. */
    public static final DeferredBlock<Block> CHIME_TILE_LIT = BLOCKS.registerSimpleBlock("chime_tile_lit",
            BlockBehaviour.Properties.of().mapColor(MapColor.GOLD).strength(0.5f).sound(SoundType.AMETHYST)
                    .lightLevel(state -> 14));

    /** Воспоминание: тёплый столб света в воздухе. Без коллизии, как печать. */
    public static final DeferredBlock<Block> MEMORY = BLOCKS.registerSimpleBlock("memory",
            BlockBehaviour.Properties.of().mapColor(MapColor.GOLD).noCollission().noOcclusion()
                    .strength(-1.0f, 3600000.0f).lightLevel(state -> 13));

    /** Собранное воспоминание: тихий голубоватый свет. */
    public static final DeferredBlock<Block> MEMORY_DONE = BLOCKS.registerSimpleBlock("memory_done",
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_LIGHT_BLUE).noCollission().noOcclusion()
                    .strength(-1.0f, 3600000.0f).lightLevel(state -> 5));

    /** Ствол Древа снов. */
    public static final DeferredBlock<Block> TREE_LOG = BLOCKS.registerSimpleBlock("tree_log",
            BlockBehaviour.Properties.of().mapColor(MapColor.QUARTZ).strength(2.0f, 3.0f).sound(SoundType.CHERRY_WOOD)
                    .lightLevel(state -> 8));

    /** Крона Древа снов: золотисто-розовая, сильно светится. */
    public static final DeferredBlock<Block> TREE_BLOSSOM = BLOCKS.registerSimpleBlock("tree_blossom",
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PINK).strength(0.2f).sound(SoundType.CHERRY_LEAVES)
                    .lightLevel(state -> 13));

    // Светящиеся цветы (вместо травы и цветов): модель cross, без коллизии, случайный сдвиг по XZ как у ванильных.
    public static final DeferredBlock<Block> BLOOM_GOLD = BLOCKS.registerSimpleBlock("bloom_gold",
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_YELLOW).noCollission().noOcclusion().instabreak()
                    .sound(SoundType.GRASS).lightLevel(state -> 9).offsetType(BlockBehaviour.OffsetType.XZ));
    public static final DeferredBlock<Block> BLOOM_BLUE = BLOCKS.registerSimpleBlock("bloom_blue",
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_LIGHT_BLUE).noCollission().noOcclusion().instabreak()
                    .sound(SoundType.GRASS).lightLevel(state -> 9).offsetType(BlockBehaviour.OffsetType.XZ));
    public static final DeferredBlock<Block> BLOOM_PINK = BLOCKS.registerSimpleBlock("bloom_pink",
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PINK).noCollission().noOcclusion().instabreak()
                    .sound(SoundType.GRASS).lightLevel(state -> 9).offsetType(BlockBehaviour.OffsetType.XZ));

    // ---- этап 14: облик города Иной стороны. Фейк-блоки; свет работает только на клиенте сновидца. ----

    private static BlockBehaviour.Properties stone(MapColor c, int light) {
        return BlockBehaviour.Properties.of().mapColor(c).strength(1.5f, 6.0f).sound(SoundType.STONE).lightLevel(s -> light);
    }

    public static final DeferredBlock<Block> CITY_BRICK = BLOCKS.registerSimpleBlock("city_brick", stone(MapColor.COLOR_RED, 2));
    public static final DeferredBlock<Block> CITY_BRICK_DARK = BLOCKS.registerSimpleBlock("city_brick_dark", stone(MapColor.CRIMSON_NYLIUM, 2));
    public static final DeferredBlock<Block> CITY_BRICK_BLOOD = BLOCKS.registerSimpleBlock("city_brick_blood", stone(MapColor.CRIMSON_NYLIUM, 3));
    public static final DeferredBlock<Block> CITY_COBBLE = BLOCKS.registerSimpleBlock("city_cobble", stone(MapColor.COLOR_GRAY, 3));
    public static final DeferredBlock<Block> CITY_COBBLE_BLOOD = BLOCKS.registerSimpleBlock("city_cobble_blood", stone(MapColor.CRIMSON_NYLIUM, 3));
    public static final DeferredBlock<Block> CITY_ASPHALT = BLOCKS.registerSimpleBlock("city_asphalt", stone(MapColor.COLOR_BLACK, 2));
    public static final DeferredBlock<Block> CITY_CURB = BLOCKS.registerSimpleBlock("city_curb", stone(MapColor.STONE, 2));
    public static final DeferredBlock<Block> CITY_DIRT = BLOCKS.registerSimpleBlock("city_dirt",
            BlockBehaviour.Properties.of().mapColor(MapColor.DIRT).strength(0.5f).sound(SoundType.GRAVEL).lightLevel(s -> 2));
    public static final DeferredBlock<Block> CITY_BEAM = BLOCKS.registerSimpleBlock("city_beam",
            BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(1.5f, 6.0f).sound(SoundType.METAL).lightLevel(s -> 1));
    public static final DeferredBlock<Block> CITY_DOOR_L = BLOCKS.registerSimpleBlock("city_door_l",
            BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(1.5f, 6.0f).sound(SoundType.METAL).lightLevel(s -> 1));
    public static final DeferredBlock<Block> CITY_DOOR_R = BLOCKS.registerSimpleBlock("city_door_r",
            BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(1.5f, 6.0f).sound(SoundType.METAL).lightLevel(s -> 1));

    private static BlockBehaviour.Properties window() {
        return BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLACK).strength(0.3f).sound(SoundType.GLASS).noOcclusion();
    }

    public static final DeferredBlock<Block> CITY_WINDOW_A = BLOCKS.registerSimpleBlock("city_window_a", window());
    public static final DeferredBlock<Block> CITY_WINDOW_B = BLOCKS.registerSimpleBlock("city_window_b", window());
    public static final DeferredBlock<Block> CITY_WINDOW_C = BLOCKS.registerSimpleBlock("city_window_c", window());

    private static BlockBehaviour.Properties prop(int light) {
        return BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(1.0f, 6.0f).sound(SoundType.METAL)
                .noOcclusion().lightLevel(s -> light);
    }

    // Фонарь: основание, 4 столба, верх с рукой, голова на конце руки (рука идёт к улице, facing = куда).
    public static final DeferredBlock<Block> CITY_LAMP_BASE = BLOCKS.register("city_lamp_base",
            () -> new PropBlock(prop(0), false, PropBlock.rotated(4, 0, 4, 12, 4.5, 12, 6.5, 4, 6.5, 9.5, 16, 9.5)));
    public static final DeferredBlock<Block> CITY_LAMP_POLE = BLOCKS.register("city_lamp_pole",
            () -> new PropBlock(prop(0), false, PropBlock.rotated(6.5, 0, 6.5, 9.5, 16, 9.5)));
    public static final DeferredBlock<Block> CITY_LAMP_TOP = BLOCKS.register("city_lamp_top",
            () -> new PropBlock(prop(0), true, PropBlock.rotated(6.5, 0, 6.5, 9.5, 15.5, 9.5, 7, 12.5, 0, 9, 14.5, 6.5)));
    public static final DeferredBlock<Block> CITY_LAMP_HEAD = BLOCKS.register("city_lamp_head",
            () -> new PropBlock(prop(11), true, PropBlock.rotated(3.5, 9.5, 1.5, 12.5, 14.5, 16)));
    public static final DeferredBlock<Block> CITY_LAMP_HEAD_DEAD = BLOCKS.register("city_lamp_head_dead",
            () -> new PropBlock(prop(0), true, PropBlock.rotated(3.5, 9.5, 1.5, 12.5, 14.5, 16)));
    public static final DeferredBlock<Block> CITY_SIGNAL_HEAD = BLOCKS.register("city_signal_head",
            () -> new PropBlock(prop(6), true, PropBlock.rotated(5, 1.5, 5, 11, 14.5, 16)));

    public static final DeferredBlock<Block> CITY_HYDRANT = BLOCKS.register("city_hydrant",
            () -> new PropBlock(prop(0), false, PropBlock.rotated(4, 0, 4, 12, 14.5, 12)));
    public static final DeferredBlock<Block> CITY_BARREL = BLOCKS.register("city_barrel",
            () -> new PropBlock(prop(0), false, PropBlock.rotated(3, 0, 3, 13, 14.5, 13)));
    public static final DeferredBlock<Block> CITY_BIN = BLOCKS.register("city_bin",
            () -> new PropBlock(prop(0), true, PropBlock.rotated(0.5, 0, 1.5, 15.5, 13.5, 14.5)));
    public static final DeferredBlock<Block> CITY_BARRIER = BLOCKS.register("city_barrier",
            () -> new PropBlock(prop(0), true, PropBlock.rotated(0, 0, 6.5, 16, 13, 9.5)));

    public static final DeferredBlock<Block> CITY_FENCE_LOW = BLOCKS.register("city_fence_low",
            () -> new FenceBlock(prop(0).sound(SoundType.CHAIN)));
    public static final DeferredBlock<Block> CITY_FENCE_UP = BLOCKS.register("city_fence_up",
            () -> new FenceBlock(prop(0).sound(SoundType.CHAIN)));

    private static BlockBehaviour.Properties car() {
        return BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(2.0f, 6.0f).sound(SoundType.METAL).noOcclusion();
    }

    // Машины четырёх раскрасок: a ржавая красная, b серо-синяя, c жёлтая (фары горят), d сгоревшая.
    public static final DeferredBlock<Block> CITY_CAR_A = BLOCKS.register("city_car_a",
            () -> new CarBlock(car().lightLevel(s -> CarBlock.lightFor(false, s.getValue(CarBlock.CELL))), false));
    public static final DeferredBlock<Block> CITY_CAR_B = BLOCKS.register("city_car_b",
            () -> new CarBlock(car().lightLevel(s -> CarBlock.lightFor(false, s.getValue(CarBlock.CELL))), false));
    public static final DeferredBlock<Block> CITY_CAR_C = BLOCKS.register("city_car_c",
            () -> new CarBlock(car().lightLevel(s -> CarBlock.lightFor(true, s.getValue(CarBlock.CELL))), true));
    public static final DeferredBlock<Block> CITY_CAR_D = BLOCKS.register("city_car_d",
            () -> new CarBlock(car().lightLevel(s -> CarBlock.lightFor(false, s.getValue(CarBlock.CELL))), false));
}
