package com.example.dreams.network;

import com.example.dreams.Dreams;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Сервер -> клиент: запустить катсцену (assets/dreams/cutscenes/<scene>.json). x, y, z: якорь для сцен вида "anchor" (например, основание Древа). */
public record DreamCutscenePayload(String scene, double x, double y, double z) implements CustomPacketPayload {

    public static final Type<DreamCutscenePayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(Dreams.MODID, "dream_cutscene"));

    public static final StreamCodec<ByteBuf, DreamCutscenePayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.STRING_UTF8, DreamCutscenePayload::scene,
            ByteBufCodecs.DOUBLE, DreamCutscenePayload::x,
            ByteBufCodecs.DOUBLE, DreamCutscenePayload::y,
            ByteBufCodecs.DOUBLE, DreamCutscenePayload::z,
            DreamCutscenePayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
