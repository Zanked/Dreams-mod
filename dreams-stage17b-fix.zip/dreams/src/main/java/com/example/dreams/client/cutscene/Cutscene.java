package com.example.dreams.client.cutscene;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Катсцена: ключевые кадры камеры из JSON (assets/dreams/cutscenes/*.json).
 *
 * Пример:
 * {
 *   "space": "player",            // player: от глаз игрока в начале; player_live: от глаз игрока сейчас;
 *                                 // anchor: от точки (её присылает сервер), ось "вперёд" смотрит от точки на игрока
 *   "duration": 150,              // тики
 *   "blend_in": 0, "blend_out": 22,   // плавный переход из/в обычный вид игрока
 *   "fade_in": 18, "fade_color": "FFF6DC",
 *   "lock_look": true,            // пока идёт сцена, поворот игрока заморожен
 *   "bars": true,
 *   "keys": [ {"t": 0, "pos": [вправо, вверх, вперёд], "look": [вправо, вверх, вперёд], "fov": 1.0}, ... ],
 *   "subtitles": [ {"t": 30, "d": 70, "key": "cutscene.dreams.prologue.1"} ]
 * }
 * "look" может быть и объектом {"whale": 0, "s": 0.35, "off": [x, y, z]}: следить за точкой на теле кита
 * (s: 0 = нос, 1 = хвост; off: мировое смещение), или {"entity": "executioner", "off": [x, y, z]}: следить за Палачом.
 * "fov": множитель обычного угла обзора.
 * Дополнительно: "fade_out" (тики) и "fade_out_color" затемняют конец сцены, "skippable": false запрещает пропуск,
 * "shake": ручная камера (градусы; отключается reducedMotion), "fog": отодвинуть туман до N блоков на время сцены, "sounds": [{"t": 30, "sound": "dreams:exec_roar", "volume": 1, "pitch": 0.8}].
 */
public final class Cutscene {

    public enum Space { PLAYER, PLAYER_LIVE, ANCHOR }

    public static final class Look {
        public double[] p;            // точка в пространстве сцены, или null
        public String entity = null;  // или следить за существом: "executioner"
        public int whale = -1;        // или следить за китом
        public float s = 0.35f;
        public double[] off = {0, 0, 0};
    }

    public static final class Key {
        public int t;
        public double[] pos = {0, 0, 0};
        public Look look = new Look();
        public float fov = 1f;
    }

    public static final class Snd {
        public int t;
        public String sound = "";
        public float volume = 1f, pitch = 1f;
    }

    public static final class Sub {
        public int t, d;
        public String key = "";
    }

    public Space space = Space.PLAYER;
    public int duration = 120;
    public int blendIn = 0;
    public int blendOut = 20;
    public int fadeIn = 0;
    public int fadeColor = 0xFFF6DC;
    public boolean lockLook = true;
    public boolean bars = true;
    public int fadeOut = 0;
    public int fadeOutColor = 0x000000;
    public boolean skippable = true;
    public float shake = 0f;                   // ручная камера: амплитуда в градусах
    public float fog = 0f;                     // >0: на время сцены туман отодвигается до этих блоков (чтобы было видно то, что показывают)
    public final List<Snd> sounds = new ArrayList<>();
    public final List<Key> keys = new ArrayList<>();
    public final List<Sub> subs = new ArrayList<>();

    public static Cutscene parse(JsonObject o) {
        Cutscene c = new Cutscene();
        String sp = str(o, "space", "player");
        c.space = switch (sp) {
            case "player_live" -> Space.PLAYER_LIVE;
            case "anchor" -> Space.ANCHOR;
            default -> Space.PLAYER;
        };
        c.duration = Math.max(20, num(o, "duration", 120));
        c.blendIn = Math.max(0, num(o, "blend_in", 0));
        c.blendOut = Math.max(0, num(o, "blend_out", 20));
        c.fadeIn = Math.max(0, num(o, "fade_in", 0));
        try {
            c.fadeColor = Integer.parseInt(str(o, "fade_color", "FFF6DC"), 16) & 0xFFFFFF;
        } catch (NumberFormatException ignored) {
        }
        c.fadeOut = Math.max(0, num(o, "fade_out", 0));
        try {
            c.fadeOutColor = Integer.parseInt(str(o, "fade_out_color", "000000"), 16) & 0xFFFFFF;
        } catch (NumberFormatException ignored) {
        }
        c.skippable = !o.has("skippable") || o.get("skippable").getAsBoolean();
        c.shake = o.has("shake") ? o.get("shake").getAsFloat() : 0f;
        c.fog = o.has("fog") ? o.get("fog").getAsFloat() : 0f;
        if (o.has("sounds")) {
            for (JsonElement e : o.getAsJsonArray("sounds")) {
                JsonObject s = e.getAsJsonObject();
                Snd snd = new Snd();
                snd.t = num(s, "t", 0);
                snd.sound = str(s, "sound", "");
                if (s.has("volume")) snd.volume = s.get("volume").getAsFloat();
                if (s.has("pitch")) snd.pitch = s.get("pitch").getAsFloat();
                c.sounds.add(snd);
            }
        }
        c.lockLook = !o.has("lock_look") || o.get("lock_look").getAsBoolean();
        c.bars = !o.has("bars") || o.get("bars").getAsBoolean();
        if (o.has("keys")) {
            for (JsonElement e : o.getAsJsonArray("keys")) {
                JsonObject k = e.getAsJsonObject();
                Key key = new Key();
                key.t = num(k, "t", 0);
                if (k.has("pos")) key.pos = vec(k.getAsJsonArray("pos"));
                if (k.has("look")) key.look = look(k.get("look"));
                if (k.has("fov")) key.fov = k.get("fov").getAsFloat();
                c.keys.add(key);
            }
        }
        c.keys.sort((a, b) -> Integer.compare(a.t, b.t));
        if (o.has("subtitles")) {
            for (JsonElement e : o.getAsJsonArray("subtitles")) {
                JsonObject s = e.getAsJsonObject();
                Sub sub = new Sub();
                sub.t = num(s, "t", 0);
                sub.d = Math.max(1, num(s, "d", 60));
                sub.key = str(s, "key", "");
                c.subs.add(sub);
            }
        }
        return c;
    }

    private static Look look(JsonElement e) {
        Look l = new Look();
        if (e.isJsonArray()) {
            l.p = vec(e.getAsJsonArray());
        } else {
            JsonObject o = e.getAsJsonObject();
            if (o.has("entity")) l.entity = o.get("entity").getAsString();
            else l.whale = num(o, "whale", 0);
            if (o.has("s")) l.s = o.get("s").getAsFloat();
            if (o.has("off")) l.off = vec(o.getAsJsonArray("off"));
        }
        return l;
    }

    private static double[] vec(JsonArray a) {
        return new double[]{a.get(0).getAsDouble(), a.get(1).getAsDouble(), a.get(2).getAsDouble()};
    }

    private static int num(JsonObject o, String k, int def) {
        return o.has(k) ? o.get(k).getAsInt() : def;
    }

    private static String str(JsonObject o, String k, String def) {
        return o.has(k) ? o.get(k).getAsString() : def;
    }
}
