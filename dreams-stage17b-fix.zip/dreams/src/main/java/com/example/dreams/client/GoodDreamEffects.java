package com.example.dreams.client;

import net.minecraft.client.renderer.DimensionSpecialEffects;
import net.minecraft.world.phys.Vec3;

/**
 * Небо мира доброго сна ("dreams:good_dream" в dimension_type): закатное небо, облака ниже островов (море облаков),
 * лёгкая дымка. Цвет неба и тумана берётся из биома dream_sky.
 */
public class GoodDreamEffects extends DimensionSpecialEffects {

    public GoodDreamEffects() {
        super(48.0F, false, SkyType.NORMAL, false, false);
    }

    @Override
    public Vec3 getBrightnessDependentFogColor(Vec3 fogColor, float brightness) {
        return fogColor.multiply(brightness * 0.94F + 0.06F, brightness * 0.94F + 0.06F, brightness * 0.97F + 0.03F);
    }

    @Override
    public boolean isFoggyAt(int x, int y) {
        return false;
    }
}
