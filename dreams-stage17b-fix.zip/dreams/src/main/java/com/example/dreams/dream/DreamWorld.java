package com.example.dreams.dream;

import com.example.dreams.Dreams;
import com.example.dreams.attachment.DreamState;
import com.example.dreams.dream.world.SkyIslands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;

import javax.annotation.Nullable;

/**
 * Отдельное измерение доброго сна ("dreams:good_dream"): парящие острова. Вход при ложном пробуждении,
 * выход через кровать на домашнем острове. Точка возврата хранится в данных игрока, так что если сервер
 * остановили во сне, при следующем входе игрок возвращается домой.
 */
public final class DreamWorld {

    private DreamWorld() {}

    public static final ResourceKey<Level> KEY =
            ResourceKey.create(Registries.DIMENSION, ResourceLocation.fromNamespaceAndPath(Dreams.MODID, "good_dream"));

    private static final String TAG_RETURN = "dreams_return";
    /** Ниже этой высоты игрок падает в пустоту: возвращаем на домашний остров. */
    public static final int RESCUE_Y = 8;

    public static boolean isDream(Level level) {
        return level.dimension().equals(KEY);
    }

    /** Переносит игрока в мир сна. false = измерения нет (оставляем старый вариант на фейк-блоках). */
    static boolean enter(ServerPlayer player, DreamState s) {
        ServerLevel dream = player.server.getLevel(KEY);
        if (dream == null) return false;

        // свой регион для каждого сна: домашние острова стоят через HOME_STEP клеток
        int hx = (player.getRandom().nextInt(2000) - 1000) * SkyIslands.HOME_STEP;
        int hz = (player.getRandom().nextInt(2000) - 1000) * SkyIslands.HOME_STEP;
        BlockPos home = SkyIslands.homeCenter(hx, hz);
        for (int dx = -1; dx <= 1; dx++) {   // чанки вокруг старта генерируем заранее, чтобы не падать сквозь пустоту
            for (int dz = -1; dz <= 1; dz++) dream.getChunk((home.getX() >> 4) + dx, (home.getZ() >> 4) + dz);
        }

        // кровать-выход: настоящая кровать на домашнем острове
        BlockPos foot = home.offset(3, 1, 0);
        BlockPos head = foot.relative(Direction.EAST);
        BlockState footState = Blocks.WHITE_BED.defaultBlockState().setValue(BedBlock.FACING, Direction.EAST).setValue(BedBlock.PART, BedPart.FOOT);
        dream.setBlock(foot, footState, 3);
        dream.setBlock(head, footState.setValue(BedBlock.PART, BedPart.HEAD), 3);

        CompoundTag t = new CompoundTag();
        t.putString("dim", player.level().dimension().location().toString());
        t.putDouble("x", player.getX());
        t.putDouble("y", player.getY());
        t.putDouble("z", player.getZ());
        t.putFloat("yaw", player.getYRot());
        t.putFloat("pitch", player.getXRot());
        player.getPersistentData().put(TAG_RETURN, t);

        s.dreamHome = home.immutable();
        s.bed = foot.immutable();
        s.transferring = true;
        try {
            player.teleportTo(dream, home.getX() + 0.5, home.getY() + 1.0, home.getZ() + 0.5, 90.0f, 0.0f);
        } finally {
            s.transferring = false;
        }
        player.fallDistance = 0.0f;
        return true;
    }

    /** Вернуть игрока туда, откуда он лёг спать. */
    static void leave(ServerPlayer player, DreamState s) {
        CompoundTag t = player.getPersistentData().getCompound(TAG_RETURN);
        player.getPersistentData().remove(TAG_RETURN);
        s.transferring = true;
        try {
            teleportBack(player, t);
        } finally {
            s.transferring = false;
        }
        s.dreamHome = null;
        player.fallDistance = 0.0f;
    }

    /** Игрок оказался в мире сна без самого сна (сервер остановили во сне): вернуть домой при входе в игру. */
    public static void leaveStray(ServerPlayer player) {
        if (!isDream(player.level())) return;
        CompoundTag t = player.getPersistentData().getCompound(TAG_RETURN);
        player.getPersistentData().remove(TAG_RETURN);
        teleportBack(player, t);
        player.fallDistance = 0.0f;
    }

    private static void teleportBack(ServerPlayer player, CompoundTag t) {
        ServerLevel target = null;
        double x = 0, y = 0, z = 0;
        float yaw = player.getYRot(), pitch = 0f;
        if (t.contains("dim")) {
            ResourceLocation id = ResourceLocation.tryParse(t.getString("dim"));
            if (id != null) target = player.server.getLevel(ResourceKey.create(Registries.DIMENSION, id));
            x = t.getDouble("x"); y = t.getDouble("y"); z = t.getDouble("z");
            yaw = t.getFloat("yaw"); pitch = t.getFloat("pitch");
        }
        if (target == null || target.dimension().equals(KEY)) {   // точки нет: мировая точка возрождения
            target = player.server.overworld();
            BlockPos sp = player.getRespawnPosition();
            if (sp == null || !player.getRespawnDimension().equals(Level.OVERWORLD)) sp = target.getSharedSpawnPos();
            x = sp.getX() + 0.5; y = sp.getY(); z = sp.getZ() + 0.5;
        }
        player.teleportTo(target, x, y, z, yaw, pitch);
    }

    /** Упал с острова: вернуть на домашний остров (во сне не умирают). */
    static void rescue(ServerPlayer player, DreamState s) {
        BlockPos h = s.dreamHome;
        if (h == null) return;
        ServerLevel dream = player.serverLevel();
        player.teleportTo(dream, h.getX() + 0.5, h.getY() + 1.0, h.getZ() + 0.5, player.getYRot(), 0.0f);
        player.fallDistance = 0.0f;
        player.setDeltaMovement(0, 0, 0);
    }

    @Nullable
    public static ServerLevel level(ServerPlayer player) {
        return player.server.getLevel(KEY);
    }

    /** Верхняя свободная поверхность острова в колонке (x, z) недалеко от высоты aroundY; null = чанк не загружен или пусто. */
    @Nullable
    public static BlockPos findSurface(ServerLevel level, int x, int z, int aroundY) {
        for (int y = Math.min(SkyIslands.HEIGHT - 4, aroundY + 45); y >= Math.max(6, aroundY - 40); y--) {
            BlockPos pos = new BlockPos(x, y, z);
            if (!level.hasChunkAt(pos)) return null;
            if (level.isEmptyBlock(pos) && level.isEmptyBlock(pos.above()) && level.isEmptyBlock(pos.above(2))
                    && level.getBlockState(pos.below()).isFaceSturdy(level, pos.below(), Direction.UP)) {
                return pos;
            }
        }
        return null;
    }
}
