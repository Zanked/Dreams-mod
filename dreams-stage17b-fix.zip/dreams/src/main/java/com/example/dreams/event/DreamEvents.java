package com.example.dreams.event;

import com.example.dreams.Dreams;
import com.example.dreams.attachment.DreamState;
import com.example.dreams.attachment.ModAttachments;
import com.example.dreams.dream.DreamManager;
import com.example.dreams.dream.DreamWorld;
import com.example.dreams.dream.GoodDream;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.BedBlock;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.level.ChunkWatchEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

@EventBusSubscriber(modid = Dreams.MODID)
public class DreamEvents {

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            DreamManager.tick(player);
        }
    }

    /** Сервер остановили посреди доброго сна: выданный полёт не должен остаться навсегда. */
    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            GoodDream.revokeStrayFlight(player);
            DreamWorld.leaveStray(player);
        }
    }

    /** В мире доброго сна не больно и не страшно: урон отменяется (из пустоты возвращает спасение на домашний остров). */
    @SubscribeEvent
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        if (event.getEntity() instanceof ServerPlayer player && DreamWorld.isDream(player.level())) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            DreamState s = player.getData(ModAttachments.DREAM_STATE);
            if (s.phase != DreamState.Phase.IDLE) {
                DreamManager.end(player, s, DreamManager.Result.ABORT, true);
            }
        }
    }

    @SubscribeEvent
    public static void onDimensionChange(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            DreamState s = player.getData(ModAttachments.DREAM_STATE);
            if (s.transferring) return;   // это наш собственный телепорт в мир сна или обратно
            if (s.phase != DreamState.Phase.IDLE) {
                DreamManager.end(player, s, DreamManager.Result.ABORT, false); // старые блоки уже не наши
            }
        }
    }

    /** Чанк переотправлен игроку -> возвращаем в нём фейки. */
    @SubscribeEvent
    public static void onChunkSent(ChunkWatchEvent.Sent event) {
        DreamManager.reapplyChunk(event.getPlayer(), event.getChunk().getPos());
    }

    /** Во время ложного пробуждения кровать = выход из сна. */
    @SubscribeEvent
    public static void onUseBlock(PlayerInteractEvent.RightClickBlock event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        DreamState s = player.getData(ModAttachments.DREAM_STATE);
        if (s.phase != DreamState.Phase.FALSE_AWAKE) return;
        if (event.getHand() != net.minecraft.world.InteractionHand.MAIN_HAND) return;
        // Этап 9: печати ритуала (фейк-блоки в воздухе; настоящий блок там - воздух)
        if (DreamManager.trySeal(player, s, event.getPos())) {
            event.setCanceled(true);
            event.setCancellationResult(InteractionResult.SUCCESS);
            return;
        }
        if (!(player.level().getBlockState(event.getPos()).getBlock() instanceof BedBlock)) return;

        event.setCanceled(true); // не даём ваниле сказать "спать можно только ночью"
        event.setCancellationResult(InteractionResult.SUCCESS);
        DreamManager.tryEscape(player, s, event.getPos());
    }
}
