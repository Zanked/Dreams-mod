package com.example.dreams.client.cutscene;

import com.example.dreams.DreamConfig;
import com.example.dreams.Dreams;
import com.example.dreams.client.SkyWhales;
import com.example.dreams.entity.ExecutionerEntity;
import com.google.gson.JsonParser;
import com.mojang.logging.LogUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.Input;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.InputEvent;
import net.neoforged.neoforge.client.event.MovementInputUpdateEvent;
import net.neoforged.neoforge.client.event.RenderGuiEvent;
import net.neoforged.neoforge.client.event.RenderGuiLayerEvent;
import net.neoforged.neoforge.client.event.RenderFrameEvent;
import net.neoforged.neoforge.client.event.RenderHandEvent;
import net.neoforged.neoforge.client.event.ViewportEvent;

import java.io.Reader;
import java.util.List;
import java.util.Optional;

/**
 * Катсцены на клиенте. Камера переключается на невидимую сущность-«оператора» (она не добавляется в мир).
 *
 * ПЛАВНОСТЬ: поза камеры считается КАЖДЫЙ КАДР (RenderFrameEvent.Pre) в непрерывном времени «тик + partialTick»,
 * а не раз в тик. Так движение не превращается в ломаную на 20 Гц, и камера одинаково гладкая на любом FPS.
 * Путь: кривая Эрмита с тангенсами по времени (скорость непрерывна и на неравномерных ключах), на концах скорость
 * нулевая (мягкий старт и остановка). Цели взгляда (Палач, кит, игрок) берутся в интерполированных позициях кадра.
 *
 * Пока сцена идёт: HUD и рука скрыты, управление и поворот игрока заморожены, сверху и снизу чёрные полосы.
 * Пропуск: пробел. Выкл. в dreams-client.toml: cutscenes = false.
 */
@EventBusSubscriber(modid = Dreams.MODID, bus = EventBusSubscriber.Bus.GAME, value = Dist.CLIENT)
public final class CutsceneManager {

    private CutsceneManager() {}

    private static final org.slf4j.Logger LOGGER = LogUtils.getLogger();
    private static final int FLASH_TICKS = 12;
    private static final int SKIP_GRACE = 14;

    private static Cutscene scene = null;
    private static String sceneName = "";
    private static int t = 0;
    private static int flashLeft = 0;

    private static ArmorStand cam = null;
    private static LocalPlayer startPlayer = null;
    private static Vec3 startEye = Vec3.ZERO;
    private static Vec3 anchor = Vec3.ZERO;
    private static double fwdX = 0.0, fwdZ = 1.0;        // «вперёд» пространства сцены
    private static float lockYaw = 0f, lockPitch = 0f;

    // состояние кадра
    private static double frameTime = 0.0;               // t + partialTick, для HUD, тумана и кривой
    private static long lastFrameNanos = System.nanoTime();
    private static Vec3 liveSmooth = null;               // глаза игрока для player_live (сервер толкает игрока)
    private static Vec3 execSmooth = null;               // позиция Палача, чуть сглаженная по времени
    private static ExecutionerEntity trackedExec = null; // за кем следим (обновляется раз в тик)

    // поза камеры текущего кадра
    private static double cx, cy, cz;
    private static float cYaw, cPitch, frameFov = 1f;

    public static boolean isActive() {
        return scene != null;
    }

    // ------------------------------------------------------------------ запуск и остановка

    /** @param ax,ay,az точка-якорь для сцен в пространстве "anchor" (остальным не нужна) */
    public static void play(String name, double ax, double ay, double az) {
        if (!DreamConfig.CLIENT.cutscenes.get()) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null || !name.matches("[a-z0-9_]{1,40}")) return;
        Cutscene c = load(mc, name);
        if (c == null || c.keys.size() < 2) return;
        if (scene != null) stop(false);

        scene = c;
        sceneName = name;
        t = 0;
        startPlayer = player;
        startEye = player.getEyePosition();
        anchor = new Vec3(ax, ay, az);
        lockYaw = player.getYRot();
        lockPitch = player.getXRot();
        liveSmooth = null;
        execSmooth = null;
        double yawRad = Math.toRadians(lockYaw);
        fwdX = -Math.sin(yawRad);
        fwdZ = Math.cos(yawRad);
        if (c.space == Cutscene.Space.ANCHOR) {            // «вперёд» от якоря на игрока
            double dx = startEye.x - ax, dz = startEye.z - az;
            double l = Math.sqrt(dx * dx + dz * dz);
            if (l > 1e-3) {
                fwdX = dx / l;
                fwdZ = dz / l;
            }
        }
        cam = new ArmorStand(EntityType.ARMOR_STAND, mc.level);
        cam.setInvisible(true);
        cam.noPhysics = true;
        findExecutioner(mc);
        frameTime = 0.0;
        lastFrameNanos = System.nanoTime();
        pose(mc, 0.0, 0f, 0.0);                            // первый кадр уже в правильной позе
        applyToCamera();
        mc.setCameraEntity(cam);
    }

    /** Остановить сцену. flash = белая вспышка (после пропуска). */
    public static void stop(boolean flash) {
        Minecraft mc = Minecraft.getInstance();
        if (scene != null && mc.player != null) mc.setCameraEntity(mc.player);
        scene = null;
        cam = null;
        startPlayer = null;
        trackedExec = null;
        t = 0;
        if (flash) flashLeft = FLASH_TICKS;
    }

    private static Cutscene load(Minecraft mc, String name) {
        ResourceLocation rl = ResourceLocation.fromNamespaceAndPath(Dreams.MODID, "cutscenes/" + name + ".json");
        Optional<net.minecraft.server.packs.resources.Resource> res = mc.getResourceManager().getResource(rl);
        if (res.isEmpty()) {
            LOGGER.warn("[dreams] cutscene not found: {}", rl);
            return null;
        }
        try (Reader r = res.get().openAsReader()) {
            return Cutscene.parse(JsonParser.parseReader(r).getAsJsonObject());
        } catch (Exception e) {
            LOGGER.warn("[dreams] cutscene {} is broken: {}", rl, e.toString());
            return null;
        }
    }

    // ------------------------------------------------------------------ расчёт камеры

    private static final double[] TMP = new double[3];

    /** Мировая точка из координат сцены: [вправо, вверх, вперёд]. */
    private static Vec3 toWorld(Vec3 origin, double[] rel) {
        double rx = -fwdZ, rz = fwdX;                      // вправо от направления «вперёд»
        return new Vec3(origin.x + rel[0] * rx + rel[2] * fwdX, origin.y + rel[1], origin.z + rel[0] * rz + rel[2] * fwdZ);
    }

    /** Ближайший Палач: раз в тик. Позицию для кадра берём у самой сущности (интерполированную). */
    private static void findExecutioner(Minecraft mc) {
        trackedExec = null;
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) return;
        double best = Double.MAX_VALUE;
        for (ExecutionerEntity e : mc.level.getEntitiesOfClass(ExecutionerEntity.class, p.getBoundingBox().inflate(150.0))) {
            double d = e.distanceToSqr(p);
            if (d < best) {
                best = d;
                trackedExec = e;
            }
        }
    }

    /** Коэффициент сглаживания по времени: не зависит от FPS. */
    private static double follow(double dt, double tau) {
        return 1.0 - Math.exp(-dt / tau);
    }

    private static Vec3 execTarget(float part, double dt) {
        ExecutionerEntity e = trackedExec;
        if (e == null || e.isRemoved()) {
            execSmooth = null;
            return null;
        }
        Vec3 raw = e.getPosition(part);
        // Лёгкий low-pass (~0.1 с): при узком FOV дрожь цели взгляда сильно увеличивается.
        execSmooth = execSmooth == null || execSmooth.distanceToSqr(raw) > 100.0 ? raw : execSmooth.lerp(raw, follow(dt, 0.10));
        return execSmooth;
    }

    /** Глаза игрока для player_live: сервер толкает игрока каждый тик, поэтому слегка сглажены. */
    private static Vec3 liveOrigin(LocalPlayer player, float part, double dt) {
        Vec3 eye = player != null ? player.getEyePosition(part) : startEye;
        liveSmooth = liveSmooth == null || liveSmooth.distanceToSqr(eye) > 64.0 ? eye : liveSmooth.lerp(eye, follow(dt, 0.10));
        return liveSmooth;
    }

    private static Vec3 lookWorld(Vec3 origin, Cutscene.Look l, Vec3 execPos) {
        if (l.p != null) return toWorld(origin, l.p);
        if (l.entity != null && execPos != null) return execPos.add(l.off[0], l.off[1], l.off[2]);
        if (SkyWhales.bodyPointNow(l.whale, l.s, TMP)) return new Vec3(TMP[0] + l.off[0], TMP[1] + l.off[1], TMP[2] + l.off[2]);
        return origin.add(fwdX * 30.0, 4.0, fwdZ * 30.0);   // цели нет: смотреть вперёд
    }

    private interface KeyVec {
        Vec3 of(Cutscene.Key k);
    }

    /** Скорость в ключе j (единиц за тик): по соседям с учётом времени между ними; на концах ноль. */
    private static Vec3 tangent(List<Cutscene.Key> ks, int j, KeyVec f) {
        if (j <= 0 || j >= ks.size() - 1) return Vec3.ZERO;
        double span = ks.get(j + 1).t - ks.get(j - 1).t;
        if (span <= 0) return Vec3.ZERO;
        return f.of(ks.get(j + 1)).subtract(f.of(ks.get(j - 1))).scale(1.0 / span);
    }

    /** Кривая Эрмита на отрезке i..i+1: гладкая по скорости даже при неравномерных ключах. */
    private static Vec3 curve(List<Cutscene.Key> ks, int i, double u, KeyVec f) {
        Cutscene.Key a = ks.get(i), b = ks.get(i + 1);
        double dt = b.t - a.t;
        Vec3 pa = f.of(a), pb = f.of(b);
        Vec3 ma = tangent(ks, i, f), mb = tangent(ks, i + 1, f);
        double u2 = u * u, u3 = u2 * u;
        double h00 = 2 * u3 - 3 * u2 + 1, h10 = u3 - 2 * u2 + u, h01 = -2 * u3 + 3 * u2, h11 = u3 - u2;
        return pa.scale(h00).add(ma.scale(h10 * dt)).add(pb.scale(h01)).add(mb.scale(h11 * dt));
    }

    private static float wrapDeg(float a) {
        a %= 360f;
        if (a >= 180f) a -= 360f;
        if (a < -180f) a += 360f;
        return a;
    }

    private static float smooth(float x) {
        x = Mth.clamp(x, 0f, 1f);
        return x * x * (3f - 2f * x);
    }

    /** Поза камеры в непрерывный момент time (тики, дробные): результат в cx..cPitch, frameFov. */
    private static void pose(Minecraft mc, double time, float part, double dt) {
        Cutscene c = scene;
        LocalPlayer player = mc.player;
        final Vec3 origin = switch (c.space) {
            case PLAYER -> startEye;
            case PLAYER_LIVE -> liveOrigin(player, part, dt);
            case ANCHOR -> anchor;
        };
        final Vec3 execPos = execTarget(part, dt);
        List<Cutscene.Key> ks = c.keys;
        int n = ks.size();
        int i = 0;
        while (i < n - 2 && time >= ks.get(i + 1).t) i++;
        Cutscene.Key k1 = ks.get(i), k2 = ks.get(i + 1);
        double u = k2.t > k1.t ? Mth.clamp((time - k1.t) / (double) (k2.t - k1.t), 0.0, 1.0) : 0.0;

        Vec3 pos = curve(ks, i, u, k -> toWorld(origin, k.pos));
        Vec3 look = curve(ks, i, u, k -> lookWorld(origin, k.look, execPos));
        float fov = (float) Mth.lerp(smooth((float) u), k1.fov, k2.fov);

        double dx = look.x - pos.x, dy = look.y - pos.y, dz = look.z - pos.z;
        float yaw = (float) Math.toDegrees(-Math.atan2(dx, dz));
        float pitch = (float) Math.toDegrees(-Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));

        // плавный вход и выход: смешиваем с обычным видом игрока
        float wIn = c.blendIn > 0 ? smooth(1f - (float) time / c.blendIn) : 0f;
        float wOut = c.blendOut > 0 ? smooth((float) (time - (c.duration - c.blendOut)) / c.blendOut) : 0f;
        float w = Math.max(wIn, wOut);
        if (w > 0f && player != null) {
            pos = pos.lerp(player.getEyePosition(part), w);
            yaw = yaw + wrapDeg(player.getViewYRot(part) - yaw) * w;
            pitch = Mth.lerp(w, pitch, player.getViewXRot(part));
            fov = Mth.lerp(w, fov, 1f);
        }
        if (c.shake > 0f && !DreamConfig.CLIENT.reducedMotion.get()) {   // ручная камера: медленное покачивание
            float amp = c.shake * DreamConfig.CLIENT.cutsceneShake.get().floatValue();
            float tt = (float) time;
            float sh = amp * (0.5f + 0.5f * smooth(Math.min(1f, tt / 20f)));
            yaw += sh * (Mth.sin(tt * 0.31f) * 0.6f + Mth.sin(tt * 0.57f + 1.0f) * 0.4f);
            pitch += sh * (Mth.sin(tt * 0.43f + 0.5f) * 0.6f + Mth.sin(tt * 0.71f) * 0.4f);
        }
        cx = pos.x; cy = pos.y; cz = pos.z;
        cYaw = yaw; cPitch = pitch; frameFov = fov;
    }

    /**
     * Ставит камеру-сущность ровно в позу кадра. Старые координаты приравнены к новым: чтобы ванильная
     * интерполяция по partialTick ничего не добавляла (иначе поза снова превратилась бы в ломаную).
     */
    private static void applyToCamera() {
        if (cam == null) return;
        float eh = cam.getEyeHeight();
        cam.xo = cx; cam.yo = cy - eh; cam.zo = cz;
        cam.xOld = cx; cam.yOld = cy - eh; cam.zOld = cz;
        cam.setPos(cx, cy - eh, cz);
        cam.yRotO = cYaw;
        cam.xRotO = cPitch;
        cam.setYRot(cYaw);
        cam.setXRot(cPitch);
    }

    // ------------------------------------------------------------------ кадр

    /** Каждый кадр, ДО отрисовки мира: здесь считается плавная поза камеры. */
    @SubscribeEvent
    public static void onRenderFrame(RenderFrameEvent.Pre event) {
        if (scene == null || cam == null) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.isPaused()) return;
        long now = System.nanoTime();
        double dt = Mth.clamp((now - lastFrameNanos) / 1.0e9, 0.0, 0.1);
        lastFrameNanos = now;
        float part = Mth.clamp(event.getPartialTick().getGameTimeDeltaPartialTick(false), 0f, 1f);
        frameTime = Math.min(t + (double) part, scene.duration);
        pose(mc, frameTime, part, dt);
        applyToCamera();
    }

    // ------------------------------------------------------------------ тик

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            scene = null;
            cam = null;
            flashLeft = 0;
            return;
        }
        if (mc.isPaused()) return;
        if (flashLeft > 0) flashLeft--;
        if (scene == null) return;
        if (mc.player != startPlayer || mc.level == null) {   // умер, сменил мир
            stop(false);
            return;
        }
        t++;
        if (t >= scene.duration) {
            stop(false);
            return;
        }
        for (Cutscene.Snd s : scene.sounds) {
            if (s.t == t) playSound(mc, s);
        }
        if (scene.skippable && t > SKIP_GRACE && mc.options.keyJump.isDown()) {
            stop(true);
            return;
        }
        if (scene.lockLook) {
            LocalPlayer p = mc.player;
            p.setYRot(lockYaw);
            p.setXRot(lockPitch);
            p.yRotO = lockYaw;
            p.xRotO = lockPitch;
        }
        findExecutioner(mc);
    }

    private static void playSound(Minecraft mc, Cutscene.Snd s) {
        ResourceLocation rl = ResourceLocation.tryParse(s.sound);
        if (rl == null) return;
        Optional<SoundEvent> ev = BuiltInRegistries.SOUND_EVENT.getOptional(rl);
        if (ev.isEmpty()) {
            LOGGER.warn("[dreams] cutscene {}: unknown sound {}", sceneName, s.sound);
            return;
        }
        mc.getSoundManager().play(SimpleSoundInstance.forUI(ev.get(), s.pitch, s.volume));
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        scene = null;
        cam = null;
        flashLeft = 0;
    }

    // ------------------------------------------------------------------ подавление обычного управления и HUD

    @SubscribeEvent
    public static void onMovement(MovementInputUpdateEvent event) {
        if (scene == null) return;
        Input in = event.getInput();
        in.forwardImpulse = 0f;
        in.leftImpulse = 0f;
        in.up = false;
        in.down = false;
        in.left = false;
        in.right = false;
        in.jumping = false;
        in.shiftKeyDown = false;
    }

    @SubscribeEvent
    public static void onInteract(InputEvent.InteractionKeyMappingTriggered event) {
        if (scene != null) {
            event.setCanceled(true);
            event.setSwingHand(false);
        }
    }

    @SubscribeEvent
    public static void onHand(RenderHandEvent event) {
        if (scene != null) event.setCanceled(true);
    }

    @SubscribeEvent
    public static void onGuiLayer(RenderGuiLayerEvent.Pre event) {
        if (scene != null) event.setCanceled(true);
    }

    @SubscribeEvent
    public static void onFov(ViewportEvent.ComputeFov event) {
        if (scene == null) return;
        event.setFOV(event.getFOV() * frameFov);
    }

    /** Дальность тумана, которую требует сцена (0 = не требует); плавно нарастает и спадает. */
    public static float fogFar() {
        if (scene == null || scene.fog <= 0f) return 0f;
        float tf = (float) frameTime;
        return scene.fog * smooth(Math.min(tf / 24f, (scene.duration - tf) / 24f));
    }

    // ------------------------------------------------------------------ полосы, субтитры, вспышки

    @SubscribeEvent
    public static void onGui(RenderGuiEvent.Post event) {
        GuiGraphics g = event.getGuiGraphics();
        int w = g.guiWidth(), h = g.guiHeight();
        Minecraft mc = Minecraft.getInstance();
        if (scene != null) {
            float tf = (float) frameTime;
            int bh = 0;
            if (scene.bars) {
                float e = smooth(Math.min(tf / 18f, (scene.duration - tf) / 18f));
                bh = (int) (h * 0.115f * e);
                g.fill(0, 0, w, bh, 0xFF000000);
                g.fill(0, h - bh, w, h, 0xFF000000);
            }
            for (Cutscene.Sub s : scene.subs) {
                if (tf < s.t || tf > s.t + s.d) continue;
                float a = Math.min(1f, Math.min((tf - s.t) / 8f, (s.t + s.d - tf) / 8f));
                int ai = (int) (255 * Mth.clamp(a, 0f, 1f));
                if (ai < 10) continue;
                int y = h - Math.max(bh, 24) / 2 - 4;
                g.drawCenteredString(mc.font, Component.translatable(s.key), w / 2, y, (ai << 24) | 0xFFF2D0);
            }
            if (scene.skippable && tf > SKIP_GRACE && tf < scene.duration - 20) {
                g.drawString(mc.font, Component.translatable("cutscene.dreams.skip"), w - mc.font.width(Component.translatable("cutscene.dreams.skip")) - 8,
                        h - 12, 0x66FFFFFF, false);
            }
            if (scene.fadeOut > 0 && tf > scene.duration - scene.fadeOut) {
                int a = (int) (255 * smooth((tf - (scene.duration - scene.fadeOut)) / scene.fadeOut));
                g.fill(0, 0, w, h, (a << 24) | scene.fadeOutColor);
            }
            if (scene.fadeIn > 0 && tf < scene.fadeIn) {
                int a = (int) (255 * smooth(1f - tf / scene.fadeIn));
                g.fill(0, 0, w, h, (a << 24) | scene.fadeColor);
            }
        }
        if (flashLeft > 0) {
            int a = (int) (255 * Mth.clamp(flashLeft / (float) FLASH_TICKS, 0f, 1f) * 0.85f);
            g.fill(0, 0, w, h, (a << 24) | 0xFFF6DC);
        }
    }
}
