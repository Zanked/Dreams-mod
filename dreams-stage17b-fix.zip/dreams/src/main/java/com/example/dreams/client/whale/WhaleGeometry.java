package com.example.dreams.client.whale;

/**
 * Процедурный небесный кит: гладкое тело из колец вдоль изогнутого позвоночника, грудные плавники, хвостовые лопасти
 * и маленький спинной плавник. Каждый кадр форма пересчитывается заново: по телу бежит волна от головы к хвосту,
 * плавники и хвост машут, весь кит изгибается по дуге полёта.
 *
 * Это чистая математика без классов Minecraft: результат уходит в {@link Sink}, по четыре вершины на четырёхугольник.
 * Координаты на выходе уже относительны камере (камера в нуле), поэтому грани, смотрящие от камеры, отбрасываются здесь же.
 * Локальные оси кита: x вправо, y вверх, z вперёд (нос на +z).
 */
public final class WhaleGeometry {

    public interface Sink {
        void vertex(float x, float y, float z, float u, float v, float nx, float ny, float nz);
    }

    /** Сегментов вдоль тела и вокруг тела. */
    public static final int NR = 40;
    public static final int NS = 20;
    /** Тело занимает в текстуре верхние 0..BODY_V по вертикали, плавники нижнюю полосу. */
    public static final float BODY_V = 0.745f;
    /** Период взмаха хвоста, тики. */
    public static final float PERIOD = 100f;

    // пропорции (доли длины)
    private static final float HALF_W = 0.125f;
    private static final float HALF_H = 0.110f;

    private static final float[] PROF_S = new float[NR + 1];
    private static final float[] PROF_F = new float[NR + 1];
    private static final float[] SIN = new float[NS + 1];
    private static final float[] COS = new float[NS + 1];
    private static final int FLIPPER_RING;
    private static final int DORSAL_A;
    private static final int DORSAL_B;

    static {
        for (int i = 0; i <= NR; i++) {
            float s = (float) Math.pow(i / (float) NR, 1.35);   // кольца гуще у носа
            PROF_S[i] = s;
            PROF_F[i] = profile(s);
        }
        for (int j = 0; j <= NS; j++) {
            double a = Math.PI * 2.0 * j / NS;
            SIN[j] = (float) Math.sin(a);
            COS[j] = (float) Math.cos(a);
        }
        FLIPPER_RING = ringAt(0.30f);
        DORSAL_A = ringAt(0.62f);
        DORSAL_B = ringAt(0.74f);
    }

    /** Толщина тела (0..1) в точке s вдоль тела: s=0 нос, s=1 хвост. */
    private static float profile(float s) {
        final float head = 0.30f;
        if (s < head) {                                   // округлая голова
            float q = (head - s) / head;
            return (float) Math.sqrt(Math.max(0.0, 1.0 - q * q));
        }
        if (s < 0.50f) return 1.0f - 0.04f * (s - head) / (0.50f - head);
        float q = (s - 0.50f) / 0.50f;                    // сужение к хвосту: тело держится плотным и сужается ближе к концу
        float c = 0.5f + 0.5f * (float) Math.cos(Math.PI * Math.pow(q, 1.35));
        return 0.17f + 0.79f * c;
    }

    private static int ringAt(float s) {
        for (int i = 0; i <= NR; i++) if (PROF_S[i] >= s) return i;
        return NR;
    }

    // ---- рабочие массивы (по экземпляру, чтобы не создавать мусор каждый кадр)
    private final float[] sx = new float[NR + 1], sy = new float[NR + 1], sz = new float[NR + 1];      // позвоночник
    private final float[] tx = new float[NR + 1], ty = new float[NR + 1], tz = new float[NR + 1];      // касательная вперёд
    private final float[] rx = new float[NR + 1], ry = new float[NR + 1], rz = new float[NR + 1];      // вправо
    private final float[] ux = new float[NR + 1], uy = new float[NR + 1], uz = new float[NR + 1];      // вверх
    private final float[] ra = new float[NR + 1], rb = new float[NR + 1];                              // полуоси кольца
    private static final int GRID = (NR + 1) * (NS + 1);
    private final float[] vx = new float[GRID], vy = new float[GRID], vz = new float[GRID];            // вершины (камера в нуле)
    private final float[] gx = new float[GRID], gy = new float[GRID], gz = new float[GRID];            // нормали

    // положение кита
    private float ox, oy, oz, fx, fz;
    private float cx, cy, cz;                 // результат tp/tn

    /** Локальная точка -> относительно камеры. */
    private void tp(float lx, float ly, float lz) {
        cx = ox + lx * fz + lz * fx;
        cy = oy + ly;
        cz = oz - lx * fx + lz * fz;
    }

    /** Локальный вектор -> мировой (без сдвига). */
    private void tn(float lx, float ly, float lz) {
        cx = lx * fz + lz * fx;
        cy = ly;
        cz = -lx * fx + lz * fz;
    }

    /**
     * @param o*   положение центра кита относительно камеры
     * @param fdx  направление вперёд (горизонталь, единичный вектор x/z)
     * @param len  длина кита в блоках
     * @param bend кривизна дуги полёта (1/радиус, знак: куда загибается тело; + вправо от кита)
     * @param time время в тиках (дробное)
     */
    public void render(Sink sink, double ox, double oy, double oz, double fdx, double fdz, float len, float bend, float time) {
        this.ox = (float) ox;
        this.oy = (float) oy;
        this.oz = (float) oz;
        this.fx = (float) fdx;
        this.fz = (float) fdz;
        float w = (float) (Math.PI * 2.0 * time / PERIOD);

        buildSpine(len, bend, w);
        buildBody(len);
        emitBody(sink);
        emitFlipper(sink, len, w, 1);
        emitFlipper(sink, len, w, -1);
        emitDorsal(sink, len);
        emitFlukes(sink, len, w);
    }

    // ------------------------------------------------------------------ позвоночник и тело

    private void buildSpine(float len, float bend, float w) {
        for (int i = 0; i <= NR; i++) {
            float s = PROF_S[i];
            float zl = len * (0.5f - s);
            float env = (float) Math.pow(s, 1.7);
            float ph = w - 4.4f * s;                         // бегущая к хвосту волна
            sy[i] = len * 0.050f * env * (float) Math.sin(ph) + len * 0.006f * (float) Math.sin(w * 0.5f) * (1f - s);
            sx[i] = len * 0.013f * env * (float) Math.sin(ph * 0.8f + 1.3f) + 0.5f * bend * zl * zl;
            sz[i] = zl;
        }
        for (int i = 0; i <= NR; i++) {
            int a = Math.max(i - 1, 0), b = Math.min(i + 1, NR);
            float dx = sx[a] - sx[b], dy = sy[a] - sy[b], dz = sz[a] - sz[b];
            float l = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (l < 1e-5f) { dx = 0; dy = 0; dz = 1; l = 1; }
            tx[i] = dx / l; ty[i] = dy / l; tz[i] = dz / l;
            // вправо = up x T (нормированный), вверх = T x вправо
            float rxv = tz[i], rzv = -tx[i];
            float hl = (float) Math.sqrt(rxv * rxv + rzv * rzv);
            if (hl < 1e-5f) { rxv = 1; rzv = 0; hl = 1; }
            rx[i] = rxv / hl; ry[i] = 0f; rz[i] = rzv / hl;
            ux[i] = ty[i] * rz[i] - tz[i] * ry[i];
            uy[i] = tz[i] * rx[i] - tx[i] * rz[i];
            uz[i] = tx[i] * ry[i] - ty[i] * rx[i];
        }
    }

    private void buildBody(float len) {
        for (int i = 0; i <= NR; i++) {
            float f = PROF_F[i];
            ra[i] = Math.max(HALF_W * len * f, 0.02f);
            rb[i] = Math.max(HALF_H * len * f, 0.02f);
            for (int j = 0; j <= NS; j++) {
                float sn = SIN[j], cs = COS[j];
                float a = ra[i];
                float b = rb[i] * (1f + 0.07f * cs);          // брюхо чуть полнее спины
                float lx = sx[i] + rx[i] * sn * a - ux[i] * cs * b;
                float ly = sy[i] + ry[i] * sn * a - uy[i] * cs * b;
                float lz = sz[i] + rz[i] * sn * a - uz[i] * cs * b;
                float nlx = rx[i] * (sn / a) - ux[i] * (cs / b);
                float nly = ry[i] * (sn / a) - uy[i] * (cs / b);
                float nlz = rz[i] * (sn / a) - uz[i] * (cs / b);
                float nl = (float) Math.sqrt(nlx * nlx + nly * nly + nlz * nlz);
                if (nl < 1e-6f) nl = 1f;
                int k = i * (NS + 1) + j;
                tp(lx, ly, lz);
                vx[k] = cx; vy[k] = cy; vz[k] = cz;
                tn(nlx / nl, nly / nl, nlz / nl);
                gx[k] = cx; gy[k] = cy; gz[k] = cz;
            }
        }
    }

    private void emitBody(Sink sink) {
        for (int i = 0; i < NR; i++) {
            float v0 = PROF_S[i] * BODY_V, v1 = PROF_S[i + 1] * BODY_V;
            for (int j = 0; j < NS; j++) {
                int k00 = i * (NS + 1) + j, k01 = k00 + 1, k10 = k00 + (NS + 1), k11 = k10 + 1;
                float nx = gx[k00] + gx[k01] + gx[k10] + gx[k11];
                float ny = gy[k00] + gy[k01] + gy[k10] + gy[k11];
                float nz = gz[k00] + gz[k01] + gz[k10] + gz[k11];
                float qx = vx[k00] + vx[k01] + vx[k10] + vx[k11];
                float qy = vy[k00] + vy[k01] + vy[k10] + vy[k11];
                float qz = vz[k00] + vz[k01] + vz[k10] + vz[k11];
                if (nx * qx + ny * qy + nz * qz >= 0f) continue;   // обращена от камеры (камера в нуле)
                float u0 = j / (float) NS, u1 = (j + 1) / (float) NS;
                sink.vertex(vx[k00], vy[k00], vz[k00], u0, v0, gx[k00], gy[k00], gz[k00]);
                sink.vertex(vx[k10], vy[k10], vz[k10], u0, v1, gx[k10], gy[k10], gz[k10]);
                sink.vertex(vx[k11], vy[k11], vz[k11], u1, v1, gx[k11], gy[k11], gz[k11]);
                sink.vertex(vx[k01], vy[k01], vz[k01], u1, v0, gx[k01], gy[k01], gz[k01]);
            }
        }
    }

    // ------------------------------------------------------------------ тонкие пластины (плавники)

    private final float[] pa = new float[5], pb = new float[5], pc = new float[5], pd = new float[5];

    /**
     * Двусторонняя пластина: рисуется только та поверхность, что смотрит на камеру, со смещением th по нормали.
     * Точки: {x, y, z, u, v} в локальных координатах кита.
     */
    private void plate(Sink sink, float[] a, float[] b, float[] c, float[] d, float nxl, float nyl, float nzl, float th) {
        float mx = (a[0] + b[0] + c[0] + d[0]) * 0.25f, my = (a[1] + b[1] + c[1] + d[1]) * 0.25f, mz = (a[2] + b[2] + c[2] + d[2]) * 0.25f;
        tp(mx, my, mz);
        float qx = cx, qy = cy, qz = cz;
        tn(nxl, nyl, nzl);
        float nx = cx, ny = cy, nz = cz;
        float side = (nx * qx + ny * qy + nz * qz) < 0f ? 1f : -1f;
        float ox2 = nxl * th * side, oy2 = nyl * th * side, oz2 = nzl * th * side;
        emitPoint(sink, a, ox2, oy2, oz2, nxl * side, nyl * side, nzl * side);
        emitPoint(sink, b, ox2, oy2, oz2, nxl * side, nyl * side, nzl * side);
        emitPoint(sink, c, ox2, oy2, oz2, nxl * side, nyl * side, nzl * side);
        emitPoint(sink, d, ox2, oy2, oz2, nxl * side, nyl * side, nzl * side);
    }

    private void emitPoint(Sink sink, float[] p, float dx, float dy, float dz, float nlx, float nly, float nlz) {
        tp(p[0] + dx, p[1] + dy, p[2] + dz);
        float x = cx, y = cy, z = cz;
        tn(nlx, nly, nlz);
        sink.vertex(x, y, z, p[3], p[4], cx, cy, cz);
    }

    private static void set(float[] p, float x, float y, float z, float u, float v) {
        p[0] = x; p[1] = y; p[2] = z; p[3] = u; p[4] = v;
    }

    private static float clamp01(float x) {
        return x < 0f ? 0f : x > 1f ? 1f : x;
    }

    // ------------------------------------------------------------------ грудные плавники

    private final float[][] leE = new float[12][3], teE = new float[12][3];

    private void emitFlipper(Sink sink, float len, float w, int side) {
        final int K = 6;
        int i = FLIPPER_RING;
        float a = ra[i], b = rb[i];
        float rootX = sx[i] + rx[i] * side * a * 0.90f - ux[i] * b * 0.30f;
        float rootY = sy[i] + ry[i] * side * a * 0.90f - uy[i] * b * 0.30f;
        float rootZ = sz[i] + rz[i] * side * a * 0.90f - uz[i] * b * 0.30f;
        float ang = 0.55f + 0.30f * (float) Math.sin(w * 0.9f + side * 0.9f + 0.6f);   // взмах вниз-вверх
        float ca = (float) Math.cos(ang), sa = (float) Math.sin(ang);
        float dx = rx[i] * side * ca * 0.95f - ux[i] * sa - tx[i] * 0.28f;
        float dy = ry[i] * side * ca * 0.95f - uy[i] * sa - ty[i] * 0.28f;
        float dz = rz[i] * side * ca * 0.95f - uz[i] * sa - tz[i] * 0.28f;
        float dl = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        dx /= dl; dy /= dl; dz /= dl;
        // нормаль пластины = d x T
        float nx = dy * tz[i] - dz * ty[i], ny = dz * tx[i] - dx * tz[i], nz = dx * ty[i] - dy * tx[i];
        float nl = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
        if (nl < 1e-6f) return;
        nx /= nl; ny /= nl; nz /= nl;
        float FL = 0.21f * len, C = 0.085f * len, th = 0.006f * len;
        for (int k = 0; k <= K; k++) {
            float t = k / (float) K;
            float lead = 0.12f * FL * t * t;
            float chord = C * (1f - 0.72f * t) * (0.75f + 0.25f * (float) Math.sin(Math.PI * t * 0.9 + 0.4));
            float flutter = 0.02f * len * t * (float) Math.sin(w * 1.8f - 3f * t + side);
            float bx = rootX + dx * FL * t + nx * flutter - tx[i] * lead;
            float by = rootY + dy * FL * t + ny * flutter - ty[i] * lead;
            float bz = rootZ + dz * FL * t + nz * flutter - tz[i] * lead;
            leE[k][0] = bx; leE[k][1] = by; leE[k][2] = bz;
            teE[k][0] = bx - tx[i] * chord; teE[k][1] = by - ty[i] * chord; teE[k][2] = bz - tz[i] * chord;
        }
        for (int k = 0; k < K; k++) {
            float u0 = 0.02f + 0.46f * (k / (float) K), u1 = 0.02f + 0.46f * ((k + 1) / (float) K);
            set(pa, leE[k][0], leE[k][1], leE[k][2], u0, 0.76f);
            set(pb, teE[k][0], teE[k][1], teE[k][2], u0, 0.98f);
            set(pc, teE[k + 1][0], teE[k + 1][1], teE[k + 1][2], u1, 0.98f);
            set(pd, leE[k + 1][0], leE[k + 1][1], leE[k + 1][2], u1, 0.76f);
            plate(sink, pa, pb, pc, pd, nx, ny, nz, th);
        }
    }

    // ------------------------------------------------------------------ спинной плавник

    private void emitDorsal(Sink sink, float len) {
        int ia = DORSAL_A, ib = DORSAL_B;
        float hF = 0.05f * len, th = 0.005f * len;
        float ax = sx[ia] + ux[ia] * rb[ia] * 0.93f, ay = sy[ia] + uy[ia] * rb[ia] * 0.93f, az = sz[ia] + uz[ia] * rb[ia] * 0.93f;
        float bx = sx[ib] + ux[ib] * rb[ib] * 0.93f, by = sy[ib] + uy[ib] * rb[ib] * 0.93f, bz = sz[ib] + uz[ib] * rb[ib] * 0.93f;
        float tipX = ax + (bx - ax) * 0.8f + ux[ia] * hF - tx[ia] * 0.01f * len;
        float tipY = ay + (by - ay) * 0.8f + uy[ia] * hF - ty[ia] * 0.01f * len;
        float tipZ = az + (bz - az) * 0.8f + uz[ia] * hF - tz[ia] * 0.01f * len;
        set(pa, ax, ay, az, 0.90f, 0.98f);
        set(pb, bx, by, bz, 0.98f, 0.98f);
        set(pc, tipX, tipY, tipZ, 0.96f, 0.80f);
        set(pd, tipX, tipY, tipZ, 0.92f, 0.80f);
        plate(sink, pa, pb, pc, pd, rx[ia], ry[ia], rz[ia], th);
    }

    // ------------------------------------------------------------------ хвостовые лопасти

    private void emitFlukes(Sink sink, float len, float w) {
        final int K = 10;
        int i = NR;
        float half = 0.235f * len, cmax = 0.125f * len, th = 0.007f * len;
        float fl = 0.30f * (float) Math.sin(w - 4.4f - 1.0f);                 // лопасти чуть запаздывают за хвостом
        float cf = (float) Math.cos(fl), sf = (float) Math.sin(fl);
        float bx = -tx[i] * cf - ux[i] * sf, by = -ty[i] * cf - uy[i] * sf, bz = -tz[i] * cf - uz[i] * sf;   // назад
        float nx = by * rz[i] - bz * ry[i], ny = bz * rx[i] - bx * rz[i], nz = bx * ry[i] - by * rx[i];     // back x right
        float nl = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
        if (nl < 1e-6f) return;
        nx /= nl; ny /= nl; nz /= nl;
        for (int side = -1; side <= 1; side += 2) {
            for (int k = 0; k <= K; k++) {
                float t = k / (float) K;
                float le = 0.13f * len * (float) Math.pow(t, 1.6);
                float chord = cmax * (1f - 0.55f * t) * (1f - 0.55f * (float) Math.pow(1f - t, 6));   // вырез посередине
                float up = 0.025f * len * t * t + 0.012f * len * t * (float) Math.sin(w * 1.5f - 4f * t);
                float px = sx[i] + rx[i] * side * half * t + ux[i] * up;
                float py = sy[i] + ry[i] * side * half * t + uy[i] * up;
                float pz = sz[i] + rz[i] * side * half * t + uz[i] * up;
                leE[k][0] = px + bx * le; leE[k][1] = py + by * le; leE[k][2] = pz + bz * le;
                teE[k][0] = px + bx * (le + chord); teE[k][1] = py + by * (le + chord); teE[k][2] = pz + bz * (le + chord);
            }
            for (int k = 0; k < K; k++) {
                float u0 = 0.52f + 0.46f * (k / (float) K), u1 = 0.52f + 0.46f * ((k + 1) / (float) K);
                set(pa, leE[k][0], leE[k][1], leE[k][2], u0, 0.76f);
                set(pb, teE[k][0], teE[k][1], teE[k][2], u0, 0.98f);
                set(pc, teE[k + 1][0], teE[k + 1][1], teE[k + 1][2], u1, 0.98f);
                set(pd, leE[k + 1][0], leE[k + 1][1], leE[k + 1][2], u1, 0.76f);
                plate(sink, pa, pb, pc, pd, nx, ny, nz, th);
            }
        }
    }
}
