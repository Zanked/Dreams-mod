package com.example.dreams.dream;

import com.example.dreams.DreamConfig;
import com.example.dreams.attachment.DreamState;
import com.example.dreams.block.ModBlocks;
import com.example.dreams.network.DreamCutscenePayload;
import com.example.dreams.network.DreamFxPayload;
import com.example.dreams.sound.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.network.protocol.game.ClientboundBlockUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Пространство лжёт: КОРИДОР Иной стороны. Из фейковых ржавых блоков (стены и потолок поверх настоящего воздуха)
 * впереди игрока вырастает тоннель. Стоит зайти поглубже, как за спиной гулко захлопывается стена и потом идёт следом;
 * впереди тоннель достраивается сам, пока не кончится земля или длина; середина сужается до одного блока и низкого потолка.
 * Сзади, в запертом тоннеле, раздаются шаги. Выход открыт всегда: у тоннеля нет торца, он просто растворяется, когда игрок выходит.
 *
 * Безопасность: фейки только ТВЁРДЫЕ поверх воздуха или другого твёрдого, внутрь тоннеля мы ничего не кладём, кроме заглушки
 * за спиной (она отодвигается вместе с игроком), поэтому сервер никогда не откатывает движение. Тоннель строится только по
 * проходимому месту (нет препятствий, перепад пола не больше 1), иначе он просто кончается.
 */
final class OtherworldHorror {

    private OtherworldHorror() {}

    private static final int LEAD = 22;           // сколько сегментов строим впереди игрока
    private static final int TRAIL = 12;          // сколько оставляем позади
    private static final int PLUG_BEHIND = 5;     // заглушка в стольких блоках за спиной
    private static final int SQUEEZE_LEN = 26;
    private static final int GIVE_UP_TICKS = 1500;

    // ------------------------------------------------------------------ жизненный цикл

    static void tick(ServerPlayer player, ServerLevel level, DreamState s, int t) {
        if (!DreamConfig.COMMON.tunnel.get()) return;
        RandomSource r = player.getRandom();
        if (s.tunnelOn) {
            tickTunnel(player, level, s, t, r);
            return;
        }
        if (s.nextTunnelAt == 0) s.nextTunnelAt = DreamTimeline.OTHERWORLD_START + 700 + r.nextInt(500);
        if (t < s.nextTunnelAt) return;
        if (s.executionerId != null || s.execArmed || s.caught || t < s.cinematicUntil || t < s.sirenUntil + 100
                || !player.onGround() || player.getAbilities().flying) {
            s.nextTunnelAt = t + 100;
            return;
        }
        if (!start(player, level, s, t, r)) s.nextTunnelAt = t + 160;
    }

    /** Коридор сейчас идёт: Палач и фигуры не должны ходить сквозь его фейковые стены. */
    static boolean isActive(DreamState s) {
        return s.tunnelOn;
    }

    private static boolean start(ServerPlayer player, ServerLevel level, DreamState s, int t, RandomSource r) {
        var look = player.getLookAngle();
        int dx = 0, dz = 0;
        if (Math.abs(look.x) > Math.abs(look.z)) dx = look.x > 0 ? 1 : -1; else dz = look.z > 0 ? 1 : -1;
        s.tDx = dx;
        s.tDz = dz;
        s.tOx = player.getBlockX() + dx * 9;
        s.tOz = player.getBlockZ() + dz * 9;
        s.tGy.clear();
        s.tBuilt = 0;
        s.tTrail = 0;
        s.tPlug = -1;
        s.tMax = 80 + r.nextInt(50);
        s.tSqueeze = 30 + r.nextInt(16);
        s.tunnelEnded = false;
        s.tunnelSealed = false;
        s.tunnelSqueezed = false;
        s.tunnelOn = true;
        s.tStartedAt = t;
        s.nextEchoAt = 0;
        int guard = 0;
        while (s.tBuilt < 10 && guard++ < 14) {
            if (!buildSegment(player, level, s, s.tBuilt)) break;
            s.tBuilt++;
        }
        if (s.tBuilt < 10) {       // место неподходящее: в лесу, у обрыва, в доме. Не мучаем.
            dismantle(player, level, s, t, r);
            return false;
        }
        player.playNotifySound(ModSounds.DRONE.get(), SoundSource.HOSTILE, 0.7f, 0.6f);
        return true;
    }

    private static void dismantle(ServerPlayer player, ServerLevel level, DreamState s, int t, RandomSource r) {
        restoreAll(player, level, s);
        s.tunnelOn = false;
        s.tunnelsDone++;
        s.nextTunnelAt = t + 1500 + r.nextInt(1500);
    }

    /** Вернуть игроку то, что под фейками тоннеля (в виде Иной стороны). Зовётся и при конце сна. */
    static void restoreAll(ServerPlayer player, ServerLevel level, DreamState s) {
        for (var e : s.tunnelCells.long2ObjectEntrySet()) {
            BlockPos pos = BlockPos.of(e.getLongKey());
            player.connection.send(new ClientboundBlockUpdatePacket(pos, underlying(level, pos)));
        }
        s.tunnelCells.clear();
        s.tGy.clear();
        s.tBuilt = 0;
        s.tTrail = 0;
        s.tPlug = -1;
        s.tunnelOn = false;
        s.tunnelSealed = false;
    }

    /** Чанк заново отправлен игроку: вернуть стены коридора в нём. */
    static void reapplyChunk(ServerPlayer player, DreamState s, ChunkPos cp) {
        if (s.tunnelCells.isEmpty()) return;
        for (var e : s.tunnelCells.long2ObjectEntrySet()) {
            BlockPos pos = BlockPos.of(e.getLongKey());
            if ((pos.getX() >> 4) == cp.x && (pos.getZ() >> 4) == cp.z) {
                player.connection.send(new ClientboundBlockUpdatePacket(pos, e.getValue()));
            }
        }
    }

    private static BlockState underlying(ServerLevel level, BlockPos pos) {
        BlockState real = level.getBlockState(pos);
        BlockState rust = DreamBlocks.replacement(real, pos, true);
        return rust != null ? rust : real;
    }

    // ------------------------------------------------------------------ тик коридора

    private static void tickTunnel(ServerPlayer player, ServerLevel level, DreamState s, int t, RandomSource r) {
        double along = along(s, player.getX(), player.getZ());
        double lat = lateral(s, player.getX(), player.getZ());
        int ip = (int) Math.floor(along);
        boolean inside = ip >= 0 && ip < s.tBuilt && Math.abs(lat) < 2.4
                && Math.abs(player.getY() - s.tGy.getInt(ip)) < 3.5;

        // Ушёл, не зайдя / слишком долго / появился Палач: убираем.
        boolean gaveUp = !s.tunnelSealed && (t - s.tStartedAt > GIVE_UP_TICKS || along < -30 || along > s.tBuilt + 30 || Math.abs(lat) > 30);
        boolean left = s.tunnelSealed && (ip >= s.tBuilt + 2 && s.tunnelEnded || Math.abs(lat) > 8 || along < -8 || along > s.tBuilt + 40);
        if (gaveUp || left || s.executionerId != null || s.caught || (s.execArmed && !s.tunnelSealed)) {
            if (left && s.tunnelEnded) release(player, level, s);
            dismantle(player, level, s, t, r);
            return;
        }

        // Достраиваем вперёд.
        int ref = Math.max(ip, 0);
        for (int n = 0; n < 3 && !s.tunnelEnded && s.tBuilt < ref + LEAD; n++) {
            if (s.tBuilt >= s.tMax || !buildSegment(player, level, s, s.tBuilt)) {
                s.tunnelEnded = true;
                break;
            }
            s.tBuilt++;
        }
        if (s.tBuilt >= s.tMax) s.tunnelEnded = true;

        // Стена за спиной.
        if (!s.tunnelSealed && inside && ip >= PLUG_BEHIND + 1) {
            s.tunnelSealed = true;
            int pj = ip - PLUG_BEHIND;
            placePlug(player, s, pj);
            s.tPlug = pj;
            player.connection.send(new ClientboundSoundPacket(ModSounds.CLANG, SoundSource.HOSTILE,
                    segX(s, pj), s.tGy.getInt(pj) + 1.0, segZ(s, pj), 4.0f, 0.55f, r.nextLong()));
            player.playNotifySound(ModSounds.DRONE.get(), SoundSource.HOSTILE, 1.0f, 0.5f);
            PacketDistributor.sendToPlayer(player, new DreamFxPayload(DreamTimeline.FX_FLASH, 8));
            PacketDistributor.sendToPlayer(player, new DreamCutscenePayload("ow_seal", segX(s, pj), s.tGy.getInt(pj), segZ(s, pj)));
            s.cinematicUntil = t + 75;
            s.nextEchoAt = t + 200;
        } else if (s.tunnelSealed && inside && ip - PLUG_BEHIND > s.tPlug && ip - PLUG_BEHIND < s.tBuilt) {
            int pj = ip - PLUG_BEHIND;
            if (s.tPlug >= 0) removePlug(player, level, s, s.tPlug);
            placePlug(player, s, pj);
            s.tPlug = pj;
        }

        // Шаги позади, в запертом тоннеле.
        if (s.tunnelSealed && inside && t >= s.nextEchoAt && s.tPlug >= 0) {
            s.nextEchoAt = t + 90 + r.nextInt(120);
            player.connection.send(new ClientboundSoundPacket(ModSounds.WATCHER_STEP, SoundSource.HOSTILE,
                    segX(s, s.tPlug), s.tGy.getInt(s.tPlug) + 1.0, segZ(s, s.tPlug), 2.5f, 0.7f + r.nextFloat() * 0.2f, r.nextLong()));
        }
        // Сужение: первый раз в нём дышит и гудит.
        if (inside && !s.tunnelSqueezed && ip >= s.tSqueeze) {
            s.tunnelSqueezed = true;
            player.playNotifySound(ModSounds.BREATH.get(), SoundSource.HOSTILE, 1.0f, 0.7f);
            player.playNotifySound(ModSounds.DRONE.get(), SoundSource.HOSTILE, 1.0f, 0.4f);
        }

        // Хвост позади растворяется.
        while (s.tTrail < ip - TRAIL && s.tTrail < s.tBuilt) {
            removeSegment(player, level, s, s.tTrail);
            s.tTrail++;
        }
    }

    /** Вышел из тоннеля: тяжёлый вдох и вспышка, как будто отпустило. */
    private static void release(ServerPlayer player, ServerLevel level, DreamState s) {
        player.playNotifySound(ModSounds.DOOR.get(), SoundSource.HOSTILE, 1.2f, 0.6f);
        PacketDistributor.sendToPlayer(player, new DreamFxPayload(DreamTimeline.FX_FLASH, 10));
    }

    // ------------------------------------------------------------------ геометрия

    private static double along(DreamState s, double x, double z) {
        return s.tDx != 0 ? (s.tDx > 0 ? x - s.tOx : s.tOx + 1 - x) : (s.tDz > 0 ? z - s.tOz : s.tOz + 1 - z);
    }

    private static double lateral(DreamState s, double x, double z) {
        return s.tDx != 0 ? z - (s.tOz + 0.5) : x - (s.tOx + 0.5);
    }

    private static double segX(DreamState s, int i) {
        return s.tOx + 0.5 + s.tDx * i;
    }

    private static double segZ(DreamState s, int i) {
        return s.tOz + 0.5 + s.tDz * i;
    }

    /** Полуширина прохода: 1 (три блока) или 0 (один блок) в зоне сужения. */
    private static int halfWidth(DreamState s, int i) {
        return i >= s.tSqueeze && i < s.tSqueeze + SQUEEZE_LEN ? 0 : 1;
    }

    private static int height(DreamState s, int i) {
        return i >= s.tSqueeze && i < s.tSqueeze + SQUEEZE_LEN ? 3 : 4;
    }

    /** Клетка сегмента i со смещением w вбок и высотой y. */
    private static BlockPos cell(DreamState s, int i, int w, int y) {
        int px = -s.tDz, pz = s.tDx;       // вбок от оси
        return new BlockPos(s.tOx + s.tDx * i + px * w, y, s.tOz + s.tDz * i + pz * w);
    }

    private static boolean passable(ServerLevel level, BlockPos pos) {
        if (!level.hasChunkAt(pos)) return false;
        BlockState st = level.getBlockState(pos);
        return st.getCollisionShape(level, pos).isEmpty() && st.getFluidState().isEmpty();
    }

    /** Пол под ногами в колонке: клетка и над ней проходимы, а ниже твёрдая опора. Возвращает y клетки у пола или Integer.MIN_VALUE. */
    private static int ground(ServerLevel level, int x, int z, int aroundY) {
        for (int y = aroundY + 2; y >= aroundY - 3; y--) {
            BlockPos p = new BlockPos(x, y, z);
            if (!level.hasChunkAt(p)) return Integer.MIN_VALUE;
            if (passable(level, p) && passable(level, p.above()) && passable(level, p.above(2))
                    && level.getBlockState(p.below()).isFaceSturdy(level, p.below(), net.minecraft.core.Direction.UP)) {
                return y;
            }
        }
        return Integer.MIN_VALUE;
    }

    private static int hash(BlockPos pos) {
        long x = pos.asLong() * -7046029254386353131L;
        x ^= x >>> 32;
        return (int) (x & 0x7fffffffL);
    }

    private static BlockState wallState(BlockPos pos) {
        return (hash(pos) % 6 == 0 ? ModBlocks.RUST_BLOODY : ModBlocks.RUST_PLATE).get().defaultBlockState();
    }

    private static void put(ServerPlayer player, DreamState s, BlockPos pos, BlockState st) {
        BlockPos p = pos.immutable();
        s.tunnelCells.put(p.asLong(), st);
        player.connection.send(new ClientboundBlockUpdatePacket(p, st));
    }

    /** Построить сегмент i. false = место не подходит (препятствие, обрыв, чужой фейк, не загружено): тоннель здесь кончается. */
    private static boolean buildSegment(ServerPlayer player, ServerLevel level, DreamState s, int i) {
        int cx = s.tOx + s.tDx * i, cz = s.tOz + s.tDz * i;
        int around = i == 0 ? player.getBlockY() : s.tGy.getInt(i - 1);
        int fy = ground(level, cx, cz, around);
        if (fy == Integer.MIN_VALUE) return false;
        if (i > 0 && Math.abs(fy - s.tGy.getInt(i - 1)) > 1) return false;
        int hw = halfWidth(s, i), h = height(s, i);

        // Внутри должно быть чисто на всей ширине; стены и потолок не должны задевать чужие фейки (печати).
        for (int w = -hw; w <= hw; w++) {
            for (int y = fy; y < fy + h; y++) {
                if (!passable(level, cell(s, i, w, y))) return false;
            }
        }
        for (int w = -(hw + 1); w <= hw + 1; w++) {
            for (int y = fy - 1; y <= fy + h; y++) {
                boolean wall = Math.abs(w) == hw + 1;
                boolean roof = y == fy + h;
                if (!wall && !roof) continue;
                BlockPos p = cell(s, i, w, y);
                if (!level.hasChunkAt(p) || s.fake.containsKey(p.asLong())) return false;
            }
        }
        // Всё хорошо: кладём.
        s.tGy.add(fy);
        for (int w = -(hw + 1); w <= hw + 1; w++) {
            for (int y = fy - 1; y <= fy + h; y++) {
                boolean wall = Math.abs(w) == hw + 1;
                boolean roof = y == fy + h;
                if (!wall && !roof) continue;
                BlockPos p = cell(s, i, w, y);
                put(player, s, p, wallState(p));
            }
        }
        return true;
    }

    private static void removeSegment(ServerPlayer player, ServerLevel level, DreamState s, int i) {
        if (i < 0 || i >= s.tGy.size()) return;
        int fy = s.tGy.getInt(i);
        int hw = halfWidth(s, i), h = height(s, i);
        for (int w = -(hw + 1); w <= hw + 1; w++) {
            for (int y = fy - 1; y <= fy + h; y++) {
                BlockPos p = cell(s, i, w, y);
                if (s.tunnelCells.remove(p.asLong()) != null) {
                    player.connection.send(new ClientboundBlockUpdatePacket(p, underlying(level, p)));
                }
            }
        }
    }

    private static void placePlug(ServerPlayer player, DreamState s, int j) {
        if (j < 0 || j >= s.tGy.size()) return;
        int fy = s.tGy.getInt(j);
        int hw = halfWidth(s, j), h = height(s, j);
        BlockState st = ModBlocks.RUST_PLATE.get().defaultBlockState();
        for (int w = -hw; w <= hw; w++) {
            for (int y = fy; y < fy + h; y++) {
                BlockPos p = cell(s, j, w, y);
                // не кладём заглушку вплотную к игроку
                if (player.getBoundingBox().inflate(0.4).intersects(p.getX(), p.getY(), p.getZ(), p.getX() + 1, p.getY() + 1, p.getZ() + 1)) continue;
                put(player, s, p, st);
            }
        }
    }

    private static void removePlug(ServerPlayer player, ServerLevel level, DreamState s, int j) {
        if (j < 0 || j >= s.tGy.size()) return;
        int fy = s.tGy.getInt(j);
        int hw = halfWidth(s, j), h = height(s, j);
        for (int w = -hw; w <= hw; w++) {
            for (int y = fy; y < fy + h; y++) {
                BlockPos p = cell(s, j, w, y);
                if (s.tunnelCells.remove(p.asLong()) != null) {
                    player.connection.send(new ClientboundBlockUpdatePacket(p, underlying(level, p)));
                }
            }
        }
    }
}
