package com.example.dreams.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Одна клетка брошенной машины (4x2 блока, два яруса). cell 0..7: нижний ярус (u*2+w), 8..11: кабина.
 * facing: куда смотрит капот. Склейка клеток делает город (OtherworldCity). Фары светятся у варианта lit.
 */
public class CarBlock extends Block {
    public static final IntegerProperty CELL = IntegerProperty.create("cell", 0, 11);
    private static final VoxelShape LOW = Block.box(0, 0, 0, 16, 14, 16);
    private static final VoxelShape CAB = Block.box(1, 0, 1, 15, 8, 15);
    private final boolean lit;

    public CarBlock(Properties props, boolean lit) {
        super(props);
        this.lit = lit;
        registerDefaultState(stateDefinition.any().setValue(HorizontalDirectionalBlock.FACING, Direction.NORTH).setValue(CELL, 0));
    }

    /** Сколько света даёт клетка: у lit-машины горят фары (капотные нижние клетки u=3: id 6 и 7). */
    public static int lightFor(boolean lit, int cell) {
        return lit && (cell == 6 || cell == 7) ? 5 : 0;
    }

    public boolean isLit() {
        return lit;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(HorizontalDirectionalBlock.FACING, CELL);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return state.getValue(CELL) >= 8 ? CAB : LOW;
    }
}
