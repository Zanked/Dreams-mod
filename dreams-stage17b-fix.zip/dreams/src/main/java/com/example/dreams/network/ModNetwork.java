package com.example.dreams.network;

import com.example.dreams.client.NightmareClient;
import com.example.dreams.client.cutscene.CutsceneManager;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

public class ModNetwork {
    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("5");
        registrar.playToClient(
                DreamPhasePayload.TYPE,
                DreamPhasePayload.STREAM_CODEC,
                (payload, context) -> context.enqueueWork(() -> NightmareClient.setPhase(payload.phase(), payload.round(), payload.kind()))
        );
        registrar.playToClient(
                DreamFxPayload.TYPE,
                DreamFxPayload.STREAM_CODEC,
                (payload, context) -> context.enqueueWork(() -> NightmareClient.onFx(payload.kind(), payload.arg()))
        );
        registrar.playToClient(
                DreamCutscenePayload.TYPE,
                DreamCutscenePayload.STREAM_CODEC,
                (payload, context) -> context.enqueueWork(() ->
                        CutsceneManager.play(payload.scene(), payload.x(), payload.y(), payload.z()))
        );
    }
}
