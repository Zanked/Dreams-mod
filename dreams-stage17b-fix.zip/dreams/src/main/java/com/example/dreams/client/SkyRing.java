package com.example.dreams.client;

import com.example.dreams.DreamConfig;
import com.example.dreams.Dreams;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import org.joml.Vector3f;

/**
 * Небо мира доброго сна (только на клиенте): светящееся кольцо с лучом света, как на референсе, и бумажные
 * фонарики, которые медленно поднимаются в небо. Кольцо висит в фиксированной стороне неба и поворачивается вместе
 * с камерой, как далёкий объект; фонарики привязаны к миру (повторяются плиткой 256x256 вокруг игрока).
 */
@EventBusSubscriber(modid = Dreams.MODID, bus = EventBusSubscriber.Bus.GAME, value = Dist.CLIENT)
public final class SkyRing {

    private SkyRing() {}

    public static final ResourceLocation DREAM = ResourceLocation.fromNamespaceAndPath(Dreams.MODID, "good_dream");
    private static final ResourceLocation RING_TEX = ResourceLocation.fromNamespaceAndPath(Dreams.MODID, "textures/entity/sky_ring.png");
    private static final ResourceLocation LANTERN_TEX = ResourceLocation.fromNamespaceAndPath(Dreams.MODID, "textures/entity/sky_lantern.png");

    private static final double DIST = 320.0;          // расстояние до центра кольца
    private static final double AZIMUTH = Math.toRadians(32.0);
    private static final double ELEVATION = Math.toRadians(31.0);
    private static final int SEGMENTS = 160;
    private static final int LANTERNS = 56;
    private static final double TILE = 256.0;

    /** Игрок сейчас в мире доброго сна? */
    public static boolean inDreamWorld() {
        Minecraft mc = Minecraft.getInstance();
        return mc.level != null && mc.level.dimension().location().equals(DREAM);
    }

    private static double hash(int i, int k) {
        long h = (i * 0x9E3779B97F4A7C15L) ^ (k * 0xC2B2AE3D27D4EB4FL);
        h ^= h >>> 31; h *= 0xff51afd7ed558ccdL; h ^= h >>> 33;
        return (h >>> 11) * (1.0 / (1L << 53));
    }

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
        if (!inDreamWorld() || !DreamConfig.CLIENT.goodVisuals.get()) return;
        Minecraft mc = Minecraft.getInstance();
        Camera camera = event.getCamera();
        Vec3 cam = camera.getPosition();
        PoseStack.Pose pose = event.getPoseStack().last();
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
        double time = System.nanoTime() / 50_000_000.0;     // в «тиках», плавно между тиками

        float fogStart = RenderSystem.getShaderFogStart();
        float fogEnd = RenderSystem.getShaderFogEnd();
        RenderSystem.setShaderFogStart(Math.max(fogStart, 500f));   // небо не тонет в тумане ближней дали
        RenderSystem.setShaderFogEnd(Math.max(fogEnd, 900f));

        drawRing(buf, pose, time);
        drawLanterns(buf, pose, cam, camera, time);

        RenderSystem.setShaderFogStart(fogStart);
        RenderSystem.setShaderFogEnd(fogEnd);
    }

    private static void vertex(VertexConsumer vc, PoseStack.Pose pose, double x, double y, double z, float u, float v, int a) {
        vc.addVertex(pose, (float) x, (float) y, (float) z).setColor(255, 255, 255, a).setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY).setLight(LightTexture.FULL_BRIGHT).setNormal(pose, 0f, 1f, 0f);
    }

    /** Четырёхугольник с обеих сторон (не зависим от отсечения задних граней). */
    private static void quad(VertexConsumer vc, PoseStack.Pose pose, double[] a, double[] b, double[] c, double[] d,
                             float u0, float v0, float u1, float v1, int alpha) {
        vertex(vc, pose, a[0], a[1], a[2], u0, v1, alpha);
        vertex(vc, pose, b[0], b[1], b[2], u1, v1, alpha);
        vertex(vc, pose, c[0], c[1], c[2], u1, v0, alpha);
        vertex(vc, pose, d[0], d[1], d[2], u0, v0, alpha);
        vertex(vc, pose, d[0], d[1], d[2], u0, v0, alpha);
        vertex(vc, pose, c[0], c[1], c[2], u1, v0, alpha);
        vertex(vc, pose, b[0], b[1], b[2], u1, v1, alpha);
        vertex(vc, pose, a[0], a[1], a[2], u0, v1, alpha);
    }

    private static void drawRing(MultiBufferSource.BufferSource buf, PoseStack.Pose pose, double time) {
        RenderType rt = RenderType.entityTranslucentEmissive(RING_TEX);
        VertexConsumer vc = buf.getBuffer(rt);
        double cx = DIST * Math.cos(ELEVATION) * Math.cos(AZIMUTH);
        double cy = DIST * Math.sin(ELEVATION);
        double cz = DIST * Math.cos(ELEVATION) * Math.sin(AZIMUTH);
        // плоскость кольца: чуть наклонена от горизонтали
        double nx = 0.16, ny = 1.0, nz = 0.10;
        double nl = Math.sqrt(nx * nx + ny * ny + nz * nz);
        nx /= nl; ny /= nl; nz /= nl;
        double dot = nx;                                   // a = (1,0,0)
        double ux = 1 - nx * dot, uy = -ny * dot, uz = -nz * dot;
        double ul = Math.sqrt(ux * ux + uy * uy + uz * uz);
        ux /= ul; uy /= ul; uz /= ul;
        double vx = ny * uz - nz * uy, vy = nz * ux - nx * uz, vz = nx * uy - ny * ux;
        int alpha = (int) (255 * (0.72 + 0.12 * Math.sin(time * 0.03)));
        float scroll = (float) (time * 0.0016);

        // две ленты: широкая светящаяся и тонкая внешняя
        double[][] bands = {{78.0, 9.0, 0.0, 0.72, 3.0}, {106.0, 2.4, 0.55, 0.75, 6.0}};
        for (double[] band : bands) {
            double R = band[0], half = band[1];
            float vA = (float) band[2], vB = (float) band[3];
            double[] p0 = new double[3], p1 = new double[3], p2 = new double[3], p3 = new double[3];
            for (int i = 0; i < SEGMENTS; i++) {
                double t0 = i * Math.PI * 2 / SEGMENTS, t1 = (i + 1) * Math.PI * 2 / SEGMENTS;
                double c0 = Math.cos(t0), s0 = Math.sin(t0), c1 = Math.cos(t1), s1 = Math.sin(t1);
                double[] in0 = {cx + (R - half) * (c0 * ux + s0 * vx), cy + (R - half) * (c0 * uy + s0 * vy), cz + (R - half) * (c0 * uz + s0 * vz)};
                double[] out0 = {cx + (R + half) * (c0 * ux + s0 * vx), cy + (R + half) * (c0 * uy + s0 * vy), cz + (R + half) * (c0 * uz + s0 * vz)};
                double[] in1 = {cx + (R - half) * (c1 * ux + s1 * vx), cy + (R - half) * (c1 * uy + s1 * vy), cz + (R - half) * (c1 * uz + s1 * vz)};
                double[] out1 = {cx + (R + half) * (c1 * ux + s1 * vx), cy + (R + half) * (c1 * uy + s1 * vy), cz + (R + half) * (c1 * uz + s1 * vz)};
                float u0 = (float) ((double) i / SEGMENTS * band[4] + scroll);
                float u1 = (float) ((double) (i + 1) / SEGMENTS * band[4] + scroll);
                quad(vc, pose, in0, in1, out1, out0, u0, vA, u1, vB, alpha);
            }
        }
        // луч света сквозь кольцо: два перекрещенных вертикальных четырёхугольника
        float uA = 0f, uB = 1f;
        float vTop = 0.75f, vBot = 1.0f;                   // нижние 16 строк текстуры: поперечный профиль
        double w = 2.2, y0 = cy - 330, y1 = cy + 160;
        int ba = (int) (255 * 0.55);
        quad(vc, pose, new double[]{cx - w, y0, cz}, new double[]{cx + w, y0, cz}, new double[]{cx + w, y1, cz}, new double[]{cx - w, y1, cz}, uA, vTop, uB, vBot, ba);
        quad(vc, pose, new double[]{cx, y0, cz - w}, new double[]{cx, y0, cz + w}, new double[]{cx, y1, cz + w}, new double[]{cx, y1, cz - w}, uA, vTop, uB, vBot, ba);
        buf.endBatch(rt);
    }

    private static void drawLanterns(MultiBufferSource.BufferSource buf, PoseStack.Pose pose, Vec3 cam, Camera camera, double time) {
        RenderType rt = RenderType.entityTranslucentEmissive(LANTERN_TEX);
        VertexConsumer vc = buf.getBuffer(rt);
        Vector3f left = camera.getLeftVector();
        Vector3f up = camera.getUpVector();
        double rx = -left.x(), ry = -left.y(), rz = -left.z();
        double ux = up.x(), uy = up.y(), uz = up.z();
        for (int i = 0; i < LANTERNS; i++) {
            double ox = hash(i, 1) * TILE, oz = hash(i, 2) * TILE;
            double dx = Mth.positiveModulo(ox - cam.x + TILE / 2, TILE) - TILE / 2;
            double dz = Mth.positiveModulo(oz - cam.z + TILE / 2, TILE) - TILE / 2;
            double hd = Math.sqrt(dx * dx + dz * dz);
            if (hd < 6.0 || hd > 120.0) continue;
            double span = 150.0;
            double yy = 30.0 + Mth.positiveModulo(hash(i, 3) * span + time * 0.07, span);
            double ph = (yy - 30.0) / span;
            double fade = Math.min(1.0, Math.min(ph, 1.0 - ph) * 8.0) * Mth.clamp((120.0 - hd) / 40.0, 0.0, 1.0);
            if (fade <= 0.02) continue;
            double sway = Math.sin(time * 0.045 + i * 1.7) * 1.4;
            double px = dx + sway, py = yy - cam.y, pz = dz + Math.cos(time * 0.037 + i) * 1.2;
            double sz = 0.7 + 0.35 * hash(i, 4);
            double w = sz * 0.75, h = sz;
            double[] a = {px - rx * w - ux * h, py - ry * w - uy * h, pz - rz * w - uz * h};
            double[] b = {px + rx * w - ux * h, py + ry * w - uy * h, pz + rz * w - uz * h};
            double[] c = {px + rx * w + ux * h, py + ry * w + uy * h, pz + rz * w + uz * h};
            double[] d = {px - rx * w + ux * h, py - ry * w + uy * h, pz - rz * w + uz * h};
            vertex(vc, pose, a[0], a[1], a[2], 0f, 1f, (int) (255 * fade));
            vertex(vc, pose, b[0], b[1], b[2], 1f, 1f, (int) (255 * fade));
            vertex(vc, pose, c[0], c[1], c[2], 1f, 0f, (int) (255 * fade));
            vertex(vc, pose, d[0], d[1], d[2], 0f, 0f, (int) (255 * fade));
        }
        buf.endBatch(rt);
    }
}
