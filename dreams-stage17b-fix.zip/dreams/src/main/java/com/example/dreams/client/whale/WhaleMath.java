package com.example.dreams.client.whale;

/** Где плывёт кит и какого он цвета. Без классов Minecraft. Сервер китов больше не считает: всё идёт от whaleSeed на клиенте. */
public final class WhaleMath {

    private WhaleMath() {}

    public static final int MAX = 3;

    public static float lengthOf(int k) {
        return k == 0 ? 56f : k == 1 ? 48f : 60f;
    }

    /**
     * Китов ведёт по кругу вокруг сновидца (в небе). out: [0..2] центр кита, [3..4] направление вперёд (x, z, единичное),
     * [5] кривизна дуги (1/радиус, знак по правилу WhaleGeometry: + вправо от кита).
     *
     * @param fin 0..1: в финале киты подплывают ближе и ниже
     */
    public static void pose(double seed, int k, double t, double fin, double px, double py, double pz, double[] out) {
        double dir = (k % 2 == 0) ? 1.0 : -1.0;
        double radius = (68 + 12 * k) * (1.0 - 0.40 * fin);
        double height = (42 + 9 * k) * (1.0 - 0.25 * fin);
        double omega = dir * (0.0030 - 0.0004 * k);
        double th = seed + k * 2.1 + omega * t;
        double sn = Math.sin(th), cs = Math.cos(th);
        out[0] = px + radius * cs;
        out[1] = py + height + 2.2 * Math.sin(t * 0.02 + k);
        out[2] = pz + radius * sn;
        out[3] = -dir * sn;                     // направление движения: касательная
        out[4] = dir * cs;
        out[5] = -dir / radius;                 // тело загибается к центру круга
    }

    /** Точка на теле кита: s = 0 нос, 1 хвост. */
    public static void bodyPoint(double[] pose, int k, float s, double[] out) {
        double len = lengthOf(k);
        double zl = len * (0.5 - s);
        double lat = 0.5 * pose[5] * zl * zl;
        double fx = pose[3], fz = pose[4];
        out[0] = pose[0] + fx * zl + fz * lat;       // вправо от кита = (fz, 0, -fx)
        out[1] = pose[1];
        out[2] = pose[2] + fz * zl - fx * lat;
    }

    /** Цвет кита: от бело-голубого к лавандовому и золотому по числу огней. */
    public static void color(float lights, float[] rgb) {
        float k = Math.max(0f, Math.min(1f, lights / 5.0f));
        if (k < 0.6f) {
            float u = k / 0.6f;
            rgb[0] = lerp(u, 0.70f, 0.86f);
            rgb[1] = lerp(u, 0.92f, 0.80f);
            rgb[2] = 1.0f;
            return;
        }
        float u = (k - 0.6f) / 0.4f;
        rgb[0] = lerp(u, 0.86f, 1.0f);
        rgb[1] = lerp(u, 0.80f, 0.90f);
        rgb[2] = lerp(u, 1.0f, 0.55f);
    }

    private static float lerp(float u, float a, float b) {
        return a + (b - a) * u;
    }
}
