package com.example.dreams.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Уличная мелочь города (фонарь, светофор, гидрант, бочка...). Фейк-блок: сервер о нём не знает.
 * Форма задаётся боксами для севера (в пикселях 0..16), остальные стороны получаются поворотом.
 * faced=false: без свойства facing (один вариант формы).
 */
public class PropBlock extends Block {
    private final boolean faced;
    private final VoxelShape[] shapes;

    public PropBlock(Properties props, boolean faced, VoxelShape[] shapes) {
        super(props);
        this.faced = faced;
        this.shapes = shapes;
        if (faced) {
            registerDefaultState(stateDefinition.any().setValue(HorizontalDirectionalBlock.FACING, Direction.NORTH));
        }
    }

    /** Формы для N, E, S, W из боксов {x1,y1,z1,x2,y2,z2,...} северной ориентации. */
    public static VoxelShape[] rotated(double... b) {
        VoxelShape[] out = new VoxelShape[4];
        for (int k = 0; k < 4; k++) {
            VoxelShape s = Shapes.empty();
            for (int i = 0; i + 5 < b.length; i += 6) {
                double x1 = b[i], y1 = b[i + 1], z1 = b[i + 2], x2 = b[i + 3], y2 = b[i + 4], z2 = b[i + 5];
                for (int r = 0; r < k; r++) {   // поворот на 90 градусов по часовой: (x, z) -> (16 - z, x)
                    double nx1 = 16 - z2, nx2 = 16 - z1, nz1 = x1, nz2 = x2;
                    x1 = nx1; x2 = nx2; z1 = nz1; z2 = nz2;
                }
                s = Shapes.or(s, Block.box(x1, y1, z1, x2, y2, z2));
            }
            out[k] = s;
        }
        return out;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        // конструктор подкласса ещё не отработал, поле faced недоступно: facing есть у всех PropBlock, лишнее свойство безвредно
        builder.add(HorizontalDirectionalBlock.FACING);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        if (!faced) return shapes[0];
        Direction d = state.getValue(HorizontalDirectionalBlock.FACING);
        return shapes[(d.get2DDataValue() + 2) & 3];
    }
}
