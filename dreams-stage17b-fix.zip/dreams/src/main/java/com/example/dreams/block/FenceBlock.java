package com.example.dreams.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Звено сетчатого забора: столб и до четырёх секций. Состояние ставит город (сервер соседей не обновляет). */
public class FenceBlock extends Block {
    private static final VoxelShape POST = Block.box(7, 0, 7, 9, 16, 9);
    private static final VoxelShape[] ARMS = {
            Block.box(7, 0, 0, 9, 16, 9),    // north
            Block.box(7, 0, 7, 16, 16, 9),   // east
            Block.box(7, 0, 7, 9, 16, 16),   // south
            Block.box(0, 0, 7, 9, 16, 9)     // west
    };

    public FenceBlock(Properties props) {
        super(props);
        registerDefaultState(stateDefinition.any()
                .setValue(BlockStateProperties.NORTH, false).setValue(BlockStateProperties.EAST, false)
                .setValue(BlockStateProperties.SOUTH, false).setValue(BlockStateProperties.WEST, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(BlockStateProperties.NORTH, BlockStateProperties.EAST, BlockStateProperties.SOUTH, BlockStateProperties.WEST);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        VoxelShape s = POST;
        if (state.getValue(BlockStateProperties.NORTH)) s = Shapes.or(s, ARMS[0]);
        if (state.getValue(BlockStateProperties.EAST)) s = Shapes.or(s, ARMS[1]);
        if (state.getValue(BlockStateProperties.SOUTH)) s = Shapes.or(s, ARMS[2]);
        if (state.getValue(BlockStateProperties.WEST)) s = Shapes.or(s, ARMS[3]);
        return s;
    }
}
