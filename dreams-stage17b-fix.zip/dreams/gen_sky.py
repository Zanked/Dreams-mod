"""Текстуры неба доброго сна: кольцо с лучом (sky_ring.png 256x64) и бумажный фонарик (sky_lantern.png 32x32).
python3 gen_sky.py src/main/resources/assets/dreams"""
import os, sys, math
import numpy as np
from PIL import Image
ROOT = sys.argv[1] if len(sys.argv) > 1 else "src/main/resources/assets/dreams"
D = os.path.join(ROOT, "textures", "entity"); os.makedirs(D, exist_ok=True)
r = np.random.default_rng(11)

# --- кольцо: верхние 48 строк = лента из нескольких светящихся линий, нижние 16 = поперечный профиль луча
W, H = 256, 64
a = np.zeros((H, W, 4))
lines = [(10, 1.6, 0.95), (17, 1.0, 0.7), (24, 2.4, 1.0), (31, 1.1, 0.75), (38, 1.8, 0.85), (44, 0.9, 0.5)]
for y in range(48):
    prof = 0.0
    for (c, s, k) in lines:
        prof += k * math.exp(-((y - c) / s) ** 2)
    prof = min(1.0, prof)
    for x in range(W):
        dash = 0.55 + 0.45 * math.sin(x * 0.19 + y * 0.7) * math.sin(x * 0.043 + y * 0.31 + 1.3)
        dash = max(0.2, dash) if r.random() > 0.04 else 1.0
        spark = 1.0 if r.random() < 0.01 else 0.0
        al = min(1.0, prof * dash + spark * 0.8)
        col = np.array([225, 208, 255.0]) * (0.85 + 0.15 * prof) + np.array([20, 20, 0.0]) * spark
        a[y, x, :3] = np.clip(col, 0, 255)
        a[y, x, 3] = 255 * al
for y in range(48, 64):                              # луч: яркая сердцевина и мягкие края поперёк (u)
    for x in range(W):
        t = (x - W / 2) / (W / 2)
        al = math.exp(-(t / 0.22) ** 2) * 0.9 + math.exp(-(t / 0.6) ** 2) * 0.25
        a[y, x, :3] = [236, 224, 255]
        a[y, x, 3] = 255 * min(1.0, al)
Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), "RGBA").save(os.path.join(D, "sky_ring.png"))

# --- фонарик: бумажный, тёплый, на фоне прозрачность
L = np.zeros((32, 32, 4))
for y in range(32):
    for x in range(32):
        cx = (x - 15.5) / 9.0
        top = 5; bot = 27
        if bot >= y >= top:
            t = (y - top) / (bot - top)
            w = 0.55 + 0.45 * math.sin(math.pi * (0.15 + 0.7 * t)) if 0.0 <= t <= 1.0 else 0
            if abs(cx) <= w:
                glow = 1.0 - 0.45 * abs(cx) / max(w, 0.01)
                base = np.array([255, 150 + 70 * glow, 60 + 90 * glow])
                if abs(cx) > w - 0.12 or (int(y) % 8 == 0):
                    base = base * 0.62
                L[y, x, :3] = base; L[y, x, 3] = 255
        if y in (3, 4) and abs(x - 15.5) < 5: L[y, x] = [90, 50, 30, 255]
        if y in (28, 29) and abs(x - 15.5) < 5: L[y, x] = [90, 50, 30, 255]
        if y == 30 and x in (15, 16): L[y, x] = [255, 200, 120, 255]
        if y == 2 and x in (15, 16): L[y, x] = [60, 40, 30, 255]
Image.fromarray(np.clip(L, 0, 255).astype(np.uint8), "RGBA").save(os.path.join(D, "sky_lantern.png"))

# --- медуза 64x64: верхние 48 строк = колокол (u вокруг, v от макушки к краю), нижние 16 = щупальце (v вдоль)
J = np.zeros((64, 64, 4))
for y in range(48):
    for x in range(64):
        v = y / 47.0
        vein = 0.5 + 0.5 * math.cos(x * math.pi * 2 / 8.0)          # радиальные жилки
        ring = 0.5 + 0.5 * math.cos(v * math.pi * 7.0)
        spot = 1.0 if r.random() < 0.025 else 0.0
        base = 0.55 + 0.25 * vein * (0.4 + v) + 0.12 * ring + 0.5 * spot
        edge = max(0.0, (v - 0.86) / 0.14)                           # светлая кромка колокола
        c = min(1.0, base + 0.5 * edge)
        J[y, x, :3] = np.clip(np.array([235, 232, 255.0]) * c + np.array([20, 0, 20.0]) * edge, 0, 255)
        J[y, x, 3] = 255 * min(1.0, 0.55 + 0.25 * vein + 0.35 * edge + 0.4 * spot) * (0.85 + 0.15 * (1 - v))
for y in range(48, 64):
    t = (y - 48) / 15.0
    for x in range(64):
        u = (x - 31.5) / 31.5
        prof = math.exp(-(u / 0.55) ** 2)
        bead = 1.0 if (y % 5 == 0 and abs(u) < 0.5) else 0.0
        J[y, x, :3] = [244, 238, 255]
        J[y, x, 3] = 255 * min(1.0, prof * (0.95 - 0.55 * t) + 0.5 * bead)
Image.fromarray(np.clip(J, 0, 255).astype(np.uint8), "RGBA").save(os.path.join(D, "sky_jelly.png"))
print("sky textures ok")
