package com.example.dreams.client;

import com.example.dreams.DreamConfig;
import com.example.dreams.Dreams;
import com.example.dreams.sound.ModSounds;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

/**
 * Мир доброго сна оживает (только клиент): лепестки сакуры, споры и светлячки в воздухе, туман и брызги у водопадов,
 * ветер, колокольчики и шум воды. Бабочки и журавлики рисуются отдельно (SkyLife).
 */
@EventBusSubscriber(modid = Dreams.MODID, bus = EventBusSubscriber.Bus.GAME, value = Dist.CLIENT)
public final class DreamAmbience {

    private DreamAmbience() {}

    private static WindSound wind;
    private static int chimeCd = 120;
    private static int waterCd = 0;

    @SubscribeEvent
    public static void onTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        ClientLevel level = mc.level;
        if (p == null || level == null || mc.isPaused()) return;
        if (!SkyRing.inDreamWorld() || !DreamConfig.CLIENT.goodAmbience.get()) {
            wind = null;   // ветер сам остановится: см. WindSound.tick
            return;
        }
        if (wind == null || wind.isStopped()) {
            wind = new WindSound();
            mc.getSoundManager().play(wind);
        }
        RandomSource r = level.getRandom();
        double px = p.getX(), py = p.getY(), pz = p.getZ();

        // лепестки: по два на тик вокруг игрока, ветер несёт их вбок
        for (int i = 0; i < 2; i++) {
            level.addParticle(ParticleTypes.CHERRY_LEAVES, px + (r.nextDouble() * 2 - 1) * 20, py + 2 + r.nextDouble() * 12, pz + (r.nextDouble() * 2 - 1) * 20,
                    0.03, -0.01, 0.01);
        }
        // споры и светлячки
        level.addParticle(ParticleTypes.SPORE_BLOSSOM_AIR, px + (r.nextDouble() * 2 - 1) * 14, py + r.nextDouble() * 9 - 2, pz + (r.nextDouble() * 2 - 1) * 14, 0.0, -0.02, 0.0);
        if (r.nextInt(3) == 0) {
            level.addParticle(ParticleTypes.GLOW, px + (r.nextDouble() * 2 - 1) * 16, py + r.nextDouble() * 6 - 1, pz + (r.nextDouble() * 2 - 1) * 16,
                    (r.nextDouble() - 0.5) * 0.03, (r.nextDouble() - 0.5) * 0.02, (r.nextDouble() - 0.5) * 0.03);
        }

        // водопады: ищем воду, под которой воздух: это нижний край струи
        if (waterCd > 0) waterCd--;
        for (int i = 0; i < 24; i++) {
            double x = px + (r.nextDouble() * 2 - 1) * 22, y = py + (r.nextDouble() * 2 - 1) * 28, z = pz + (r.nextDouble() * 2 - 1) * 22;
            BlockPos pos = BlockPos.containing(x, y, z);
            if (!level.getFluidState(pos).is(FluidTags.WATER)) continue;
            if (!level.isEmptyBlock(pos.below())) continue;
            double cx = pos.getX() + 0.5, cy = pos.getY() + 0.1, cz = pos.getZ() + 0.5;
            for (int k = 0; k < 3; k++) {
                level.addParticle(ParticleTypes.CLOUD, cx + (r.nextDouble() - 0.5) * 1.6, cy, cz + (r.nextDouble() - 0.5) * 1.6,
                        (r.nextDouble() - 0.5) * 0.04, 0.03, (r.nextDouble() - 0.5) * 0.04);
            }
            level.addParticle(ParticleTypes.SPLASH, cx + (r.nextDouble() - 0.5), cy, cz + (r.nextDouble() - 0.5), 0.0, 0.1, 0.0);
            if (waterCd <= 0) {
                waterCd = 70;
                level.playLocalSound(cx, cy, cz, ModSounds.DREAM_WATER.get(), SoundSource.AMBIENT,
                        0.9f * vol(), 0.9f + r.nextFloat() * 0.2f, false);
            }
        }

        // колокольчики где-то рядом
        if (--chimeCd <= 0) {
            chimeCd = 90 + r.nextInt(180);
            level.playLocalSound(px + (r.nextDouble() * 2 - 1) * 14, py + 2 + r.nextDouble() * 6, pz + (r.nextDouble() * 2 - 1) * 14,
                    ModSounds.DREAM_CHIME.get(), SoundSource.AMBIENT, 0.55f * vol(), 0.85f + r.nextFloat() * 0.3f, false);
        }
    }

    private static float vol() {
        return DreamConfig.CLIENT.goodAmbienceVolume.get().floatValue();
    }

    /** Ветер: не позиционный, по кругу; сильнее на высоте и в полёте. */
    private static class WindSound extends AbstractTickableSoundInstance {
        private float cur = 0f;

        WindSound() {
            super(ModSounds.DREAM_WIND.get(), SoundSource.AMBIENT, RandomSource.create());
            this.looping = true;
            this.delay = 0;
            this.volume = 0.0001f;
            this.relative = true;
            this.attenuation = SoundInstance.Attenuation.NONE;
        }

        @Override
        public boolean canStartSilent() {
            return true;
        }

        @Override
        public void tick() {
            Minecraft mc = Minecraft.getInstance();
            LocalPlayer p = mc.player;
            if (p == null || !SkyRing.inDreamWorld() || !DreamConfig.CLIENT.goodAmbience.get()) {
                stop();
                return;
            }
            double speed = p.getDeltaMovement().length();
            float height = (float) Mth.clamp((p.getY() - 60.0) / 120.0, 0.0, 1.0);
            float target = 0.16f + 0.14f * height + (float) Math.min(0.35, speed * 0.7);
            cur += (target - cur) * 0.04f;
            this.volume = Math.max(0.0001f, cur * vol());
        }
    }
}
