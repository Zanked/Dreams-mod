package com.example.dreams.client;

import com.example.dreams.DreamConfig;
import com.example.dreams.Dreams;
import com.example.dreams.client.cutscene.CutsceneManager;
import com.example.dreams.client.whale.WhaleGeometry;
import com.example.dreams.client.whale.WhaleMath;
import com.example.dreams.sound.ModSounds;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/**
 * Небесные киты доброго сна: настоящая 3D-модель, плавно анимированная каждый кадр (см. WhaleGeometry), только на клиенте.
 * Сервер шлёт одно число (whaleSeed) и число огней; положение, появление, цвет и песню клиент считает сам.
 * Рисуется светящимся полупрозрачным слоем (RenderType.entityTranslucentEmissive), туман на время рисования отодвигается.
 */
@EventBusSubscriber(modid = Dreams.MODID, bus = EventBusSubscriber.Bus.GAME, value = Dist.CLIENT)
public final class SkyWhales {

    private SkyWhales() {}

    private static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath(Dreams.MODID, "textures/entity/sky_whale.png");
    private static final int APPEAR_TICKS = 120;
    private static final int FIRST_AT = 300;               // с 15-й секунды в мире сна
    private static final WhaleGeometry[] GEO = {new WhaleGeometry(), new WhaleGeometry(), new WhaleGeometry()};

    private static boolean haveSeed = false;
    private static double seed = 0.0;
    private static int lights = 0;
    private static float lightsSmooth = 0f;
    private static int t = 0;                              // тиков в мире сна
    private static boolean finale = false;
    private static int finaleT = 0;
    private static final int[] BORN = {-1, -1, -1};
    private static boolean sceneShown = false;
    private static long lastTickNanos = System.nanoTime();

    private static final double[] POSE = new double[6];
    private static final double[] TMP = new double[3];
    private static final float[] RGB = new float[3];

    // ---------- события

    public static void setSeed(double s) {
        seed = s;
        haveSeed = true;
    }

    public static void setLights(int n) {
        lights = Mth.clamp(n, 0, 5);
    }

    public static void startFinale() {
        finale = true;
        finaleT = 0;
    }

    public static void reset() {
        haveSeed = false;
        lights = 0;
        lightsSmooth = 0f;
        t = 0;
        finale = false;
        finaleT = 0;
        BORN[0] = BORN[1] = BORN[2] = -1;
        sceneShown = false;
        centerInit = false;
        frozen = false;
        rideK = -1;
        rideMul = 1.0;
    }

    // ---------- состояние

    private static int count() {
        if (!haveSeed || t < FIRST_AT || !DreamConfig.CLIENT.whaleModel.get()) return 0;
        return finale || lights >= 4 ? 3 : lights >= 2 ? 2 : 1;
    }

    // ---------- центр круга китов и поездка

    private static boolean centerInit = false;
    private static double cenX, cenY, cenZ, penX, penY, penZ;   // центр круга: сейчас и на прошлом тике
    private static boolean frozen = false;                      // во время поездки центр стоит на месте
    private static int rideK = -1;
    private static double rideBase, rideT0, rideMul = 1.0;       // эффективное время ездового кита: base + mul * (время - T0)

    /** Центр круга медленно подтягивается к игроку (а не прибит к нему): киты плывут плавно и не дёргаются от его шагов. */
    private static void updateCenter(LocalPlayer p) {
        if (p == null) return;
        double ty = altitude(p.getY());
        if (!centerInit) {
            cenX = penX = p.getX(); cenY = penY = ty; cenZ = penZ = p.getZ();
            centerInit = true;
            return;
        }
        penX = cenX; penY = cenY; penZ = cenZ;
        if (!frozen) {
            cenX += (p.getX() - cenX) * 0.02;
            cenY += (ty - cenY) * 0.02;
            cenZ += (p.getZ() - cenZ) * 0.02;
        }
    }

    private static double rideEff(double time) {
        return rideBase + rideMul * (time - rideT0);
    }

    private static void poseFor(int k, double time, double fin, float part, double[] out) {
        double cx = penX + (cenX - penX) * part, cy = penY + (cenY - penY) * part, cz = penZ + (cenZ - penZ) * part;
        WhaleMath.pose(seed, k, k == rideK ? rideEff(time) : time, fin, cx, cy, cz, out);
    }

    /** Первый кит уже полностью появился: на нём можно прокатиться. */
    public static boolean rideReady() {
        return SkyRing.inDreamWorld() && count() > 0 && BORN[0] >= 0 && appear(0, 0f) >= 0.95f;
    }

    public static void rideBegin() {
        double now = t + (double) partial();
        frozen = true;
        rideK = 0;
        rideBase = now;
        rideT0 = now;
        rideMul = 1.0;
    }

    /** Меняет скорость ездового кита без скачка позиции. */
    public static void rideSpeed(double mul) {
        if (rideK < 0) return;
        double now = t + (double) partial();
        rideBase = rideEff(now);
        rideT0 = now;
        rideMul = mul;
    }

    public static void rideEnd() {
        rideSpeed(1.0);
        frozen = false;
    }

    /** Спина первого кита (куда сажаем игрока). */
    public static boolean ridePoint(double[] out) {
        if (!bodyPointNow(0, 0.42f, out)) return false;
        out[1] += 0.085 * WhaleMath.lengthOf(0) + 0.8;
        return true;
    }

    /**
     * Высота, от которой киты отсчитывают свой круг. В мире островов киты держатся выше любых островов и крон
     * (иначе остров между камерой и китом закрывает его, а катсцена целится в него): не ниже 100.
     */
    private static double altitude(double y) {
        return SkyRing.inDreamWorld() ? Math.max(y, 100.0) : y;
    }

    private static float framePart = 0f;

    /** Дробная часть тика текущего кадра: одна на всех (камера катсцены, киты), иначе цель и камера расходятся. */
    public static void setFramePartial(float p) {
        framePart = Mth.clamp(p, 0f, 1f);
    }

    @SubscribeEvent
    public static void onFramePre(net.neoforged.neoforge.client.event.RenderFrameEvent.Pre event) {
        framePart = Mth.clamp(event.getPartialTick().getGameTimeDeltaPartialTick(false), 0f, 1f);
    }

    private static float partial() {
        return framePart;
    }

    private static float appear(int k, float part) {
        if (BORN[k] < 0) return 0f;
        float a = Mth.clamp((t - BORN[k] + part) / APPEAR_TICKS, 0f, 1f);
        return a * a * (3f - 2f * a);
    }

    private static double fin(float part) {
        return finale ? Mth.clamp((finaleT + part) / 120.0, 0.0, 1.0) : 0.0;
    }

    /** Точка на теле кита k (для камеры катсцен): s = 0 нос, 1 хвост. false, если кита сейчас нет. */
    public static boolean bodyPoint(int k, float s, double[] out) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || k < 0 || k >= WhaleMath.MAX || k >= count() || BORN[k] < 0) return false;
        poseFor(k, t, fin(0f), 0f, POSE);
        WhaleMath.bodyPoint(POSE, k, s, out);
        return true;
    }

    /**
     * Точка на теле кита в непрерывном времени кадра: те же входы, что у onRender (время t + part, игрок интерполирован).
     * Камера катсцены целится в неё каждый кадр, поэтому цель не дёргается относительно рисуемого кита.
     */
    public static boolean bodyPointNow(int k, float s, double[] out) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || k < 0 || k >= WhaleMath.MAX || k >= count() || BORN[k] < 0) return false;
        float part = partial();
        poseFor(k, t + (double) part, fin(part), part, POSE);
        WhaleMath.bodyPoint(POSE, k, s, out);
        return true;
    }

    /** Насколько кит k уже проявился (0..1), для запуска катсцены. */
    public static float visible(int k) {
        return k < count() ? appear(k, 0f) : 0f;
    }

    // ---------- тик

    /** Раз в тик, пока идёт добрый сон и игрок уже в его мире. */
    public static void tick(boolean running) {
        lastTickNanos = System.nanoTime();
        Minecraft mc = Minecraft.getInstance();
        if (!running || mc.player == null || mc.level == null || mc.isPaused()) return;
        t++;
        updateCenter(mc.player);
        if (finale) finaleT++;
        lightsSmooth += (lights - lightsSmooth) * 0.04f;
        int n = count();
        if (n == 0) return;
        for (int k = 0; k < n; k++) if (BORN[k] < 0) BORN[k] = t;
        var r = mc.level.getRandom();
        LocalPlayer p = mc.player;
        double fin = fin(0f);
        for (int k = 0; k < n; k++) {
            float ap = appear(k, 0f);
            if (ap < 0.05f) continue;
            poseFor(k, t, fin, 0f, POSE);
            // звёздная пыль тянется от хвоста и от лопастей
            if (r.nextFloat() < ap) {
                WhaleMath.bodyPoint(POSE, k, 0.97f, TMP);
                mc.level.addParticle(ParticleTypes.END_ROD, true,
                        TMP[0] + (r.nextDouble() - 0.5) * 8.0, TMP[1] + (r.nextDouble() - 0.5) * 3.0, TMP[2] + (r.nextDouble() - 0.5) * 8.0,
                        0.0, -0.01, 0.0);
            }
            if (lights >= 1 && ap > 0.5f && t % 160 == 40 * k) {   // песня из точки, где плывёт голова
                WhaleMath.bodyPoint(POSE, k, 0.0f, TMP);
                mc.level.playLocalSound(TMP[0], TMP[1], TMP[2], ModSounds.TREE_HUM.get(), SoundSource.AMBIENT,
                        6.0f, 0.45f, false);
            }
        }
        if (!sceneShown && appear(0, 0f) >= 0.45f) {   // первый кит: кадр со стороны
            sceneShown = true;
            CutsceneManager.play("whale_first", 0.0, 0.0, 0.0);
        }
    }

    // ---------- рисование

    private static int cr, cg, cb, ca;

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
        int n = count();
        if (n == 0) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) return;

        float part = partial();
        Vec3 cam = event.getCamera().getPosition();
        double px = Mth.lerp(part, p.xo, p.getX());
        double py = altitude(Mth.lerp(part, p.yo, p.getY()));
        double pz = Mth.lerp(part, p.zo, p.getZ());
        double fin = fin(part);
        double time = t + part;
        WhaleMath.color(lightsSmooth, RGB);
        cr = (int) (RGB[0] * 255f);
        cg = (int) (RGB[1] * 255f);
        cb = (int) (RGB[2] * 255f);

        PoseStack ps = event.getPoseStack();
        PoseStack.Pose pose = ps.last();
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
        RenderType rt = RenderType.entityTranslucentEmissive(TEXTURE);
        VertexConsumer vc = buf.getBuffer(rt);
        WhaleGeometry.Sink sink = (x, y, z, u, v, nx, ny, nz) ->
                vc.addVertex(pose, x, y, z).setColor(cr, cg, cb, ca).setUv(u, v)
                        .setOverlay(OverlayTexture.NO_OVERLAY).setLight(LightTexture.FULL_BRIGHT).setNormal(pose, nx, ny, nz);

        float fogStart = RenderSystem.getShaderFogStart();
        float fogEnd = RenderSystem.getShaderFogEnd();
        RenderSystem.setShaderFogStart(Math.max(fogStart, 260f));   // киты далеко: туман им не мешает, и всё же слегка тонет в дымке
        RenderSystem.setShaderFogEnd(Math.max(fogEnd, 420f));
        for (int k = 0; k < n; k++) {
            float ap = appear(k, part);
            if (ap <= 0.01f) continue;
            poseFor(k, time, fin, part, POSE);
            ca = (int) (255f * 0.80f * ap);
            GEO[k].render(sink, POSE[0] - cam.x, POSE[1] - cam.y, POSE[2] - cam.z, POSE[3], POSE[4],
                    WhaleMath.lengthOf(k), (float) POSE[5], (float) (time + k * 37.0));
        }
        buf.endBatch(rt);
        RenderSystem.setShaderFogStart(fogStart);
        RenderSystem.setShaderFogEnd(fogEnd);
    }
}
