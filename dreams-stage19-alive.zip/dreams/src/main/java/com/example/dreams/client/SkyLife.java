package com.example.dreams.client;

import com.example.dreams.DreamConfig;
import com.example.dreams.Dreams;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import org.joml.Vector3f;

/**
 * Живность мира сна (только клиент): бабочки порхают вокруг игрока, стаи бумажных журавликов кружат в небе клином.
 * Рисуются картинками, повёрнутыми к камере; взмахи крыльев это смена двух кадров текстуры sky_life.png.
 */
@EventBusSubscriber(modid = Dreams.MODID, bus = EventBusSubscriber.Bus.GAME, value = Dist.CLIENT)
public final class SkyLife {

    private SkyLife() {}

    private static final ResourceLocation TEX = ResourceLocation.fromNamespaceAndPath(Dreams.MODID, "textures/entity/sky_life.png");
    private static final int BUTTERFLIES = 48;
    private static final int FLOCKS = 3;
    private static final int BIRDS = 7;
    private static final double TILE = 72.0;
    private static final int[][] TINTS = {{255, 170, 230}, {255, 215, 120}, {160, 205, 255}, {205, 165, 255}, {175, 255, 215}, {255, 150, 150}};

    private static double hash(int i, int k) {
        long h = (i * 0x9E3779B97F4A7C15L) ^ (k * 0x94D049BB133111EBL);
        h ^= h >>> 30; h *= 0xbf58476d1ce4e5b9L; h ^= h >>> 27;
        return (h >>> 11) * (1.0 / (1L << 53));
    }

    private static PoseStack.Pose pose;
    private static VertexConsumer vc;
    private static double rx, ry, rz, ux, uy, uz;

    private static void sprite(double x, double y, double z, double size, int frame, int r, int g, int b, int a) {
        double w = size, h = size;
        float u0 = frame * 0.25f, u1 = u0 + 0.25f;
        v(x - rx * w - ux * h, y - ry * w - uy * h, z - rz * w - uz * h, u0, 1f, r, g, b, a);
        v(x + rx * w - ux * h, y + ry * w - uy * h, z + rz * w - uz * h, u1, 1f, r, g, b, a);
        v(x + rx * w + ux * h, y + ry * w + uy * h, z + rz * w + uz * h, u1, 0f, r, g, b, a);
        v(x - rx * w + ux * h, y - ry * w + uy * h, z - rz * w + uz * h, u0, 0f, r, g, b, a);
    }

    private static void v(double x, double y, double z, float u, float vv, int r, int g, int b, int a) {
        vc.addVertex(pose, (float) x, (float) y, (float) z).setColor(r, g, b, a).setUv(u, vv)
                .setOverlay(OverlayTexture.NO_OVERLAY).setLight(LightTexture.FULL_BRIGHT).setNormal(pose, 0f, 1f, 0f);
    }

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
        if (!SkyRing.inDreamWorld() || !DreamConfig.CLIENT.goodVisuals.get() || !DreamConfig.CLIENT.goodAmbience.get()) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null) return;
        Camera camera = event.getCamera();
        Vec3 cam = camera.getPosition();
        pose = event.getPoseStack().last();
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
        RenderType rt = RenderType.entityTranslucentEmissive(TEX);
        vc = buf.getBuffer(rt);
        Vector3f left = camera.getLeftVector(), up = camera.getUpVector();
        rx = -left.x(); ry = -left.y(); rz = -left.z();
        ux = up.x(); uy = up.y(); uz = up.z();
        double time = System.nanoTime() / 50_000_000.0;
        double py = p.getY();

        // бабочки: порхают у земли и в воздухе вокруг игрока, привязаны к миру плиткой
        for (int i = 0; i < BUTTERFLIES; i++) {
            double ox = hash(i, 1) * TILE, oz = hash(i, 2) * TILE;
            double dx = Mth.positiveModulo(ox - cam.x + TILE / 2, TILE) - TILE / 2
                    + Math.sin(time * 0.021 * (0.5 + hash(i, 4)) + i * 1.7) * 4.5;
            double dz = Mth.positiveModulo(oz - cam.z + TILE / 2, TILE) - TILE / 2
                    + Math.cos(time * 0.017 * (0.5 + hash(i, 5)) + i * 2.3) * 4.5;
            double hd = Math.sqrt(dx * dx + dz * dz);
            if (hd > 34.0 || hd < 1.5) continue;
            double y = py - 3.0 + 10.0 * hash(i, 3) + Math.sin(time * 0.05 + i) * 1.1 - cam.y;
            double fade = Mth.clamp((34.0 - hd) / 10.0, 0.0, 1.0);
            int frame = ((int) (time / 2.5 + hash(i, 6) * 10)) & 1;
            int[] t = TINTS[i % TINTS.length];
            sprite(dx, y, dz, 0.34 + 0.2 * hash(i, 7), frame, t[0], t[1], t[2], (int) (255 * fade));
        }

        // журавлики: три клина кружат высоко, взмахи крыльев по кадрам
        for (int f = 0; f < FLOCKS; f++) {
            double dir = (f % 2 == 0) ? 1.0 : -1.0;
            double a = time * 0.0022 * (1 + 0.3 * f) * dir + f * 2.1;
            double R = 78 + 14 * f;
            double hx = -Math.sin(a) * dir, hz = Math.cos(a) * dir;    // направление полёта
            double sx = hz, sz = -hx;                                   // вбок от направления
            double cx = R * Math.cos(a), cz = R * Math.sin(a);
            double cy = py + 36 + 9 * f + Math.sin(time * 0.01 + f) * 2.0 - cam.y;
            for (int j = 0; j < BIRDS; j++) {
                int side = (j + 1) / 2 * ((j % 2 == 1) ? 1 : -1);
                double back = Math.abs(side) * 3.0, lat = side * 3.2;
                double bx = cx - hx * back + sx * lat, bz = cz - hz * back + sz * lat;
                double by = cy + Math.sin(time * 0.06 + j) * 0.5;
                int frame = 2 + (((int) (time / 4.0 + j * 0.7)) & 1);
                sprite(bx, by, bz, 1.9, frame, 255, 236, 246, 235);
            }
        }
        buf.endBatch(rt);
        vc = null;
        pose = null;
    }
}
