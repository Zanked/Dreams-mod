package com.example.dreams.client;

import com.example.dreams.client.cutscene.CutsceneManager;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.Input;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.MovementInputUpdateEvent;
import com.example.dreams.Dreams;

/**
 * Прокатиться на ките: клавиша (по умолчанию G) зовёт первого кита, сновидец плавно взлетает на его спину и
 * летит по его кругу над островами. Присесть (или клавиша ещё раз) = спуститься обратно, туда, где ты сел.
 * Позиция ведётся на клиенте каждый тик, управление на время поездки отключено, мышь свободна: можно смотреть вокруг.
 */
@EventBusSubscriber(modid = Dreams.MODID, bus = EventBusSubscriber.Bus.GAME, value = Dist.CLIENT)
public final class WhaleRide {

    private WhaleRide() {}

    public static final KeyMapping KEY = new KeyMapping("key.dreams.whale", InputConstants.KEY_G, "key.categories.dreams");

    private static final int LIFT = 90;          // тиков: взлёт на спину
    private static final int RIDE_MAX = 2600;    // ~2 минуты, потом кит сам везёт обратно
    private static final int BACK = 110;         // тиков: спуск на место
    private static final double SPEED = 1.9;     // во сколько раз кит летит быстрее обычного

    private static int stage = 0;                // 0 нет, 1 взлёт, 2 полёт, 3 возвращение
    private static int tickIn = 0;
    private static Vec3 startPos = Vec3.ZERO;
    private static boolean hinted = false;
    private static final double[] TMP = new double[3];

    public static boolean riding() {
        return stage != 0;
    }

    private static double ease(double u) {
        u = Math.max(0.0, Math.min(1.0, u));
        return u * u * (3.0 - 2.0 * u);
    }

    private static void abort() {
        if (stage != 0) SkyWhales.rideEnd();
        stage = 0;
        tickIn = 0;
    }

    /** До движения игрока в тике: ставим его туда, где он должен быть сейчас. */
    @SubscribeEvent
    public static void onTickPre(ClientTickEvent.Pre event) {
        if (stage == 0) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || !SkyRing.inDreamWorld() || !GoodDreamClient.isAwake() || !SkyWhales.ridePoint(TMP)) {
            abort();
            return;
        }
        Vec3 back = new Vec3(TMP[0], TMP[1], TMP[2]);
        Vec3 target;
        if (stage == 1) target = startPos.lerp(back, ease(tickIn / (double) LIFT));
        else if (stage == 2) target = back;
        else target = back.lerp(startPos, ease(tickIn / (double) BACK));
        p.setPos(target.x, target.y, target.z);
        p.setDeltaMovement(Vec3.ZERO);
        p.fallDistance = 0.0f;
    }

    @SubscribeEvent
    public static void onTickPost(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) {
            stage = 0;
            return;
        }
        if (stage == 0) {
            if (!hinted && SkyRing.inDreamWorld() && GoodDreamClient.isAwake() && !CutsceneManager.isActive() && SkyWhales.rideReady()) {
                hinted = true;
                mc.gui.setOverlayMessage(Component.translatable("hint.dreams.whale_ride", KEY.getTranslatedKeyMessage()), false);
            }
            while (KEY.consumeClick()) {
                if (!SkyRing.inDreamWorld() || !GoodDreamClient.isAwake() || CutsceneManager.isActive()) continue;
                if (!SkyWhales.rideReady()) continue;
                stage = 1;
                tickIn = 0;
                startPos = p.position();
                SkyWhales.rideBegin();
            }
            return;
        }
        tickIn++;
        if (stage == 1) {
            if (tickIn >= LIFT) {
                stage = 2;
                tickIn = 0;
                SkyWhales.rideSpeed(SPEED);
                mc.gui.setOverlayMessage(Component.translatable("hint.dreams.whale_ride_end"), false);
            }
        } else if (stage == 2) {
            boolean stop = mc.options.keyShift.isDown() || tickIn >= RIDE_MAX;
            while (KEY.consumeClick()) stop = true;
            if (stop) {
                stage = 3;
                tickIn = 0;
            }
            // звёздная пыль и лепестки за китом
            var r = mc.level.getRandom();
            if (r.nextInt(2) == 0) {
                mc.level.addParticle(ParticleTypes.END_ROD, p.getX() + (r.nextDouble() - 0.5) * 3, p.getY() - 1.0 + r.nextDouble(),
                        p.getZ() + (r.nextDouble() - 0.5) * 3, 0.0, -0.02, 0.0);
            }
        } else if (stage == 3) {
            while (KEY.consumeClick()) { /* лишние нажатия не копим */ }
            if (tickIn >= BACK) {
                SkyWhales.rideEnd();
                stage = 0;
                tickIn = 0;
                p.setDeltaMovement(Vec3.ZERO);
                p.fallDistance = 0.0f;
            }
        }
    }

    /** На время поездки обычное управление выключено (как в катсценах); присесть читаем напрямую. */
    @SubscribeEvent
    public static void onMovement(MovementInputUpdateEvent event) {
        if (stage == 0) return;
        Input in = event.getInput();
        in.forwardImpulse = 0f;
        in.leftImpulse = 0f;
        in.up = false;
        in.down = false;
        in.left = false;
        in.right = false;
        in.jumping = false;
        in.shiftKeyDown = false;
    }
}
