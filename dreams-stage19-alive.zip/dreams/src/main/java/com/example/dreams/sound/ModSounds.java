package com.example.dreams.sound;

import com.example.dreams.Dreams;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Все звуки мода - собственные события. В assets/dreams/sounds.json они пока ссылаются на ванильные звуки.
 * Чтобы поставить свои: положи .ogg в assets/dreams/sounds/ и замени запись в sounds.json
 * (убери "type": "event", укажи "name": "dreams:имя_файла_без_расширения").
 */
public class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(Registries.SOUND_EVENT, Dreams.MODID);

    public static final DeferredHolder<SoundEvent, SoundEvent> HEARTBEAT = reg("heartbeat");
    public static final DeferredHolder<SoundEvent, SoundEvent> AMBIENT = reg("ambient");
    public static final DeferredHolder<SoundEvent, SoundEvent> CHIME = reg("chime");
    public static final DeferredHolder<SoundEvent, SoundEvent> SCARE = reg("scare");
    public static final DeferredHolder<SoundEvent, SoundEvent> WATCHER_STEP = reg("watcher_step");
    public static final DeferredHolder<SoundEvent, SoundEvent> WAKE = reg("wake");
    // этап 7: звуки "за спиной" и чёрная вспышка
    public static final DeferredHolder<SoundEvent, SoundEvent> BEHIND_STEP = reg("behind_step");
    public static final DeferredHolder<SoundEvent, SoundEvent> DOOR = reg("door");
    public static final DeferredHolder<SoundEvent, SoundEvent> KNOCK = reg("knock");
    public static final DeferredHolder<SoundEvent, SoundEvent> BREATH = reg("breath");
    public static final DeferredHolder<SoundEvent, SoundEvent> WHISPER = reg("whisper");
    public static final DeferredHolder<SoundEvent, SoundEvent> BLINK = reg("blink");

    // этап 8: Иная сторона
    public static final DeferredHolder<SoundEvent, SoundEvent> SIREN = reg("siren");
    public static final DeferredHolder<SoundEvent, SoundEvent> OW_BREAK = reg("ow_break");
    public static final DeferredHolder<SoundEvent, SoundEvent> DRONE = reg("drone");
    public static final DeferredHolder<SoundEvent, SoundEvent> STATIC = reg("static");
    public static final DeferredHolder<SoundEvent, SoundEvent> SCRAPE = reg("scrape");
    public static final DeferredHolder<SoundEvent, SoundEvent> CLANG = reg("clang");
    public static final DeferredHolder<SoundEvent, SoundEvent> CHAIN = reg("chain");

    // этап 9: Палач, фигуры, печати
    public static final DeferredHolder<SoundEvent, SoundEvent> EXEC_STEP = reg("exec_step");
    public static final DeferredHolder<SoundEvent, SoundEvent> EXEC_DRAG = reg("exec_drag");
    public static final DeferredHolder<SoundEvent, SoundEvent> EXEC_ROAR = reg("exec_roar");
    public static final DeferredHolder<SoundEvent, SoundEvent> FIGURE_MOAN = reg("figure_moan");
    public static final DeferredHolder<SoundEvent, SoundEvent> SEAL_HUM = reg("seal_hum");
    public static final DeferredHolder<SoundEvent, SoundEvent> SEAL_ACTIVATE = reg("seal_activate");
    public static final DeferredHolder<SoundEvent, SoundEvent> UNSEAL = reg("unseal");

    // добрый сон
    public static final DeferredHolder<SoundEvent, SoundEvent> TILE_NOTE = reg("tile_note");
    public static final DeferredHolder<SoundEvent, SoundEvent> MEMORY = reg("memory");
    public static final DeferredHolder<SoundEvent, SoundEvent> TREE_HUM = reg("tree_hum");
    public static final DeferredHolder<SoundEvent, SoundEvent> GOOD_FINALE = reg("good_finale");
    public static final DeferredHolder<SoundEvent, SoundEvent> STEP_NOTE = reg("step_note");
    public static final DeferredHolder<SoundEvent, SoundEvent> JUMP_NOTE = reg("jump_note");
    /** Три слоя хора одинаковой длины (запускаются одновременно, громкость каждого ведёт клиент). */
    public static final DeferredHolder<SoundEvent, SoundEvent> GOOD_SONG = reg("good_song");   // авторская песня доброго сна
    public static final DeferredHolder<SoundEvent, SoundEvent> DREAM_WIND = reg("dream_wind");
    public static final DeferredHolder<SoundEvent, SoundEvent> DREAM_WATER = reg("dream_water");
    public static final DeferredHolder<SoundEvent, SoundEvent> DREAM_CHIME = reg("dream_chime");
    public static final DeferredHolder<SoundEvent, SoundEvent> CHOIR_BASE = reg("choir_base");
    public static final DeferredHolder<SoundEvent, SoundEvent> CHOIR_ORGAN = reg("choir_organ");
    public static final DeferredHolder<SoundEvent, SoundEvent> CHOIR_HIGH = reg("choir_high");

    private static DeferredHolder<SoundEvent, SoundEvent> reg(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(
                ResourceLocation.fromNamespaceAndPath(Dreams.MODID, name)));
    }
}
