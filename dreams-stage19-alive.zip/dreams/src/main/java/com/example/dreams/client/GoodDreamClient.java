package com.example.dreams.client;

import com.example.dreams.DreamConfig;
import com.example.dreams.Dreams;
import com.example.dreams.client.cutscene.CutsceneManager;
import com.example.dreams.dream.DreamTimeline;
import com.example.dreams.sound.ModSounds;
import com.mojang.logging.LogUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.FogRenderer;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.material.FogType;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RenderGuiEvent;
import net.neoforged.neoforge.client.event.ViewportEvent;

/**
 * Добрый сон на клиенте: золотая дымка, мягкая виньетка, индикатор огней и хор.
 * Хор состоит из трёх слоёв (категория звука AMBIENT, чтобы не зависеть от ползунка музыки) одинаковой длины (основа, орган, высокие голоса), которые стартуют вместе;
 * чем больше огней собрано, тем больше слоёв слышно. На финале у Древа играют все.
 */
@EventBusSubscriber(modid = Dreams.MODID, bus = EventBusSubscriber.Bus.GAME, value = Dist.CLIENT)
public class GoodDreamClient {

    private static final org.slf4j.Logger LOGGER = LogUtils.getLogger();

    private static boolean active = false;     // идёт сон доброго вида (в постели или уже в мире сна)
    private static boolean awake = false;      // вышел в мир сна
    private static int ticks = 0;
    private static int lights = 0;
    private static int finaleTotal = 0;
    private static int finaleLeft = 0;
    private static float vis = 0f;             // 0..1 плавное появление дымки

    private static final StemSound[] STEMS = new StemSound[3];
    private static SongSound song = null;
    private static int ticksSinceCheck = 0;

    public static boolean isAwake() {
        return active && awake;
    }

    // ---------- события от сервера

    /** Смена фазы сна (вызывается из NightmareClient.setPhase). */
    public static void onPhase(int phase, int kind) {
        if (phase == DreamTimeline.PHASE_NONE || kind != DreamTimeline.KIND_GOOD) {
            if (active) {
                SkyWhales.reset();
                CutsceneManager.stop(false);
            }
            active = false;
            awake = false;
            finaleLeft = 0;
            return;
        }
        if (!active) {
            active = true;
            ticks = 0;
            lights = 0;
            finaleLeft = 0;
            finaleTotal = 0;
            startMusic();   // (киты сбрасываются при выходе из сна: сид мог прийти раньше пакета фазы)
        }
        if (phase == DreamTimeline.PHASE_FALSE_AWAKE && !awake) {
            awake = true;
            CutsceneManager.play("good_prologue", 0.0, 0.0, 0.0);   // пролог: камера входит в глаза сновидца
            startSong();
        }
    }

    public static void onFx(int type, int arg) {
        if (type == DreamTimeline.FX_GOOD_LIGHTS) {
            lights = Mth.clamp(arg, 0, DreamTimeline.GOOD_LIGHTS_TOTAL);
            SkyWhales.setLights(lights);
        } else if (type == DreamTimeline.FX_GOOD_WHALES) {
            SkyWhales.setSeed(arg / 10000.0);
        } else if (type == DreamTimeline.FX_GOOD_FINALE) {
            finaleTotal = Math.max(40, arg);
            finaleLeft = finaleTotal;
            SkyWhales.startFinale();
            CutsceneManager.play("finale_rise", 0.0, 0.0, 0.0);
            if (DreamConfig.CLIENT.goodMusic.get()) {   // отдельный финал: аминь и колокол, звучит и после пробуждения
                Minecraft.getInstance().getSoundManager().play(
                        SimpleSoundInstance.forUI(ModSounds.GOOD_FINALE.get(), 1.0f,
                                DreamConfig.CLIENT.goodMusicVolume.get().floatValue()));
            }
        }
    }

    public static void reset() {
        song = null;
        SkyWhales.reset();
        CutsceneManager.stop(false);
        active = false;
        awake = false;
        ticks = 0;
        lights = 0;
        finaleLeft = 0;
        vis = 0f;
    }

    // ---------- хор

    private static void startMusic() {
        if (!DreamConfig.CLIENT.goodMusic.get()) {
            LOGGER.info("[dreams] good dream music is off (dreams-client.toml: goodMusic=false)");
            return;
        }
        var sm = Minecraft.getInstance().getSoundManager();
        SoundEvent[] events = {ModSounds.CHOIR_BASE.get(), ModSounds.CHOIR_ORGAN.get(), ModSounds.CHOIR_HIGH.get()};
        for (int i = 0; i < STEMS.length; i++) {
            if (STEMS[i] == null || STEMS[i].isStopped()) {
                LOGGER.info("[dreams] good dream music: starting choir layer {} (category AMBIENT)", i);
                STEMS[i] = new StemSound(events[i], i);
                sm.play(STEMS[i]);
            }
        }
    }

    /** Песня доброго сна: мягко вступает, когда сновидец вышел в мир, и играет по кругу, пока идёт сон. */
    private static void startSong() {
        if (!DreamConfig.CLIENT.goodSong.get()) return;
        if (song != null && !song.isStopped()) return;
        LOGGER.info("[dreams] good dream song: starting (category AMBIENT, assets/dreams/sounds/good_song.ogg)");
        song = new SongSound();
        Minecraft.getInstance().getSoundManager().play(song);
    }

    private static boolean songAudible() {
        return song != null && !song.isStopped() && finaleLeft <= 0;
    }

    /** Одна дорожка песни: не позиционная, по кругу, громкость плавно ведёт сама. Ползунок «Музыка». */
    private static class SongSound extends net.minecraft.client.resources.sounds.AbstractTickableSoundInstance {
        private float cur = 0f;

        SongSound() {
            super(ModSounds.GOOD_SONG.get(), SoundSource.AMBIENT, RandomSource.create());   // как хор: свой ползунок не обнулит песню
            this.looping = true;
            this.delay = 0;
            this.volume = 0.0001f;
            this.relative = true;
            this.attenuation = SoundInstance.Attenuation.NONE;
        }

        @Override
        public boolean canStartSilent() {
            return true;   // ползунок на нуле на старте не должен навсегда снимать песню с проигрывания
        }

        @Override
        public void tick() {
            float target = !active ? 0f : finaleLeft > 0 ? 0.3f : 1f;   // в финале уступает хору
            cur += (target - cur) * (target > cur ? 0.012f : 0.03f);     // вступает медленно, стихает быстрее
            this.volume = Math.max(0.0001f, cur * DreamConfig.CLIENT.goodSongVolume.get().floatValue());
            if (!active && cur < 0.01f) stop();
        }
    }

    private static float targetVolume(int idx) {
        if (!active) return 0f;
        float lf = lights / (float) DreamTimeline.GOOD_LIGHTS_TOTAL;
        if (finaleLeft > 0) {
            return idx == 0 ? 0.95f : idx == 1 ? 0.9f : 0.85f;
        }
        if (!awake) return idx == 0 ? 0.30f : 0f;   // в постели хор только угадывается
        return switch (idx) {
            case 0 -> 0.62f + 0.25f * lf;
            case 1 -> 0.55f * Mth.clamp((lights - 1) / 3f, 0f, 1f);
            default -> 0.50f * Mth.clamp((lights - 2) / 2f, 0f, 1f);
        };
    }

    /** Один слой хора: циклический, не позиционный, громкость плавно ведёт targetVolume. */
    private static class StemSound extends net.minecraft.client.resources.sounds.AbstractTickableSoundInstance {
        private final int idx;
        private float cur = 0f;
        private boolean logged = false;

        StemSound(SoundEvent event, int idx) {
            super(event, SoundSource.AMBIENT, RandomSource.create());
            this.idx = idx;
            this.looping = true;
            this.delay = 0;
            this.volume = 0.0001f;
            this.relative = true;
            this.attenuation = SoundInstance.Attenuation.NONE;
        }

        @Override
        public void tick() {
            float target = targetVolume(idx) * (songAudible() ? 0.45f : 1f);   // под песней хор тише
            cur += (target - cur) * (target > cur ? 0.02f : 0.04f);
            this.volume = Math.max(0.0001f, cur * DreamConfig.CLIENT.goodMusicVolume.get().floatValue());
            if (!logged && this.volume > 0.05f) {
                logged = true;
                LOGGER.info("[dreams] choir layer {} is audible (volume {})", idx, this.volume);
            }
            if (!active && cur < 0.01f) stop();
        }
    }

    // ---------- тик

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            reset();
            return;
        }
        if (mc.isPaused()) return;
        SkyWhales.tick(active && awake);
        if (active) ticks++;
        // звуки могли оборваться (смена измерения, перезапуск звукового движка): подхватываем
        if (active && ticksSinceCheck++ >= 40) {
            ticksSinceCheck = 0;
            if (DreamConfig.CLIENT.goodMusic.get()) startMusic();
            if (awake && DreamConfig.CLIENT.goodSong.get() && (song == null || song.isStopped())) startSong();
        }
        if (finaleLeft > 0) finaleLeft--;
        float tv = !active ? 0f : finaleLeft > 0 ? 0.25f : awake ? 1f : 0.35f;
        if (!DreamConfig.CLIENT.goodVisuals.get()) tv = 0f;
        vis += (tv - vis) * 0.03f;
        if (vis < 0.001f) vis = 0f;
    }

    // ---------- туман и цвет

    @SubscribeEvent
    public static void onFog(ViewportEvent.RenderFog event) {
        if (vis <= 0.001f) return;
        if (event.getType() != FogType.NONE) return;
        if (event.getMode() != FogRenderer.FogMode.FOG_TERRAIN) return;
        float orig = event.getFarPlaneDistance();
        boolean fin = finaleLeft > 0;
        boolean dim = SkyRing.inDreamWorld();   // в своём мире дали открыты: острова видны далеко, лёгкая сиреневая дымка
        float far = fin ? orig : Mth.lerp(vis * (dim ? 0.55f : 0.7f), orig, Math.min(orig, dim ? 320f : 110f));   // мягкая золотая даль; в финале чистое небо
        event.setNearPlaneDistance(Mth.lerp(vis, event.getNearPlaneDistance(), fin ? 60f : (dim ? 48f : 20f)));
        event.setFarPlaneDistance(far);
        event.setCanceled(true);
    }

    @SubscribeEvent
    public static void onFogColor(ViewportEvent.ComputeFogColor event) {
        if (vis <= 0.001f) return;
        if (SkyRing.inDreamWorld()) {   // мир сна: тянем только чуть к персиковому, основной цвет задаёт биом
            float kd = vis * 0.18f;
            event.setRed(Mth.lerp(kd, event.getRed(), 1.00f));
            event.setGreen(Mth.lerp(kd, event.getGreen(), 0.72f));
            event.setBlue(Mth.lerp(kd, event.getBlue(), 0.78f));
            return;
        }
        float k = vis * 0.78f;
        event.setRed(Mth.lerp(k, event.getRed(), 1.00f));
        event.setGreen(Mth.lerp(k, event.getGreen(), 0.87f));
        event.setBlue(Mth.lerp(k, event.getBlue(), 0.68f));
    }

    @SubscribeEvent
    public static void onCamera(ViewportEvent.ComputeCameraAngles event) {
        if (CutsceneManager.isActive()) return;
        if (vis <= 0.001f || DreamConfig.CLIENT.reducedMotion.get()) return;
        float t = ticks + (float) event.getPartialTick();
        event.setRoll(event.getRoll() + Mth.sin(t * 0.021f) * 0.9f * vis);   // едва заметное качание, как на облаке
        event.setPitch(event.getPitch() + Mth.sin(t * 0.017f + 1.1f) * 0.35f * vis);
    }

    @SubscribeEvent
    public static void onFov(ViewportEvent.ComputeFov event) {
        if (CutsceneManager.isActive()) return;
        if (vis <= 0.001f || DreamConfig.CLIENT.reducedMotion.get()) return;
        float t = ticks + (float) event.getPartialTick();
        event.setFOV(event.getFOV() + Mth.sin(t * 0.03f) * 1.4f * vis);
    }

    // ---------- HUD

    @SubscribeEvent
    public static void onGui(RenderGuiEvent.Post event) {
        if (vis <= 0.001f && finaleLeft <= 0) return;
        GuiGraphics g = event.getGuiGraphics();
        int w = g.guiWidth();
        int h = g.guiHeight();
        float scale = DreamConfig.CLIENT.effectScale.get().floatValue();

        if (vis > 0.001f) {
            boolean dim = SkyRing.inDreamWorld();
            int tint = (int) (255 * (dim ? 0.045f : 0.09f) * vis * scale);
            g.fill(0, 0, w, h, (tint << 24) | (dim ? 0xFFB8E0 : 0xFFE0A0));   // тёплая (в мире сна розоватая) цветокоррекция
            drawGlow(g, w, h, vis * scale);
        }
        if (awake && vis > 0.5f && finaleLeft <= 0) drawLights(g, w);

        if (finaleLeft > 0) {                                             // Древо проснулось: свет заливает мир
            int ft = finaleTotal - finaleLeft;
            float a = ft < 24 ? ft / 24f * 0.9f : Math.max(0f, 0.9f - (ft - 24) / 70f * 0.9f);   // вспышка и сразу открывается небо
            if (finaleLeft < 60) a = Math.max(a, 1f - finaleLeft / 60f);                       // в конце всё заливает белый свет
            g.fill(0, 0, w, h, ((int) (255 * Mth.clamp(a * scale, 0f, 1f)) << 24) | 0xFFF6DC);
        }
    }

    /** Мягкая светлая виньетка. */
    private static void drawGlow(GuiGraphics g, int w, int h, float i) {
        int steps = 16;
        int maxInset = (int) (Math.min(w, h) * 0.32f);
        int size = Math.max(1, maxInset / steps);
        for (int s = 0; s < steps; s++) {
            float f = 1f - (float) s / steps;
            int a = (int) (255 * 0.32f * i * f * f);
            if (a <= 0) continue;
            int color = (Mth.clamp(a, 0, 255) << 24) | 0xFFF1D0;
            int in = s * size;
            g.fill(in, in, w - in, in + size, color);
            g.fill(in, h - in - size, w - in, h - in, color);
            g.fill(in, in + size, in + size, h - in - size, color);
            g.fill(w - in - size, in + size, w - in, h - in - size, color);
        }
    }

    /** Пять огней сверху по центру: собранные горят золотом. */
    private static void drawLights(GuiGraphics g, int w) {
        int n = DreamTimeline.GOOD_LIGHTS_TOTAL;
        int size = 6;
        int gap = 5;
        int total = n * size + (n - 1) * gap;
        int x0 = (w - total) / 2;
        int y = 8;
        for (int i = 0; i < n; i++) {
            int x = x0 + i * (size + gap);
            boolean lit = i < lights;
            g.fill(x - 1, y - 1, x + size + 1, y + size + 1, 0x66301800);
            g.fill(x, y, x + size, y + size, lit ? 0xFFFFD27A : 0x55FFFFFF);
            if (lit) g.fill(x + 1, y + 1, x + size - 2, y + size - 2, 0xFFFFF4C8);
        }
    }
}
