"""Звуки мира доброго сна (синтез): ветер (петля), водопад, колокольчики пагод. Нужны numpy, scipy и ffmpeg.
python3 gen_ambience.py src/main/resources/assets/dreams"""
import os, sys, subprocess, math
import numpy as np
from scipy.signal import butter, sosfilt
from scipy.io import wavfile
ROOT = sys.argv[1] if len(sys.argv) > 1 else "src/main/resources/assets/dreams"
OUT = os.path.join(ROOT, "sounds"); os.makedirs(OUT, exist_ok=True)
SR = 44100
rng = np.random.default_rng(42)

def to_ogg(name, data, q=4):
    d = np.asarray(data, float)
    peak = np.max(np.abs(d)) + 1e-9
    d = d / peak * 0.7
    tmp = f"/tmp/{name}.wav"
    wavfile.write(tmp, SR, (d * 32767).astype(np.int16))
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", tmp, "-c:a", "libvorbis", "-q:a", str(q), os.path.join(OUT, name + ".ogg")], check=True)

def band(x, lo, hi, order=3):
    return sosfilt(butter(order, [lo, hi], btype="band", fs=SR, output="sos"), x)

def lowp(x, f, order=3):
    return sosfilt(butter(order, f, btype="low", fs=SR, output="sos"), x)

def loopify(x, fade):
    n = len(x) - fade
    y = x[:n].copy()
    w = np.linspace(0, 1, fade)
    y[:fade] = x[:fade] * w + x[n:] * (1 - w)
    return y

# --- ветер: стерео, 22 с, плавные порывы, лёгкий свист; петля без шва
L = 22 * SR + 2 * SR
def wind(seed):
    r = np.random.default_rng(seed)
    n = r.standard_normal(L)
    base = lowp(n, 500) * 2.2 + band(n, 600, 1400) * 0.7
    t = np.arange(L) / SR
    gust = 0.55 + 0.45 * (0.5 + 0.5 * np.sin(2 * np.pi * t / 7.3 + seed) * np.sin(2 * np.pi * t / 11.1 + 1.0 + seed))
    whistle = band(r.standard_normal(L), 900, 1300) * (0.2 + 0.2 * np.sin(2 * np.pi * t / 5.1 + seed * 2) ** 2)
    return (base * gust + whistle)
wl, wr = loopify(wind(1), 2 * SR), loopify(wind(2), 2 * SR)
to_ogg("dream_wind", np.stack([wl, wr], axis=1), q=3)

# --- водопад: моно, 8 с (проигрывается кусками из точки у воды)
Lw = 8 * SR + SR
n = rng.standard_normal(Lw)
w = band(n, 300, 3200) * 1.0 + band(rng.standard_normal(Lw), 3500, 9000) * 0.35 + lowp(rng.standard_normal(Lw), 160) * 0.9
t = np.arange(Lw) / SR
w *= 0.8 + 0.2 * np.sin(2 * np.pi * t / 2.3)
to_ogg("dream_water", loopify(w, SR), q=3)

# --- колокольчики: пентатоника, моно, ~4 с
def bell(freq, dur=4.2, bright=1.0):
    t = np.arange(int(dur * SR)) / SR
    s = np.zeros_like(t)
    for ratio, dec, amp in ((1.0, 2.6, 1.0), (2.76, 1.7, 0.55), (5.40, 1.0, 0.30), (8.93, 0.55, 0.16 * bright)):
        s += amp * np.sin(2 * np.pi * freq * ratio * t + rng.random() * 6.28) * np.exp(-t / dec * 1.3)
    s *= np.minimum(1.0, t / 0.004)
    # короткий удар
    click = band(rng.standard_normal(len(t)), 2500, 7000) * np.exp(-t / 0.012) * 0.25
    return s + click
notes = [523.25, 587.33, 659.25, 783.99, 880.0]
for i, f in enumerate(notes, 1):
    to_ogg(f"dream_chime_{i}", bell(f * (1 if i % 2 else 0.5 * 2)), q=4)
# более глубокий колокол и бамбуковые трубочки
to_ogg("dream_chime_6", bell(261.63, dur=5.0, bright=0.6), q=4)
print("ambience ok")
