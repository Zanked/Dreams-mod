package com.example.dreams.dream.world.town;

import com.example.dreams.dream.world.town.Town.B;
import com.example.dreams.dream.world.town.Town.Clip;
import com.example.dreams.dream.world.town.Town.Sink;

import java.util.ArrayList;
import java.util.List;

import static com.example.dreams.dream.world.town.Town.F0;
import static com.example.dreams.dream.world.town.Town.G;

/** Планировка: улицы, участки, площадь, набережная над пропастью, пирс, уличная мелочь, рельеф. */
final class TownMap {
    private TownMap() {}

    static final int AB_CV = -155, AB_A = 190, AB_B = 88;       // эллипс пропасти
    static final int PIER_END = -128;

    // Остров: плато с городом ограничено со всех сторон (запад и восток |u| <= IS_U, юг v <= IS_V1, север IS_V0),
    // дальше пропасть без дна. На севере кромку по-прежнему ведёт эллипс, он глубже и красивее прямой.
    static final int IS_U = 114, IS_V0 = -90, IS_V1 = 100;
    static final int FENCE_U = 106, FENCE_V = 92;       // ограда по краю острова (запад, восток, юг)

    // ------------------------------------------------------------------ участки
    static final class Lot {
        final String kind; final int u0, v0, u1, v1, front; final long seed;
        Lot(String kind, int u0, int v0, int u1, int v1, int front, long seed) {
            this.kind = kind; this.u0 = u0; this.v0 = v0; this.u1 = u1; this.v1 = v1; this.front = front; this.seed = seed;
        }
    }

    static List<Lot> lots(long seed) {
        List<Lot> l = new ArrayList<>();
        int N = 0, E = 1, S = 2, W = 3;
        l.add(new Lot("church", 5, -39, 47, -5, S, seed + 1));
        l.add(new Lot("police", -47, -39, -5, -5, S, seed + 2));
        l.add(new Lot("hotel", -90, -39, -58, -5, S, seed + 3));
        l.add(new Lot("house", 58, -39, 90, -23, N, seed + 4));
        l.add(new Lot("house", 58, -21, 90, -5, S, seed + 5));
        l.add(new Lot("house", -90, 5, -58, 20, N, seed + 6));
        l.add(new Lot("house", -90, 22, -58, 37, S, seed + 7));
        l.add(new Lot("shop", -47, 5, -37, 20, N, seed + 8));
        l.add(new Lot("shop", -36, 5, -26, 20, N, seed + 9));
        l.add(new Lot("diner", -24, 5, -5, 20, N, seed + 10));
        l.add(new Lot("home", -47, 23, -31, 37, S, seed + 11));
        l.add(new Lot("hospital", 5, 5, 47, 37, N, seed + 12));
        l.add(new Lot("school", 58, 5, 90, 37, W, seed + 13));
        l.add(new Lot("house", -90, 47, -75, 62, N, seed + 14));
        l.add(new Lot("house", -73, 47, -58, 62, N, seed + 15));
        l.add(new Lot("apartments", -47, 47, -5, 66, N, seed + 16));
        l.add(new Lot("gas", 5, 47, 47, 75, N, seed + 17));
        l.add(new Lot("house", 58, 47, 73, 62, N, seed + 18));
        l.add(new Lot("house", 75, 47, 90, 62, N, seed + 19));
        return l;
    }

    // ------------------------------------------------------------------ улицы
    // горизонтальные (вдоль u): центр v, от u0 до u1; вертикальные: центр u, от v0 до v1
    static final int[][] HROADS = {{-44, -92, 92}, {0, -92, 92}, {42, -92, 92}};
    static final int[][] VROADS = {{0, -48, 78}, {-52, -48, 46}, {52, -48, 46}};

    /** 0 нет, 1 тротуар, 2 асфальт, 3 жёлтая разметка, 4 белая разметка (переход). */
    static int road(int u, int v) {
        int best = 0;
        for (int[] r : HROADS) {
            if (u < r[1] || u > r[2]) continue;
            int o = Math.abs(v - r[0]);
            if (o > 4) continue;
            int k = o >= 3 ? 1 : (o == 0 && (u & 3) < 2) ? 3 : 2;
            best = Math.max(best, k);
        }
        for (int[] r : VROADS) {
            if (v < r[1] || v > r[2]) continue;
            int o = Math.abs(u - r[0]);
            if (o > 4) continue;
            int k = o >= 3 ? 1 : (o == 0 && (v & 3) < 2) ? 3 : 2;
            if (best == 1 && k == 3) k = 3;
            best = best == 2 && k == 1 ? 2 : Math.max(best, k);
        }
        // перекрёстки: асфальт без разметки
        for (int[] h : HROADS) for (int[] w : VROADS)
            if (Math.abs(v - h[0]) <= 4 && Math.abs(u - w[0]) <= 4 && u >= h[1] && u <= h[2] && v >= w[1] && v <= w[2]) {
                int ou = Math.abs(u - w[0]), ov = Math.abs(v - h[0]);
                best = (ou <= 2 || ov <= 2) ? 2 : 1;
                if (ou <= 2 && ov <= 2) best = 2;
            }
        return best;
    }

    static boolean inPlaza(int u, int v) { return u * u + v * v <= 64; }

    // ------------------------------------------------------------------ рельеф
    static double smooth(double t) { t = Math.max(0, Math.min(1, t)); return t * t * (3 - 2 * t); }

    /** Высота верхнего блока земли в (u, v) по миру. Мировой шум, на плато плоско. Пропасть учитывается отдельно. */
    static int ground(long seed, int wx, int wz, int u, int v) {
        double dx = Math.max(Math.max(-100 - u, u - 100), 0), dz = Math.max(Math.max(-72 - v, v - 84), 0);
        double dist = Math.hypot(dx, dz);
        double w = smooth(dist / 46.0);
        double hills = 7.0 * Town.nz(seed, 11, wx, wz, 56) + 3.0 * Town.nz(seed, 12, wx, wz, 21) + 1.2 * Town.nz(seed, 13, wx, wz, 8);
        return G + (int) Math.round(hills * w);
    }

    /**
     * Глубина внутрь пропасти в блоках (>0 = пропасть): максимум из северного эллипса и расстояния за краем острова.
     * Так город один: за его границей со всех сторон обрыв, а не холмы и следующий город.
     */
    static double abyssDepth(long seed, int u, int v) {
        double q = Math.hypot(u / (double) AB_A, (v - AB_CV) / (double) AB_B);
        double wob = 0.018 * Town.nz(seed, 21, u, v, 13) + 0.012 * Math.sin(u * 0.11 + seed % 7) + 0.01 * Town.nz(seed, 22, u, v, 5);
        double ellipse = (1.0 - (q + wob)) * AB_B;
        double eu = Math.abs(u) - IS_U, ev = Math.max(v - IS_V1, IS_V0 - v);
        double out = (eu > 0 && ev > 0) ? Math.hypot(eu, ev) : Math.max(eu, ev);
        out += 1.1 * Town.nz(seed, 23, u, v, 11) + 0.5 * Town.nz(seed, 24, u, v, 4);   // рваный край
        return Math.max(ellipse, out);
    }

    static double abyssQ(long seed, int u, int v) {
        return 1.0 - abyssDepth(seed, u, v) / AB_B;
    }

    static boolean inAbyss(long seed, int u, int v) { return abyssQ(seed, u, v) < 1.0; }

    /** Расстояние внутрь пропасти от кромки в блоках (приблизительно); <0 вне. */
    static double rimDepth(long seed, int u, int v) { return (1.0 - abyssQ(seed, u, v)) * AB_B; }

    /** Выступ-карниз стены пропасти на уровне y. */
    static boolean ledge(long seed, int u, int v, int y) {
        double s = rimDepth(seed, u, v);
        if (s <= 0 || s > 9) return false;
        for (int k = 0; k < 4; k++) {
            int yl = G - 11 - k * 14 - (int) Math.round(3 * Town.nz(seed, 30 + k, u, v, 17));
            if (Math.abs(y - yl) <= 1) {
                double ext = 1.5 + 5.5 * Math.max(0, Town.nz(seed, 40 + k, u, v, 9) + 0.2);
                if (s < ext) return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------------------ сборка
    static void build(Sink s, long seed, Clip clip) {
        Cx c = new Cx(s, seed);
        List<Lot> lots = lots(seed);
        surfaces(c, seed, clip, lots);
        promenade(c, seed, clip);
        pier(c, seed, clip);
        islandFence(c, seed, clip);
        plaza(c, clip);
        streetProps(c, seed, clip);
        for (Lot lot : lots) {
            if (!clip.hits(lot.u0 - 4, lot.v0 - 4, lot.u1 + 4, lot.v1 + 4)) continue;
            Buildings.build(c, lot);
        }
        trees(c, seed, clip, lots);
        bloodTrail(c, seed, clip);
        manholes(c, seed, clip);
        abyssEyes(c, seed, clip);
        marks(c);
    }

    static void marks(Cx c) {
        c.s.mark("start", 2, F0, 11);
    }

    static boolean occupied(int u, int v, List<Lot> lots) {
        if (road(u, v) != 0 || inPlaza(u, v)) return true;
        for (Lot l : lots) if (u >= l.u0 - 1 && u <= l.u1 + 1 && v >= l.v0 - 1 && v <= l.v1 + 1) return true;
        return false;
    }

    static void surfaces(Cx c, long seed, Clip clip, List<Lot> lots) {
        int u0 = Math.max(clip.u0, -110), u1 = Math.min(clip.u1, 110), v0 = Math.max(clip.v0, -75), v1 = Math.min(clip.v1, 90);
        for (int u = u0; u <= u1; u++) {
            for (int v = v0; v <= v1; v++) {
                int k = road(u, v);
                if (k == 0) continue;
                B b;
                double h = Town.rand(seed, u, v, 0, 5);
                if (k == 1) b = h < 0.06 ? B.COBBLE_BLOOD : B.CURB;
                else if (k == 3) b = B.ROAD_YELLOW;
                else b = h < 0.015 ? B.COBBLE : B.ASPHALT;
                c.p(u, G, v, b);
            }
        }
    }

    // ------------------------------------------------------------------ площадь с фонтаном
    static void plaza(Cx c, Clip clip) {
        if (!clip.hits(-10, -10, 10, 10)) return;
        for (int u = -9; u <= 9; u++) for (int v = -9; v <= 9; v++) {
            int d2 = u * u + v * v;
            if (d2 > 64) continue;
            c.p(u, G, v, d2 > 49 ? B.CURB : ((u + v) & 1) == 0 ? B.COBBLE : B.CURB);
        }
        // сухой фонтан: чаша, в ней кровавая плитка, колонна с глазом
        for (int u = -4; u <= 4; u++) for (int v = -4; v <= 4; v++) {
            int d2 = u * u + v * v;
            if (d2 > 16 || d2 < 6) { if (d2 <= 16) { c.p(u, G, v, B.COBBLE_BLOOD); } continue; }
            c.p(u, F0, v, B.STONE);
            if (d2 >= 12) c.p(u, F0 + 1, v, B.STONE);
        }
        for (int u = -2; u <= 2; u++) for (int v = -2; v <= 2; v++) if (u * u + v * v <= 5) c.p(u, G, v, B.COBBLE_BLOOD);
        c.box(0, F0, 0, 0, F0 + 3, 0, B.STONE);
        c.p(0, F0 + 4, 0, B.EYE);
        c.p(0, F0 + 5, 0, B.LANTERN);
        // скамьи у края
        for (int d = 0; d < 4; d++) {
            int x = Town.dx(d) * 7, z = Town.dz(d) * 7;
            c.stair(x, F0, z, B.V_SPRUCE, d, false);
        }
    }

    // ------------------------------------------------------------------ набережная над пропастью
    static void promenade(Cx c, long seed, Clip clip) {
        if (!clip.hits(-100, -72, 100, -48)) return;
        int u0 = Math.max(clip.u0, -92), u1 = Math.min(clip.u1, 92);
        // дорожка вдоль края
        for (int u = u0; u <= u1; u++) for (int v = -56; v <= -54; v++) c.p(u, G, v, B.CURB);
        // сетчатый забор у края (с проломом у пирса)
        Cx.Net fence = c.net(B.FENCE_CHAIN_UP);
        fence.line(-92, -62, -7, -62);
        fence.line(7, -62, 92, -62);
        fence.line(-7, -62, -7, -62); fence.line(7, -62, 7, -62);
        fence.flush(F0, F0);
        for (int u = -92; u <= 92; u += 8) {
            if (u < u0 - 1 || u > u1 + 1) continue;
            if (Math.abs(u) < 8) continue;
            if ((u & 15) == 0) lamp(c, seed, u, -56, 0, 2, u * 3 + 1);
        }
        // скамьи
        for (int u = -80; u <= 80; u += 20) {
            if (Math.abs(u) < 12 || u < u0 - 2 || u > u1 + 2) continue;
            c.stair(u, F0, -58, B.V_SPRUCE, 0, false);
            c.stair(u + 1, F0, -58, B.V_SPRUCE, 0, false);
        }
        // обрыв у пирса: табличка-барьер
        c.pf(-8, F0, -61, B.BARRIER, 0);
        c.pf(8, F0, -61, B.BARRIER, 0);
    }

    /** Ограда по краю острова (запад, восток, юг), у северной набережной стыкуется с её забором. В паре мест пролом. */
    static void islandFence(Cx c, long seed, Clip clip) {
        if (!clip.hits(-FENCE_U - 1, -63, FENCE_U + 1, FENCE_V + 1)) return;
        Cx.Net f = c.net(B.FENCE_CHAIN_UP);
        f.line(-FENCE_U, -62, -FENCE_U, FENCE_V);
        f.line(FENCE_U, -62, FENCE_U, FENCE_V);
        f.line(-FENCE_U, FENCE_V, FENCE_U, FENCE_V);
        f.line(-FENCE_U, -62, -93, -62);
        f.line(93, -62, FENCE_U, -62);
        // проломы: смотрят в пропасть
        int[][] gaps = {{-FENCE_U, 20}, {FENCE_U, -18}, {-30, FENCE_V}, {44, FENCE_V}};
        for (int[] g : gaps) for (int d = -1; d <= 1; d++) {
            if (g[0] == -FENCE_U || g[0] == FENCE_U) f.remove(g[0], g[1] + d); else f.remove(g[0] + d, g[1]);
        }
        f.flush(F0, F0);
    }

    static void pier(Cx c, long seed, Clip clip) {
        if (!clip.hits(-12, -140, 12, -60)) return;
        for (int v = -66; v >= PIER_END + 4; v--) {
            for (int u = -3; u <= 3; u++) c.p(u, G, v, (Math.abs(u) == 3 || Math.abs(u) == 0 && (v & 3) == 0) ? B.RUST_PLATE : B.RUST_GRATE);
            c.p(-3, G - 1, v, B.BEAM); c.p(3, G - 1, v, B.BEAM);
            if ((v & 3) == 0) { for (int u = -2; u <= 2; u++) c.p(u, G - 1, v, B.BEAM); c.box(-3, G - 6, v, -3, G - 2, v, B.CHAIN); c.box(3, G - 6, v, 3, G - 2, v, B.CHAIN); }
            if (v % 8 == 0) { c.p(-3, F0, v, B.BEAM); c.p(-3, F0 + 1, v, B.BEAM); c.p(-3, F0 + 2, v, B.LANTERN); c.p(3, F0, v, B.BEAM); c.p(3, F0 + 1, v, B.BEAM); c.p(3, F0 + 2, v, B.LANTERN); }
        }
        Cx.Net rail = c.net(B.FENCE_CHAIN_UP);
        rail.line(-3, -66, -3, PIER_END + 4); rail.line(3, -66, 3, PIER_END + 4);
        rail.flush(F0, F0);
        // круглая площадка на конце и смотровая будка
        int cz = PIER_END;
        for (int u = -9; u <= 9; u++) for (int v = cz - 9; v <= cz + 9; v++) {
            int d2 = u * u + (v - cz) * (v - cz);
            if (d2 > 81) continue;
            c.p(u, G, v, d2 > 64 ? B.BEAM : (d2 < 20 ? B.RUST_BLOODY : B.RUST_PLATE));
            if (d2 > 70 && !(Math.abs(u) <= 3 && v > cz)) c.p(u, F0, v, B.FENCE_CHAIN_UP);
            if (d2 < 60 && (u + v) % 2 == 0) c.p(u, G - 1, v, B.BEAM);
        }
        for (int dx = -2; dx <= 2; dx += 4) for (int dz = -2; dz <= 2; dz += 4) c.box(dx, F0, cz + dz, dx, F0 + 6, cz + dz, B.BEAM);
        c.box(-3, F0 + 7, cz - 3, 3, F0 + 7, cz + 3, B.RUST_PLATE);
        c.box(-1, F0 + 8, cz - 1, 1, F0 + 8, cz + 1, B.RUST_PLATE);
        c.p(0, F0 + 9, cz, B.SEA_LANTERN);
        c.p(3, F0, cz + 6, B.LANTERN);
        c.s.mark("seal", 0, F0, cz + 6);
    }

    // ------------------------------------------------------------------ уличная мелочь
    /** Фонарь: основание, 4 столба, верх с рукой; голова на соседней клетке в сторону улицы (dir). */
    static void lamp(Cx c, long seed, int u, int v, int towardStreet, int unused, int salt) {
        c.p(u, F0, v, B.LAMP_BASE);
        for (int k = 1; k <= 4; k++) c.p(u, F0 + k, v, B.LAMP_POLE);
        c.pf(u, F0 + 5, v, B.LAMP_TOP, towardStreet);
        double r = Town.rand(seed, u, v, salt, 77);
        c.pf(u + Town.dx(towardStreet), F0 + 5, v + Town.dz(towardStreet), r < 0.42 ? B.LAMP_HEAD_DEAD : B.LAMP_HEAD, towardStreet);
    }

    static void car(Cx c, int minU, int minV, boolean vert, boolean fwdPos, int variant) {
        int f = vert ? (fwdPos ? 2 : 0) : (fwdPos ? 1 : 3);
        for (int a = 0; a < 2; a++) for (int al = 0; al < 4; al++) {
            int u = fwdPos ? al : 3 - al;
            int rightCross = vert ? -Town.dz(f) : Town.dx(f);
            int w = rightCross > 0 ? a : 1 - a;
            int x = vert ? minU + a : minU + al, z = vert ? minV + al : minV + a;
            c.car(x, F0, z, variant, f, u * 2 + w);
            if (u == 1 || u == 2) c.car(x, F0 + 1, z, variant, f, 8 + (u - 1) * 2 + w);
        }
    }

    static void streetProps(Cx c, long seed, Clip clip) {
        for (int[] r : HROADS) {
            for (int u = r[1] + 6; u <= r[2] - 6; u += 16) {
                if (!clip.hits(u - 2, r[0] - 6, u + 2, r[0] + 6)) continue;
                if (nearJunction(u, r[0], true)) continue;
                boolean north = ((u / 16) & 1) == 0;
                lamp(c, seed, u, north ? r[0] - 4 : r[0] + 4, north ? 2 : 0, 0, u);
            }
            for (int slot = r[1] + 8; slot <= r[2] - 14; slot += 12) {
                if (!clip.hits(slot, r[0] - 3, slot + 4, r[0] + 3)) continue;
                if (nearJunction(slot, r[0], true) || nearJunction(slot + 4, r[0], true) || (Math.abs(slot) < 14 && Math.abs(r[0]) < 6)) continue;
                double h = Town.rand(seed, slot, r[0], 0, 91);
                if (h > 0.2) continue;
                boolean lane = h < 0.1;
                car(c, slot, lane ? r[0] - 2 : r[0] + 1, false, Town.rand(seed, slot, r[0], 1, 92) < 0.5, (int) (Town.rand(seed, slot, r[0], 2, 93) * 4));
            }
            // дорожные барьеры на концах
            if (clip.hits(r[1] - 2, r[0] - 5, r[1] + 3, r[0] + 5)) barrier(c, r[1] + 1, r[0], true);
            if (clip.hits(r[2] - 3, r[0] - 5, r[2] + 2, r[0] + 5)) barrier(c, r[2] - 1, r[0], true);
        }
        for (int[] r : VROADS) {
            for (int v = r[1] + 6; v <= r[2] - 6; v += 16) {
                if (!clip.hits(r[0] - 6, v - 2, r[0] + 6, v + 2)) continue;
                if (nearJunction(r[0], v, false)) continue;
                boolean west = ((v / 16) & 1) == 0;
                lamp(c, seed, west ? r[0] - 4 : r[0] + 4, v, west ? 1 : 3, 0, v + 500);
            }
            for (int slot = r[1] + 8; slot <= r[2] - 12; slot += 12) {
                if (!clip.hits(r[0] - 3, slot, r[0] + 3, slot + 4)) continue;
                if (nearJunction(r[0], slot, false) || nearJunction(r[0], slot + 4, false) || (Math.abs(r[0]) < 6 && Math.abs(slot) < 14)) continue;
                double h = Town.rand(seed, r[0], slot, 3, 94);
                if (h > 0.2) continue;
                boolean lane = h < 0.1;
                car(c, lane ? r[0] - 2 : r[0] + 1, slot, true, Town.rand(seed, r[0], slot, 4, 95) < 0.5, (int) (Town.rand(seed, r[0], slot, 5, 96) * 4));
            }
            if (r[2] < 60 && clip.hits(r[0] - 5, r[2] - 2, r[0] + 5, r[2] + 3)) barrier(c, r[0], r[2] + 1, false);
        }
        // гидранты и мусор на тротуарах
        for (int u = -88; u <= 88; u += 6) for (int[] r : HROADS) {
            if (!clip.hits(u, r[0] - 4, u, r[0] + 4)) continue;
            double h = Town.rand(seed, u, r[0], 0, 61);
            if (h > 0.12 || nearJunction(u, r[0], true)) continue;
            int v = h < 0.06 ? r[0] - 3 : r[0] + 3;
            if (((u - 6) & 15) == 0 || ((u - 6 + 1) & 15) == 0) continue;
            B b = h < 0.03 ? B.HYDRANT : h < 0.07 ? B.BARREL : B.BIN;
            if (b == B.BIN) c.pf(u, F0, v, b, v < r[0] ? 2 : 0); else c.p(u, F0, v, b);
        }
    }

    static boolean nearJunction(int u, int v, boolean alongU) {
        for (int[] w : VROADS) if (alongU && Math.abs(u - w[0]) <= 6 && v >= w[1] - 4 && v <= w[2] + 4) return true;
        for (int[] h : HROADS) if (!alongU && Math.abs(v - h[0]) <= 6 && u >= h[1] - 4 && u <= h[2] + 4) return true;
        return false;
    }

    static void barrier(Cx c, int u, int v, boolean alongU) {
        for (int o = -2; o <= 2; o++) {
            if (alongU) c.pf(u, F0, v + o, B.BARRIER, 1); else c.pf(u + o, F0, v, B.BARRIER, 0);
        }
    }

    // ------------------------------------------------------------------ кровавый след к пирсу
    /** От площади на север по главной улице и дальше по пирсу тянется след капель: к пирсу всё гуще. */
    static void bloodTrail(Cx c, long seed, Clip clip) {
        if (!clip.hits(-4, -130, 4, -8)) return;
        for (int v = -9; v >= PIER_END + 6; v--) {
            double t = Math.min(1.0, (-9 - v) / 110.0);
            for (int u = -2; u <= 2; u++) {
                if (Math.abs(u) == 2 && Town.rand(seed, u, v, 0, 931) < 0.6) continue;
                if (Town.rand(seed, u, v, 1, 932) > 0.05 + 0.30 * t) continue;
                if (v > -48) { if (road(u, v) < 2) continue; c.p(u, G, v, B.COBBLE_BLOOD); }
                else if (v <= -66) c.p(u, G, v, B.RUST_BLOODY);
            }
        }
    }

    // ------------------------------------------------------------------ люки
    /** Люки по осевой линии улиц; из некоторых ночью тянется рука (OtherworldScares ищет блок люка рядом с игроком). */
    static void manholes(Cx c, long seed, Clip clip) {
        for (int[] r : VROADS) for (int v = r[1] + 10; v <= r[2] - 10; v += 12) {
            if (Town.rand(seed, r[0], v, 0, 951) > 0.5 || nearJunction(r[0], v, false) || nearStart(r[0], v)) continue;
            if (clip.hits(r[0], v, r[0], v)) manhole(c, r[0], v);
        }
        for (int[] r : HROADS) for (int u = r[1] + 10; u <= r[2] - 10; u += 12) {
            if (Town.rand(seed, u, r[0], 0, 952) > 0.5 || nearJunction(u, r[0], true) || nearStart(u, r[0])) continue;
            if (clip.hits(u, r[0], u, r[0])) manhole(c, u, r[0]);
        }
    }

    static boolean nearStart(int u, int v) { return Math.abs(u - 2) < 7 && Math.abs(v - 11) < 7; }

    static void manhole(Cx c, int u, int v) {
        c.p(u, G, v, B.MANHOLE);
        for (int y = G - 1; y >= G - 3; y--) c.p(u, y, v, B.AIR);   // шахта под крышкой
    }

    // ------------------------------------------------------------------ глаза в пропасти
    /** Пары глаз висят в пустоте над бездной и смотрят на набережную. */
    static void abyssEyes(Cx c, long seed, Clip clip) {
        if (!clip.hits(-104, -154, 104, -70)) return;
        for (int gu = -9; gu <= 8; gu++) for (int gv = -13; gv <= -6; gv++) {
            if (Town.rand(seed, gu, gv, 0, 941) > 0.16) continue;
            int u = gu * 12 + (int) (Town.rand(seed, gu, gv, 1, 942) * 10);
            int v = gv * 12 + (int) (Town.rand(seed, gu, gv, 2, 943) * 10);
            int y = 30 + (int) (Town.rand(seed, gu, gv, 3, 944) * 34);
            if (Math.abs(u) < 9 && v > -138) continue;                       // не над пирсом
            if (rimDepth(seed, u, v) < 7 || rimDepth(seed, u + 2, v) < 7) continue;   // не в стене
            if (!clip.hits(u, v, u + 2, v)) continue;
            c.p(u, y, v, B.EYE);
            c.p(u + 2, y, v, B.EYE);
        }
    }

    // ------------------------------------------------------------------ мёртвые деревья
    static void trees(Cx c, long seed, Clip clip, List<Lot> lots) {
        int u0 = Math.max(clip.u0, -104), u1 = Math.min(clip.u1, 104), v0 = Math.max(clip.v0, -66), v1 = Math.min(clip.v1, 90);
        for (int gu = Math.floorDiv(u0 - 6, 8); gu <= Math.floorDiv(u1 + 6, 8); gu++) {
            for (int gv = Math.floorDiv(v0 - 6, 8); gv <= Math.floorDiv(v1 + 6, 8); gv++) {
                double h = Town.rand(seed, gu, gv, 0, 71);
                if (h > 0.22) continue;
                int u = gu * 8 + (int) (Town.rand(seed, gu, gv, 1, 72) * 8), v = gv * 8 + (int) (Town.rand(seed, gu, gv, 2, 73) * 8);
                if (u < u0 - 5 || u > u1 + 5 || v < v0 - 5 || v > v1 + 5) continue;   // ветки до 4 блоков: запас 5, иначе шов на границе чанка
                boolean bad = false;
                for (int du = -2; du <= 2 && !bad; du += 2) for (int dv = -2; dv <= 2 && !bad; dv += 2) bad = occupied(u + du, v + dv, lots);
                if (bad || Math.abs(u) > 98 || v > 80 || v < -61) continue;
                deadTree(c, seed, u, v, 5 + (int) (4 * Town.rand(seed, gu, gv, 3, 74)));
            }
        }
    }

    static void deadTree(Cx c, long seed, int u, int v, int h) {
        for (int y = 0; y < h; y++) c.log(u, G + 1 + y, v, 1);
        for (int k = 0; k < 4; k++) {
            int d = k;
            int by = G + 1 + h / 2 + (int) (Town.rand(seed, u, v, k, 75) * (h / 2));
            int len = 2 + (int) (Town.rand(seed, u, v, k, 76) * 3);
            for (int i = 1; i <= len; i++) {
                c.log(u + Town.dx(d) * i, by + i / 2, v + Town.dz(d) * i, Town.dx(d) != 0 ? 0 : 2);
            }
            c.p(u + Town.dx(d) * len, by + len / 2 + 1, v + Town.dz(d) * len, B.COBWEB);
        }
    }
}
