package com.example.dreams.client;

import com.example.dreams.Dreams;
import com.example.dreams.dream.DreamWorld;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/**
 * Небо Иной стороны (только на клиенте): огромный глаз над пропастью. Открывается медленно (около минуты после входа),
 * зрачок дышит, время от времени глаз моргает. Рисуется как далёкий объект, по образцу SkyRing.
 */
@EventBusSubscriber(modid = Dreams.MODID, bus = EventBusSubscriber.Bus.GAME, value = Dist.CLIENT)
public final class OtherworldSky {

    private OtherworldSky() {}

    private static final ResourceLocation EYE_TEX = ResourceLocation.fromNamespaceAndPath(Dreams.MODID, "textures/entity/sky_eye.png");
    private static final ResourceLocation PUPIL_TEX = ResourceLocation.fromNamespaceAndPath(Dreams.MODID, "textures/entity/sky_eye_pupil.png");

    private static final double DIST = 320.0;
    private static final double AZIMUTH = Math.toRadians(-90.0);     // над пропастью (север, -z)
    private static final double ELEVATION = Math.toRadians(27.0);
    private static final double RADIUS = 125.0;                      // половина ширины глаза
    private static long enteredAt = -1;

    public static boolean inOtherworld() {
        Minecraft mc = Minecraft.getInstance();
        return mc.level != null && mc.level.dimension().location().equals(DreamWorld.OW_KEY.location());
    }

    private static void vertex(VertexConsumer vc, PoseStack.Pose pose, double x, double y, double z, float u, float v, int a) {
        vc.addVertex(pose, (float) x, (float) y, (float) z).setColor(255, 255, 255, a).setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY).setLight(LightTexture.FULL_BRIGHT).setNormal(pose, 0f, 1f, 0f);
    }

    /** Квадрат в плоскости, перпендикулярной направлению на глаз; с обеих сторон. */
    private static void quad(VertexConsumer vc, PoseStack.Pose pose, double[] c, double[] right, double[] up, double w, double h, double ox, int alpha) {
        double[][] p = new double[4][3];
        int[][] sg = {{-1, -1}, {1, -1}, {1, 1}, {-1, 1}};
        float[][] uv = {{0f, 1f}, {1f, 1f}, {1f, 0f}, {0f, 0f}};
        for (int i = 0; i < 4; i++) {
            for (int k = 0; k < 3; k++) p[i][k] = c[k] + right[k] * (w * sg[i][0] + ox) + up[k] * h * sg[i][1];
        }
        for (int i = 0; i < 4; i++) vertex(vc, pose, p[i][0], p[i][1], p[i][2], uv[i][0], uv[i][1], alpha);
        for (int i = 3; i >= 0; i--) vertex(vc, pose, p[i][0], p[i][1], p[i][2], uv[i][0], uv[i][1], alpha);
    }

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
        if (!inOtherworld()) { enteredAt = -1; return; }
        long now = System.nanoTime();
        if (enteredAt < 0) enteredAt = now;
        double sec = (now - enteredAt) / 1.0e9;
        double open = Mth.clamp((sec - 4.0) / 55.0, 0.0, 1.0);        // глаз медленно проступает
        if (open <= 0.01) return;

        // моргание: раз в ~23 секунды веки смыкаются на четверть секунды
        double ph = (sec % 23.0);
        double lid = 1.0;
        if (ph > 22.0) { double q = (ph - 22.0); lid = Math.abs(Math.cos(q * Math.PI)); lid = Math.max(0.04, lid); }
        lid *= 0.35 + 0.65 * open;                                     // сначала приоткрыт щёлочкой

        Minecraft mc = Minecraft.getInstance();
        Camera camera = event.getCamera();
        PoseStack.Pose pose = event.getPoseStack().last();
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();

        double cx = DIST * Math.cos(ELEVATION) * Math.cos(AZIMUTH);
        double cy = DIST * Math.sin(ELEVATION);
        double cz = DIST * Math.cos(ELEVATION) * Math.sin(AZIMUTH);
        double nl = Math.sqrt(cx * cx + cy * cy + cz * cz);
        double nx = cx / nl, ny = cy / nl, nz = cz / nl;
        // right = normalize((0,1,0) x n) = (nz, 0, -nx), up2 = n x right
        double rx = nz, ry = 0.0, rz = -nx;
        double rl = Math.sqrt(rx * rx + ry * ry + rz * rz);
        rx /= rl; ry /= rl; rz /= rl;
        double ux = ny * rz - nz * ry, uy = nz * rx - nx * rz, uz = nx * ry - ny * rx;
        double[] c = {cx, cy, cz}, right = {rx, ry, rz}, up = {ux, uy, uz};

        float fogStart = RenderSystem.getShaderFogStart();
        float fogEnd = RenderSystem.getShaderFogEnd();
        RenderSystem.setShaderFogStart(Math.max(fogStart, 500f));
        RenderSystem.setShaderFogEnd(Math.max(fogEnd, 900f));

        int alpha = (int) (255 * (0.55 + 0.45 * open) * (0.94 + 0.06 * Math.sin(sec * 1.7)));
        double h = RADIUS * lid;
        RenderType rt = RenderType.entityTranslucentEmissive(EYE_TEX);
        quad(buf.getBuffer(rt), pose, c, right, up, RADIUS, h, 0.0, alpha);
        buf.endBatch(rt);

        // зрачок: чуть ближе к игроку, дышит
        double breathe = 1.0 + 0.10 * Math.sin(sec * 0.9);
        double[] c2 = {c[0] * 0.99, c[1] * 0.99, c[2] * 0.99};
        RenderType rp = RenderType.entityTranslucentEmissive(PUPIL_TEX);
        quad(buf.getBuffer(rp), pose, c2, right, up, RADIUS * breathe, h * (0.9 + 0.1 * breathe), 0.0, alpha);
        buf.endBatch(rp);

        RenderSystem.setShaderFogStart(fogStart);
        RenderSystem.setShaderFogEnd(fogEnd);
    }
}
