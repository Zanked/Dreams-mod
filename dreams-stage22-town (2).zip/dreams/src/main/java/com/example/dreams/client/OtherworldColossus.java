package com.example.dreams.client;

import com.example.dreams.Dreams;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/**
 * Силуэт гигантского существа на горизонте Иной стороны (только на клиенте). Стоит далеко за пропастью, по пояс в тумане,
 * очень медленно бродит вдоль горизонта и дышит; глаза открываются и закрываются. Проступает через пару минут после входа.
 * Рисуется как далёкий объект по образцу OtherworldSky.
 */
@EventBusSubscriber(modid = Dreams.MODID, bus = EventBusSubscriber.Bus.GAME, value = Dist.CLIENT)
public final class OtherworldColossus {

    private OtherworldColossus() {}

    private static final ResourceLocation BODY_TEX = ResourceLocation.fromNamespaceAndPath(Dreams.MODID, "textures/entity/sky_colossus.png");
    private static final ResourceLocation EYES_TEX = ResourceLocation.fromNamespaceAndPath(Dreams.MODID, "textures/entity/sky_colossus_eyes.png");

    private static final double DIST = 360.0;
    private static final double AZIMUTH = Math.toRadians(-140.0);   // северо-запад
    private static final double HALF_W = 95.0, HALF_H = 190.0;      // размер в блоках на расстоянии DIST (текстура 1:2)
    private static final double BASE_Y = -30.0;                     // подножие чуть ниже горизонта камеры: стоит в бездне
    private static long enteredAt = -1;

    private static void vertex(VertexConsumer vc, PoseStack.Pose pose, double x, double y, double z, float u, float v, int a) {
        vc.addVertex(pose, (float) x, (float) y, (float) z).setColor(255, 255, 255, a).setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY).setLight(LightTexture.FULL_BRIGHT).setNormal(pose, 0f, 1f, 0f);
    }

    /** Вертикальный четырёхугольник (ось вверх = мировая), виден с обеих сторон. */
    private static void quad(VertexConsumer vc, PoseStack.Pose pose, double cx, double cz, double rx, double rz, double yb, double yt, double hw, int alpha) {
        double[][] p = {
                {cx - rx * hw, yb, cz - rz * hw}, {cx + rx * hw, yb, cz + rz * hw},
                {cx + rx * hw, yt, cz + rz * hw}, {cx - rx * hw, yt, cz - rz * hw}};
        float[][] uv = {{0f, 1f}, {1f, 1f}, {1f, 0f}, {0f, 0f}};
        for (int i = 0; i < 4; i++) vertex(vc, pose, p[i][0], p[i][1], p[i][2], uv[i][0], uv[i][1], alpha);
        for (int i = 3; i >= 0; i--) vertex(vc, pose, p[i][0], p[i][1], p[i][2], uv[i][0], uv[i][1], alpha);
    }

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
        if (!OtherworldSky.inOtherworld()) { enteredAt = -1; return; }
        long now = System.nanoTime();
        if (enteredAt < 0) enteredAt = now;
        double sec = (now - enteredAt) / 1.0e9;
        double appear = Mth.clamp((sec - 120.0) / 90.0, 0.0, 1.0);   // через две минуты начинает проступать
        if (appear <= 0.01) return;

        Minecraft mc = Minecraft.getInstance();
        PoseStack.Pose pose = event.getPoseStack().last();
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();

        double az = AZIMUTH + Math.toRadians(7.0) * Math.sin(sec / 70.0);     // медленно бродит вдоль горизонта
        double cx = DIST * Math.cos(az), cz = DIST * Math.sin(az);
        double rx = -Math.sin(az), rz = Math.cos(az);                            // горизонтальное направление «вправо»
        double breathe = 1.0 + 0.012 * Math.sin(sec * 0.55);
        double yb = BASE_Y, yt = BASE_Y + HALF_H * 2.0 * breathe;
        int alpha = (int) (255 * 0.92 * appear);

        float fogStart = RenderSystem.getShaderFogStart();
        float fogEnd = RenderSystem.getShaderFogEnd();
        RenderSystem.setShaderFogStart(Math.max(fogStart, 500f));
        RenderSystem.setShaderFogEnd(Math.max(fogEnd, 900f));

        RenderType body = RenderType.entityTranslucentEmissive(BODY_TEX);
        quad(buf.getBuffer(body), pose, cx, cz, rx, rz, yb, yt, HALF_W, alpha);
        buf.endBatch(body);

        // глаза: открыты большую часть времени, пульсируют, раз в ~17 секунд все разом закрываются
        double blinkPh = sec % 17.0;
        double eyes = 0.55 + 0.45 * Math.sin(sec * 0.8);
        if (blinkPh > 16.4 && blinkPh < 16.9) eyes = 0.0;
        if (eyes > 0.02) {
            double k = 0.985;   // чуть ближе, чтобы не мерцало на теле
            RenderType eye = RenderType.entityTranslucentEmissive(EYES_TEX);
            quad(buf.getBuffer(eye), pose, cx * k, cz * k, rx, rz, yb, yt, HALF_W * k, (int) (alpha * Mth.clamp(eyes, 0.0, 1.0)));
            buf.endBatch(eye);
        }

        RenderSystem.setShaderFogStart(fogStart);
        RenderSystem.setShaderFogEnd(fogEnd);
    }
}
