package com.example.dreams.dream;

import com.example.dreams.attachment.DreamState;
import com.example.dreams.block.ModBlocks;
import com.example.dreams.sound.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.network.protocol.game.ClientboundBlockUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Режиссёр страха в городке Иной стороны (измерение dreams:otherworld). Раз в несколько секунд случайно:
 * звук где-то за спиной (шёпот, стук, скрежет, цепь, шаги), хлопнувшая или приоткрывшаяся дверь, фонарь, который
 * мигает и гаснет. Фонари меняются только у игрока (пакетом, как печати): мир на сервере не трогаем, а при смене
 * измерения или повторной отправке чанка всё возвращается само. Двери меняются по-настоящему (сервер и клиент
 * согласны, игрок не упрётся в невидимую стену).
 */
public final class OtherworldScares {
    private OtherworldScares() {}

    private static final class Later {
        final long pos, at;
        final boolean dead;

        Later(long pos, long at, boolean dead) { this.pos = pos; this.at = at; this.dead = dead; }
    }

    private static final Map<UUID, List<Later>> LATER = new HashMap<>();

    /** Вызывается каждый тик из DreamManager.tickOtherworldMechanics, когда игрок в измерении Иной стороны. t = тик сна. */
    public static void tick(ServerPlayer player, ServerLevel level, DreamState s, int t) {
        long now = level.getGameTime();
        flushLater(player, level, now);
        tickWindows(player, level, now);
        tickHands(player, level, now);
        if (t % 20 != 9) return;
        RandomSource r = player.getRandom();
        int rate = t > 3600 ? 7 : t > 1800 ? 10 : 13;   // чем дольше сон, тем чаще
        if (r.nextInt(rate) != 0) return;
        double k = r.nextDouble();
        if (k < 0.30) ghostSound(player, r);
        else if (k < 0.40) doorEvent(player, level, r);
        else if (k < 0.56) lampFlicker(player, level, r, now);
        else if (k < 0.78) windowLights(player, level, r, now);
        else manholeHand(player, level, r, now);
    }

    // ------------------------------------------------------------------ звук за спиной

    private static void send(ServerPlayer p, Holder<SoundEvent> ev, double x, double y, double z, float vol, float pitch, RandomSource r) {
        p.connection.send(new ClientboundSoundPacket(ev, SoundSource.AMBIENT, x, y, z, vol, pitch, r.nextLong()));
    }

    /** Точка в 9..26 блоках от игрока, предпочтительно за спиной или сбоку. */
    private static Vec3 behind(ServerPlayer p, RandomSource r) {
        Vec3 look = p.getLookAngle();
        double dx = 1, dz = 0, dist = 14;
        for (int i = 0; i < 8; i++) {
            double ang = r.nextDouble() * Math.PI * 2;
            dx = Math.cos(ang);
            dz = Math.sin(ang);
            dist = 9 + r.nextDouble() * 17;
            if (dx * look.x + dz * look.z < 0.2) break;
        }
        return new Vec3(p.getX() + dx * dist, p.getY() + r.nextInt(3), p.getZ() + dz * dist);
    }

    private static void ghostSound(ServerPlayer p, RandomSource r) {
        Vec3 at = behind(p, r);
        Holder<SoundEvent> ev;
        float vol, pitch;
        switch (r.nextInt(10)) {
            case 0, 1 -> { ev = ModSounds.WHISPER; vol = 1.8f; pitch = 0.7f + r.nextFloat() * 0.3f; }
            case 2 -> { ev = ModSounds.KNOCK; vol = 1.6f; pitch = 0.8f + r.nextFloat() * 0.3f; }
            case 3 -> { ev = ModSounds.SCRAPE; vol = 1.5f; pitch = 0.6f + r.nextFloat() * 0.3f; }
            case 4 -> { ev = ModSounds.CHAIN; vol = 1.5f; pitch = 0.7f + r.nextFloat() * 0.4f; }
            case 5, 6 -> { ev = ModSounds.BEHIND_STEP; vol = 1.4f; pitch = 0.75f + r.nextFloat() * 0.2f; }
            case 7 -> { ev = ModSounds.FIGURE_MOAN; vol = 1.2f; pitch = 0.55f + r.nextFloat() * 0.25f; }
            case 8 -> { ev = ModSounds.CLANG; vol = 1.4f; pitch = 0.5f + r.nextFloat() * 0.2f; }
            default -> { ev = ModSounds.BREATH; vol = 1.3f; pitch = 0.6f + r.nextFloat() * 0.2f; }
        }
        send(p, ev, at.x, at.y, at.z, vol, pitch, r);
    }

    // ------------------------------------------------------------------ двери

    private static void doorEvent(ServerPlayer p, ServerLevel level, RandomSource r) {
        Vec3 look = p.getLookAngle();
        BlockPos base = p.blockPosition();
        for (int i = 0; i < 48; i++) {
            BlockPos pos = base.offset(r.nextInt(29) - 14, r.nextInt(4) - 1, r.nextInt(29) - 14);
            if (!level.hasChunkAt(pos)) continue;
            BlockState st = level.getBlockState(pos);
            if (!(st.getBlock() instanceof DoorBlock) || st.getBlock() == Blocks.IRON_DOOR) continue;
            if (st.getValue(DoorBlock.HALF) != DoubleBlockHalf.LOWER) continue;
            double dx = pos.getX() + 0.5 - p.getX(), dz = pos.getZ() + 0.5 - p.getZ();
            double len = Math.sqrt(dx * dx + dz * dz);
            if (len < 4.0) continue;
            if ((dx * look.x + dz * look.z) / len > 0.45) continue;   // за спиной или сбоку: на глазах двери не двигаются
            boolean open = st.getValue(DoorBlock.OPEN);
            level.setBlock(pos, st.setValue(DoorBlock.OPEN, !open), 10);
            BlockPos up = pos.above();
            BlockState us = level.getBlockState(up);
            if (us.getBlock() instanceof DoorBlock && us.getValue(DoorBlock.HALF) == DoubleBlockHalf.UPPER) {
                level.setBlock(up, us.setValue(DoorBlock.OPEN, !open), 10);
            }
            send(p, ModSounds.DOOR, pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5, 1.6f, open ? 0.7f : 0.85f, r);
            return;
        }
        ghostSound(p, r);   // двери рядом не нашлось
    }

    // ------------------------------------------------------------------ фонари

    private static void lampFlicker(ServerPlayer p, ServerLevel level, RandomSource r, long now) {
        Vec3 look = p.getLookAngle();
        BlockPos base = p.blockPosition();
        for (int i = 0; i < 70; i++) {
            BlockPos pos = base.offset(r.nextInt(37) - 18, r.nextInt(10) - 1, r.nextInt(37) - 18);
            if (!level.hasChunkAt(pos)) continue;
            BlockState st = level.getBlockState(pos);
            if (!st.is(ModBlocks.CITY_LAMP_HEAD.get())) continue;
            double dx = pos.getX() + 0.5 - p.getX(), dz = pos.getZ() + 0.5 - p.getZ();
            double len = Math.sqrt(dx * dx + dz * dz);
            if (len < 4.0 || (dx * look.x + dz * look.z) / len < -0.2) continue;   // гаснет там, куда смотрит игрок
            long key = pos.asLong();
            List<Later> list = LATER.computeIfAbsent(p.getUUID(), k -> new ArrayList<>());
            list.add(new Later(key, now, true));
            list.add(new Later(key, now + 3, false));
            list.add(new Later(key, now + 5, true));
            list.add(new Later(key, now + 8, false));
            list.add(new Later(key, now + 10, true));   // последний раз гаснет насовсем (до смены измерения)
            send(p, ModSounds.CLANG, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 0.7f, 1.7f + r.nextFloat() * 0.3f, r);
            return;
        }
    }

    // ------------------------------------------------------------------ окна

    private static final class Lit {
        final long pos, until;
        final boolean figure;

        Lit(long pos, long until, boolean figure) { this.pos = pos; this.until = until; this.figure = figure; }
    }

    private static final Map<UUID, List<Lit>> WINDOWS = new HashMap<>();

    private static boolean isWindow(BlockState st) {
        return st.is(ModBlocks.CITY_WINDOW_A.get()) || st.is(ModBlocks.CITY_WINDOW_B.get()) || st.is(ModBlocks.CITY_WINDOW_C.get());
    }

    /** За спиной загорается окно (иногда с чёрным силуэтом в нём); стоит обернуться, и оно гаснет. */
    private static void windowLights(ServerPlayer p, ServerLevel level, RandomSource r, long now) {
        List<Lit> list = WINDOWS.computeIfAbsent(p.getUUID(), k -> new ArrayList<>());
        if (list.size() >= 6) return;
        Vec3 look = p.getLookAngle();
        BlockPos base = p.blockPosition();
        for (int i = 0; i < 80; i++) {
            BlockPos pos = base.offset(r.nextInt(49) - 24, r.nextInt(12) - 2, r.nextInt(49) - 24);
            if (!level.hasChunkAt(pos) || !isWindow(level.getBlockState(pos))) continue;
            double dx = pos.getX() + 0.5 - p.getX(), dz = pos.getZ() + 0.5 - p.getZ();
            double len = Math.sqrt(dx * dx + dz * dz);
            if (len < 7.0 || (dx * look.x + dz * look.z) / len > 0.3) continue;   // не на глазах
            boolean figure = r.nextInt(100) < 35;
            BlockState lit = (figure ? ModBlocks.CITY_WINDOW_LIT_FIGURE : ModBlocks.CITY_WINDOW_LIT).get().defaultBlockState();
            p.connection.send(new ClientboundBlockUpdatePacket(pos, lit));
            list.add(new Lit(pos.asLong(), now + 160 + r.nextInt(360), figure));
            return;
        }
    }

    private static void tickWindows(ServerPlayer p, ServerLevel level, long now) {
        List<Lit> list = WINDOWS.get(p.getUUID());
        if (list == null) return;
        Vec3 look = p.getLookAngle();
        Iterator<Lit> it = list.iterator();
        while (it.hasNext()) {
            Lit l = it.next();
            BlockPos pos = BlockPos.of(l.pos);
            Vec3 to = new Vec3(pos.getX() + 0.5 - p.getX(), pos.getY() + 0.5 - p.getEyeY(), pos.getZ() + 0.5 - p.getZ());
            double len = to.length();
            boolean watched = len > 1.0 && len < 48.0 && to.scale(1.0 / len).dot(look) > 0.86;
            if (!watched && now < l.until) continue;
            it.remove();
            if (!level.hasChunkAt(pos)) continue;
            BlockState real = level.getBlockState(pos);
            if (isWindow(real)) p.connection.send(new ClientboundBlockUpdatePacket(pos, real));   // свет гаснет
        }
        if (list.isEmpty()) WINDOWS.remove(p.getUUID());
    }

    // ------------------------------------------------------------------ руки из люков

    private static final class Hand {
        final long base, start;
        int stage;
        boolean grabbed;
        long grabAt;

        Hand(long base, long start) { this.base = base; this.start = start; }
    }

    private static final Map<UUID, List<Hand>> HANDS = new HashMap<>();

    /** Из крышки люка рядом медленно тянется бледная рука; подойдёшь вплотную, сожмётся в кулак и пропадёт. */
    private static void manholeHand(ServerPlayer p, ServerLevel level, RandomSource r, long now) {
        List<Hand> hs = HANDS.computeIfAbsent(p.getUUID(), k -> new ArrayList<>());
        if (hs.size() >= 2) return;
        Vec3 look = p.getLookAngle();
        BlockPos pp = p.blockPosition();
        List<BlockPos> found = new ArrayList<>();
        for (int dx = -13; dx <= 13; dx++) for (int dz = -13; dz <= 13; dz++) for (int dy = -2; dy <= -1; dy++) {
            BlockPos pos = pp.offset(dx, dy, dz);
            if (!level.hasChunkAt(pos) || !level.getBlockState(pos).is(ModBlocks.CITY_MANHOLE.get())) continue;
            double len = Math.sqrt((double) dx * dx + (double) dz * dz);
            if (len < 5.0 || len > 13.0 || (dx * look.x + dz * look.z) / len < -0.1) continue;   // видно, но не вплотную
            if (!level.getBlockState(pos.above()).isAir() || !level.getBlockState(pos.above(2)).isAir()) continue;
            found.add(pos);
        }
        if (found.isEmpty()) return;
        BlockPos m = found.get(r.nextInt(found.size()));
        BlockPos base = m.above();
        for (Hand h : hs) if (h.base == base.asLong()) return;
        hs.add(new Hand(base.asLong(), now));
        send(p, ModSounds.SCRAPE, base.getX() + 0.5, base.getY(), base.getZ() + 0.5, 1.4f, 0.55f, r);
    }

    private static void showHand(ServerPlayer p, ServerLevel level, BlockPos base, int stage) {
        BlockPos top = base.above();
        BlockState lo = stage >= 1 ? ModBlocks.PALE_ARM.get().defaultBlockState() : level.getBlockState(base);
        BlockState hi = level.getBlockState(top);
        if (stage >= 2) {
            hi = (stage == 2 ? ModBlocks.PALE_HAND_A : stage == 3 ? ModBlocks.PALE_HAND_B : ModBlocks.PALE_HAND_C).get().defaultBlockState();
        }
        p.connection.send(new ClientboundBlockUpdatePacket(base, lo));
        p.connection.send(new ClientboundBlockUpdatePacket(top, hi));
    }

    private static void tickHands(ServerPlayer p, ServerLevel level, long now) {
        List<Hand> hs = HANDS.get(p.getUUID());
        if (hs == null) return;
        Iterator<Hand> it = hs.iterator();
        while (it.hasNext()) {
            Hand h = it.next();
            BlockPos base = BlockPos.of(h.base);
            if (!level.hasChunkAt(base)) { it.remove(); continue; }
            long age = now - h.start;
            double dx = base.getX() + 0.5 - p.getX(), dz = base.getZ() + 0.5 - p.getZ();
            boolean end = false;
            int stage = age < 10 ? 1 : age < 30 ? 2 : age < 80 ? 3 : age < 150 ? 4 : 5;
            if (!h.grabbed && dx * dx + dz * dz < 9.0 && age >= 10) {
                h.grabbed = true;
                h.grabAt = now;
                send(p, ModSounds.CLANG, base.getX() + 0.5, base.getY() + 1.0, base.getZ() + 0.5, 1.2f, 0.5f, p.getRandom());
            }
            if (h.grabbed) { stage = 4; end = now - h.grabAt > 8; }
            if (stage == 5) end = true;
            if (end) {
                BlockState real = level.getBlockState(base), realTop = level.getBlockState(base.above());
                p.connection.send(new ClientboundBlockUpdatePacket(base, real));
                p.connection.send(new ClientboundBlockUpdatePacket(base.above(), realTop));
                it.remove();
                continue;
            }
            if (stage != h.stage) { h.stage = stage; showHand(p, level, base, stage); }
        }
        if (hs.isEmpty()) HANDS.remove(p.getUUID());
    }

    /** Рядом с Палачом (в 7 блоках) гаснет фонарь: вызывается его поведением. */
    static void killLampsNear(ServerPlayer p, ServerLevel level, Vec3 at, RandomSource r) {
        long now = level.getGameTime();
        BlockPos base = BlockPos.containing(at);
        for (int i = 0; i < 40; i++) {
            BlockPos pos = base.offset(r.nextInt(15) - 7, r.nextInt(9) - 1, r.nextInt(15) - 7);
            if (!level.hasChunkAt(pos) || !level.getBlockState(pos).is(ModBlocks.CITY_LAMP_HEAD.get())) continue;
            long key = pos.asLong();
            List<Later> list = LATER.computeIfAbsent(p.getUUID(), k -> new ArrayList<>());
            list.add(new Later(key, now, true));
            list.add(new Later(key, now + 3, false));
            list.add(new Later(key, now + 5, true));
            return;
        }
    }

    private static void flushLater(ServerPlayer p, ServerLevel level, long now) {
        List<Later> list = LATER.get(p.getUUID());
        if (list == null) return;
        Iterator<Later> it = list.iterator();
        while (it.hasNext()) {
            Later l = it.next();
            if (l.at > now) continue;
            it.remove();
            if (now - l.at > 100) continue;   // осталось от прошлого сна
            BlockPos pos = BlockPos.of(l.pos);
            if (!level.hasChunkAt(pos)) continue;
            BlockState real = level.getBlockState(pos);
            if (!real.is(ModBlocks.CITY_LAMP_HEAD.get())) continue;
            BlockState shown = real;
            if (l.dead) {
                shown = ModBlocks.CITY_LAMP_HEAD_DEAD.get().defaultBlockState()
                        .setValue(HorizontalDirectionalBlock.FACING, real.getValue(HorizontalDirectionalBlock.FACING));
            }
            p.connection.send(new ClientboundBlockUpdatePacket(pos, shown));
        }
        if (list.isEmpty()) LATER.remove(p.getUUID());
    }
}
