package com.example.dreams;

import net.neoforged.neoforge.common.ModConfigSpec;
import org.apache.commons.lang3.tuple.Pair;

public class DreamConfig {

    public static class Common {
        public final ModConfigSpec.DoubleValue nightmareChance;
        public final ModConfigSpec.BooleanValue applyDebuffs;
        public final ModConfigSpec.BooleanValue fakeBlocks;
        public final ModConfigSpec.BooleanValue fakeTime;
        public final ModConfigSpec.IntValue falseAwakeSeconds;
        public final ModConfigSpec.IntValue maxFakeBlocks;
        public final ModConfigSpec.BooleanValue watcherEnabled;
        public final ModConfigSpec.DoubleValue watcherSpeed;
        public final ModConfigSpec.IntValue cooldownNights;
        public final ModConfigSpec.DoubleValue repeatChance;
        public final ModConfigSpec.IntValue maxRepeats;
        public final ModConfigSpec.BooleanValue gaslight;
        public final ModConfigSpec.BooleanValue behindSounds;
        public final ModConfigSpec.BooleanValue serverFlashes;
        public final ModConfigSpec.BooleanValue watcherJump;
        public final ModConfigSpec.BooleanValue watcherOpensDoors;
        public final ModConfigSpec.BooleanValue otherworld;
        public final ModConfigSpec.BooleanValue city;
        public final ModConfigSpec.DoubleValue cityDensity;
        public final ModConfigSpec.BooleanValue cityProps;
        public final ModConfigSpec.BooleanValue goodDimension;
        public final ModConfigSpec.BooleanValue sirenRush;
        public final ModConfigSpec.IntValue ritualSeals;
        public final ModConfigSpec.BooleanValue executioner;
        public final ModConfigSpec.BooleanValue figures;
        public final ModConfigSpec.BooleanValue townWatches;
        public final ModConfigSpec.BooleanValue tunnel;
        public final ModConfigSpec.BooleanValue selfChat;
        public final ModConfigSpec.BooleanValue timeSpin;
        public final ModConfigSpec.BooleanValue nausea;
        public final ModConfigSpec.BooleanValue particles;
        // три вида сна + добрый сон
        public final ModConfigSpec.IntValue weightNightmare;
        public final ModConfigSpec.IntValue weightOtherworld;
        public final ModConfigSpec.IntValue weightGood;
        public final ModConfigSpec.IntValue goodCooldownNights;
        public final ModConfigSpec.IntValue goodSeconds;
        public final ModConfigSpec.BooleanValue goodFlight;
        public final ModConfigSpec.BooleanValue goodWind;
        public final ModConfigSpec.BooleanValue goodTiles;
        public final ModConfigSpec.BooleanValue goodTree;
        public final ModConfigSpec.BooleanValue goodParticles;
        public final ModConfigSpec.BooleanValue goodWhales;
        public final ModConfigSpec.BooleanValue goodPlayful;

        Common(ModConfigSpec.Builder b) {
            nightmareChance = b.comment("Chance (0..1) that a sleep becomes a special dream (nightmare, otherworld or good dream; see the weights below). 1.0 = always (for testing).")
                    .defineInRange("nightmareChance", 1.0, 0.0, 1.0);
            weightNightmare = b.comment("Relative weight of the Nightmare (false awakenings, Watcher, loops). 0 = never.")
                    .defineInRange("weightNightmare", 4, 0, 100);
            weightOtherworld = b.comment("Relative weight of the Otherworld dream (rusting world, seals ritual, Executioner). 0 = never. Needs 'otherworld' = true.")
                    .defineInRange("weightOtherworld", 2, 0, 100);
            weightGood = b.comment("Relative weight of the Good dream (memories, chime tiles, weightless sky, Tree of Dreams). 0 = never.")
                    .defineInRange("weightGood", 3, 0, 100);
            goodCooldownNights = b.comment("Minimum in-game days between two good dreams for one player (0 = no cooldown).")
                    .defineInRange("goodCooldownNights", 0, 0, 100);
            goodSeconds = b.comment("How long a good dream lasts at most (seconds). It ends gently, without penalty.")
                    .defineInRange("goodSeconds", 300, 60, 1800);
            goodFlight = b.comment("Good dream: lets the dreamer fly (mayfly) and builds floating islands. Also protects against the vanilla 'flying is not allowed' kick on servers. Removed when the dream ends (and on next login after a crash).")
                    .define("goodFlight", true);
            goodWind = b.comment("Good dream: ribbons of wind that lift you up (needs goodFlight for the floating island).")
                    .define("goodWind", true);
            goodTiles = b.comment("Good dream: ringing tiles in a grove that play a melody to repeat.")
                    .define("goodTiles", true);
            goodTree = b.comment("Good dream: the Tree of Dreams (finale and reward). false = the dream just times out.")
                    .define("goodTree", true);
            goodParticles = b.comment("Good dream: petals and fireflies around the dreamer.")
                    .define("goodParticles", true);
            goodWhales = b.comment("Good dream: huge whales of light drifting across the sky (particles; more of them and brighter with every light collected).")
                    .define("goodWhales", true);
            goodPlayful = b.comment("Good dream: footsteps play notes of a pentatonic scale, jumps play an arpeggio, landings a soft chord.")
                    .define("goodPlayful", true);
            applyDebuffs = b.comment("Apply debuffs if the player fails to escape the nightmare.")
                    .define("applyDebuffs", true);
            fakeBlocks = b.comment("Send fake blocks (visible only to the dreamer). Disable if your anti-cheat complains.")
                    .define("fakeBlocks", true);
            fakeTime = b.comment("Fake the time of day (sun rushes to night) for the dreamer only.")
                    .define("fakeTime", true);
            falseAwakeSeconds = b.comment("How long the false awakening lasts before the player fails (seconds).")
                    .defineInRange("falseAwakeSeconds", 120, 30, 600);
            maxFakeBlocks = b.comment("Maximum number of fake blocks per dreamer.")
                    .defineInRange("maxFakeBlocks", 4000, 100, 20000);
            watcherEnabled = b.comment("Spawn the Watcher during the false awakening.")
                    .define("watcherEnabled", true);
            watcherSpeed = b.comment("Watcher speed multiplier (1.0 = a bit faster than walking, about sprint speed at the end).")
                    .defineInRange("watcherSpeed", 1.0, 0.3, 2.5);
            cooldownNights = b.comment("Minimum number of in-game days between two nightmares for one player (0 = no cooldown).")
                    .defineInRange("cooldownNights", 0, 0, 100);
            repeatChance = b.comment("Chance (0..1) that the FIRST escape is a false escape and the dream starts over. Each next loop adds +0.2.")
                    .defineInRange("repeatChance", 0.35, 0.0, 1.0);
            maxRepeats = b.comment("How many false escapes (dream loops) are possible in one nightmare. Each loop is faster and scarier. 0 = never.")
                    .defineInRange("maxRepeats", 3, 0, 5);
            gaslight = b.comment("Fake blocks you look at turn back to normal; only what is behind you changes.")
                    .define("gaslight", true);
            behindSounds = b.comment("Footsteps, doors, knocking and breathing from behind the dreamer (heard only by them).")
                    .define("behindSounds", true);
            serverFlashes = b.comment("Sudden black blinks during the dream (also needed for the Watcher jump). Client option 'flashes' can still hide them.")
                    .define("serverFlashes", true);
            watcherJump = b.comment("During a black blink the Watcher jumps several blocks closer.")
                    .define("watcherJump", true);
            watcherOpensDoors = b.comment("The Watcher can open (and close) real wooden doors on its way to the dreamer.")
                    .define("watcherOpensDoors", true);
            otherworld = b.comment("Silent Hill style 'Otherworld': ~40 s into the dream the world rusts over (metal plates, gratings, blood) in a spreading wave and stays that way.")
                    .define("otherworld", true);
            city = b.comment("Otherworld city: streets, sealed rusty buildings, lamp posts and wrecks grow with the rust wave (fake blocks, only the dreamer sees them). Needs flat natural ground; forests, water and real buildings are skipped.")
                    .define("city", true);
            cityDensity = b.comment("Chance (0..1) that a city lot gets a building. Lower = more empty lots.")
                    .defineInRange("cityDensity", 0.85, 0.1, 1.0);
            cityProps = b.comment("Otherworld city decorations as 3D block models: street lamps, traffic lights, chain-link fences, wrecked cars, hydrants, barrels. false = bare streets (use if a resource pack breaks the models).")
                    .define("cityProps", true);
            goodDimension = b.comment("The good dream takes place in its own dimension (floating islands). false = the old version: your own world re-skinned with fake blocks.")
                    .define("goodDimension", true);
            sirenRush = b.comment("In the Otherworld the siren sometimes sounds: for ~4 s the Executioner runs faster and Figures move even while you look at them.")
                    .define("sirenRush", true);
            ritualSeals = b.comment("Otherworld exit ritual: this many glowing seals must be found and activated (right click) before the bed opens. A hum guides you to them. 0 = bed always open.")
                    .defineInRange("ritualSeals", 3, 0, 5);
            executioner = b.comment("The Executioner: slow, relentless, ignores your gaze, drags a huge blade (heard from afar). Appears after the 2nd seal (or later without the ritual).")
                    .define("executioner", true);
            figures = b.comment("Lying Figures in the Otherworld: lie still until you come close, then twitch and crawl at you (but freeze when watched). A touch hurts a little and slows you.")
                    .define("figures", true);
            tunnel = b.comment("The Corridor in the Otherworld: a tunnel of rust walls (fake blocks) grows ahead of you, seals behind you, narrows, and has no end until it lets you go. Only before the Executioner comes.")
                    .define("tunnel", true);
            townWatches = b.comment("Villagers, animals and golems near the dreamer freeze and turn to stare at them.")
                    .define("townWatches", true);
            selfChat = b.comment("Creepy chat messages 'from' the dreamer themselves and glitchy action bar text.")
                    .define("selfChat", true);
            timeSpin = b.comment("At the end of the dream day and night spin faster and faster (fake time, only for the dreamer).")
                    .define("timeSpin", true);
            nausea = b.comment("Periodic waves of the vanilla Nausea effect (screen wobble) late in the dream.")
                    .define("nausea", true);
            particles = b.comment("Ash and reverse-portal particles around the dreamer.")
                    .define("particles", true);
        }
    }

    public static class Client {
        public final ModConfigSpec.BooleanValue cameraShake;
        public final ModConfigSpec.BooleanValue flashes;
        public final ModConfigSpec.BooleanValue scareSound;
        public final ModConfigSpec.BooleanValue reducedMotion;
        public final ModConfigSpec.DoubleValue cutsceneShake;
        public final ModConfigSpec.DoubleValue effectScale;
        public final ModConfigSpec.BooleanValue doppelganger;
        public final ModConfigSpec.BooleanValue psychedelic;
        public final ModConfigSpec.BooleanValue goodMusic;
        public final ModConfigSpec.DoubleValue goodMusicVolume;
        public final ModConfigSpec.BooleanValue goodSong;
        public final ModConfigSpec.DoubleValue goodSongVolume;
        public final ModConfigSpec.BooleanValue goodVisuals;
        public final ModConfigSpec.BooleanValue cutscenes;
        public final ModConfigSpec.BooleanValue whaleModel;
        public final ModConfigSpec.BooleanValue jellyModel;
        public final ModConfigSpec.DoubleValue owFogDistance;

        Client(ModConfigSpec.Builder b) {
            cameraShake = b.comment("Camera shake during nightmares.").define("cameraShake", true);
            flashes = b.comment("Sudden dark flashes during nightmares. Disable if sensitive.").define("flashes", true);
            scareSound = b.comment("Loud scare sound during nightmares.").define("scareSound", true);
            reducedMotion = b.comment("Accessibility: no camera shake, no flashes, no pulsing. Overrides the options above.")
                    .define("reducedMotion", false);
            cutsceneShake = b.comment("Handheld camera shake inside cutscenes: 0 = none, 1 = as authored. Ignored with reducedMotion.")
                    .defineInRange("cutsceneShake", 0.5, 0.0, 1.0);
            effectScale = b.comment("Accessibility: overall strength of fog/red tint/vignette (0 = off, 1 = full).")
                    .defineInRange("effectScale", 1.0, 0.0, 1.0);
            doppelganger = b.comment("The Watcher wears your own skin (with black eyes). false = classic black figure.")
                    .define("doppelganger", true);
            psychedelic = b.comment("Psychedelic effects: breathing FOV, slow camera tilt, rainbow fog and tint. Off with reducedMotion.")
                    .define("psychedelic", true);
            goodMusic = b.comment("Choir and organ music during the good dream (plays on the Music volume slider).")
                    .define("goodMusic", true);
            goodMusicVolume = b.comment("Extra volume multiplier for the good dream music (0..1).")
                    .defineInRange("goodMusicVolume", 1.0, 0.0, 1.0);
            goodSong = b.comment("The song of the good dream (assets/dreams/sounds/good_song.ogg): plays on the Music volume slider once you step into the dream world. The choir gets quieter under it.")
                    .define("goodSong", true);
            goodSongVolume = b.comment("Volume multiplier for the good dream song (0..1).")
                    .defineInRange("goodSongVolume", 0.9, 0.0, 1.0);
            goodVisuals = b.comment("Golden haze, soft vignette and gentle sway during the good dream. Sway is off with reducedMotion.")
                    .define("goodVisuals", true);
            cutscenes = b.comment("Cinematic camera scenes in the good dream (prologue, first whale, the Tree waking, the ascension). Space skips a scene.")
                    .define("cutscenes", true);
            whaleModel = b.comment("Sky whales in the good dream as smooth animated 3D models. false = no whales are drawn (the server option goodWhales also has to be on).")
                    .define("whaleModel", true);
            jellyModel = b.comment("Flying jellyfish in the good dream world (animated 3D models, client only). false = no jellyfish.")
                    .define("jellyModel", true);
            owFogDistance = b.comment("Otherworld fog distance in blocks (how far you see buildings as silhouettes). Lower = thicker fog. Halved while the siren howls.")
                    .defineInRange("owFogDistance", 36.0, 10.0, 96.0);
        }
    }

    public static final ModConfigSpec COMMON_SPEC;
    public static final Common COMMON;
    public static final ModConfigSpec CLIENT_SPEC;
    public static final Client CLIENT;

    static {
        Pair<Common, ModConfigSpec> c = new ModConfigSpec.Builder().configure(Common::new);
        COMMON = c.getLeft();
        COMMON_SPEC = c.getRight();
        Pair<Client, ModConfigSpec> cl = new ModConfigSpec.Builder().configure(Client::new);
        CLIENT = cl.getLeft();
        CLIENT_SPEC = cl.getRight();
    }
}
