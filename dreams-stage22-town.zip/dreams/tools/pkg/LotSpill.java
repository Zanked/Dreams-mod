package com.example.dreams.dream.world.town;

import java.util.*;

/** Проверка: не выходит ли здание за границы своего участка (с запасом MARGIN). Запуск: java -cp out com.example.dreams.dream.world.town.LotSpill */
public class LotSpill {
    static int MARGIN = 6;
    public static void main(String[] a) {
        long seed = a.length > 0 ? Long.parseLong(a[0]) : 20261124L; if (a.length > 1) MARGIN = Integer.parseInt(a[1]);
        int bad = 0;
        for (TownMap.Lot lot : TownMap.lots(seed)) {
            final int[] ext = {Integer.MAX_VALUE, Integer.MAX_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE};
            final Map<String, Integer> out = new TreeMap<>();
            Town.Sink s = new Town.Sink() {
                void w(int x, int y, int z, Town.B b) {
                    if (b == Town.B.AIR) return;
                    if (x < lot.u0 - MARGIN || x > lot.u1 + MARGIN || z < lot.v0 - MARGIN || z > lot.v1 + MARGIN) {
                        out.merge(b.name(), 1, Integer::sum);
                        ext[0] = Math.min(ext[0], x); ext[1] = Math.min(ext[1], z); ext[2] = Math.max(ext[2], x); ext[3] = Math.max(ext[3], z);
                    }
                }
                public void put(int x, int y, int z, Town.B b) { w(x, y, z, b); }
                public void face(int x, int y, int z, Town.B b, int d) { w(x, y, z, b); }
                public void stair(int x, int y, int z, Town.B f, int d, boolean t, int sh) { w(x, y, z, f); }
                public void slab(int x, int y, int z, Town.B f, boolean t) { w(x, y, z, f); }
                public void door(int x, int y, int z, Town.B k, int d, boolean h) { w(x, y, z, k); }
                public void conn(int x, int y, int z, Town.B b, int m) { w(x, y, z, b); }
                public void bed(int x, int y, int z, Town.B c, int d) { w(x, y, z, c); }
                public void car(int x, int y, int z, int v, int d, int c) { w(x, y, z, Town.B.CAR); }
                public void log(int x, int y, int z, int ax) { w(x, y, z, Town.B.LOG); }
                public void trapdoor(int x, int y, int z, Town.B k, int d, boolean o, boolean t) { w(x, y, z, k); }
            };
            Buildings.build(new Cx(s, seed), lot);
            if (!out.isEmpty()) {
                bad++;
                System.out.println(lot.kind + " участок u" + lot.u0 + ".." + lot.u1 + " v" + lot.v0 + ".." + lot.v1 + " front=" + lot.front
                        + ": за границей " + out + " охват u" + ext[0] + ".." + ext[2] + " v" + ext[1] + ".." + ext[3]);
            }
        }
        System.out.println(bad == 0 ? "участки: всё в границах" : "участков с выходом за границы: " + bad);
    }
}
