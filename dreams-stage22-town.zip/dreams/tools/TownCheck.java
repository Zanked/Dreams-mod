import com.example.dreams.dream.world.town.Town;
import com.example.dreams.dream.world.town.Town.B;

import java.util.*;

/**
 * Проверка городка вне игры (нужен только JDK).
 *   javac -d out src/main/java/com/example/dreams/dream/world/town/*.java tools/TownCheck.java
 *   java -cp out TownCheck [seed]
 * 1) швы: город целиком против города по чанкам 16x16 (как в игре, со сдвигом сетки 0 и 1 для разных поворотов);
 * 2) проходимость: от старта до кровати, печатей и дверей (ходьба игрока: шаг вверх 1, спуск до 3, лестницы);
 * 3) двери: по обе стороны должно быть свободно.
 */
public class TownCheck {
    static final int U0 = -125, V0 = -140, Y0 = 40, NU = 251, NV = 260, NY = 100;
    static final B[] BV = B.values();
    // виды клеток
    static final byte AIR = 0, FULL = 1, HALF = 2, PASS = 3, CLIMB = 4, DOOR = 5, IRON = 6;

    static final Set<B> PASSABLE = EnumSet.of(B.AIR, B.GRASS_SHORT, B.DEAD_BUSH, B.COBWEB, B.CARPET_RED, B.CARPET_GRAY, B.CARPET_WHITE,
            B.CARPET_GREEN, B.BUTTON, B.PRESSURE, B.CANDLE, B.LANTERN, B.LANTERN_HANG, B.SOUL_LANTERN, B.SOUL_HANG, B.CHAIN,
            B.BED_WHITE, B.BED_RED, B.BED_GRAY, B.SEAL_STONE);

    static final class Grid implements Town.Sink {
        final byte[] k = new byte[NU * NY * NV];
        final short[] b = new short[NU * NY * NV];
        boolean clipped; int cu0, cv0, cu1, cv1;
        final List<String> marks = new ArrayList<>();
        final List<int[]> doors = new ArrayList<>();   // x, y, z, dir, kindOrdinal

        static int idx(int u, int y, int v) { return ((u - U0) * NY + (y - Y0)) * NV + (v - V0); }
        static boolean in(int u, int y, int v) { return u >= U0 && u < U0 + NU && y >= Y0 && y < Y0 + NY && v >= V0 && v < V0 + NV; }

        void set(int u, int y, int v, byte kind, B blk) {
            if (!in(u, y, v)) return;
            if (clipped && (u < cu0 || u > cu1 || v < cv0 || v > cv1)) return;
            int i = idx(u, y, v);
            k[i] = kind; b[i] = (short) (blk.ordinal() + 1);
        }
        void setB(int u, int y, int v, B blk) {
            byte kind = blk == B.AIR ? AIR : blk == B.LADDER ? CLIMB : PASSABLE.contains(blk) ? PASS : FULL;
            set(u, y, v, kind, blk);
        }
        byte kind(int u, int y, int v) { return in(u, y, v) ? k[idx(u, y, v)] : AIR; }
        B blk(int u, int y, int v) { if (!in(u, y, v)) return B.AIR; int s = b[idx(u, y, v)]; return s == 0 ? B.AIR : BV[s - 1]; }

        public void put(int x, int y, int z, B bb) { setB(x, y, z, bb); }
        public void face(int x, int y, int z, B bb, int d) { setB(x, y, z, bb); }
        public void stair(int x, int y, int z, B f, int d, boolean top, int sh) { set(x, y, z, HALF, f); }
        public void slab(int x, int y, int z, B f, boolean top) { set(x, y, z, HALF, f); }
        public void door(int x, int y, int z, B kd, int d, boolean h) {
            byte kk = kd == B.DOOR_IRON ? IRON : DOOR;
            set(x, y, z, kk, kd); set(x, y + 1, z, kk, kd);
            if (!clipped) doors.add(new int[]{x, y, z, d, kd.ordinal()});
        }
        public void conn(int x, int y, int z, B bb, int m) { setB(x, y, z, bb); }
        public void bed(int x, int y, int z, B c, int d) { setB(x, y, z, c); setB(x + Town.dx(d), y, z + Town.dz(d), c); }
        public void car(int x, int y, int z, int v, int d, int c) { setB(x, y, z, B.CAR); }
        public void log(int x, int y, int z, int a) { setB(x, y, z, B.LOG); }
        public void trapdoor(int x, int y, int z, B kd, int d, boolean o, boolean t) { set(x, y, z, PASS, kd); }
        public void mark(String n, int x, int y, int z) { if (!clipped) marks.add(n + " " + x + " " + y + " " + z); }
    }

    static void terrain(Grid g, long seed) {
        for (int u = U0; u < U0 + NU; u++) for (int v = V0; v < V0 + NV; v++) {
            int top = Town.groundForTest(seed, u, v);
            boolean ab = Town.inAbyssForTest(seed, u, v);
            if (ab) {
                for (int y = Y0; y < Town.G - 4; y++) if (Town.ledgeForTest(seed, u, v, y)) g.setB(u, y, v, B.STONE_V);
                continue;
            }
            for (int y = Y0; y <= top; y++) g.setB(u, y, v, y == top ? B.GRASS : B.STONE_V);
        }
    }

    public static void main(String[] a) {
        long seed = a.length > 0 ? Long.parseLong(a[0]) : 20261124L;
        Grid all = new Grid();
        Town.build(all, seed, Town.Clip.ALL);
        int problems = 0;

        // ---- 1. швы
        for (int off = 0; off <= 1; off++) {
            Grid cw = new Grid();
            cw.clipped = true;
            for (int cu = U0 - 16 + off; cu < U0 + NU; cu += 16) {
                for (int cv = V0 - 16 + off; cv < V0 + NV; cv += 16) {
                    cw.cu0 = cu; cw.cu1 = cu + 15; cw.cv0 = cv; cw.cv1 = cv + 15;
                    Town.build(cw, seed, new Town.Clip(cu, cv, cu + 15, cv + 15));
                }
            }
            int diff = 0; Map<String, Integer> kinds = new TreeMap<>(); List<String> samples = new ArrayList<>();
            for (int u = U0; u < U0 + NU; u++) for (int y = Y0; y < Y0 + NY; y++) for (int v = V0; v < V0 + NV; v++) {
                int i = Grid.idx(u, y, v);
                if (all.k[i] == cw.k[i] && all.b[i] == cw.b[i]) continue;
                // terrain в all, а в cw нет: пропускаем клетки, которые пишет только terrain()
                diff++;
                B want = all.blk(u, y, v), got = cw.blk(u, y, v);
                kinds.merge(want + "->" + got, 1, Integer::sum);
                if (samples.size() < 12) samples.add("(" + u + "," + y + "," + v + ") ожидали " + want + ", получили " + got);
            }
            System.out.println("[швы, сдвиг сетки " + off + "] расхождений: " + diff);
            if (diff > 0) { problems++; kinds.forEach((kk, n) -> System.out.println("   " + kk + " x" + n)); samples.forEach(s -> System.out.println("   " + s)); }
        }

        terrain(all, seed);   // рельеф поверх (не затирая город, который мы уже записали): ставим только в пустые клетки
        // terrain() перезаписывает; перестроим город поверх, чтобы порядок был как в игре (сначала рельеф, потом город)
        Grid g = new Grid();
        terrain(g, seed);
        Town.build(g, seed, Town.Clip.ALL);

        // ---- 2. проходимость
        int[] start = null, bed = null; List<int[]> seals = new ArrayList<>();
        for (String m : g.marks) {
            String[] t = m.split(" ");
            int[] p = {Integer.parseInt(t[1]), Integer.parseInt(t[2]), Integer.parseInt(t[3])};
            if (t[0].equals("start")) start = p; else if (t[0].equals("bed")) bed = p; else if (t[0].equals("seal")) seals.add(p);
        }
        boolean[] seen = new boolean[NU * NY * NV];
        reach(g, start, seen);
        System.out.println("[проходимость] от старта достижимо клеток: " + count(seen));
        if (bed != null) {
            boolean ok = near(g, seen, bed);
            System.out.println("   кровать " + Arrays.toString(bed) + (ok ? ": достижима" : ": НЕДОСТИЖИМА <<<")); if (!ok) problems++;
        }
        for (int[] s : seals) {
            boolean ok = near(g, seen, s);
            System.out.println("   печать " + Arrays.toString(s) + (ok ? ": достижима" : ": НЕДОСТИЖИМА <<<")); if (!ok) problems++;
        }

        // ---- 3. двери
        int badDoors = 0;
        for (int[] d : g.doors) {
            int x = d[0], y = d[1], z = d[2], dir = d[3];
            B kd = BV[d[4]];
            int fx = x + Town.dx(dir), fz = z + Town.dz(dir), bx = x - Town.dx(dir), bz = z - Town.dz(dir);
            boolean f = free2(g, fx, y, fz), bk = free2(g, bx, y, bz);
            String why = kd == B.DOOR_IRON ? "железная (руками не открыть)" : !f ? "снаружи занято " + g.blk(fx, y, fz) + "/" + g.blk(fx, y + 1, fz) : !bk ? "внутри занято " + g.blk(bx, y, bz) + "/" + g.blk(bx, y + 1, bz) : null;
            if (why != null) { badDoors++; if (badDoors <= 25) System.out.println("   дверь " + kd + " (" + x + "," + y + "," + z + ") dir=" + dir + ": " + why); }
        }
        System.out.println("[двери] всего " + g.doors.size() + ", проблемных " + badDoors);
        if (badDoors > 0) problems++;
        System.out.println(problems == 0 ? "ВСЁ ЧИСТО" : "ПРОБЛЕМ: " + problems);
        if (a.length >= 7 && a[1].equals("dump")) dump(g, seen, Integer.parseInt(a[2]), Integer.parseInt(a[3]), Integer.parseInt(a[4]), Integer.parseInt(a[5]), Integer.parseInt(a[6]));
    }

    /** Срез на высоте y: # твёрдое, s ступень/плита, D дверь, = железная, H лестница, . проходимая мелочь, + достижимый воздух, пробел недостижимый воздух. */
    static void dump(Grid g, boolean[] seen, int u0, int u1, int v0, int v1, int y) {
        System.out.println("срез y=" + y + " u " + u0 + ".." + u1 + " (вправо), v " + v0 + ".." + v1 + " (вниз)");
        for (int v = v0; v <= v1; v++) {
            StringBuilder sb = new StringBuilder(String.format("%4d ", v));
            for (int u = u0; u <= u1; u++) {
                byte k = g.kind(u, y, v);
                char c = k == FULL ? '#' : k == HALF ? 's' : k == DOOR ? 'D' : k == IRON ? '=' : k == CLIMB ? 'H' : k == PASS ? '.' : ' ';
                if ((k == AIR || k == PASS) && Grid.in(u, y, v) && seen[Grid.idx(u, y, v)]) c = '+';
                sb.append(c);
            }
            System.out.println(sb);
        }
    }

    static boolean free2(Grid g, int x, int y, int z) {
        return pass(g.kind(x, y, z)) && pass(g.kind(x, y + 1, z));
    }

    static boolean pass(byte k) { return k == AIR || k == PASS || k == CLIMB || k == DOOR; }

    static int count(boolean[] s) { int n = 0; for (boolean b : s) if (b) n++; return n; }

    static boolean near(Grid g, boolean[] seen, int[] p) {
        for (int du = -1; du <= 1; du++) for (int dv = -1; dv <= 1; dv++) for (int dy = -1; dy <= 1; dy++) {
            int u = p[0] + du, y = p[1] + dy, v = p[2] + dv;
            if (Grid.in(u, y, v) && seen[Grid.idx(u, y, v)]) return true;
        }
        return false;
    }

    static boolean standable(Grid g, int u, int y, int v) {
        if (!Grid.in(u, y - 1, v) || !Grid.in(u, y + 2, v)) return false;
        byte f = g.kind(u, y, v), h = g.kind(u, y + 1, v), s = g.kind(u, y - 1, v);
        if (!(pass(f) || f == HALF) || !pass(h)) return false;
        if (f == HALF && !pass(g.kind(u, y + 2, v))) return false;
        return f == HALF || f == CLIMB || s == FULL || s == HALF || s == IRON;
    }

    static void reach(Grid g, int[] st, boolean[] seen) {
        ArrayDeque<int[]> q = new ArrayDeque<>();
        q.add(st); seen[Grid.idx(st[0], st[1], st[2])] = true;
        int[] du = {0, 1, 0, -1}, dv = {-1, 0, 1, 0};
        while (!q.isEmpty()) {
            int[] c = q.poll();
            int u = c[0], y = c[1], v = c[2];
            if (g.kind(u, y, v) == CLIMB) {
                for (int d = -1; d <= 1; d += 2) {
                    int ny = y + d;
                    if (!Grid.in(u, ny, v) || seen[Grid.idx(u, ny, v)]) continue;
                    if (pass(g.kind(u, ny, v)) && pass(g.kind(u, ny + 1, v))) { seen[Grid.idx(u, ny, v)] = true; q.add(new int[]{u, ny, v}); }
                }
            }
            for (int d = 0; d < 4; d++) {
                int nu = u + du[d], nv = v + dv[d];
                for (int dy = 1; dy >= -3; dy--) {
                    int ny = y + dy;
                    if (!Grid.in(nu, ny, nv) || seen[Grid.idx(nu, ny, nv)]) continue;
                    if (!standable(g, nu, ny, nv)) continue;
                    if (dy == 1 && !pass(g.kind(u, y + 2, v))) continue;
                    if (dy < 0) { boolean ok = true; for (int yy = ny + 1; yy <= y + 1 && ok; yy++) ok = pass(g.kind(nu, yy, nv)); if (!ok) continue; }
                    if (dy == 0 && g.kind(u, y, v) != HALF && false) continue;
                    seen[Grid.idx(nu, ny, nv)] = true; q.add(new int[]{nu, ny, nv});
                    break;
                }
            }
        }
    }
}
