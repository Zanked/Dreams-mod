package com.example.dreams.dream.world.town;

import com.example.dreams.dream.world.town.Town.B;
import com.example.dreams.dream.world.town.TownMap.Lot;

import static com.example.dreams.dream.world.town.Town.F0;
import static com.example.dreams.dream.world.town.Town.G;

/** Церковь: готический неф с витражами и розой, колокольня со шпилем, алтарь и скамьи; кладбище рядом. */
final class Church {
    private Church() {}

    static final B[] GLASS = {B.GLASS_RED, B.GLASS_BLUE, B.GLASS_PURPLE, B.GLASS_AMBER};

    static void build(Cx c, Lot lot) {
        int w = 11, d = 22;
        Cx h = Buildings.place(c, lot, w, d + 5, -12, 4);
        int yc = F0 + 10;
        // пол, стены нефа
        h.box(0, F0, 0, w - 1, F0, d - 1, B.PLANKS_DARK);
        h.walls(0, 0, w - 1, d - 1, F0, F0 + 1, B.STONE_BRICKS);
        h.rwalls(0, 0, w - 1, d - 1, F0 + 2, yc, B.STONE, B.STONE_BRICKS, 0.08, 601);
        // контрфорсы
        for (int z = 1; z < d; z += 4) {
            for (int xx : new int[]{-1, w}) {
                h.box(xx, F0, z, xx, F0 + 8, z, B.STONE);
                h.stair(xx, F0 + 9, z, B.STONE, xx < 0 ? 1 : 3, false);
            }
        }
        // витражи: узкие высокие окна между контрфорсами
        for (int z = 3; z < d - 2; z += 4) {
            for (int xx : new int[]{0, w - 1}) {
                B g = GLASS[((z / 4) + (xx == 0 ? 0 : 2)) & 3];
                h.box(xx, F0 + 3, z, xx, F0 + 7, z, g);
                h.p(xx, F0 + 8, z, B.STONE);
            }
        }
        // крыша: двускатная вдоль z, скаты по x
        int ridgeY = yc;
        for (int j = 0; ; j++) {
            int xf = -1 + j, xb = w - j;
            if (xf > xb) break;
            if (xf == xb) { h.box(xf, yc + j, -1, xf, yc + j, d, B.ROOF); ridgeY = yc + j; break; }
            for (int z = -1; z <= d; z++) { h.stair(xf, yc + 1 + j, z, B.ROOF, 1, false); h.stair(xb, yc + 1 + j, z, B.ROOF, 3, false); }
            ridgeY = yc + 1 + j;
        }
        // фронтоны
        for (int x = 0; x < w; x++) {
            int jx = Math.min(x + 1, w - x);
            for (int y = yc + 1; y <= yc + jx; y++) { h.p(x, y, 0, B.STONE); }
        }
        // потолочные балки с лампами
        for (int z = 3; z < d - 3; z += 4) {
            h.box(0, yc - 1, z, w - 1, yc - 1, z, B.WOOD);
            h.p(5, yc - 2, z, B.CHAIN); h.p(5, yc - 3, z, B.LANTERN_HANG);
        }
        // роза над алтарём
        for (int x = 1; x <= 9; x++) for (int y = F0 + 5; y <= F0 + 13; y++) {
            double dx = x - 5, dy = y - (F0 + 9);
            double r = Math.hypot(dx, dy);
            if (r > 3.6) continue;
            if (r < 0.8) { h.p(x, y, 0, B.EYE); continue; }   // в розе смотрит глаз
            double a = Math.atan2(dy, dx);
            int sector = (int) Math.floor((a + Math.PI) / (Math.PI / 4)) & 7;
            if (r > 2.8 || Math.abs(dx) < 0.5 || Math.abs(dy) < 0.5) h.p(x, y, 0, B.STONE);
            else h.p(x, y, 0, GLASS[sector & 3]);
        }
        // алтарь: возвышение, ступени, алтарный стол, свечи, крест
        h.box(1, F0 + 1, 1, w - 2, F0 + 1, 4, B.STONE);
        for (int x = 1; x <= w - 2; x++) h.stair(x, F0 + 1, 5, B.STONE, 0, false);
        h.box(4, F0 + 2, 2, 6, F0 + 2, 2, B.QUARTZ);
        h.p(4, F0 + 3, 2, B.CANDLE); h.p(6, F0 + 3, 2, B.CANDLE);
        h.p(5, F0 + 3, 2, B.LECTERN);
        h.p(1, F0 + 2, 1, B.SOUL_LANTERN); h.p(w - 2, F0 + 2, 1, B.SOUL_LANTERN);
        // ковёр, скамьи
        for (int z = 9; z < d - 1; z++) h.p(5, F0 + 1, z, B.CARPET_RED);
        for (int z = 8; z < d - 3; z += 2) {
            for (int x : new int[]{2, 3, 7, 8}) { h.stair(x, F0 + 1, z, B.V_DARK, 0, false); }
            h.p(2, F0 + 2, z + 1 > d ? z : z, B.AIR);
        }
        // колокольня на фасаде
        tower(h, w, d);
        h.mark("seal", 5, F0 + 1, 7);
        cemetery(c, lot);
    }

    static void tower(Cx h, int w, int d) {
        int x0 = 3, x1 = 7, z0 = d, z1 = d + 4;
        int top = F0 + 15;
        h.box(x0, F0, z0, x1, F0, z1, B.PLANKS_DARK);
        h.rwalls(x0, z0, x1, z1, F0 + 1, top, B.STONE, B.STONE_BRICKS, 0.08, 611);
        h.walls(x0, z0, x1, z1, F0, F0 + 1, B.STONE_BRICKS);
        for (int y = F0 + 5; y <= top; y += 5) h.walls(x0 - 1, z0 - 1, x1 + 1, z1 + 1, y, y, B.STONE);   // пояса-карнизы
        // вход
        h.box(5, F0 + 1, z1, 5, F0 + 3, z1, B.AIR);
        h.door(5, F0 + 1, z1, B.DOOR_DARK, 2, false);
        h.box(4, F0 + 4, z1, 6, F0 + 4, z1, B.STONE);
        h.stair(5, F0, z1 + 1, B.STONE, 0, false); h.stair(4, F0, z1 + 1, B.STONE, 0, false); h.stair(6, F0, z1 + 1, B.STONE, 0, false);
        h.p(4, F0 + 3, z1 + 1, B.SOUL_LANTERN); h.p(6, F0 + 3, z1 + 1, B.SOUL_LANTERN);
        // проём в неф: стена башни (z0) и стена самого нефа (z0 - 1) стоят вплотную, пробивать надо обе
        h.box(4, F0 + 1, z0 - 1, 6, F0 + 4, z0, B.AIR);
        h.box(4, F0 + 5, z0 - 1, 6, F0 + 5, z0, B.STONE);
        // стрельчатое окно фасада
        h.box(5, F0 + 7, z1, 5, F0 + 11, z1, B.GLASS_BLUE);
        h.box(4, F0 + 8, z1, 4, F0 + 10, z1, B.GLASS_PURPLE); h.box(6, F0 + 8, z1, 6, F0 + 10, z1, B.GLASS_PURPLE);
        // колокольня: открытые проёмы, колокол
        for (int y = F0 + 16; y <= F0 + 20; y++) {
            for (int[] p : new int[][]{{x0, z0}, {x1, z0}, {x0, z1}, {x1, z1}}) h.p(p[0], y, p[1], B.STONE);
            for (int x = x0 + 1; x < x1; x++) { if (y >= F0 + 19) { h.p(x, y, z0, B.STONE); h.p(x, y, z1, B.STONE); } else { h.p(x, y, z0, x == 5 ? B.AIR : B.BARS); h.p(x, y, z1, x == 5 ? B.AIR : B.BARS); } }
            for (int z = z0 + 1; z < z1; z++) { if (y >= F0 + 19) { h.p(x0, y, z, B.STONE); h.p(x1, y, z, B.STONE); } else { h.p(x0, y, z, z == (z0 + z1) / 2 ? B.AIR : B.BARS); h.p(x1, y, z, z == (z0 + z1) / 2 ? B.AIR : B.BARS); } }
        }
        h.box(x0, F0 + 16, z0, x1, F0 + 16, z1, B.STONE);
        h.p(5, F0 + 19, (z0 + z1) / 2, B.WOOD);
        h.p(5, F0 + 18, (z0 + z1) / 2, B.BELL);
        // шпиль
        int yy = F0 + 21, cz = (z0 + z1) / 2;
        for (int r = 3; r >= 1; r--, yy++) {
            for (int x = 5 - r; x <= 5 + r; x++) for (int z = cz - r; z <= cz + r; z++) {
                boolean edge = Math.abs(x - 5) == r || Math.abs(z - cz) == r;
                if (!edge) { h.p(x, yy, z, B.ROOF); continue; }
                boolean cornerX = Math.abs(x - 5) == r, cornerZ = Math.abs(z - cz) == r;
                if (cornerX && cornerZ) { h.p(x, yy, z, B.ROOF); continue; }
                int dir = cornerX ? (x < 5 ? 1 : 3) : (z < cz ? 2 : 0);
                h.stair(x, yy, z, B.ROOF, dir, false);
            }
        }
        h.box(5, yy, cz, 5, yy + 3, cz, B.ROOF);
        h.box(5, yy + 4, cz, 5, yy + 7, cz, B.BEAM);
        h.box(4, yy + 6, cz, 6, yy + 6, cz, B.BEAM);
    }

    static void cemetery(Cx c, Lot lot) {
        int u0 = lot.u0 + 22, u1 = lot.u1 - 1, v0 = lot.v0 + 1, v1 = lot.v1 - 3;
        Cx.Net fence = c.net(B.BARS);
        fence.rect(u0 - 1, v0 - 1, u1 + 1, v1 + 1);
        for (int u = u0 + 8; u <= u0 + 11; u++) fence.remove(u, v1 + 1);
        fence.flush(F0, F0 + 1);
        for (int u = u0 + 1; u <= u1 - 1; u += 3) for (int v = v0 + 1; v <= v1 - 1; v += 3) {
            double r = Town.rand(c.seed, u, v, 0, 811);
            if (r < 0.15) continue;
            int pu = u + (int) (Town.rand(c.seed, u, v, 1, 812) * 2), pv = v + (int) (Town.rand(c.seed, u, v, 2, 813) * 2);
            if (pv >= v1 - 4 && pu >= u0 + 6 && pu <= u0 + 13) continue;   // дорожка к калитке
            if (r < 0.5) { c.box(pu, F0, pv, pu, F0 + 1, pv, B.STONE); c.slab(pu, F0 + 2, pv, B.STONE, false); }
            else if (r < 0.75) { c.box(pu, F0, pv, pu, F0 + 2, pv, B.STONE); c.p(pu - 1, F0 + 2, pv, B.STONE); c.p(pu + 1, F0 + 2, pv, B.STONE); c.p(pu, F0 + 3, pv, B.STONE); }
            else if (r < 0.9) { c.p(pu, F0, pv, B.DIRT_C); c.p(pu, F0 + 1, pv, B.STONE_BRICKS); }
            else { c.box(pu, F0, pv, pu, F0 + 3, pv, B.BEAM); c.p(pu, F0 + 4, pv, B.SOUL_LANTERN); }
        }
        for (int v = v1 - 3; v <= v1; v++) for (int u = u0 + 8; u <= u0 + 11; u++) c.p(u, G, v, B.CURB);
    }
}
