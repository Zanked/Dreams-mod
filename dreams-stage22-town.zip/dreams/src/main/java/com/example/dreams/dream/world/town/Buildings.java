package com.example.dreams.dream.world.town;

import com.example.dreams.dream.world.town.Town.B;
import com.example.dreams.dream.world.town.TownMap.Lot;

import static com.example.dreams.dream.world.town.Town.F0;
import static com.example.dreams.dream.world.town.Town.G;

/** Диспетчер зданий и общие приёмы: постановка в участок, двери, крыльцо, крыши, мебель. */
final class Buildings {
    private Buildings() {}

    static void build(Cx c, Lot lot) {
        switch (lot.kind) {
            case "house": Houses.house(c, lot, false); break;
            case "home": Houses.house(c, lot, true); break;
            case "church": Church.build(c, lot); break;
            case "police": Civic.police(c, lot); break;
            case "hospital": Civic.hospital(c, lot); break;
            case "school": Civic.school(c, lot); break;
            case "hotel": Civic.hotel(c, lot); break;
            case "apartments": Civic.apartments(c, lot); break;
            case "shop": Shops.shop(c, lot); break;
            case "diner": Shops.diner(c, lot); break;
            case "gas": Shops.gas(c, lot); break;
            default: break;
        }
    }

    /** Постановка здания w x d (перед = +z в системе здания) в участок лицом к улице; along = смещение вдоль фасада. */
    static Cx place(Cx c, Lot lot, int w, int d, int along) { return place(c, lot, w, d, along, 0); }

    /** setback: отступ здания от улицы (двор, парковка перед фасадом). */
    static Cx place(Cx c, Lot lot, int w, int d, int along, int setback) {
        int rot = (lot.front - 2) & 3;
        int cu = 0, cv = 0;                                  // образ угла (w-1, d-1)
        int u = w - 1, v = d - 1;
        for (int i = 0; i < rot; i++) { int t = u; u = -v; v = t; }
        cu = u; cv = v;
        int minU = Math.min(0, cu), minV = Math.min(0, cv);
        int ww = Math.abs(cu) + 1, dd = Math.abs(cv) + 1;     // размеры после поворота
        int lotW = lot.u1 - lot.u0 + 1, lotH = lot.v1 - lot.v0 + 1;
        int wantU, wantV;
        switch (lot.front) {
            case 2: wantV = lot.v1 - (dd - 1) - setback; wantU = lot.u0 + (lotW - ww) / 2 + along; break;
            case 0: wantV = lot.v0 + setback; wantU = lot.u0 + (lotW - ww) / 2 + along; break;
            case 1: wantU = lot.u1 - (ww - 1) - setback; wantV = lot.v0 + (lotH - dd) / 2 + along; break;
            default: wantU = lot.u0 + setback; wantV = lot.v0 + (lotH - dd) / 2 + along; break;
        }
        return c.frame(wantU - minU, wantV - minV, rot, lot.seed);
    }

    // ------------------------------------------------------------------ крыша: двускатная вдоль x (щипцы на x=0 и x=w-1)
    /** yc = верхний уровень стен (потолок). Возвращает высоту конька. Скаты по z, свесы по 1 блоку. */
    static int gable(Cx h, int w, int d, int yc, B fam, B full, B gableWall, boolean eavesOnly) {
        int j = 0;
        int ridge = yc;
        for (; ; j++) {
            int zf = -1 + j, zb = d - j;
            if (zf > zb) break;
            if (zf == zb) {
                h.box(-1, yc + j, zf, w, yc + j, zf, full);
                ridge = yc + j;
                break;
            }
            for (int x = -1; x <= w; x++) {
                h.stair(x, yc + 1 + j, zf, fam, 2, false);
                h.stair(x, yc + 1 + j, zb, fam, 0, false);
            }
            ridge = yc + 1 + j;
        }
        if (!eavesOnly) {
            for (int z = 0; z < d; z++) {
                int jz = Math.min(z + 1, d - z);
                for (int y = yc + 1; y <= yc + jz; y++) {
                    h.p(0, y, z, gableWall);
                    h.p(w - 1, y, z, gableWall);
                }
            }
        }
        return ridge;
    }

    // ------------------------------------------------------------------ мелочи
    static void lanternHang(Cx h, int x, int ceilY, int z) {
        h.p(x, ceilY - 1, z, B.LANTERN_HANG);
    }

    /** Дверь в стене с ступенькой снаружи. wallDir = куда смотрит наружу (0..3). */
    static void doorway(Cx h, int x, int z, int outDir, B kind, boolean step) {
        h.box(x, F0 + 1, z, x, F0 + 3, z, B.AIR);
        h.door(x, F0 + 1, z, kind, outDir, false, h.r(x, z, 0, 909) < 0.35);   // треть дверей стоит приоткрытой
        if (step) h.stair(x + Town.dx(outDir), F0, z + Town.dz(outDir), B.CURB, Town.opp(outDir), false);
    }

    /** Подвешенная лампа посреди комнаты. */
    static void lamp(Cx h, int x, int ceilY, int z) {
        h.p(x, ceilY - 1, z, B.CHAIN);
        h.p(x, ceilY - 2, z, B.LANTERN_HANG);
    }

    /** Стол: забор и плита. */
    static void table(Cx h, int x, int y, int z) {
        h.p(x, y, z, B.FENCE_SPRUCE);
        h.slab(x, y + 1, z, B.V_SPRUCE, false);
    }

    static void chair(Cx h, int x, int y, int z, int facing) {
        h.stair(x, y, z, B.V_SPRUCE, Town.opp(facing), false);
    }
}
