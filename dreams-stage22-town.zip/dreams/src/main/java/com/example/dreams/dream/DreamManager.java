package com.example.dreams.dream;

import com.example.dreams.DreamConfig;
import com.example.dreams.attachment.DreamState;
import com.example.dreams.attachment.DreamState.Phase;
import com.example.dreams.attachment.ModAttachments;
import com.example.dreams.network.DreamCutscenePayload;
import com.example.dreams.network.DreamFxPayload;
import com.example.dreams.network.DreamPhasePayload;
import com.example.dreams.entity.ModEntities;
import com.example.dreams.sound.ModSounds;
import com.example.dreams.entity.WatcherEntity;
import com.example.dreams.entity.ExecutionerEntity;
import com.example.dreams.entity.FigureEntity;
import com.example.dreams.block.ModBlocks;
import it.unimi.dsi.fastutil.longs.LongArrayList;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundBlockUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundSetTimePacket;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.phys.AABB;
import java.util.UUID;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

public class DreamManager {

    public enum Result { ABORT, SUCCESS, FAIL, CAUGHT }

    private static final int RADIUS = 18;
    private static final int V_RADIUS = 8;

    // ------------------------------------------------------------------ главный тик

    public static void tick(ServerPlayer player) {
        DreamState s = player.getData(ModAttachments.DREAM_STATE);
        boolean sleeping = player.isSleeping();

        switch (s.phase) {
            case IDLE -> {
                if (sleeping) beginSleep(player, s);
            }
            case NORMAL -> {
                if (!sleeping) s.reset();
            }
            case SLEEP -> {
                if (sleeping) {
                    s.ticks++;
                } else if (s.ticks >= DreamTimeline.FULL_SLEEP_TICKS) {
                    beginFalseAwake(player, s);   // ванильный сон кончился -> "ложное пробуждение"
                } else {
                    end(player, s, Result.ABORT, true);
                }
            }
            case FALSE_AWAKE -> tickFalseAwake(player, s);
        }
    }

    // ------------------------------------------------------------------ фазы

    static int kindId(DreamState.Kind k) {
        return k.ordinal();   // NIGHTMARE=0, OTHERWORLD=1, GOOD=2 = DreamTimeline.KIND_*
    }

    /** Какой сон приснится: взвешенный выбор среди тех видов, чей кулдаун прошёл. null = обычный сон. */
    private static DreamState.Kind pickKind(ServerPlayer player, long now) {
        DreamConfig.Common c = DreamConfig.COMMON;
        boolean badReady = now - player.getData(ModAttachments.LAST_NIGHTMARE) >= c.cooldownNights.get() * 24000L;
        boolean goodReady = now - player.getData(ModAttachments.LAST_GOOD_DREAM) >= c.goodCooldownNights.get() * 24000L;
        int wN = badReady ? c.weightNightmare.get() : 0;
        int wO = badReady && c.otherworld.get() ? c.weightOtherworld.get() : 0;
        int wG = goodReady ? c.weightGood.get() : 0;
        int total = wN + wO + wG;
        if (total <= 0) return null;
        int r = player.getRandom().nextInt(total);
        if (r < wN) return DreamState.Kind.NIGHTMARE;
        r -= wN;
        if (r < wO) return DreamState.Kind.OTHERWORLD;
        return DreamState.Kind.GOOD;
    }

    private static void beginSleep(ServerPlayer player, DreamState s) {
        long now = player.serverLevel().getGameTime();
        DreamState.Kind kind = null;
        if (player.getRandom().nextDouble() < DreamConfig.COMMON.nightmareChance.get()) {
            kind = pickKind(player, now);
        }
        if (kind == null) {
            s.phase = Phase.NORMAL;
            return;
        }
        player.setData(kind == DreamState.Kind.GOOD ? ModAttachments.LAST_GOOD_DREAM : ModAttachments.LAST_NIGHTMARE, now);
        s.kind = kind;
        s.phase = Phase.SLEEP;
        s.ticks = 0;
        s.bed = player.getSleepingPos().orElse(null);
        PacketDistributor.sendToPlayer(player, new DreamPhasePayload(DreamTimeline.PHASE_SLEEP, 0, kindId(kind)));
    }

    private static void beginFalseAwake(ServerPlayer player, DreamState s) {
        s.phase = Phase.FALSE_AWAKE;
        s.ticks = DreamTimeline.startTick(kindId(s.kind), s.repeats);   // кошмар: каждый следующий круг стартует "с разгона"
        s.clearSchedule();
        PacketDistributor.sendToPlayer(player, new DreamPhasePayload(DreamTimeline.PHASE_FALSE_AWAKE, s.repeats, kindId(s.kind)));
        if (s.kind == DreamState.Kind.GOOD) {
            // добрый сон: отдельный мир парящих островов (если измерение есть), иначе старая версия на фейк-блоках
            if (DreamConfig.COMMON.goodDimension.get()) DreamWorld.enter(player, s);
            GoodDream.begin(player, player.serverLevel(), s);
        }
    }

    private static void tickFalseAwake(ServerPlayer player, DreamState s) {
        ServerLevel level = player.serverLevel();
        int t = ++s.ticks;
        if (s.kind == DreamState.Kind.GOOD) {
            GoodDream.tick(player, level, s, t);
            return;
        }

        // 1) Солнце убегает: подменяем время суток только для этого игрока.
        if (DreamConfig.COMMON.fakeTime.get() && t >= DreamTimeline.SUN_RUSH_START) {
            if (t == DreamTimeline.SUN_RUSH_START) {
                s.timeFrom = level.getDayTime() % 24000L;
            }
            long target = s.timeFrom < 18000L ? 18000L : 42000L;
            float p = Mth.clamp((t - DreamTimeline.SUN_RUSH_START)
                    / (float) (DreamTimeline.SUN_RUSH_END - DreamTimeline.SUN_RUSH_START), 0f, 1f);
            float e = p * p * (3f - 2f * p);
            long fakeDay = (long) Mth.lerp(e, (float) s.timeFrom, (float) target);
            if (DreamConfig.COMMON.timeSpin.get() && s.kind == DreamState.Kind.NIGHTMARE && t > DreamTimeline.SPIN_START) {
                // под конец сутки раскручиваются: сначала ~1 оборот в 80 с, потом ~1 в 8 с
                int raw = t - DreamTimeline.SPIN_START;
                int u = Math.min(raw, 1800);                       // разгон до 156 тиков времени за тик
                long spin = (long) (12.0 * u + 0.04 * u * u) + Math.max(0, raw - 1800) * 156L;
                fakeDay = target + spin;
            }
            if (s.otherworld) fakeDay = target;   // Иная сторона: вечная ночь
            // tickDayTime=false -> клиент не двигает время сам; шлём каждый тик
            // (ванильная рассылка времени раз в секунду идёт ДО тика игроков, поэтому наш пакет всегда последний).
            player.connection.send(new ClientboundSetTimePacket(level.getGameTime(), fakeDay, false));
        }

        // 2) Дом начинает врать: волны фейковых блоков за спиной.
        if (DreamConfig.COMMON.fakeBlocks.get() && s.kind == DreamState.Kind.NIGHTMARE && t >= DreamTimeline.WAVES_START && t % 5 == 0) {
            wave(player, level, s);
        }

        // 2a) Этап 8: Иная сторона (волна ржавчины от игрока, потом следует за ним).
        if (s.kind == DreamState.Kind.OTHERWORLD && DreamConfig.COMMON.otherworld.get()) {
            if (!s.otherworld && t >= DreamTimeline.OTHERWORLD_START) {
                if (DreamConfig.COMMON.otherworldDimension.get() && startOtherworldDim(player, s, t)) return;   // уже в другом измерении
                startOtherworld(player, level, s, t);
            }
            if (s.otherworld && !s.owDim) sweepOtherworld(player, level, s);
        }

        // 2b) Этап 7: газлайтинг, звуки за спиной, свои сообщения, вспышки, частицы, тошнота.
        tickHorror(player, level, s, t);

        // 2c) Этап 9: печати, фигуры, Палач, взгляды жителей.
        if (s.otherworld) tickOtherworldMechanics(player, level, s, t);
        if (DreamConfig.COMMON.townWatches.get() && t >= DreamTimeline.SUN_RUSH_START + 60) tickTownWatch(player, level, t);
        if (s.phase != Phase.FALSE_AWAKE) return;   // Палач поймал -> сон уже завершён

        // 3) Кровать-выход светится.
        if (t >= DreamTimeline.BEACON_START && s.bed != null && t % 8 == 0) {
            level.sendParticles(player, ParticleTypes.END_ROD, true,
                    s.bed.getX() + 0.5, s.bed.getY() + 0.9, s.bed.getZ() + 0.5,
                    3, 0.3, 0.2, 0.3, 0.02);
        }

        // 3b) Смотритель (двойник со скином игрока). В Иной стороне его нет: там охотятся Палач и фигуры.
        if (DreamConfig.COMMON.watcherEnabled.get() && s.kind != DreamState.Kind.OTHERWORLD && t >= DreamTimeline.WATCHER_START && !s.caught && t >= s.cinematicUntil) {
            tickWatcher(player, level, s);
            if (s.phase != Phase.FALSE_AWAKE) return;   // поймала -> сон уже завершён
        }

        // 4) Время вышло -> проигрыш.
        int limit = DreamConfig.COMMON.falseAwakeSeconds.get() * 20 + (s.seals.isEmpty() ? 0 : DreamTimeline.RITUAL_EXTRA);
        if (t >= limit) {
            end(player, s, Result.FAIL, true);
        }
    }

    // ------------------------------------------------------------------ фейковые блоки

    private static void wave(ServerPlayer player, ServerLevel level, DreamState s) {
        int max = DreamConfig.COMMON.maxFakeBlocks.get();
        if (s.fake.size() >= max) return;

        float progress = Mth.clamp((s.ticks - DreamTimeline.WAVES_START) / 1200f + 0.2f * s.repeats, 0f, 1f);
        int samples = (int) Mth.lerp(progress, 150f, 600f);
        int maxReplace = (int) Mth.lerp(progress, 25f, 80f);

        Vec3 look = player.getLookAngle();
        BlockPos base = player.blockPosition();
        RandomSource r = player.getRandom();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        int replaced = 0;

        for (int i = 0; i < samples && replaced < maxReplace && s.fake.size() < max; i++) {
            int dx = r.nextInt(RADIUS * 2 + 1) - RADIUS;
            int dy = r.nextInt(V_RADIUS * 2 + 1) - V_RADIUS;
            int dz = r.nextInt(RADIUS * 2 + 1) - RADIUS;
            if (dx * dx + dy * dy + dz * dz < 9) continue;           // не вплотную
            Vec3 dir = new Vec3(dx, dy, dz).normalize();
            if (dir.dot(look) > -0.15) continue;                      // только то, что у игрока ЗА СПИНОЙ

            pos.set(base.getX() + dx, base.getY() + dy, base.getZ() + dz);
            if (!level.hasChunkAt(pos)) continue;
            long key = pos.asLong();
            if (s.fake.containsKey(key)) continue;

            BlockState fake = DreamBlocks.replacement(level.getBlockState(pos), pos, s.otherworld);
            if (fake == null) continue;

            s.fake.put(key, fake);
            player.connection.send(new ClientboundBlockUpdatePacket(pos.immutable(), fake));
            replaced++;
        }
    }

    /** Чанк заново отправлен игроку (отошёл и вернулся) -> фейки в нём пропали, возвращаем. */
    public static void reapplyChunk(ServerPlayer player, ChunkPos cp) {
        DreamState s = player.getData(ModAttachments.DREAM_STATE);
        if (s.phase != Phase.FALSE_AWAKE) return;
        if (s.kind == DreamState.Kind.GOOD) {
            GoodDream.reapplyChunk(player, s, cp);
            return;
        }
        if (s.otherworld) {
            // чанк отправлен заново -> клиент забыл подмены: пусть свип пройдёт по нему ещё раз
            s.owCount -= removeOwChunk(s, cp, player.getBlockY());
        }
        for (int i = 0; i < s.seals.size(); i++) {
            BlockPos sp = BlockPos.of(s.seals.getLong(i));
            if ((sp.getX() >> 4) == cp.x && (sp.getZ() >> 4) == cp.z) sendSeal(player, s, i);
        }
        OtherworldHorror.reapplyChunk(player, s, cp);
        if (s.fake.isEmpty()) return;
        ServerLevel level = player.serverLevel();

        var it = s.fake.long2ObjectEntrySet().iterator();
        while (it.hasNext()) {
            var entry = it.next();
            BlockPos pos = BlockPos.of(entry.getLongKey());
            if ((pos.getX() >> 4) != cp.x || (pos.getZ() >> 4) != cp.z) continue;
            BlockState fake = DreamBlocks.replacement(level.getBlockState(pos), pos, s.otherworld);
            if (fake == null || !fake.equals(entry.getValue())) {     // блок уже сломали/заменили -> забываем
                it.remove();
                continue;
            }
            player.connection.send(new ClientboundBlockUpdatePacket(pos, fake));
        }
    }

    // ------------------------------------------------------------------ этап 7: жуть

    private static final int SELF_MESSAGES = 8;     // message.dreams.self.0..7
    private static final int GLITCH_MESSAGES = 5;   // message.dreams.glitch.0..4

    private static void tickHorror(ServerPlayer player, ServerLevel level, DreamState s, int t) {
        DreamConfig.Common c = DreamConfig.COMMON;
        RandomSource r = player.getRandom();

        // Газлайтинг: то, на что посмотрели, снова нормальное.
        if (c.gaslight.get() && !s.otherworld && t % 4 == 0 && !s.fake.isEmpty()) {
            rollbackSeen(player, level, s);
        }
        if (t < DreamTimeline.SUN_RUSH_START) return;

        int total = Math.max(1, c.falseAwakeSeconds.get() * 20 - DreamTimeline.SUN_RUSH_START);
        float prog = Mth.clamp((t - DreamTimeline.SUN_RUSH_START) / (float) total, 0f, 1f);
        float k = Mth.clamp(prog + 0.2f * s.repeats, 0f, 1f);   // "накал": растёт со временем и с кругами
        if (s.otherworld) k = Math.max(k, 0.65f);
        tickSiren(player, s, t, r);

        // Звуки за спиной.
        if (c.behindSounds.get() && t >= DreamTimeline.SUN_RUSH_START + 40) {
            if (s.nextSoundAt == 0) {
                s.nextSoundAt = t + 40 + r.nextInt(60);
            } else if (t >= s.nextSoundAt) {
                playBehind(player, r, s.otherworld);
                s.nextSoundAt = t + (int) Mth.lerp(k, 260f, 70f) + r.nextInt(60);
            }
        }

        // Свои сообщения: чат "от себя" и глючный текст над хотбаром.
        if (c.selfChat.get() && t >= DreamTimeline.TEXT_START) {
            if (s.nextTextAt == 0) {
                s.nextTextAt = t + 40 + r.nextInt(80);
            } else if (t >= s.nextTextAt) {
                sendDreamText(player, r, s.otherworld);
                s.nextTextAt = t + (int) Mth.lerp(k, 600f, 220f) + r.nextInt(120);
            }
        }

        // Чёрное "моргание": экран гаснет, а Смотритель оказывается ближе.
        if (c.serverFlashes.get() && t >= DreamTimeline.FLASH_START) {
            if (s.nextFlashAt == 0) {
                s.nextFlashAt = t + 100 + r.nextInt(100);
            } else if (t >= s.nextFlashAt) {
                doFlash(player, level, s);
                s.nextFlashAt = t + (int) Mth.lerp(k, 400f, 140f) + r.nextInt(100);
            }
        }

        // Частицы вокруг: пепел, потом пурпурная муть, в конце души.
        if (c.particles.get() && t % 3 == 0) {
            Vec3 p = player.position();
            int n = (int) Mth.lerp(k, 1f, 6f);
            level.sendParticles(player, ParticleTypes.ASH, true, p.x, p.y + 1.5, p.z, n * 3, 6.0, 3.0, 6.0, 0.0);
            if (k > 0.4f) {
                level.sendParticles(player, ParticleTypes.REVERSE_PORTAL, true, p.x, p.y + 1.0, p.z, n, 4.0, 2.0, 4.0, 0.1);
            }
            if (k > 0.7f) {
                level.sendParticles(player, ParticleTypes.SCULK_SOUL, true, p.x, p.y + 0.5, p.z, n, 5.0, 1.0, 5.0, 0.02);
            }
            if (s.otherworld) {   // багровые споры и дым над ржавым миром
                level.sendParticles(player, ParticleTypes.CRIMSON_SPORE, true, p.x, p.y + 1.5, p.z, n * 4, 7.0, 3.0, 7.0, 0.0);
                if (t % 6 == 0) {
                    level.sendParticles(player, ParticleTypes.LARGE_SMOKE, true, p.x, p.y + 0.3, p.z, 2, 6.0, 0.5, 6.0, 0.01);
                }
            }
        }

        // Тошнота волнами (ванильный эффект: экран "плывёт").
        if (c.nausea.get() && prog > 0.45f && t >= s.nextNauseaAt) {
            player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 20 * 7, 0, false, false, false));
            s.nauseaOn = true;
            s.nextNauseaAt = t + 20 * (20 - (int) (10 * k));
        }
    }

    /** Фейки в конусе взгляда (и не дальше 20 блоков) возвращаются в настоящие блоки. */
    private static void rollbackSeen(ServerPlayer player, ServerLevel level, DreamState s) {
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        var it = s.fake.long2ObjectEntrySet().iterator();
        while (it.hasNext()) {
            var e = it.next();
            BlockPos p = BlockPos.of(e.getLongKey());
            Vec3 d = Vec3.atCenterOf(p).subtract(eye);
            double len2 = d.lengthSqr();
            if (len2 < 1e-6 || len2 > 400.0) continue;
            if (d.normalize().dot(look) > 0.6) {
                player.connection.send(new ClientboundBlockUpdatePacket(p, level.getBlockState(p)));
                it.remove();
            }
        }
    }

    /** Звук из точки позади игрока (слышит только он). */
    private static void playBehind(ServerPlayer player, RandomSource r, boolean ow) {
        Vec3 look = player.getLookAngle();
        Vec3 h = new Vec3(look.x, 0, look.z);
        if (h.lengthSqr() < 1e-4) h = new Vec3(0, 0, 1); else h = h.normalize();
        double dist = 2.5 + r.nextDouble() * 4.0;
        double side = (r.nextDouble() - 0.5) * 3.0;
        Vec3 p = player.position().add(h.scale(-dist)).add(-h.z * side, 0.5, h.x * side);

        Holder<SoundEvent> snd;
        float vol = 1.0f;
        float pitch = 0.8f + r.nextFloat() * 0.3f;
        if (ow) {   // Иная сторона: скрежет, лязг, цепи
            switch (r.nextInt(5)) {
                case 0 -> { snd = ModSounds.CLANG; vol = 1.3f; pitch = 0.5f + r.nextFloat() * 0.2f; }
                case 1 -> { snd = ModSounds.SCRAPE; vol = 1.1f; pitch = 0.5f + r.nextFloat() * 0.2f; }
                case 2 -> { snd = ModSounds.CHAIN; vol = 1.2f; pitch = 0.7f; }
                case 3 -> { snd = ModSounds.BEHIND_STEP; vol = 1.5f; pitch = 0.5f; }
                default -> { snd = ModSounds.BREATH; vol = 1.0f; pitch = 0.55f; }
            }
        } else {
            switch (r.nextInt(5)) {
                case 0 -> { snd = ModSounds.BEHIND_STEP; vol = 1.4f; pitch = 0.6f + r.nextFloat() * 0.2f; }
                case 1 -> snd = ModSounds.DOOR;
                case 2 -> { snd = ModSounds.KNOCK; vol = 1.2f; }
                case 3 -> { snd = ModSounds.BREATH; vol = 0.9f; pitch = 0.7f; }
                default -> { snd = ModSounds.WHISPER; vol = 0.8f; pitch = 0.5f + r.nextFloat() * 0.2f; }
            }
        }
        player.connection.send(new ClientboundSoundPacket(snd, SoundSource.HOSTILE,
                p.x, p.y, p.z, vol, pitch, r.nextLong()));
    }

    private static final int OW_MESSAGES = 6;       // message.dreams.ow.0..5
    private static final int OW_GLITCH = 3;          // message.dreams.glitch.ow.0..2

    private static void sendDreamText(ServerPlayer player, RandomSource r, boolean ow) {
        if (r.nextInt(3) == 0) {
            player.displayClientMessage(Component.empty()
                    .append(Component.translatable(ow ? "message.dreams.glitch.ow." + r.nextInt(OW_GLITCH)
                            : "message.dreams.glitch." + r.nextInt(GLITCH_MESSAGES))
                            .withStyle(ChatFormatting.DARK_RED))
                    .append(Component.literal(" ||||||").withStyle(ChatFormatting.DARK_RED, ChatFormatting.OBFUSCATED)), true);
        } else {
            // сообщение "от самого игрока"
            player.sendSystemMessage(Component.literal("<" + player.getName().getString() + "> ")
                    .append(Component.translatable(ow ? "message.dreams.ow." + r.nextInt(OW_MESSAGES)
                            : "message.dreams.self." + r.nextInt(SELF_MESSAGES))));
        }
    }

    private static void doFlash(ServerPlayer player, ServerLevel level, DreamState s) {
        PacketDistributor.sendToPlayer(player, new DreamFxPayload(DreamTimeline.FX_FLASH, 9));
        player.playNotifySound(ModSounds.BLINK.get(), SoundSource.HOSTILE, 0.6f, 0.5f);
        if (DreamConfig.COMMON.watcherJump.get()) {
            jumpWatcher(player, level, s);
        }
    }

    /**
     * Пока экран чёрный, Смотритель перепрыгивает ближе. Если игрок в помещении, а Смотритель снаружи
     * (за окном/дверью), он появляется ВНУТРИ, в 4.5-9 блоках от игрока. Иначе прыгает по прямой (до 6 блоков, не ближе 4).
     */
    private static void jumpWatcher(ServerPlayer player, ServerLevel level, DreamState s) {
        if (s.watcherId == null) return;
        if (!(level.getEntity(s.watcherId) instanceof WatcherEntity w) || !w.isAlive()) return;

        boolean playerIndoors = !level.canSeeSky(player.blockPosition().above());
        boolean watcherOutdoors = level.canSeeSky(w.blockPosition().above());
        RandomSource r = player.getRandom();
        BlockPos g = null;

        if (playerIndoors && watcherOutdoors) {
            for (int i = 0; i < 24 && g == null; i++) {
                double ang = r.nextDouble() * Math.PI * 2;
                double dist = 4.5 + r.nextDouble() * 4.5;
                int x = Mth.floor(player.getX() + Math.cos(ang) * dist);
                int z = Mth.floor(player.getZ() + Math.sin(ang) * dist);
                BlockPos c = findGround(level, x, z, player.getBlockY());
                if (c != null && !level.canSeeSky(c.above(2))) g = c;   // под крышей
            }
        }
        if (g == null) {
            double dx = player.getX() - w.getX();
            double dz = player.getZ() - w.getZ();
            double dist = Math.sqrt(dx * dx + dz * dz);
            if (dist < 8.0) return;
            double len = Math.min(6.0, dist - 4.0);
            g = findGround(level, Mth.floor(w.getX() + dx / dist * len), Mth.floor(w.getZ() + dz / dist * len), w.getBlockY());
        }
        if (g == null) return;
        w.getNavigation().stop();
        w.moveTo(g.getX() + 0.5, g.getY(), g.getZ() + 0.5, w.getYRot(), w.getXRot());
    }

    @javax.annotation.Nullable
    static BlockPos findGround(ServerLevel level, int x, int z, int aroundY) {
        return findGround(level, x, z, aroundY, 3, 4);
    }

    @javax.annotation.Nullable
    static BlockPos findGround(ServerLevel level, int x, int z, int aroundY, int up, int down) {
        for (int y = aroundY + up; y >= aroundY - down; y--) {
            BlockPos pos = new BlockPos(x, y, z);
            if (!level.hasChunkAt(pos)) return null;
            if (level.isEmptyBlock(pos) && level.isEmptyBlock(pos.above()) && level.isEmptyBlock(pos.above(2))
                    && level.getBlockState(pos.below()).isFaceSturdy(level, pos.below(), Direction.UP)) {
                return pos;
            }
        }
        return null;
    }

    // ------------------------------------------------------------------ этап 8: Иная сторона

    private static final int OW_RADIUS = 26;
    private static final int OW_BUDGET = 34;        // колонок за тик (волна расходится ~1 блок/тик)
    private static final int OW_MAX_BLOCKS = 900_000;
    private static final int OW_PACKETS = 1600;     // пакетов блоков за тик (здания тяжелее ржавчины)
    private static final int OW_EXT = 2047;         // служебная "полоса" в owDone для верха зданий
    private static final int[] OW_DX;
    private static final int[] OW_DZ;
    static {
        List<int[]> l = new ArrayList<>();
        for (int dx = -OW_RADIUS; dx <= OW_RADIUS; dx++) {
            for (int dz = -OW_RADIUS; dz <= OW_RADIUS; dz++) {
                if (dx * dx + dz * dz <= OW_RADIUS * OW_RADIUS) l.add(new int[]{dx, dz});
            }
        }
        l.sort(Comparator.comparingInt(a -> a[0] * a[0] + a[1] * a[1]));   // от игрока наружу
        OW_DX = new int[l.size()];
        OW_DZ = new int[l.size()];
        for (int i = 0; i < l.size(); i++) {
            OW_DX[i] = l.get(i)[0];
            OW_DZ[i] = l.get(i)[1];
        }
    }

    /** Иная сторона в своём измерении: переносим игрока в городок на краю пропасти, печати ставим на места города. */
    private static boolean startOtherworldDim(ServerPlayer player, DreamState s, int t) {
        com.example.dreams.dream.world.OtherworldGen.Marks m = OtherworldWorld.enter(player, s);
        if (m == null) return false;
        s.otherworld = true;
        s.owDim = true;
        s.owDone.clear();
        s.city = null;
        s.nextSirenAt = t + 360 + player.getRandom().nextInt(200);
        PacketDistributor.sendToPlayer(player, new DreamFxPayload(DreamTimeline.FX_OTHERWORLD, 0));
        PacketDistributor.sendToPlayer(player, new DreamFxPayload(DreamTimeline.FX_FLASH, 14));
        player.playNotifySound(ModSounds.OW_BREAK.get(), SoundSource.HOSTILE, 1.2f, 0.8f);
        player.playNotifySound(ModSounds.SIREN.get(), SoundSource.HOSTILE, 1.0f, 0.65f);
        player.displayClientMessage(Component.translatable("message.dreams.otherworld")
                .withStyle(ChatFormatting.DARK_RED), true);
        PacketDistributor.sendToPlayer(player, new DreamCutscenePayload("ow_enter", player.getX(), player.getY(), player.getZ()));
        s.cinematicUntil = t + 135;
        placeSealsDim(player, s, m);
        if (!s.seals.isEmpty()) {
            player.sendSystemMessage(Component.translatable("message.dreams.ritual", s.seals.size())
                    .withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC));
        }
        return true;
    }

    /** Печати на местах города: церковь, больница, участок, школа, отель, пирс... Не ближе 20 блоков к кровати. */
    private static void placeSealsDim(ServerPlayer player, DreamState s, com.example.dreams.dream.world.OtherworldGen.Marks m) {
        s.seals.clear();
        s.sealMask = 0;
        int n = DreamConfig.COMMON.ritualSeals.get();
        if (n <= 0) return;
        RandomSource r = player.getRandom();
        java.util.List<BlockPos> sites = new java.util.ArrayList<>();
        for (BlockPos p : m.seals) if (s.bed == null || p.distSqr(s.bed) > 20 * 20) sites.add(p);
        java.util.Collections.shuffle(sites, new java.util.Random(r.nextLong()));
        for (int i = 0; i < Math.min(n, sites.size()); i++) {
            s.seals.add(sites.get(i).asLong());
            sendSeal(player, s, s.seals.size() - 1);
        }
    }

    private static void startOtherworld(ServerPlayer player, ServerLevel level, DreamState s, int t) {
        s.otherworld = true;
        s.owDone.clear();
        s.city = DreamConfig.COMMON.city.get()
                ? new OtherworldCity(player.getRandom().nextLong(), player.blockPosition(), s.bed, DreamConfig.COMMON.cityDensity.get())
                : null;
        s.nextSirenAt = t + 360 + player.getRandom().nextInt(200);
        PacketDistributor.sendToPlayer(player, new DreamFxPayload(DreamTimeline.FX_OTHERWORLD, 0));
        PacketDistributor.sendToPlayer(player, new DreamFxPayload(DreamTimeline.FX_FLASH, 14));
        player.playNotifySound(ModSounds.OW_BREAK.get(), SoundSource.HOSTILE, 1.2f, 0.8f);
        player.playNotifySound(ModSounds.SIREN.get(), SoundSource.HOSTILE, 1.0f, 0.65f);
        player.displayClientMessage(Component.translatable("message.dreams.otherworld")
                .withStyle(ChatFormatting.DARK_RED), true);
        PacketDistributor.sendToPlayer(player, new DreamCutscenePayload("ow_enter", player.getX(), player.getY(), player.getZ()));
        s.cinematicUntil = t + 135;
        placeSeals(player, level, s);
        if (!s.seals.isEmpty()) {
            player.sendSystemMessage(Component.translatable("message.dreams.ritual", s.seals.size())
                    .withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC));
        }
    }

    /**
     * Волна ржавчины: колонки вокруг игрока по порядку расстояния. Расходится от игрока наружу,
     * а потом, пока он идёт, достраивает новые колонки спереди. Высота колонки: полоса в 48 блоков вокруг игрока.
     */
    static void sweepOtherworld(ServerPlayer player, ServerLevel level, DreamState s) {
        final boolean good = s.kind == DreamState.Kind.GOOD;
        if (s.owCount >= OW_MAX_BLOCKS) return;
        final OtherworldCity city = good ? null : s.city;
        int px = player.getBlockX();
        int pz = player.getBlockZ();
        if (city != null) city.setPlayer(px, pz);
        int band = Math.floorDiv(player.getBlockY(), 16);
        int minY = Math.max(level.getMinBuildHeight(), band * 16 - 16);
        int maxY = Math.min(level.getMaxBuildHeight() - 1, band * 16 + 31);
        int budget = OW_BUDGET;
        int packets = 0;
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

        for (int i = 0; i < OW_DX.length && budget > 0 && packets < OW_PACKETS; i++) {
            int x = px + OW_DX[i];
            int z = pz + OW_DZ[i];
            long key = BlockPos.asLong(x, band, z);
            if (s.owDone.contains(key)) continue;
            pos.set(x, player.getBlockY(), z);
            if (!level.hasChunkAt(pos)) continue;          // ещё не загружено: попробуем позже
            OtherworldCity.Col col = null;
            if (city != null) {
                col = city.column(level, x, z);
                if (col == null) continue;                 // участок города ещё нельзя решить: позже
            }
            s.owDone.add(key);
            budget--;
            for (int y = minY; y <= maxY; y++) {
                pos.set(x, y, z);
                BlockState real = level.getBlockState(pos);
                BlockState fake;
                BlockState cityState = col == null ? null : col.at(y, real);
                if (cityState != null) {
                    fake = cityState.equals(real) ? null : cityState;   // город решил сам: ржавчина здесь не нужна
                } else {
                    fake = good ? DreamBlocks.good(real, pos) : DreamBlocks.replacement(real, pos, true);
                }
                if (fake == null) continue;
                if (good && s.fake.containsKey(pos.asLong())) continue;   // плитки, остров, Древо: свои фейки, не трогаем
                player.connection.send(new ClientboundBlockUpdatePacket(pos.immutable(), fake));
                packets++;
                LongArrayList list = owList(s, x, z);
                list.add(pos.asLong());
                s.owCount++;
                if (good && fake.is(ModBlocks.DREAM_MOSS.get()) && DreamBlocks.sprinkle(pos)) {   // на мху вырастают цветы
                    BlockPos above = pos.above();
                    if (level.isEmptyBlock(above) && !s.fake.containsKey(above.asLong())) {
                        player.connection.send(new ClientboundBlockUpdatePacket(above, DreamBlocks.bloom(above)));
                        list.add(above.asLong());
                        s.owCount++;
                    }
                }
            }
            // Высокое здание выше полосы свипа: достраиваем верх один раз на колонку.
            if (col != null && col.hi >= col.lo) {
                long ek = BlockPos.asLong(x, OW_EXT, z);
                if (s.owDone.add(ek)) {
                    int top = Math.min(col.hi, level.getMaxBuildHeight() - 1);
                    for (int y = Math.max(col.lo, level.getMinBuildHeight()); y <= top; y++) {
                        if (y >= minY && y <= maxY) continue;
                        pos.set(x, y, z);
                        BlockState real = level.getBlockState(pos);
                        BlockState cityState = col.at(y, real);
                        if (cityState == null || cityState.equals(real)) continue;
                        player.connection.send(new ClientboundBlockUpdatePacket(pos.immutable(), cityState));
                        packets++;
                        owList(s, x, z).add(pos.asLong());
                        s.owCount++;
                    }
                }
            }
        }
    }

    private static LongArrayList owList(DreamState s, int x, int z) {
        long ck = ChunkPos.asLong(x >> 4, z >> 4);
        LongArrayList list = s.owPos.get(ck);
        if (list == null) {
            list = new LongArrayList();
            s.owPos.put(ck, list);
        }
        return list;
    }

    /** Чанк отправлен клиенту заново: забываем его подмены и колонки, чтобы свип прошёл по нему снова. */
    static int removeOwChunk(DreamState s, ChunkPos cp, int playerY) {
        LongArrayList list = s.owPos.remove(ChunkPos.asLong(cp.x, cp.z));
        int band = Math.floorDiv(playerY, 16);
        for (int b = band - 3; b <= band + 3; b++) {
            for (int dx = 0; dx < 16; dx++) {
                for (int dz = 0; dz < 16; dz++) {
                    s.owDone.remove(BlockPos.asLong(cp.getMinBlockX() + dx, b, cp.getMinBlockZ() + dz));
                }
            }
        }
        for (int dx = 0; dx < 16; dx++) {
            for (int dz = 0; dz < 16; dz++) {
                s.owDone.remove(BlockPos.asLong(cp.getMinBlockX() + dx, OW_EXT, cp.getMinBlockZ() + dz));
            }
        }
        return list == null ? 0 : list.size();
    }

    /** Сирена: несколько секунд Смотритель идёт, даже когда на него смотрят. */
    private static void tickSiren(ServerPlayer player, DreamState s, int t, RandomSource r) {
        if (!s.otherworld || !DreamConfig.COMMON.sirenRush.get()) return;
        if (t >= s.nextSirenAt) {
            s.sirenUntil = t + 80;
            s.sirenCount++;
            if (s.seals.isEmpty() && s.sirenCount >= 2) s.execArmed = true;   // без ритуала Палач приходит со 2-й сиреной
            s.nextSirenAt = t + 700 + r.nextInt(400);
            PacketDistributor.sendToPlayer(player, new DreamFxPayload(DreamTimeline.FX_SIREN, 80));
            player.playNotifySound(ModSounds.SIREN.get(), SoundSource.HOSTILE, 1.0f, 0.9f);
        }
    }

    /** Вернуть игроку настоящие блоки (обычные фейки + Иная сторона; последнее только для чанков, которые у него загружены). */
    static void restoreWorldBlocks(ServerPlayer player, ServerLevel level, DreamState s) {
        OtherworldHorror.restoreAll(player, level, s);
        for (long key : s.fake.keySet()) {
            BlockPos pos = BlockPos.of(key);
            player.connection.send(new ClientboundBlockUpdatePacket(pos, level.getBlockState(pos)));
        }
        if (!s.owPos.isEmpty()) {
            int vd = level.getServer().getPlayerList().getViewDistance() + 1;
            ChunkPos pc = player.chunkPosition();
            for (var e : s.owPos.long2ObjectEntrySet()) {
                long ck = e.getLongKey();
                if (Math.abs(ChunkPos.getX(ck) - pc.x) > vd || Math.abs(ChunkPos.getZ(ck) - pc.z) > vd) continue;
                LongArrayList list = e.getValue();
                for (int i = 0; i < list.size(); i++) {
                    BlockPos pos = BlockPos.of(list.getLong(i));
                    player.connection.send(new ClientboundBlockUpdatePacket(pos, level.getBlockState(pos)));
                }
            }
        }
        for (int i = 0; i < s.seals.size(); i++) {
            BlockPos p = BlockPos.of(s.seals.getLong(i));
            player.connection.send(new ClientboundBlockUpdatePacket(p, level.getBlockState(p)));
            player.connection.send(new ClientboundBlockUpdatePacket(p.above(), level.getBlockState(p.above())));
        }
        s.owPos.clear();
        s.owDone.clear();
        s.owCount = 0;
        s.city = null;
        s.seals.clear();
        s.sealMask = 0;
    }

    // ------------------------------------------------------------------ этап 9: ритуал, Палач, фигуры, жители

    private static final int FIGURE_TARGET = 6;

    private static void tickOtherworldMechanics(ServerPlayer player, ServerLevel level, DreamState s, int t) {
        DreamConfig.Common c = DreamConfig.COMMON;
        RandomSource r = player.getRandom();

        // Поймал: идёт сцена, потом конец сна.
        if (s.caught) {
            freezeHostiles(level, s, player);
            if (t >= s.caughtAt + 78) end(player, s, Result.CAUGHT, true);
            return;
        }
        // Упал в пропасть: возвращаем на площадь (во сне не умирают).
        if (s.owDim && player.getY() < OtherworldWorld.RESCUE_Y) {
            OtherworldWorld.rescue(player, s);
            PacketDistributor.sendToPlayer(player, new DreamFxPayload(DreamTimeline.FX_FLASH, 10));
            player.playNotifySound(ModSounds.CLANG.get(), SoundSource.HOSTILE, 1.0f, 0.5f);
            return;
        }
        // Этап 12: коридор, в котором пространство лжёт (в городке не нужен).
        if (!s.owDim) OtherworldHorror.tick(player, level, s, t);
        // Идёт катсцена: всё враждебное замирает.
        if (t < s.cinematicUntil) {
            freezeHostiles(level, s, player);
            return;
        }

        // Гул печатей: направленный звук (volume 4 = слышно до ~64 блоков), по нему и ищем печати в тумане.
        if (!s.seals.isEmpty() && t % 40 == 0) {
            for (int i = 0; i < s.seals.size(); i++) {
                if ((s.sealMask & (1 << i)) != 0) continue;
                BlockPos p = BlockPos.of(s.seals.getLong(i));
                double x = p.getX() + 0.5, y = p.getY() + 1.0, z = p.getZ() + 0.5;
                if (player.distanceToSqr(x, y, z) > 70.0 * 70.0) continue;
                player.connection.send(new ClientboundSoundPacket(ModSounds.SEAL_HUM, SoundSource.AMBIENT,
                        x, y, z, 4.0f, 0.9f + r.nextFloat() * 0.2f, r.nextLong()));
            }
        }
        // Городок Иной стороны: звуки за спиной, хлопающие двери, гаснущие фонари
        if (s.owDim) OtherworldScares.tick(player, level, s, t);
        // Если игрок слишком долго тянет, Палач приходит сам.
        if (!s.execArmed && t > DreamTimeline.OTHERWORLD_START + (s.seals.isEmpty() ? 900 : 2400)) {
            s.execArmed = true;
        }
        if (c.figures.get()) tickFigures(player, level, s, t, r);
        if (c.executioner.get()) tickExecutioner(player, level, s, t, r);
    }

    /** Пока идёт катсцена: Палач и фигуры стоят на месте, Палач смотрит на игрока. */
    private static void freezeHostiles(ServerLevel level, DreamState s, ServerPlayer player) {
        if (s.executionerId != null && level.getEntity(s.executionerId) instanceof ExecutionerEntity ex && ex.isAlive()) {
            ex.getNavigation().stop();
            ex.getLookControl().setLookAt(player, 30.0f, 30.0f);
        }
        for (UUID id : s.figures) {
            if (level.getEntity(id) instanceof FigureEntity f) f.getNavigation().stop();
        }
    }

    // ---- печати

    private static void placeSeals(ServerPlayer player, ServerLevel level, DreamState s) {
        s.seals.clear();
        s.sealMask = 0;
        int n = DreamConfig.COMMON.ritualSeals.get();
        if (n <= 0) return;
        RandomSource r = player.getRandom();
        BlockPos center = s.bed != null ? s.bed : player.blockPosition();
        double base = r.nextDouble() * Math.PI * 2;
        for (int i = 0; i < n; i++) {
            BlockPos found = null;
            for (int tries = 0; tries < 40 && found == null; tries++) {
                double ang = base + i * (Math.PI * 2 / n) + (r.nextDouble() - 0.5) * 0.7;
                double dist = 22 + r.nextDouble() * 22;
                int x = Mth.floor(center.getX() + Math.cos(ang) * dist);
                int z = Mth.floor(center.getZ() + Math.sin(ang) * dist);
                found = findGround(level, x, z, center.getY(), 5, 8);
                if (found != null && s.city != null && s.city.blockedForce(level, found.getX(), found.getZ())) found = null;   // не в здании
            }
            if (found != null) {
                if (s.city != null) s.city.protect(found.getX(), found.getZ(), 2);
                s.seals.add(found.asLong());
                sendSeal(player, s, s.seals.size() - 1);
            }
        }
    }

    private static void sendSeal(ServerPlayer player, DreamState s, int i) {
        BlockPos p = BlockPos.of(s.seals.getLong(i));
        BlockState st = ((s.sealMask & (1 << i)) != 0 ? ModBlocks.SEAL_DONE : ModBlocks.SEAL).get().defaultBlockState();
        player.connection.send(new ClientboundBlockUpdatePacket(p, st));
        player.connection.send(new ClientboundBlockUpdatePacket(p.above(), st));
    }

    /** ПКМ по печати (вызывается из события). true = клик наш, ваниле его не отдавать. */
    public static boolean trySeal(ServerPlayer player, DreamState s, BlockPos clicked) {
        if (s.phase != Phase.FALSE_AWAKE || !s.otherworld || s.seals.isEmpty()) return false;
        for (int i = 0; i < s.seals.size(); i++) {
            BlockPos p = BlockPos.of(s.seals.getLong(i));
            if (!clicked.equals(p) && !clicked.equals(p.above())) continue;
            if ((s.sealMask & (1 << i)) == 0) activateSeal(player, s, i);
            else sendSeal(player, s, i);   // клик по уже погашенной: вернуть клиенту её вид
            return true;
        }
        return false;
    }

    private static void activateSeal(ServerPlayer player, DreamState s, int i) {
        s.sealMask |= 1 << i;
        sendSeal(player, s, i);
        int total = s.seals.size();
        int done = Integer.bitCount(s.sealMask);
        BlockPos p = BlockPos.of(s.seals.getLong(i));
        player.serverLevel().sendParticles(player, ParticleTypes.SOUL_FIRE_FLAME, true,
                p.getX() + 0.5, p.getY() + 1.0, p.getZ() + 0.5, 40, 0.3, 1.0, 0.3, 0.05);
        player.playNotifySound(ModSounds.SEAL_ACTIVATE.get(), SoundSource.HOSTILE, 1.4f, 1.0f);
        if (done >= total) {
            player.playNotifySound(ModSounds.UNSEAL.get(), SoundSource.HOSTILE, 1.6f, 1.0f);
            player.displayClientMessage(Component.translatable("message.dreams.unsealed")
                    .withStyle(ChatFormatting.GRAY), true);
        } else {
            player.displayClientMessage(Component.translatable("message.dreams.seal", done, total)
                    .withStyle(ChatFormatting.DARK_RED), true);
        }
        // Цена каждой печати: скоро завоет сирена, а со второй печати приходит Палач.
        s.nextSirenAt = Math.min(s.nextSirenAt, s.ticks + 40);
        if (done >= Math.min(2, total)) s.execArmed = true;
    }

    // ---- лежащие фигуры

    private static void tickFigures(ServerPlayer player, ServerLevel level, DreamState s, int t, RandomSource r) {
        var it = s.figures.iterator();
        while (it.hasNext()) {
            UUID id = it.next();
            Entity e = level.getEntity(id);
            if (!(e instanceof FigureEntity f) || !f.isAlive()) {
                it.remove();
                continue;
            }
            if (f.distanceToSqr(player) > 60.0 * 60.0) {   // остались далеко позади
                f.discard();
                it.remove();
                continue;
            }
            double d = f.distanceTo(player);
            if (!f.isAwake()) {
                if (d < 5.5 && t >= f.dormantUntil) {
                    f.setAwake(true);
                    player.connection.send(new ClientboundSoundPacket(ModSounds.FIGURE_MOAN, SoundSource.HOSTILE,
                            f.getX(), f.getY(), f.getZ(), 1.6f, 0.9f + r.nextFloat() * 0.3f, r.nextLong()));
                }
                continue;
            }
            f.getLookControl().setLookAt(player, 30.0f, 30.0f);
            if (isSeen(player, f, s)) {
                f.getNavigation().stop();      // под взглядом замирает
            } else if (t % 8 == 0 || f.getNavigation().isDone()) {
                moveToward(level, s, f, player, 1.0);
            }
            if (d < 1.5) {                     // схватила: больно, тошнит, ноги тяжелеют; потом затихает на 12 с
                f.setAwake(false);
                f.dormantUntil = t + 240;
                f.getNavigation().stop();
                player.hurt(level.damageSources().generic(), 2.0f);
                if (s.phase != Phase.FALSE_AWAKE) return;   // умер: end() уже почистил список, не итерируем дальше
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 2, false, false, true));
                player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 100, 0, false, false, false));
                s.nauseaOn = true;
                player.playNotifySound(ModSounds.FIGURE_MOAN.get(), SoundSource.HOSTILE, 1.2f, 0.6f);
            }
        }
        if (t % 40 == 0 && s.figures.size() < FIGURE_TARGET && !OtherworldHorror.isActive(s)) spawnFigure(player, level, s, r);
    }

    /** Идти к цели, а не сквозь фейковые здания: в городе путь прокладывается по улицам. */
    private static void moveToward(ServerLevel level, DreamState s, Mob mob, Entity target, double speed) {
        if (s.city != null) {
            Vec3 wp = s.city.steer(level, mob.position(), target.position());
            if (wp != null) {
                mob.getNavigation().moveTo(wp.x, wp.y, wp.z, speed);
                return;
            }
        }
        mob.getNavigation().moveTo(target, speed);
    }

    private static void spawnFigure(ServerPlayer player, ServerLevel level, DreamState s, RandomSource r) {
        Vec3 look = player.getLookAngle();
        for (int i = 0; i < 14; i++) {
            double ang = r.nextDouble() * Math.PI * 2;
            double dist = 12 + r.nextDouble() * 18;
            double dx = Math.cos(ang), dz = Math.sin(ang);
            if (dx * look.x + dz * look.z > 0.5 && dist < 22) continue;   // не прямо на глазах
            BlockPos g = findGround(level, Mth.floor(player.getX() + dx * dist), Mth.floor(player.getZ() + dz * dist),
                    player.getBlockY(), 4, 6);
            if (g == null || (s.city != null && s.city.blockedForce(level, g.getX(), g.getZ()))) continue;
            FigureEntity f = ModEntities.FIGURE.get().create(level);
            if (f == null) return;
            f.setOwner(player.getUUID());
            f.moveTo(g.getX() + 0.5, g.getY(), g.getZ() + 0.5, r.nextFloat() * 360f, 0f);
            level.addFreshEntity(f);
            s.figures.add(f.getUUID());
            return;
        }
    }

    // ---- Палач

    private static void tickExecutioner(ServerPlayer player, ServerLevel level, DreamState s, int t, RandomSource r) {
        ExecutionerEntity ex = null;
        if (s.executionerId != null) {
            Entity e = level.getEntity(s.executionerId);
            if (e instanceof ExecutionerEntity x && x.isAlive()) ex = x; else s.executionerId = null;
        }
        if (ex == null) {
            if (s.execArmed && t % 20 == 0 && !OtherworldHorror.isActive(s)) spawnExecutioner(player, level, s, r);
            return;
        }
        double dist = ex.distanceTo(player);
        if (dist > 95.0) {   // потерялся: пусть возродится рядом
            ex.discard();
            s.executionerId = null;
            return;
        }
        boolean siren = t < s.sirenUntil;
        double speed = (1.0 + 0.08 * s.repeats) * (siren ? 1.7 : 1.0) * (dist < 20.0 ? 1.2 : 1.0);   // вблизи рвётся вперёд
        boolean hunting = true;
        if (s.owDim) {
            hunting = ExecutionerAI.tick(player, level, s, ex, t, siren, speed, r);   // городок: показывается, патрулирует, идёт на звук
        } else {
            ex.getLookControl().setLookAt(player, 30.0f, 30.0f);
            if (t % 4 == 0 || ex.getNavigation().isDone()) {
                moveToward(level, s, ex, player, speed);
            }
        }
        // Застрял (не сдвинулся за 2 с, а игрок далеко): перескакивает ближе (только на охоте).
        if (hunting && t % 40 == 0) {
            double moved = Math.hypot(ex.getX() - s.execLastX, ex.getZ() - s.execLastZ);
            if (moved < 1.5 && dist > 7.0) s.execStuck++; else s.execStuck = 0;
            s.execLastX = ex.getX();
            s.execLastZ = ex.getZ();
            if (s.execStuck >= 2) {
                s.execStuck = 0;
                double dx = player.getX() - ex.getX(), dz = player.getZ() - ex.getZ();
                double len = Math.min(10.0, dist - 7.0);
                BlockPos g = findGround(level, Mth.floor(ex.getX() + dx / dist * len),
                        Mth.floor(ex.getZ() + dz / dist * len), ex.getBlockY(), 5, 6);
                if (g != null && (s.city == null || !s.city.blockedForce(level, g.getX(), g.getZ()))) {
                    ex.getNavigation().stop();
                    ex.moveTo(g.getX() + 0.5, g.getY(), g.getZ() + 0.5, ex.getYRot(), ex.getXRot());
                }
            }
        }
        if (dist < 3.4 && (s.city != null ? s.city.sightClear(ex.getEyePosition(), player.getEyePosition()) : clearLine(level, ex, player))) {   // поймал: сцена (камера снизу вверх на него), потом конец сна
            s.caught = true;
            s.caughtAt = t;
            ex.getNavigation().stop();
            PacketDistributor.sendToPlayer(player, new DreamCutscenePayload("ow_caught", ex.getX(), ex.getY(), ex.getZ()));
        }
    }

    /** Между двумя существами нет твёрдых блоков (в городке из настоящих блоков Палач не ловит сквозь стену и окно). */
    private static int t0(DreamState s) { return s.ticks; }

    private static boolean clearLine(ServerLevel level, Entity from, Entity to) {
        net.minecraft.world.phys.BlockHitResult hit = level.clip(new net.minecraft.world.level.ClipContext(
                from.getEyePosition(), to.getEyePosition(),
                net.minecraft.world.level.ClipContext.Block.COLLIDER, net.minecraft.world.level.ClipContext.Fluid.NONE, from));
        return hit.getType() == net.minecraft.world.phys.HitResult.Type.MISS;
    }

    private static void spawnExecutioner(ServerPlayer player, ServerLevel level, DreamState s, RandomSource r) {
        Vec3 look = player.getLookAngle();
        for (int i = 0; i < 24; i++) {
            double ang = r.nextDouble() * Math.PI * 2;
            boolean firstShow = s.owDim && !ExecutionerAI.shown(player.getUUID());
            double dist = s.owDim ? (firstShow ? 26 + r.nextDouble() * 8 : 40 + r.nextDouble() * 20) : 22 + r.nextDouble() * 8;   // первый показ в пределах тумана (36)
            double dx = Math.cos(ang), dz = Math.sin(ang);   // первый раз он стоит вдали на виду
            if (!firstShow && dx * look.x + dz * look.z > 0.3) continue;   // сзади или сбоку, не в лицо
            BlockPos g = findGround(level, Mth.floor(player.getX() + dx * dist), Mth.floor(player.getZ() + dz * dist),
                    player.getBlockY(), 4, 6);
            if (g == null || (s.city != null && s.city.blockedForce(level, g.getX(), g.getZ()))) continue;
            ExecutionerEntity e = ModEntities.EXECUTIONER.get().create(level);
            if (e == null) return;
            e.setOwner(player.getUUID());
            e.moveTo(g.getX() + 0.5, g.getY(), g.getZ() + 0.5, r.nextFloat() * 360f, 0f);
            level.addFreshEntity(e);
            s.executionerId = e.getUUID();
            s.execLastX = e.getX();
            s.execLastZ = e.getZ();
            s.execStuck = 0;
            if (s.owDim) {   // в городке: без рыка и катсцены, он просто стоит вдали
                ExecutionerAI.begin(player.getUUID(), t0(s));
                return;
            }
            player.playNotifySound(ModSounds.EXEC_ROAR.get(), SoundSource.HOSTILE, 2.0f, 0.7f);
            PacketDistributor.sendToPlayer(player, new DreamCutscenePayload("ow_executioner", e.getX(), e.getY(), e.getZ()));
            s.cinematicUntil = s.ticks + 135;   // камера разворачивается к нему, пока он стоит
            player.displayClientMessage(Component.translatable("message.dreams.executioner")
                    .withStyle(ChatFormatting.DARK_RED), true);
            return;
        }
    }

    // ---- жители смотрят

    private static void tickTownWatch(ServerPlayer player, ServerLevel level, int t) {
        if (t % 2 != 0) return;
        AABB box = player.getBoundingBox().inflate(40.0);
        for (Mob m : level.getEntitiesOfClass(Mob.class, box,
                e -> (e instanceof Animal || e instanceof AbstractVillager || e instanceof IronGolem) && !e.isVehicle())) {
            m.getNavigation().stop();
            m.getLookControl().setLookAt(player, 90.0f, 90.0f);
            if (t % 20 == 0) {   // "замораживаем" короткой сильной медлительностью: сама пройдёт, если сон оборвётся
                m.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 6, false, false, false));
            }
        }
    }

    // ------------------------------------------------------------------ Смотритель

    private static void tickWatcher(ServerPlayer player, ServerLevel level, DreamState s) {
        WatcherEntity w = null;
        if (s.watcherId != null && level.getEntity(s.watcherId) instanceof WatcherEntity found && found.isAlive()) {
            w = found;
        }
        if (w == null) {
            s.watcherId = null;
            if (s.ticks % 20 == 0) trySpawnWatcher(player, level, s);
            return;
        }
        if (w.distanceTo(player) > 40f) {          // потерялась/застряла -> заспавним заново
            w.discard();
            s.watcherId = null;
            return;
        }

        int total = Math.max(1, DreamConfig.COMMON.falseAwakeSeconds.get() * 20 - DreamTimeline.WATCHER_START);
        float progress = Mth.clamp((s.ticks - DreamTimeline.WATCHER_START) / (float) total, 0f, 1f);
        boolean siren = s.ticks < s.sirenUntil;   // сирена: двигается даже под взглядом, быстрее
        double speed = (0.8 + 0.35 * progress) * DreamConfig.COMMON.watcherSpeed.get() * (1.0 + 0.1 * s.repeats)
                * (siren ? 1.5 : 1.0);

        // Всегда лицом к игроку.
        double dx = player.getX() - w.getX();
        double dz = player.getZ() - w.getZ();
        float yaw = (float) (Mth.atan2(dz, dx) * (180.0 / Math.PI)) - 90f;
        w.setYRot(yaw);
        w.setYHeadRot(yaw);
        w.setYBodyRot(yaw);

        if (!siren && isSeen(player, w, s)) {
            // Пока на неё смотрят - замирает намертво.
            w.getNavigation().stop();
            w.getMoveControl().setWantedPosition(w.getX(), w.getY(), w.getZ(), 0.0);
            w.setDeltaMovement(0.0, w.getDeltaMovement().y, 0.0);
        } else if (s.ticks % 10 == 0 || (siren && s.ticks % 4 == 0) || (w.getNavigation().isDone() && s.ticks % 4 == 0)) {
            w.getNavigation().moveTo(player, speed);
        }

        if (w.distanceTo(player) < 1.7f) {
            end(player, s, Result.CAUGHT, true);
        }
    }

    /** "Смотрит": объект в конусе ~60 градусов от взгляда и между вами нет блоков. */
    private static boolean isSeen(ServerPlayer player, Entity w, DreamState s) {
        Vec3 eye = player.getEyePosition();
        Vec3 target = w.position().add(0, w.getBbHeight() * 0.6, 0);
        Vec3 dir = target.subtract(eye).normalize();
        if (dir.dot(player.getLookAngle()) < 0.5) return false;
        if (s.city != null && !s.city.sightClear(eye, target)) return false;   // фейковая стена закрывает обзор
        return player.hasLineOfSight(w);
    }

    private static void trySpawnWatcher(ServerPlayer player, ServerLevel level, DreamState s) {
        Vec3 look = player.getLookAngle();
        Vec3 lookH = new Vec3(look.x, 0, look.z);
        double ll = lookH.length();
        if (ll > 1e-3) lookH = lookH.scale(1.0 / ll);
        RandomSource r = player.getRandom();

        for (int i = 0; i < 24; i++) {
            double ang = r.nextDouble() * Math.PI * 2;
            double dist = 14 + r.nextDouble() * 6;
            double dx = Math.cos(ang) * dist;
            double dz = Math.sin(ang) * dist;
            if (ll > 1e-3 && new Vec3(dx, 0, dz).normalize().dot(lookH) > 0.3) continue; // не на глазах

            int x = Mth.floor(player.getX() + dx);
            int z = Mth.floor(player.getZ() + dz);
            for (int y = player.getBlockY() + 6; y >= player.getBlockY() - 6; y--) {
                BlockPos pos = new BlockPos(x, y, z);
                if (!level.hasChunkAt(pos)) break;
                if (level.isEmptyBlock(pos) && level.isEmptyBlock(pos.above()) && level.isEmptyBlock(pos.above(2))
                        && level.getBlockState(pos.below()).isFaceSturdy(level, pos.below(), Direction.UP)) {
                    WatcherEntity w = ModEntities.WATCHER.get().create(level);
                    if (w == null) return;
                    w.setOwner(player.getUUID());
                    w.moveTo(x + 0.5, y, z + 0.5, 0f, 0f);
                    level.addFreshEntity(w);
                    s.watcherId = w.getUUID();
                    return;
                }
            }
        }
    }

    private static void discardWatcher(ServerPlayer player, DreamState s) {
        if (s.watcherId != null) {
            Entity e = player.serverLevel().getEntity(s.watcherId);
            if (e != null) e.discard();
            s.watcherId = null;
        }
        if (s.executionerId != null) {
            Entity e = player.serverLevel().getEntity(s.executionerId);
            if (e != null) e.discard();
            s.executionerId = null;
            ExecutionerAI.end(player.getUUID());
        }
        for (UUID id : s.figures) {
            Entity e = player.serverLevel().getEntity(id);
            if (e != null) e.discard();
        }
        s.figures.clear();
    }

    // ------------------------------------------------------------------ второй круг и команды

    /** "Ложный выход": игрок думает, что проснулся, а сон начинается заново. */
    private static void restartFalseAwake(ServerPlayer player, DreamState s) {
        ServerLevel level = player.serverLevel();
        discardWatcher(player, s);
            restoreWorldBlocks(player, level, s);
        player.connection.send(new ClientboundSetTimePacket(level.getGameTime(), level.getDayTime(),
                level.getGameRules().getBoolean(GameRules.RULE_DAYLIGHT)));
        if (s.nauseaOn) {
            player.removeEffect(MobEffects.CONFUSION);
        }
        s.fake.clear();
        s.repeats++;
        s.ticks = DreamTimeline.skip(s.repeats);
        s.timeFrom = 0L;
        s.clearSchedule();
        player.playNotifySound(ModSounds.WAKE.get(), SoundSource.PLAYERS, 1.0f, 1.0f);
        player.displayClientMessage(Component.translatable("message.dreams.woke_up"), true);
        PacketDistributor.sendToPlayer(player, new DreamPhasePayload(DreamTimeline.PHASE_FALSE_AWAKE, s.repeats, kindId(s.kind)));
    }

    /** Для команды /dreams nightmare: сразу в ложное пробуждение. */
    public static boolean forceStart(ServerPlayer player) {
        return forceStart(player, 0);
    }

    /** /dreams executioner: Иная сторона + Палач сразу. */
    public static boolean forceExecutioner(ServerPlayer player) {
        if (!forceStartAt(player, DreamTimeline.OTHERWORLD_START - 60)) return false;
        player.getData(ModAttachments.DREAM_STATE).execArmed = true;
        return true;
    }

    /** /dreams otherworld: сон вида OTHERWORLD, старт сразу перед переходом в Иную сторону. */
    public static boolean forceStartAt(ServerPlayer player, int tick) {
        if (!forceStart(player, DreamState.Kind.OTHERWORLD, 0)) return false;
        player.getData(ModAttachments.DREAM_STATE).ticks = tick;
        return true;
    }

    /** /dreams good: сразу добрый сон. */
    public static boolean forceGood(ServerPlayer player) {
        return forceStart(player, DreamState.Kind.GOOD, 0);
    }

    /** /dreams loop N: сразу N-й круг кошмара (0 = обычный первый). */
    public static boolean forceStart(ServerPlayer player, int round) {
        return forceStart(player, DreamState.Kind.NIGHTMARE, round);
    }

    /** Запуск сна любого вида без ожидания ночи. */
    public static boolean forceStart(ServerPlayer player, DreamState.Kind kind, int round) {
        DreamState s = player.getData(ModAttachments.DREAM_STATE);
        if (s.phase != Phase.IDLE || player.isSleeping()) return false;
        s.reset();
        s.kind = kind;
        s.repeats = Math.max(0, round);
        s.bed = findBed(player);
        beginFalseAwake(player, s);
        return true;
    }

    @javax.annotation.Nullable
    private static BlockPos findBed(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        BlockPos respawn = player.getRespawnPosition();
        if (respawn != null && player.getRespawnDimension() == level.dimension()
                && level.getBlockState(respawn).getBlock() instanceof BedBlock) {
            return respawn;
        }
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        BlockPos c = player.blockPosition();
        for (BlockPos p : BlockPos.betweenClosed(c.offset(-12, -6, -12), c.offset(12, 6, 12))) {
            if (level.getBlockState(p).getBlock() instanceof BedBlock) {
                double d = p.distSqr(c);
                if (d < bestDist) { bestDist = d; best = p.immutable(); }
            }
        }
        return best;
    }

    // ------------------------------------------------------------------ выход

    public static void tryEscape(ServerPlayer player, DreamState s, BlockPos clicked) {
        if (s.phase != Phase.FALSE_AWAKE) return;
        int beaconAt = s.kind == DreamState.Kind.GOOD ? GoodDream.BED_GLOW_AT : DreamTimeline.BEACON_START;
        if (s.ticks < beaconAt || s.bed == null) return;
        if (!clicked.closerThan(s.bed, 2.5)) return;
        if (s.kind == DreamState.Kind.GOOD) {
            GoodDream.leave(player, s);   // добрый сон: кровать открыта всегда, награда по числу огней
            return;
        }
        if (s.otherworld && Integer.bitCount(s.sealMask) < s.seals.size()) {
            player.displayClientMessage(Component.translatable("message.dreams.sealed",
                    s.seals.size() - Integer.bitCount(s.sealMask)).withStyle(ChatFormatting.DARK_RED), true);
            player.playNotifySound(ModSounds.CLANG.get(), SoundSource.HOSTILE, 0.8f, 0.6f);
            return;   // кровать запечатана, пока не погашены все печати
        }
        double chance = Math.min(0.95, DreamConfig.COMMON.repeatChance.get() + 0.2 * s.repeats);
        if (s.kind == DreamState.Kind.NIGHTMARE && s.repeats < DreamConfig.COMMON.maxRepeats.get() && player.getRandom().nextDouble() < chance) {
            restartFalseAwake(player, s);   // ложный выход: сон начинается заново, каждый круг быстрее и злее
            return;
        }
        end(player, s, Result.SUCCESS, true);
    }

    /**
     * Завершить сон.
     * @param restoreWorld вернуть игроку настоящие блоки и время (false при смене измерения).
     */
    public static void end(ServerPlayer player, DreamState s, Result result, boolean restoreWorld) {
        boolean wasDreaming = s.phase == Phase.SLEEP || s.phase == Phase.FALSE_AWAKE;
        discardWatcher(player, s);
        if (wasDreaming) {
            PacketDistributor.sendToPlayer(player, new DreamPhasePayload(DreamTimeline.PHASE_NONE, 0, kindId(s.kind)));
        }
        if (s.kind == DreamState.Kind.GOOD) {
            GoodDream.cleanup(player, s);   // полёт, дождь, эффекты
        }
        if (s.nauseaOn) {
            player.removeEffect(MobEffects.CONFUSION);
        }

        if (restoreWorld && s.phase == Phase.FALSE_AWAKE) {
            ServerLevel level = player.serverLevel();
            restoreWorldBlocks(player, level, s);
            player.connection.send(new ClientboundSetTimePacket(level.getGameTime(), level.getDayTime(),
                    level.getGameRules().getBoolean(GameRules.RULE_DAYLIGHT)));
        }

        if (DreamWorld.isAnyDream(player.level())) {
            DreamWorld.leave(player, s);   // из мира сна: назад к настоящей кровати
        }

        if (result == Result.CAUGHT) {
            player.playNotifySound(SoundEvents.ENDERMAN_SCREAM, SoundSource.HOSTILE, 1.5f, 0.6f);
            player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 20 * 6, 0));
        }

        switch (result) {
            case SUCCESS -> {
                player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 20 * 10, 1));
                player.playNotifySound(ModSounds.WAKE.get(), SoundSource.PLAYERS, 1.0f, 1.0f);
                player.displayClientMessage(Component.translatable("message.dreams.woke_up"), true);
            }
            case FAIL, CAUGHT -> {
                if (DreamConfig.COMMON.applyDebuffs.get()) {
                    player.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 20 * 30, 0));
                    player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 20 * 15, 0));
                    player.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 20 * 8, 0));
                }
                player.displayClientMessage(Component.translatable(result == Result.CAUGHT ? "message.dreams.caught" : "message.dreams.exhausted"), true);
            }
            case ABORT -> { }
        }

        s.reset();
    }
}
