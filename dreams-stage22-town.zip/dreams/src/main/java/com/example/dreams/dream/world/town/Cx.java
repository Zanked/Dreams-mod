package com.example.dreams.dream.world.town;

import com.example.dreams.dream.world.town.Town.B;
import com.example.dreams.dream.world.town.Town.Sink;

import java.util.HashMap;
import java.util.Map;

/**
 * Контекст здания: своя система координат (x на восток, z на юг, перед здания обычно +z), которая поворачивается
 * на rot четвертей и сдвигается на (tx, tz) в родительскую систему. Так здание рисуется один раз и ставится лицом
 * к любой улице. Цепочка контекстов кончается корнем, который пишет прямо в Sink.
 */
final class Cx {
    final Sink s;          // только у корня
    final Cx parent;
    final long seed;
    final int rot, tx, tz;

    Cx(Sink s, long seed) {
        this.s = s; this.parent = null; this.seed = seed; this.rot = 0; this.tx = 0; this.tz = 0;
    }

    Cx(Cx parent, long seed, int rot, int tx, int tz) {
        this.s = null; this.parent = parent; this.seed = seed; this.rot = rot & 3; this.tx = tx; this.tz = tz;
    }

    /** Вложенная система: её (0,0) лежит в (ox, oz) этой системы, повёрнута на r четвертей. */
    Cx frame(int ox, int oz, int r) {
        return new Cx(this, seed, r, ox, oz);
    }

    Cx frame(int ox, int oz, int r, long newSeed) {
        return new Cx(this, newSeed, r, ox, oz);
    }

    int mu(int x, int z) {
        int u = x, v = z;
        for (int i = 0; i < rot; i++) { int t = u; u = -v; v = t; }
        return u + tx;
    }

    int mv(int x, int z) {
        int u = x, v = z;
        for (int i = 0; i < rot; i++) { int t = u; u = -v; v = t; }
        return v + tz;
    }

    int dir(int d) { return (d + rot) & 3; }

    int mask(int m) {
        int out = 0;
        for (int i = 0; i < 4; i++) if ((m & (1 << i)) != 0) out |= 1 << ((i + rot) & 3);
        return out;
    }

    double r(int a, int b, int c, int salt) { return Town.rand(seed, a, b, c, salt); }

    // ------------------------------------------------------------------ запись
    void p(int x, int y, int z, B b) {
        int u = mu(x, z), v = mv(x, z);
        if (parent == null) s.put(u, y, v, b); else parent.p(u, y, v, b);
    }

    void pf(int x, int y, int z, B b, int d) {
        int u = mu(x, z), v = mv(x, z);
        if (parent == null) s.face(u, y, v, b, dir(d)); else parent.pf(u, y, v, b, dir(d));
    }

    void stair(int x, int y, int z, B fam, int d, boolean top) { stair(x, y, z, fam, d, top, 0); }

    void stair(int x, int y, int z, B fam, int d, boolean top, int shape) {
        int u = mu(x, z), v = mv(x, z);
        if (parent == null) s.stair(u, y, v, fam, dir(d), top, shape); else parent.stair(u, y, v, fam, dir(d), top, shape);
    }

    void slab(int x, int y, int z, B fam, boolean top) {
        int u = mu(x, z), v = mv(x, z);
        if (parent == null) s.slab(u, y, v, fam, top); else parent.slab(u, y, v, fam, top);
    }

    void door(int x, int y, int z, B kind, int d, boolean hingeRight) {
        int u = mu(x, z), v = mv(x, z);
        if (parent == null) s.door(u, y, v, kind, dir(d), hingeRight); else parent.door(u, y, v, kind, dir(d), hingeRight);
    }

    void door(int x, int y, int z, B kind, int d, boolean hingeRight, boolean open) {
        int u = mu(x, z), v = mv(x, z);
        if (parent == null) s.door(u, y, v, kind, dir(d), hingeRight, open); else parent.door(u, y, v, kind, dir(d), hingeRight, open);
    }

    void conn(int x, int y, int z, B b, int m) {
        int u = mu(x, z), v = mv(x, z);
        if (parent == null) s.conn(u, y, v, b, mask(m)); else parent.conn(u, y, v, b, mask(m));
    }

    void bed(int x, int y, int z, B color, int d) {
        int u = mu(x, z), v = mv(x, z);
        if (parent == null) s.bed(u, y, v, color, dir(d)); else parent.bed(u, y, v, color, dir(d));
    }

    void car(int x, int y, int z, int variant, int d, int cell) {
        int u = mu(x, z), v = mv(x, z);
        if (parent == null) s.car(u, y, v, variant, dir(d), cell); else parent.car(u, y, v, variant, dir(d), cell);
    }

    void log(int x, int y, int z, int axis) {
        int u = mu(x, z), v = mv(x, z);
        int a = (rot & 1) == 1 && axis != 1 ? 2 - axis : axis;
        if (parent == null) s.log(u, y, v, a); else parent.log(u, y, v, a);
    }

    void trap(int x, int y, int z, B kind, int d, boolean open, boolean top) {
        int u = mu(x, z), v = mv(x, z);
        if (parent == null) s.trapdoor(u, y, v, kind, dir(d), open, top); else parent.trap(u, y, v, kind, dir(d), open, top);
    }

    void mark(String name, int x, int y, int z) {
        int u = mu(x, z), v = mv(x, z);
        if (parent == null) s.mark(name, u, y, v); else parent.mark(name, u, y, v);
    }

    // ------------------------------------------------------------------ фигуры
    void box(int x0, int y0, int z0, int x1, int y1, int z1, B b) {
        for (int x = Math.min(x0, x1); x <= Math.max(x0, x1); x++)
            for (int y = Math.min(y0, y1); y <= Math.max(y0, y1); y++)
                for (int z = Math.min(z0, z1); z <= Math.max(z0, z1); z++) p(x, y, z, b);
    }

    /** Заливка двумя блоками вперемешку: alt с вероятностью chance (износ, пятна). */
    void rbox(int x0, int y0, int z0, int x1, int y1, int z1, B main, B alt, double chance, int salt) {
        for (int x = Math.min(x0, x1); x <= Math.max(x0, x1); x++)
            for (int y = Math.min(y0, y1); y <= Math.max(y0, y1); y++)
                for (int z = Math.min(z0, z1); z <= Math.max(z0, z1); z++)
                    p(x, y, z, r(x, y, z, salt) < chance ? alt : main);
    }

    /** Воздух (очистить объём). */
    void clear(int x0, int y0, int z0, int x1, int y1, int z1) {
        box(x0, y0, z0, x1, y1, z1, B.AIR);
    }

    /** Четыре стены прямоугольника x0..x1, z0..z1 по высоте y0..y1. */
    void walls(int x0, int z0, int x1, int z1, int y0, int y1, B b) {
        for (int y = y0; y <= y1; y++) {
            for (int x = x0; x <= x1; x++) { p(x, y, z0, b); p(x, y, z1, b); }
            for (int z = z0 + 1; z < z1; z++) { p(x0, y, z, b); p(x1, y, z, b); }
        }
    }

    /** Стены с вкраплением износа (alt). */
    void rwalls(int x0, int z0, int x1, int z1, int y0, int y1, B main, B alt, double chance, int salt) {
        for (int y = y0; y <= y1; y++) {
            for (int x = x0; x <= x1; x++) {
                p(x, y, z0, r(x, y, z0, salt) < chance ? alt : main);
                p(x, y, z1, r(x, y, z1, salt) < chance ? alt : main);
            }
            for (int z = z0 + 1; z < z1; z++) {
                p(x0, y, z, r(x0, y, z, salt) < chance ? alt : main);
                p(x1, y, z, r(x1, y, z, salt) < chance ? alt : main);
            }
        }
    }

    /** Горизонтальный прямоугольный пол/потолок. */
    void floor(int x0, int z0, int x1, int z1, int y, B b) {
        box(x0, y, z0, x1, y, z1, b);
    }

    /** Окно: случайно целое, разбитое или с занавеской. */
    void window(int x, int y, int z, int salt) {
        double v = r(x, y, z, salt);
        p(x, y, z, v < 0.62 ? B.WIN_A : v < 0.82 ? B.WIN_B : B.WIN_C);
    }

    /** Ряд окон вдоль стены: от (x0, z0) в направлении along на len блоков, окно высотой h с шагом pitch, первое со смещением first. */
    void winRow(int x0, int z0, int along, int len, int y, int h, int pitch, int first, int salt) {
        for (int i = first; i < len; i += pitch) {
            int x = x0 + Town.dx(along) * i, z = z0 + Town.dz(along) * i;
            for (int k = 0; k < h; k++) window(x, y + k, z, salt + k * 7);
        }
    }

    /** Линия блоков от (x0,z0) вдоль along длиной len на высоте y. */
    void line(int x0, int z0, int along, int len, int y, B b) {
        for (int i = 0; i < len; i++) p(x0 + Town.dx(along) * i, y, z0 + Town.dz(along) * i, b);
    }

    // ------------------------------------------------------------------ заборы и решётки со связями
    /** Сеть блоков со связями (заборы, решётки). Сначала линии, потом flush: связи считаются по соседям. */
    final class Net {
        final B kind;
        final Map<Long, Integer> cells = new HashMap<>();

        Net(B kind) { this.kind = kind; }

        private void add(int x, int z, int m) {
            cells.merge(((long) x << 32) ^ (z & 0xffffffffL), m, (a, b) -> a | b);
        }

        /** Прямая линия вдоль x или z (концы соединяются внутрь). */
        void line(int x0, int z0, int x1, int z1) {
            if (x0 == x1 && z0 == z1) { add(x0, z0, 0); return; }
            if (z0 == z1) {
                int a = Math.min(x0, x1), b = Math.max(x0, x1);
                for (int x = a; x <= b; x++) add(x, z0, (x > a ? 8 : 0) | (x < b ? 2 : 0));
            } else {
                int a = Math.min(z0, z1), b = Math.max(z0, z1);
                for (int z = a; z <= b; z++) add(x0, z, (z > a ? 1 : 0) | (z < b ? 4 : 0));
            }
        }

        void rect(int x0, int z0, int x1, int z1) {
            line(x0, z0, x1, z0); line(x0, z1, x1, z1); line(x0, z0, x0, z1); line(x1, z0, x1, z1);
        }

        boolean has(int x, int z) { return cells.containsKey(((long) x << 32) ^ (z & 0xffffffffL)); }

        void remove(int x, int z) { cells.remove(((long) x << 32) ^ (z & 0xffffffffL)); }

        void flush(int y0, int y1) {
            for (Map.Entry<Long, Integer> e : cells.entrySet()) {
                int x = (int) (e.getKey() >> 32), z = (int) (long) e.getKey();
                for (int y = y0; y <= y1; y++) conn(x, y, z, kind, e.getValue());
            }
        }
    }

    Net net(B kind) { return new Net(kind); }
}
