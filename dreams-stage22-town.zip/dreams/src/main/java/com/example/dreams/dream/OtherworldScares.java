package com.example.dreams.dream;

import com.example.dreams.attachment.DreamState;
import com.example.dreams.block.ModBlocks;
import com.example.dreams.sound.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.network.protocol.game.ClientboundBlockUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Режиссёр страха в городке Иной стороны (измерение dreams:otherworld). Раз в несколько секунд случайно:
 * звук где-то за спиной (шёпот, стук, скрежет, цепь, шаги), хлопнувшая или приоткрывшаяся дверь, фонарь, который
 * мигает и гаснет. Фонари меняются только у игрока (пакетом, как печати): мир на сервере не трогаем, а при смене
 * измерения или повторной отправке чанка всё возвращается само. Двери меняются по-настоящему (сервер и клиент
 * согласны, игрок не упрётся в невидимую стену).
 */
public final class OtherworldScares {
    private OtherworldScares() {}

    private static final class Later {
        final long pos, at;
        final boolean dead;

        Later(long pos, long at, boolean dead) { this.pos = pos; this.at = at; this.dead = dead; }
    }

    private static final Map<UUID, List<Later>> LATER = new HashMap<>();

    /** Вызывается каждый тик из DreamManager.tickOtherworldMechanics, когда игрок в измерении Иной стороны. t = тик сна. */
    public static void tick(ServerPlayer player, ServerLevel level, DreamState s, int t) {
        long now = level.getGameTime();
        flushLater(player, level, now);
        if (t % 20 != 9) return;
        RandomSource r = player.getRandom();
        int rate = t > 3600 ? 7 : t > 1800 ? 10 : 13;   // чем дольше сон, тем чаще
        if (r.nextInt(rate) != 0) return;
        double k = r.nextDouble();
        if (k < 0.52) ghostSound(player, r);
        else if (k < 0.70) doorEvent(player, level, r);
        else if (k < 0.94) lampFlicker(player, level, r, now);
        else ghostSound(player, r);
    }

    // ------------------------------------------------------------------ звук за спиной

    private static void send(ServerPlayer p, Holder<SoundEvent> ev, double x, double y, double z, float vol, float pitch, RandomSource r) {
        p.connection.send(new ClientboundSoundPacket(ev, SoundSource.AMBIENT, x, y, z, vol, pitch, r.nextLong()));
    }

    /** Точка в 9..26 блоках от игрока, предпочтительно за спиной или сбоку. */
    private static Vec3 behind(ServerPlayer p, RandomSource r) {
        Vec3 look = p.getLookAngle();
        double dx = 1, dz = 0, dist = 14;
        for (int i = 0; i < 8; i++) {
            double ang = r.nextDouble() * Math.PI * 2;
            dx = Math.cos(ang);
            dz = Math.sin(ang);
            dist = 9 + r.nextDouble() * 17;
            if (dx * look.x + dz * look.z < 0.2) break;
        }
        return new Vec3(p.getX() + dx * dist, p.getY() + r.nextInt(3), p.getZ() + dz * dist);
    }

    private static void ghostSound(ServerPlayer p, RandomSource r) {
        Vec3 at = behind(p, r);
        Holder<SoundEvent> ev;
        float vol, pitch;
        switch (r.nextInt(10)) {
            case 0, 1 -> { ev = ModSounds.WHISPER; vol = 1.8f; pitch = 0.7f + r.nextFloat() * 0.3f; }
            case 2 -> { ev = ModSounds.KNOCK; vol = 1.6f; pitch = 0.8f + r.nextFloat() * 0.3f; }
            case 3 -> { ev = ModSounds.SCRAPE; vol = 1.5f; pitch = 0.6f + r.nextFloat() * 0.3f; }
            case 4 -> { ev = ModSounds.CHAIN; vol = 1.5f; pitch = 0.7f + r.nextFloat() * 0.4f; }
            case 5, 6 -> { ev = ModSounds.BEHIND_STEP; vol = 1.4f; pitch = 0.75f + r.nextFloat() * 0.2f; }
            case 7 -> { ev = ModSounds.FIGURE_MOAN; vol = 1.2f; pitch = 0.55f + r.nextFloat() * 0.25f; }
            case 8 -> { ev = ModSounds.CLANG; vol = 1.4f; pitch = 0.5f + r.nextFloat() * 0.2f; }
            default -> { ev = ModSounds.BREATH; vol = 1.3f; pitch = 0.6f + r.nextFloat() * 0.2f; }
        }
        send(p, ev, at.x, at.y, at.z, vol, pitch, r);
    }

    // ------------------------------------------------------------------ двери

    private static void doorEvent(ServerPlayer p, ServerLevel level, RandomSource r) {
        Vec3 look = p.getLookAngle();
        BlockPos base = p.blockPosition();
        for (int i = 0; i < 48; i++) {
            BlockPos pos = base.offset(r.nextInt(29) - 14, r.nextInt(4) - 1, r.nextInt(29) - 14);
            if (!level.hasChunkAt(pos)) continue;
            BlockState st = level.getBlockState(pos);
            if (!(st.getBlock() instanceof DoorBlock) || st.getBlock() == Blocks.IRON_DOOR) continue;
            if (st.getValue(DoorBlock.HALF) != DoubleBlockHalf.LOWER) continue;
            double dx = pos.getX() + 0.5 - p.getX(), dz = pos.getZ() + 0.5 - p.getZ();
            double len = Math.sqrt(dx * dx + dz * dz);
            if (len < 4.0) continue;
            if ((dx * look.x + dz * look.z) / len > 0.45) continue;   // за спиной или сбоку: на глазах двери не двигаются
            boolean open = st.getValue(DoorBlock.OPEN);
            level.setBlock(pos, st.setValue(DoorBlock.OPEN, !open), 10);
            BlockPos up = pos.above();
            BlockState us = level.getBlockState(up);
            if (us.getBlock() instanceof DoorBlock && us.getValue(DoorBlock.HALF) == DoubleBlockHalf.UPPER) {
                level.setBlock(up, us.setValue(DoorBlock.OPEN, !open), 10);
            }
            send(p, ModSounds.DOOR, pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5, 1.6f, open ? 0.7f : 0.85f, r);
            return;
        }
        ghostSound(p, r);   // двери рядом не нашлось
    }

    // ------------------------------------------------------------------ фонари

    private static void lampFlicker(ServerPlayer p, ServerLevel level, RandomSource r, long now) {
        Vec3 look = p.getLookAngle();
        BlockPos base = p.blockPosition();
        for (int i = 0; i < 70; i++) {
            BlockPos pos = base.offset(r.nextInt(37) - 18, r.nextInt(10) - 1, r.nextInt(37) - 18);
            if (!level.hasChunkAt(pos)) continue;
            BlockState st = level.getBlockState(pos);
            if (!st.is(ModBlocks.CITY_LAMP_HEAD.get())) continue;
            double dx = pos.getX() + 0.5 - p.getX(), dz = pos.getZ() + 0.5 - p.getZ();
            double len = Math.sqrt(dx * dx + dz * dz);
            if (len < 4.0 || (dx * look.x + dz * look.z) / len < -0.2) continue;   // гаснет там, куда смотрит игрок
            long key = pos.asLong();
            List<Later> list = LATER.computeIfAbsent(p.getUUID(), k -> new ArrayList<>());
            list.add(new Later(key, now, true));
            list.add(new Later(key, now + 3, false));
            list.add(new Later(key, now + 5, true));
            list.add(new Later(key, now + 8, false));
            list.add(new Later(key, now + 10, true));   // последний раз гаснет насовсем (до смены измерения)
            send(p, ModSounds.CLANG, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 0.7f, 1.7f + r.nextFloat() * 0.3f, r);
            return;
        }
    }

    /** Рядом с Палачом (в 7 блоках) гаснет фонарь: вызывается его поведением. */
    static void killLampsNear(ServerPlayer p, ServerLevel level, Vec3 at, RandomSource r) {
        long now = level.getGameTime();
        BlockPos base = BlockPos.containing(at);
        for (int i = 0; i < 40; i++) {
            BlockPos pos = base.offset(r.nextInt(15) - 7, r.nextInt(9) - 1, r.nextInt(15) - 7);
            if (!level.hasChunkAt(pos) || !level.getBlockState(pos).is(ModBlocks.CITY_LAMP_HEAD.get())) continue;
            long key = pos.asLong();
            List<Later> list = LATER.computeIfAbsent(p.getUUID(), k -> new ArrayList<>());
            list.add(new Later(key, now, true));
            list.add(new Later(key, now + 3, false));
            list.add(new Later(key, now + 5, true));
            return;
        }
    }

    private static void flushLater(ServerPlayer p, ServerLevel level, long now) {
        List<Later> list = LATER.get(p.getUUID());
        if (list == null) return;
        Iterator<Later> it = list.iterator();
        while (it.hasNext()) {
            Later l = it.next();
            if (l.at > now) continue;
            it.remove();
            if (now - l.at > 100) continue;   // осталось от прошлого сна
            BlockPos pos = BlockPos.of(l.pos);
            if (!level.hasChunkAt(pos)) continue;
            BlockState real = level.getBlockState(pos);
            if (!real.is(ModBlocks.CITY_LAMP_HEAD.get())) continue;
            BlockState shown = real;
            if (l.dead) {
                shown = ModBlocks.CITY_LAMP_HEAD_DEAD.get().defaultBlockState()
                        .setValue(HorizontalDirectionalBlock.FACING, real.getValue(HorizontalDirectionalBlock.FACING));
            }
            p.connection.send(new ClientboundBlockUpdatePacket(pos, shown));
        }
        if (list.isEmpty()) LATER.remove(p.getUUID());
    }
}
