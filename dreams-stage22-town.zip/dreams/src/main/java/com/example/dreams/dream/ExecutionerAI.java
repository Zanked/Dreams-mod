package com.example.dreams.dream;

import com.example.dreams.attachment.DreamState;
import com.example.dreams.entity.ExecutionerEntity;
import com.example.dreams.sound.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Поведение Палача в городке Иной стороны (измерение dreams:otherworld).
 * 1) SHOW: первый раз он только показывается: стоит неподвижно далеко и смотрит. Стоит игроку посмотреть на него и отвернуться,
 *    он пропадает и дальше ходит по городу. Если смотреть на него слишком долго, он срывается с места.
 * 2) PATROL: медленно бродит по улицам, дрейфуя в сторону игрока. Скрежет клинка слышен издалека, фонари рядом с ним гаснут.
 * 3) HUNT: слышит бег, прыжки, сирену и тех, кто рядом и не крадётся. Идёт на ЗВУК (в точку, где тебя услышал), а не за тобой:
 *    присел или замер, и он теряет след. Поимка (3.4 блока и прямая видимость) осталась в DreamManager.
 */
final class ExecutionerAI {
    private ExecutionerAI() {}

    static final int SHOW = 0, PATROL = 1, HUNT = 2;

    static final class St {
        int mode = SHOW, spawnT, seen, goalT, alertUntil, lampT;
        boolean shown;
        Vec3 goal, heard;
    }

    private static final Map<UUID, St> MAP = new HashMap<>();

    /** Палач создан. Если игрок его уже видел раньше (после потери и возрождения), сразу патруль. */
    static void begin(UUID id, int t) {
        St old = MAP.get(id);
        St st = new St();
        st.spawnT = t;
        st.shown = old != null && old.shown;
        st.mode = st.shown ? PATROL : SHOW;
        MAP.put(id, st);
    }

    static boolean shown(UUID id) {
        St st = MAP.get(id);
        return st != null && st.shown;
    }

    static void end(UUID id) { MAP.remove(id); }

    private static boolean clear(ServerLevel level, ServerPlayer p, ExecutionerEntity ex) {
        BlockHitResult hit = level.clip(new ClipContext(ex.getEyePosition(), p.getEyePosition(),
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, ex));
        return hit.getType() == HitResult.Type.MISS;
    }

    /** Игрок смотрит на Палача (в конусе ~35 градусов, без стен между). */
    private static boolean watched(ServerLevel level, ServerPlayer p, ExecutionerEntity ex) {
        Vec3 to = ex.getEyePosition().subtract(p.getEyePosition());
        double len = to.length();
        if (len < 1.0 || len > 90.0) return false;
        if (to.scale(1.0 / len).dot(p.getLookAngle()) < 0.82) return false;
        return clear(level, p, ex);
    }

    /** Насколько далеко игрока слышно: бег громче всего, присел или замер: почти тишина. */
    private static double noise(ServerPlayer p, boolean siren) {
        if (siren) return 90.0;
        if (p.isSprinting()) return 32.0;
        if (!p.onGround()) return 22.0;
        if (p.isShiftKeyDown()) return 4.0;
        return p.getDeltaMovement().horizontalDistanceSqr() > 0.0009 ? 13.0 : 3.0;
    }

    private static void roar(ServerPlayer p, ExecutionerEntity ex, RandomSource r) {
        p.connection.send(new ClientboundSoundPacket(ModSounds.EXEC_ROAR, SoundSource.HOSTILE,
                ex.getX(), ex.getY(), ex.getZ(), 3.0f, 0.75f + r.nextFloat() * 0.1f, r.nextLong()));
    }

    /** Один тик поведения. Возвращает true, если Палач сейчас охотится (тогда работает прыжок вперёд при застревании). */
    static boolean tick(ServerPlayer p, ServerLevel level, DreamState s, ExecutionerEntity ex, int t, boolean siren, double huntSpeed, RandomSource r) {
        St st = MAP.get(p.getUUID());
        if (st == null) { begin(p.getUUID(), t); st = MAP.get(p.getUUID()); }
        double dist = ex.distanceTo(p);

        // ---- 1. показывается
        if (st.mode == SHOW) {
            ex.getNavigation().stop();
            ex.getLookControl().setLookAt(p, 30.0f, 30.0f);
            if (watched(level, p, ex)) {
                st.seen++;
                st.shown = true;
                if (st.seen > 110) {            // смотришь слишком долго: срывается
                    st.mode = HUNT;
                    st.heard = p.position();
                    st.alertUntil = t + 160;
                    roar(p, ex, r);
                }
            } else if (st.seen >= 25 || t - st.spawnT > 700) {
                vanish(level, p, ex, r);          // отвернулся: его уже нет
                st.mode = PATROL;
                st.seen = 0;
            }
            return st.mode == HUNT;
        }

        // ---- слух и зрение
        boolean heard = dist <= noise(p, siren) || (dist < 10.0 && !p.isShiftKeyDown() && clear(level, p, ex));
        if (heard) {
            st.heard = p.position();
            st.alertUntil = t + 120;
            if (st.mode != HUNT) {
                st.mode = HUNT;
                roar(p, ex, r);                   // слышимое предупреждение: он тебя услышал
            }
        }

        // фонари вокруг него гаснут
        if (t - st.lampT > 25) {
            st.lampT = t;
            OtherworldScares.killLampsNear(p, level, ex.position(), r);
        }

        // ---- 3. охота: идёт в точку, где услышал
        if (st.mode == HUNT) {
            ex.getLookControl().setLookAt(st.heard.x, st.heard.y + 1.0, st.heard.z);
            if (t % 4 == 0 || ex.getNavigation().isDone()) {
                ex.getNavigation().moveTo(st.heard.x, st.heard.y, st.heard.z, huntSpeed);
            }
            boolean arrived = ex.position().distanceTo(st.heard) < 3.0;
            if (arrived || t > st.alertUntil) {   // потерял след: обходит окрестность
                st.mode = PATROL;
                st.goal = st.heard;
                st.goalT = t + 200;
                ex.getNavigation().stop();
            }
            return true;
        }

        // ---- 2. патруль: медленно, в сторону игрока, заглядывая в улицы
        if (st.goal == null || t > st.goalT || ex.getNavigation().isDone()) {
            for (int i = 0; i < 8; i++) {
                double ang = r.nextDouble() * Math.PI * 2;
                double len = 16 + r.nextDouble() * 16;
                double bx = r.nextDouble() < 0.6 ? p.getX() : ex.getX();
                double bz = r.nextDouble() < 0.6 ? p.getZ() : ex.getZ();
                BlockPos g = DreamManager.findGround(level, Mth.floor(bx + Math.cos(ang) * len),
                        Mth.floor(bz + Math.sin(ang) * len), ex.getBlockY(), 4, 6);
                if (g == null) continue;
                st.goal = new Vec3(g.getX() + 0.5, g.getY(), g.getZ() + 0.5);
                st.goalT = t + 300;
                ex.getNavigation().moveTo(st.goal.x, st.goal.y, st.goal.z, 0.55);
                break;
            }
        }
        return false;
    }

    /** Исчезает на глазах у отвернувшегося: возрождается далеко (50..70 блоков) и идёт патрулировать. */
    private static void vanish(ServerLevel level, ServerPlayer p, ExecutionerEntity ex, RandomSource r) {
        for (int i = 0; i < 16; i++) {
            double ang = r.nextDouble() * Math.PI * 2, d = 50 + r.nextDouble() * 20;
            BlockPos g = DreamManager.findGround(level, Mth.floor(p.getX() + Math.cos(ang) * d),
                    Mth.floor(p.getZ() + Math.sin(ang) * d), p.getBlockY(), 4, 6);
            if (g == null) continue;
            ex.getNavigation().stop();
            ex.moveTo(g.getX() + 0.5, g.getY(), g.getZ() + 0.5, ex.getYRot(), ex.getXRot());
            return;
        }
    }
}
