package com.example.dreams.client.cutscene;

import com.example.dreams.DreamConfig;
import com.example.dreams.Dreams;
import com.example.dreams.client.SkyWhales;
import com.example.dreams.entity.ExecutionerEntity;
import com.google.gson.JsonParser;
import com.mojang.logging.LogUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.Input;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.InputEvent;
import net.neoforged.neoforge.client.event.MovementInputUpdateEvent;
import net.neoforged.neoforge.client.event.RenderGuiEvent;
import net.neoforged.neoforge.client.event.RenderGuiLayerEvent;
import net.neoforged.neoforge.client.event.RenderHandEvent;
import net.neoforged.neoforge.client.event.ViewportEvent;

import java.io.Reader;
import java.util.List;
import java.util.Optional;

/**
 * Катсцены на клиенте. Камера переключается на невидимую сущность-«оператора» (она не добавляется в мир),
 * которая каждый тик идёт по ключевым кадрам (сплайн Катмулла-Рома); между тиками Minecraft сам плавно её интерполирует.
 * Пока сцена идёт: HUD и рука скрыты, управление и поворот игрока заморожены, сверху и снизу чёрные полосы.
 * Пропуск: пробел. Выкл. в dreams-client.toml: cutscenes = false.
 */
@EventBusSubscriber(modid = Dreams.MODID, bus = EventBusSubscriber.Bus.GAME, value = Dist.CLIENT)
public final class CutsceneManager {

    private CutsceneManager() {}

    private static final org.slf4j.Logger LOGGER = LogUtils.getLogger();
    private static final int FLASH_TICKS = 12;
    private static final int SKIP_GRACE = 14;

    private static Cutscene scene = null;
    private static String sceneName = "";
    private static int t = 0;
    private static long lastTickNanos = System.nanoTime();
    private static int flashLeft = 0;

    private static ArmorStand cam = null;
    private static LocalPlayer startPlayer = null;
    private static Vec3 startEye = Vec3.ZERO;
    private static Vec3 anchor = Vec3.ZERO;
    private static double fwdX = 0.0, fwdZ = 1.0;        // «вперёд» пространства сцены
    private static float lockYaw = 0f, lockPitch = 0f;

    // поза камеры: предыдущий и текущий тик
    private static double px, py, pz, cx, cy, cz;
    private static float pYaw, pPitch, cYaw, cPitch, pFov = 1f, cFov = 1f;

    public static boolean isActive() {
        return scene != null;
    }

    // ------------------------------------------------------------------ запуск и остановка

    /** @param ax,ay,az точка-якорь для сцен в пространстве "anchor" (остальным не нужна) */
    public static void play(String name, double ax, double ay, double az) {
        if (!DreamConfig.CLIENT.cutscenes.get()) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null || !name.matches("[a-z0-9_]{1,40}")) return;
        Cutscene c = load(mc, name);
        if (c == null || c.keys.size() < 2) return;
        if (scene != null) stop(false);

        scene = c;
        sceneName = name;
        t = 0;
        startPlayer = player;
        startEye = player.getEyePosition();
        anchor = new Vec3(ax, ay, az);
        lockYaw = player.getYRot();
        lockPitch = player.getXRot();
        double yawRad = Math.toRadians(lockYaw);
        fwdX = -Math.sin(yawRad);
        fwdZ = Math.cos(yawRad);
        if (c.space == Cutscene.Space.ANCHOR) {            // «вперёд» от якоря на игрока
            double dx = startEye.x - ax, dz = startEye.z - az;
            double l = Math.sqrt(dx * dx + dz * dz);
            if (l > 1e-3) {
                fwdX = dx / l;
                fwdZ = dz / l;
            }
        }
        cam = new ArmorStand(EntityType.ARMOR_STAND, mc.level);
        cam.setInvisible(true);
        cam.noPhysics = true;
        compute(mc, 0);
        px = cx; py = cy; pz = cz; pYaw = cYaw; pPitch = cPitch; pFov = cFov;   // первый кадр без интерполяции из пустоты
        applyToCamera();
        mc.setCameraEntity(cam);
        lastTickNanos = System.nanoTime();
    }

    /** Остановить сцену. flash = белая вспышка (после пропуска). */
    public static void stop(boolean flash) {
        Minecraft mc = Minecraft.getInstance();
        if (scene != null && mc.player != null) mc.setCameraEntity(mc.player);
        scene = null;
        cam = null;
        startPlayer = null;
        t = 0;
        if (flash) flashLeft = FLASH_TICKS;
    }

    private static Cutscene load(Minecraft mc, String name) {
        ResourceLocation rl = ResourceLocation.fromNamespaceAndPath(Dreams.MODID, "cutscenes/" + name + ".json");
        Optional<net.minecraft.server.packs.resources.Resource> res = mc.getResourceManager().getResource(rl);
        if (res.isEmpty()) {
            LOGGER.warn("[dreams] cutscene not found: {}", rl);
            return null;
        }
        try (Reader r = res.get().openAsReader()) {
            return Cutscene.parse(JsonParser.parseReader(r).getAsJsonObject());
        } catch (Exception e) {
            LOGGER.warn("[dreams] cutscene {} is broken: {}", rl, e.toString());
            return null;
        }
    }

    // ------------------------------------------------------------------ расчёт камеры

    private static final double[] TMP = new double[3];

    /** Мировая точка из координат сцены: [вправо, вверх, вперёд]. */
    private static Vec3 toWorld(Vec3 origin, double[] rel) {
        double rx = -fwdZ, rz = fwdX;                      // вправо от направления «вперёд»
        return new Vec3(origin.x + rel[0] * rx + rel[2] * fwdX, origin.y + rel[1], origin.z + rel[0] * rz + rel[2] * fwdZ);
    }

    private static Vec3 entityPos = null;     // ближайший Палач на этот тик (или null)

    private static void findEntities(Minecraft mc) {
        entityPos = null;
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) return;
        double best = Double.MAX_VALUE;
        for (ExecutionerEntity e : mc.level.getEntitiesOfClass(ExecutionerEntity.class, p.getBoundingBox().inflate(150.0))) {
            double d = e.distanceToSqr(p);
            if (d < best) {
                best = d;
                entityPos = e.position();
            }
        }
    }

    private static Vec3 lookWorld(Minecraft mc, Vec3 origin, Cutscene.Look l) {
        if (l.p != null) return toWorld(origin, l.p);
        if (l.entity != null && entityPos != null) return entityPos.add(l.off[0], l.off[1], l.off[2]);
        if (SkyWhales.bodyPoint(l.whale, l.s, TMP)) return new Vec3(TMP[0] + l.off[0], TMP[1] + l.off[1], TMP[2] + l.off[2]);
        LocalPlayer p = mc.player;   // кита нет: смотреть вперёд
        return (p != null ? p.getEyePosition() : startEye).add(fwdX * 30.0, 4.0, fwdZ * 30.0);
    }

    private static double cr(double p0, double p1, double p2, double p3, double u) {
        return 0.5 * ((2 * p1) + (-p0 + p2) * u + (2 * p0 - 5 * p1 + 4 * p2 - p3) * u * u + (-p0 + 3 * p1 - 3 * p2 + p3) * u * u * u);
    }

    private static Vec3 spline(Vec3 a, Vec3 b, Vec3 c, Vec3 d, double u) {
        return new Vec3(cr(a.x, b.x, c.x, d.x, u), cr(a.y, b.y, c.y, d.y, u), cr(a.z, b.z, c.z, d.z, u));
    }

    private static float wrapDeg(float a) {
        a %= 360f;
        if (a >= 180f) a -= 360f;
        if (a < -180f) a += 360f;
        return a;
    }

    private static float smooth(float x) {
        x = Mth.clamp(x, 0f, 1f);
        return x * x * (3f - 2f * x);
    }

    /** Поза камеры в момент tt: результат в cx..cPitch, cFov. */
    private static void compute(Minecraft mc, int tt) {
        Cutscene c = scene;
        LocalPlayer player = mc.player;
        Vec3 origin = switch (c.space) {
            case PLAYER -> startEye;
            case PLAYER_LIVE -> player != null ? player.getEyePosition() : startEye;
            case ANCHOR -> anchor;
        };
        findEntities(mc);
        List<Cutscene.Key> ks = c.keys;
        int n = ks.size();
        int i = 0;
        while (i < n - 2 && tt >= ks.get(i + 1).t) i++;
        Cutscene.Key k1 = ks.get(i), k2 = ks.get(Math.min(i + 1, n - 1));
        Cutscene.Key k0 = ks.get(Math.max(i - 1, 0)), k3 = ks.get(Math.min(i + 2, n - 1));
        double u = k2.t > k1.t ? Mth.clamp((tt - k1.t) / (double) (k2.t - k1.t), 0.0, 1.0) : 0.0;

        Vec3 pos = spline(toWorld(origin, k0.pos), toWorld(origin, k1.pos), toWorld(origin, k2.pos), toWorld(origin, k3.pos), u);
        Vec3 look = spline(lookWorld(mc, origin, k0.look), lookWorld(mc, origin, k1.look),
                lookWorld(mc, origin, k2.look), lookWorld(mc, origin, k3.look), u);
        float fov = (float) Mth.lerp(u, k1.fov, k2.fov);

        double dx = look.x - pos.x, dy = look.y - pos.y, dz = look.z - pos.z;
        float yaw = (float) Math.toDegrees(-Math.atan2(dx, dz));
        float pitch = (float) Math.toDegrees(-Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));

        // плавный вход и выход: смешиваем с обычным видом игрока
        float wIn = c.blendIn > 0 ? smooth(1f - tt / (float) c.blendIn) : 0f;
        float wOut = c.blendOut > 0 ? smooth((tt - (c.duration - c.blendOut)) / (float) c.blendOut) : 0f;
        float w = Math.max(wIn, wOut);
        if (w > 0f && player != null) {
            Vec3 pe = player.getEyePosition();
            pos = pos.lerp(pe, w);
            yaw = yaw + wrapDeg(player.getYRot() - yaw) * w;
            pitch = Mth.lerp(w, pitch, player.getXRot());
            fov = Mth.lerp(w, fov, 1f);
        }
        if (c.shake > 0f && !DreamConfig.CLIENT.reducedMotion.get()) {   // ручная камера
            float sh = c.shake * (0.5f + 0.5f * smooth(Math.min(1f, tt / 20f)));
            yaw += sh * (Mth.sin(tt * 1.7f) * 0.6f + Mth.sin(tt * 3.1f + 1.0f) * 0.4f);
            pitch += sh * (Mth.sin(tt * 2.3f + 0.5f) * 0.6f + Mth.sin(tt * 4.1f) * 0.4f);
        }
        cx = pos.x; cy = pos.y; cz = pos.z;
        cYaw = yaw; cPitch = pitch; cFov = fov;
    }

    private static void applyToCamera() {
        if (cam == null) return;
        float eh = cam.getEyeHeight();
        cam.xo = px; cam.yo = py - eh; cam.zo = pz;
        cam.setPos(cx, cy - eh, cz);
        cam.yRotO = cYaw - wrapDeg(cYaw - pYaw);      // короткий путь поворота: без «пол-оборота» на стыке ±180
        cam.xRotO = pPitch;
        cam.setYRot(cYaw);
        cam.setXRot(cPitch);
    }

    // ------------------------------------------------------------------ тик

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            scene = null;
            cam = null;
            flashLeft = 0;
            return;
        }
        if (mc.isPaused()) return;
        lastTickNanos = System.nanoTime();
        if (flashLeft > 0) flashLeft--;
        if (scene == null) return;
        if (mc.player != startPlayer || mc.level == null) {   // умер, сменил мир
            stop(false);
            return;
        }
        t++;
        if (t >= scene.duration) {
            stop(false);
            return;
        }
        for (Cutscene.Snd s : scene.sounds) {
            if (s.t == t) playSound(mc, s);
        }
        if (scene.skippable && t > SKIP_GRACE && mc.options.keyJump.isDown()) {
            stop(true);
            return;
        }
        if (scene.lockLook) {
            LocalPlayer p = mc.player;
            p.setYRot(lockYaw);
            p.setXRot(lockPitch);
            p.yRotO = lockYaw;
            p.xRotO = lockPitch;
        }
        px = cx; py = cy; pz = cz; pYaw = cYaw; pPitch = cPitch; pFov = cFov;
        compute(mc, t);
        applyToCamera();
    }

    private static void playSound(Minecraft mc, Cutscene.Snd s) {
        ResourceLocation rl = ResourceLocation.tryParse(s.sound);
        if (rl == null) return;
        Optional<SoundEvent> ev = BuiltInRegistries.SOUND_EVENT.getOptional(rl);
        if (ev.isEmpty()) {
            LOGGER.warn("[dreams] cutscene {}: unknown sound {}", sceneName, s.sound);
            return;
        }
        mc.getSoundManager().play(SimpleSoundInstance.forUI(ev.get(), s.pitch, s.volume));
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        scene = null;
        cam = null;
        flashLeft = 0;
    }

    // ------------------------------------------------------------------ подавление обычного управления и HUD

    @SubscribeEvent
    public static void onMovement(MovementInputUpdateEvent event) {
        if (scene == null) return;
        Input in = event.getInput();
        in.forwardImpulse = 0f;
        in.leftImpulse = 0f;
        in.up = false;
        in.down = false;
        in.left = false;
        in.right = false;
        in.jumping = false;
        in.shiftKeyDown = false;
    }

    @SubscribeEvent
    public static void onInteract(InputEvent.InteractionKeyMappingTriggered event) {
        if (scene != null) {
            event.setCanceled(true);
            event.setSwingHand(false);
        }
    }

    @SubscribeEvent
    public static void onHand(RenderHandEvent event) {
        if (scene != null) event.setCanceled(true);
    }

    @SubscribeEvent
    public static void onGuiLayer(RenderGuiLayerEvent.Pre event) {
        if (scene != null) event.setCanceled(true);
    }

    @SubscribeEvent
    public static void onFov(ViewportEvent.ComputeFov event) {
        if (scene == null) return;
        float f = Mth.lerp((float) Mth.clamp(framePart(), 0.0, 1.0), pFov, cFov);
        event.setFOV(event.getFOV() * f);
    }

    /** Дальность тумана, которую требует сцена (0 = не требует); плавно нарастает и спадает. */
    public static float fogFar() {
        if (scene == null || scene.fog <= 0f) return 0f;
        float tf = t + (float) Mth.clamp(framePart(), 0.0, 1.0);
        return scene.fog * smooth(Math.min(tf / 24f, (scene.duration - tf) / 24f));
    }

    private static double framePart() {
        return (System.nanoTime() - lastTickNanos) / 50_000_000.0;
    }

    // ------------------------------------------------------------------ полосы, субтитры, вспышки

    @SubscribeEvent
    public static void onGui(RenderGuiEvent.Post event) {
        GuiGraphics g = event.getGuiGraphics();
        int w = g.guiWidth(), h = g.guiHeight();
        Minecraft mc = Minecraft.getInstance();
        if (scene != null) {
            float tf = t + (float) Mth.clamp(framePart(), 0.0, 1.0);
            int bh = 0;
            if (scene.bars) {
                float e = smooth(Math.min(tf / 18f, (scene.duration - tf) / 18f));
                bh = (int) (h * 0.115f * e);
                g.fill(0, 0, w, bh, 0xFF000000);
                g.fill(0, h - bh, w, h, 0xFF000000);
            }
            for (Cutscene.Sub s : scene.subs) {
                if (tf < s.t || tf > s.t + s.d) continue;
                float a = Math.min(1f, Math.min((tf - s.t) / 8f, (s.t + s.d - tf) / 8f));
                int ai = (int) (255 * Mth.clamp(a, 0f, 1f));
                if (ai < 10) continue;
                int y = h - Math.max(bh, 24) / 2 - 4;
                g.drawCenteredString(mc.font, Component.translatable(s.key), w / 2, y, (ai << 24) | 0xFFF2D0);
            }
            if (scene.skippable && tf > SKIP_GRACE && tf < scene.duration - 20) {
                g.drawString(mc.font, Component.translatable("cutscene.dreams.skip"), w - mc.font.width(Component.translatable("cutscene.dreams.skip")) - 8,
                        h - 12, 0x66FFFFFF, false);
            }
            if (scene.fadeOut > 0 && tf > scene.duration - scene.fadeOut) {
                int a = (int) (255 * smooth((tf - (scene.duration - scene.fadeOut)) / scene.fadeOut));
                g.fill(0, 0, w, h, (a << 24) | scene.fadeOutColor);
            }
            if (scene.fadeIn > 0 && tf < scene.fadeIn) {
                int a = (int) (255 * smooth(1f - tf / scene.fadeIn));
                g.fill(0, 0, w, h, (a << 24) | scene.fadeColor);
            }
        }
        if (flashLeft > 0) {
            int a = (int) (255 * Mth.clamp(flashLeft / (float) FLASH_TICKS, 0f, 1f) * 0.85f);
            g.fill(0, 0, w, h, (a << 24) | 0xFFF6DC);
        }
    }
}
