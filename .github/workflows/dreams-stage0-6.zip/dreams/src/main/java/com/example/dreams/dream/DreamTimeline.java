package com.example.dreams.dream;

/** Тайминги сна в тиках. Используются и сервером, и клиентом. */
public class DreamTimeline {
    /** Сколько тиков в кровати считается "досмотрел" (ванильный сон = 100). */
    public static final int FULL_SLEEP_TICKS = 80;

    // Всё ниже считается от начала фазы FALSE_AWAKE.
    public static final int CALM_END = 200;          // 10 с: обычное утро, ничего странного
    public static final int SUN_RUSH_START = 200;    // солнце начинает "убегать"
    public static final int SUN_RUSH_END = 400;      // стало ночью
    public static final int WAVES_START = 300;       // дом начинает меняться (за спиной)
    public static final int BEACON_START = 400;      // кровать-выход начинает светиться, на неё можно нажать
    public static final int WATCHER_START = 450;     // появляется Смотритель

    // Фазы для пакета
    public static final int PHASE_NONE = 0;
    public static final int PHASE_SLEEP = 1;
    public static final int PHASE_FALSE_AWAKE = 2;
}
