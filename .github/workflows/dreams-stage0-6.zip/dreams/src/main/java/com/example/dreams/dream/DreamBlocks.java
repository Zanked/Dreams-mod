package com.example.dreams.dream;

import com.example.dreams.block.ModBlocks;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.LanternBlock;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

/**
 * Правила подмены: настоящий блок -> кошмарный фейк.
 * ВАЖНО: форма коллизии фейка должна совпадать с оригиналом, иначе сервер откатит движение игрока.
 */
public class DreamBlocks {

    @Nullable
    public static BlockState replacement(BlockState s) {
        if (s.is(BlockTags.BASE_STONE_OVERWORLD) || s.is(Blocks.COBBLESTONE) || s.is(Blocks.STONE_BRICKS)) {
            return ModBlocks.VEINED_STONE.get().defaultBlockState();
        }
        if (s.is(BlockTags.PLANKS)) {
            return ModBlocks.ROTTEN_PLANKS.get().defaultBlockState();
        }
        if (s.is(BlockTags.DIRT)) {
            return ModBlocks.ASHEN_DIRT.get().defaultBlockState();
        }
        if (s.is(Blocks.TORCH)) {
            return Blocks.SOUL_TORCH.defaultBlockState();
        }
        if (s.is(Blocks.WALL_TORCH)) {
            return Blocks.SOUL_WALL_TORCH.defaultBlockState()
                    .setValue(HorizontalDirectionalBlock.FACING, s.getValue(HorizontalDirectionalBlock.FACING));
        }
        if (s.is(Blocks.LANTERN)) {
            return Blocks.SOUL_LANTERN.defaultBlockState()
                    .setValue(LanternBlock.HANGING, s.getValue(LanternBlock.HANGING))
                    .setValue(LanternBlock.WATERLOGGED, s.getValue(LanternBlock.WATERLOGGED));
        }
        if (s.is(Blocks.SHORT_GRASS)) {
            return Blocks.DEAD_BUSH.defaultBlockState();
        }
        if (s.is(BlockTags.SMALL_FLOWERS)) {
            return Blocks.WITHER_ROSE.defaultBlockState();
        }
        return null;
    }
}
