package com.example.dreams.attachment;

import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;
import java.util.UUID;

/** Изменяемое состояние сна игрока. Живёт только на сервере, не сохраняется. */
public class DreamState {

    public enum Phase {
        IDLE,        // не спит
        NORMAL,      // спит, кошмар не выпал
        SLEEP,       // кошмар: лежит в кровати
        FALSE_AWAKE  // "ложное пробуждение": уже встал, но сон продолжается
    }

    public Phase phase = Phase.IDLE;
    public int ticks = 0;
    @Nullable public BlockPos bed = null;
    public long timeFrom = 0L;
    public int repeats = 0;   // сколько раз уже был ложный выход
    @Nullable public UUID watcherId = null;
    /** pos.asLong() -> фейковый блок, отправленный игроку. */
    public final Long2ObjectOpenHashMap<BlockState> fake = new Long2ObjectOpenHashMap<>();

    public void reset() {
        phase = Phase.IDLE;
        ticks = 0;
        bed = null;
        timeFrom = 0L;
        watcherId = null;
        repeats = 0;
        fake.clear();
    }
}
