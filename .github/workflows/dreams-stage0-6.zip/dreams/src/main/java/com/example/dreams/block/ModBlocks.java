package com.example.dreams.block;

import com.example.dreams.Dreams;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Блоки кошмара. Предметов нет: в мир они попадают только как фейк, видимый одному игроку.
 * Прочность подобрана под оригиналы, чтобы ломание не рассинхронизировалось.
 */
public class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(Dreams.MODID);

    public static final DeferredBlock<Block> VEINED_STONE = BLOCKS.registerSimpleBlock("veined_stone",
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_RED).strength(1.5f, 6.0f).sound(SoundType.STONE));

    public static final DeferredBlock<Block> ROTTEN_PLANKS = BLOCKS.registerSimpleBlock("rotten_planks",
            BlockBehaviour.Properties.of().mapColor(MapColor.WOOD).strength(2.0f, 3.0f).sound(SoundType.WOOD));

    public static final DeferredBlock<Block> ASHEN_DIRT = BLOCKS.registerSimpleBlock("ashen_dirt",
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_GRAY).strength(0.5f).sound(SoundType.GRAVEL));
}
