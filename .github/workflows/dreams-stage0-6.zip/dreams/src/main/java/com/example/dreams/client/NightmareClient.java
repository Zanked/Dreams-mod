package com.example.dreams.client;

import com.example.dreams.DreamConfig;
import com.example.dreams.Dreams;
import com.example.dreams.dream.DreamTimeline;
import com.example.dreams.entity.WatcherEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.FogRenderer;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import com.example.dreams.sound.ModSounds;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.material.FogType;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RenderGuiEvent;
import net.neoforged.neoforge.client.event.RenderGuiLayerEvent;
import net.neoforged.neoforge.client.event.ViewportEvent;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;

/**
 * Клиентская атмосфера. Две фазы:
 *  1 (SLEEP): засыпание, экран темнеет, лёгкая тревога.
 *  2 (FALSE_AWAKE): "проснулся" -> спокойное утро -> всё катится в кошмар.
 */
@EventBusSubscriber(modid = Dreams.MODID, bus = EventBusSubscriber.Bus.GAME, value = Dist.CLIENT)
public class NightmareClient {

    private static int phase = 0;
    private static int ticks = 0;          // тики внутри текущей фазы
    private static float intensity = 0f;   // 0..1: туман, красный цвет, виньетка, тряска
    private static float darkness = 0f;    // 0..1: чёрное затемнение (засыпание/пробуждение)
    private static int heartbeatCooldown = 0;
    private static int flashLeft = 0;

    public static void setPhase(int p) {
        if (p == DreamTimeline.PHASE_NONE) {
            phase = 0;
            return;
        }
        if (p == DreamTimeline.PHASE_FALSE_AWAKE && phase == DreamTimeline.PHASE_FALSE_AWAKE) {
            darkness = 0.85f;   // второй круг: экран "моргает"
        }
        ticks = 0;
        heartbeatCooldown = 10;
        flashLeft = 0;
        if (p == DreamTimeline.PHASE_SLEEP) {
            intensity = 0f;
            darkness = 0f;
        }
        phase = p;
    }

    private static void reset() {
        phase = 0;
        ticks = 0;
        intensity = 0f;
        darkness = 0f;
        flashLeft = 0;
    }

    // ---------- профиль интенсивности ----------

    private static float targetIntensity() {
        if (phase == DreamTimeline.PHASE_SLEEP) {
            return 0.35f * Mth.clamp(ticks / 80f, 0f, 1f);
        }
        if (phase == DreamTimeline.PHASE_FALSE_AWAKE) {
            if (ticks < 40) return Mth.lerp(ticks / 40f, 0.35f, 0f);            // проснулся, отпустило
            if (ticks < DreamTimeline.CALM_END) return 0f;                      // обычное утро
            if (ticks < DreamTimeline.SUN_RUSH_END) {                           // солнце убегает
                return 0.4f * (ticks - DreamTimeline.SUN_RUSH_START)
                        / (float) (DreamTimeline.SUN_RUSH_END - DreamTimeline.SUN_RUSH_START);
            }
            return Mth.lerp(Mth.clamp((ticks - DreamTimeline.SUN_RUSH_END) / 1200f, 0f, 1f), 0.4f, 0.95f);
        }
        return 0f;
    }

    private static float targetDarkness() {
        if (phase == DreamTimeline.PHASE_SLEEP) {
            return 0.85f * Mth.clamp(ticks / 100f, 0f, 1f);
        }
        return 0f; // в FALSE_AWAKE затемнение само плавно спадает (см. тик)
    }

    // ---------- тик ----------

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) { reset(); return; }
        if (mc.isPaused()) return;

        if (phase != 0) {
            ticks++;
            intensity = targetIntensity();
            if (mc.level != null) {   // чем ближе Смотритель, тем сильнее туман, тряска и сердцебиение
                float boost = 0f;
                for (Entity e : mc.level.entitiesForRendering()) {
                    if (e instanceof WatcherEntity) {
                        boost = Math.max(boost, Mth.clamp((20f - e.distanceTo(mc.player)) / 20f, 0f, 1f) * 0.45f);
                    }
                }
                intensity = Math.min(1f, intensity + boost);
            }
            intensity *= DreamConfig.CLIENT.effectScale.get().floatValue();
            float td = targetDarkness();
            darkness = td > darkness ? td : Math.max(td, darkness - 0.03f); // пробуждение ~1 сек

            tickSounds(mc);

            if (phase == DreamTimeline.PHASE_FALSE_AWAKE && ticks >= 600
                    && DreamConfig.CLIENT.flashes.get() && !DreamConfig.CLIENT.reducedMotion.get() && mc.player.getRandom().nextInt(200) == 0) {
                flashLeft = 3;
            }
        } else {
            intensity = Math.max(0f, intensity - 0.05f);
            darkness = Math.max(0f, darkness - 0.05f);
        }

        if (flashLeft > 0) flashLeft--;
    }

    private static void tickSounds(Minecraft mc) {
        var sm = mc.getSoundManager();

        if (phase == DreamTimeline.PHASE_SLEEP && ticks == 1) {
            sm.play(SimpleSoundInstance.forUI(ModSounds.AMBIENT.get(), 0.6f, 0.8f));
        }
        if (phase == DreamTimeline.PHASE_FALSE_AWAKE) {
            if (ticks == 1) {   // добрый "перезвон": точно проснулся...
                sm.play(SimpleSoundInstance.forUI(ModSounds.CHIME.get(), 1.2f, 0.8f));
            }
            if (ticks == DreamTimeline.SUN_RUSH_START + 20) {
                sm.play(SimpleSoundInstance.forUI(ModSounds.AMBIENT.get(), 0.8f, 1.0f));
            }
            if (ticks == 520 && DreamConfig.CLIENT.scareSound.get()) {
                sm.play(SimpleSoundInstance.forUI(ModSounds.SCARE.get(), 0.7f, 1.0f));
            }
        }

        // Сердцебиение, когда тревога заметна
        if (--heartbeatCooldown <= 0) {
            if (intensity > 0.2f) {
                float pitch = Mth.lerp(intensity, 0.9f, 1.3f);
                sm.play(SimpleSoundInstance.forUI(ModSounds.HEARTBEAT.get(), pitch, 1.0f));
                heartbeatCooldown = (int) Mth.lerp(intensity, 34f, 12f);
            } else {
                heartbeatCooldown = 10;
            }
        }
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        reset();
    }

    // ---------- туман и цвет ----------

    @SubscribeEvent
    public static void onFog(ViewportEvent.RenderFog event) {
        if (intensity <= 0.001f) return;
        if (event.getType() != FogType.NONE) return;
        if (event.getMode() != FogRenderer.FogMode.FOG_TERRAIN) return;

        float ease = intensity * intensity * (3f - 2f * intensity);
        event.setNearPlaneDistance(Mth.lerp(ease, event.getNearPlaneDistance(), 0f));
        event.setFarPlaneDistance(Mth.lerp(ease, event.getFarPlaneDistance(), 12f)); // 12: видно путь до кровати
        event.setCanceled(true);
    }

    @SubscribeEvent
    public static void onFogColor(ViewportEvent.ComputeFogColor event) {
        if (intensity <= 0.001f) return;
        float k = intensity * 0.9f;
        event.setRed(Mth.lerp(k, event.getRed(), 0.30f));
        event.setGreen(Mth.lerp(k, event.getGreen(), 0.0f));
        event.setBlue(Mth.lerp(k, event.getBlue(), 0.02f));
    }

    @SubscribeEvent
    public static void onCamera(ViewportEvent.ComputeCameraAngles event) {
        if (intensity <= 0.001f || !DreamConfig.CLIENT.cameraShake.get() || DreamConfig.CLIENT.reducedMotion.get()) return;
        float t = ticks + (float) event.getPartialTick();
        float amp = 2.2f * intensity * intensity;
        event.setYaw(event.getYaw() + Mth.sin(t * 1.7f) * amp * 0.6f);
        event.setPitch(event.getPitch() + Mth.sin(t * 2.3f + 1.3f) * amp * 0.5f);
        event.setRoll(event.getRoll() + Mth.sin(t * 1.1f + 0.7f) * amp);
    }

    // ---------- HUD ----------

    /** Убираем ванильное синее затемнение сна, рисуем своё. */
    @SubscribeEvent
    public static void onLayerPre(RenderGuiLayerEvent.Pre event) {
        if ((phase != 0 || darkness > 0f) && event.getName().equals(VanillaGuiLayers.SLEEP_OVERLAY)) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onGui(RenderGuiEvent.Post event) {
        if (intensity <= 0.001f && darkness <= 0.001f && flashLeft <= 0) return;
        GuiGraphics g = event.getGuiGraphics();
        int w = g.guiWidth();
        int h = g.guiHeight();

        if (intensity > 0.001f) {
            int tint = (int) (255 * 0.20f * intensity);
            g.fill(0, 0, w, h, (tint << 24) | 0x300000);
            drawVignette(g, w, h, intensity);
        }
        if (darkness > 0.001f) {
            g.fill(0, 0, w, h, ((int) (255 * darkness) << 24) | 0x0A0000);
        }
        if (flashLeft > 0) {
            g.fill(0, 0, w, h, 0xB0000000);
        }
    }

    private static void drawVignette(GuiGraphics g, int w, int h, float i) {
        int steps = 20;
        int maxInset = (int) (Math.min(w, h) * 0.45f);
        int size = Math.max(1, maxInset / steps);
        float pulse = DreamConfig.CLIENT.reducedMotion.get() ? 1f : 0.85f + 0.15f * Mth.sin(ticks * 0.5f);
        for (int s = 0; s < steps; s++) {
            float f = 1f - (float) s / steps;
            int a = (int) (255 * 0.85f * i * pulse * f * f);
            if (a <= 0) continue;
            int color = (Mth.clamp(a, 0, 255) << 24) | 0x500000;
            int in = s * size;
            g.fill(in, in, w - in, in + size, color);
            g.fill(in, h - in - size, w - in, h - in, color);
            g.fill(in, in + size, in + size, h - in - size, color);
            g.fill(w - in - size, in + size, w - in, h - in - size, color);
        }
    }
}
