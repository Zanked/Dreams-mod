package com.example.dreams.sound;

import com.example.dreams.Dreams;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Все звуки мода - собственные события. В assets/dreams/sounds.json они пока ссылаются на ванильные звуки.
 * Чтобы поставить свои: положи .ogg в assets/dreams/sounds/ и замени запись в sounds.json
 * (убери "type": "event", укажи "name": "dreams:имя_файла_без_расширения").
 */
public class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(Registries.SOUND_EVENT, Dreams.MODID);

    public static final DeferredHolder<SoundEvent, SoundEvent> HEARTBEAT = reg("heartbeat");
    public static final DeferredHolder<SoundEvent, SoundEvent> AMBIENT = reg("ambient");
    public static final DeferredHolder<SoundEvent, SoundEvent> CHIME = reg("chime");
    public static final DeferredHolder<SoundEvent, SoundEvent> SCARE = reg("scare");
    public static final DeferredHolder<SoundEvent, SoundEvent> WATCHER_STEP = reg("watcher_step");
    public static final DeferredHolder<SoundEvent, SoundEvent> WAKE = reg("wake");

    private static DeferredHolder<SoundEvent, SoundEvent> reg(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(
                ResourceLocation.fromNamespaceAndPath(Dreams.MODID, name)));
    }
}
