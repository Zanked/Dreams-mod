package com.example.dreams;

import net.neoforged.neoforge.common.ModConfigSpec;
import org.apache.commons.lang3.tuple.Pair;

public class DreamConfig {

    public static class Common {
        public final ModConfigSpec.DoubleValue nightmareChance;
        public final ModConfigSpec.BooleanValue applyDebuffs;
        public final ModConfigSpec.BooleanValue fakeBlocks;
        public final ModConfigSpec.BooleanValue fakeTime;
        public final ModConfigSpec.IntValue falseAwakeSeconds;
        public final ModConfigSpec.IntValue maxFakeBlocks;
        public final ModConfigSpec.BooleanValue watcherEnabled;
        public final ModConfigSpec.DoubleValue watcherSpeed;
        public final ModConfigSpec.IntValue cooldownNights;
        public final ModConfigSpec.DoubleValue repeatChance;

        Common(ModConfigSpec.Builder b) {
            nightmareChance = b.comment("Chance (0..1) that a sleep becomes a nightmare. 1.0 = always (for testing).")
                    .defineInRange("nightmareChance", 1.0, 0.0, 1.0);
            applyDebuffs = b.comment("Apply debuffs if the player fails to escape the nightmare.")
                    .define("applyDebuffs", true);
            fakeBlocks = b.comment("Send fake blocks (visible only to the dreamer). Disable if your anti-cheat complains.")
                    .define("fakeBlocks", true);
            fakeTime = b.comment("Fake the time of day (sun rushes to night) for the dreamer only.")
                    .define("fakeTime", true);
            falseAwakeSeconds = b.comment("How long the false awakening lasts before the player fails (seconds).")
                    .defineInRange("falseAwakeSeconds", 120, 30, 600);
            maxFakeBlocks = b.comment("Maximum number of fake blocks per dreamer.")
                    .defineInRange("maxFakeBlocks", 4000, 100, 20000);
            watcherEnabled = b.comment("Spawn the Watcher during the false awakening.")
                    .define("watcherEnabled", true);
            watcherSpeed = b.comment("Watcher speed multiplier (1.0 = a bit faster than walking, about sprint speed at the end).")
                    .defineInRange("watcherSpeed", 1.0, 0.3, 2.5);
            cooldownNights = b.comment("Minimum number of in-game days between two nightmares for one player (0 = no cooldown).")
                    .defineInRange("cooldownNights", 0, 0, 100);
            repeatChance = b.comment("Chance (0..1) that escaping is a false escape and the dream starts over once more.")
                    .defineInRange("repeatChance", 0.2, 0.0, 1.0);
        }
    }

    public static class Client {
        public final ModConfigSpec.BooleanValue cameraShake;
        public final ModConfigSpec.BooleanValue flashes;
        public final ModConfigSpec.BooleanValue scareSound;
        public final ModConfigSpec.BooleanValue reducedMotion;
        public final ModConfigSpec.DoubleValue effectScale;

        Client(ModConfigSpec.Builder b) {
            cameraShake = b.comment("Camera shake during nightmares.").define("cameraShake", true);
            flashes = b.comment("Sudden dark flashes during nightmares. Disable if sensitive.").define("flashes", true);
            scareSound = b.comment("Loud scare sound during nightmares.").define("scareSound", true);
            reducedMotion = b.comment("Accessibility: no camera shake, no flashes, no pulsing. Overrides the options above.")
                    .define("reducedMotion", false);
            effectScale = b.comment("Accessibility: overall strength of fog/red tint/vignette (0 = off, 1 = full).")
                    .defineInRange("effectScale", 1.0, 0.0, 1.0);
        }
    }

    public static final ModConfigSpec COMMON_SPEC;
    public static final Common COMMON;
    public static final ModConfigSpec CLIENT_SPEC;
    public static final Client CLIENT;

    static {
        Pair<Common, ModConfigSpec> c = new ModConfigSpec.Builder().configure(Common::new);
        COMMON = c.getLeft();
        COMMON_SPEC = c.getRight();
        Pair<Client, ModConfigSpec> cl = new ModConfigSpec.Builder().configure(Client::new);
        CLIENT = cl.getLeft();
        CLIENT_SPEC = cl.getRight();
    }
}
