# Dreams: этапы 0-6

Распакуй поверх проекта. Тест без ожидания ночи: /dreams nightmare  (op), прервать: /dreams stop.
Обычный путь: /time set 13000 -> лечь в кровать.

Ход сна: засыпание -> "утро" -> солнце убегает -> дом меняется за спиной -> кровать светится (20 с) ->
Смотритель (22 с) -> ПКМ по кровати = выход. С шансом repeatChance это "ложный выход": экран моргает, сон начинается заново (один раз).

Конфиги: run/config/dreams-common.toml (шансы, кулдаун, таймаут, фейк-блоки, Смотритель),
         run/config/dreams-client.toml (доступность: reducedMotion, effectScale, flashes, cameraShake, scareSound).
Звуки: assets/dreams/sounds.json (пока ссылаются на ванильные). Текстуры: см. TEXTURES.md.
