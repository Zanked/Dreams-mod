package com.example.dreams.command;

import com.example.dreams.Dreams;
import com.example.dreams.attachment.DreamState;
import com.example.dreams.attachment.ModAttachments;
import com.example.dreams.dream.DreamManager;
import com.example.dreams.dream.DreamTimeline;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

/**
 * /dreams nightmare [игрок]  - сразу запустить "ложное пробуждение" (для тестов, без ожидания ночи)
 * /dreams loop <круг> [игрок] - сразу N-й круг сна (1-5: быстрее и злее, для теста ложных выходов)
 * /dreams stop [игрок]       - прервать сон
 */
@EventBusSubscriber(modid = Dreams.MODID)
public class DreamCommands {

    @SubscribeEvent
    public static void onRegister(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("dreams")
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("nightmare")
                        .executes(ctx -> start(ctx, ctx.getSource().getPlayerOrException()))
                        .then(Commands.argument("target", EntityArgument.player())
                                .executes(ctx -> start(ctx, EntityArgument.getPlayer(ctx, "target")))))
                .then(Commands.literal("otherworld")
                        .executes(ctx -> startAt(ctx, ctx.getSource().getPlayerOrException(), DreamTimeline.OTHERWORLD_START - 60))
                        .then(Commands.argument("target", EntityArgument.player())
                                .executes(ctx -> startAt(ctx, EntityArgument.getPlayer(ctx, "target"), DreamTimeline.OTHERWORLD_START - 60))))
                .then(Commands.literal("loop")
                        .then(Commands.argument("round", IntegerArgumentType.integer(0, 5))
                                .executes(ctx -> start(ctx, ctx.getSource().getPlayerOrException(),
                                        IntegerArgumentType.getInteger(ctx, "round")))
                                .then(Commands.argument("target", EntityArgument.player())
                                        .executes(ctx -> start(ctx, EntityArgument.getPlayer(ctx, "target"),
                                                IntegerArgumentType.getInteger(ctx, "round"))))))
                .then(Commands.literal("stop")
                        .executes(ctx -> stop(ctx, ctx.getSource().getPlayerOrException()))
                        .then(Commands.argument("target", EntityArgument.player())
                                .executes(ctx -> stop(ctx, EntityArgument.getPlayer(ctx, "target"))))));
    }

    private static int start(CommandContext<CommandSourceStack> ctx, ServerPlayer target) {
        return start(ctx, target, 0);
    }

    private static int startAt(CommandContext<CommandSourceStack> ctx, ServerPlayer target, int tick) {
        if (!DreamManager.forceStartAt(target, tick)) {
            ctx.getSource().sendFailure(Component.translatable("commands.dreams.busy", target.getDisplayName()));
            return 0;
        }
        ctx.getSource().sendSuccess(() -> Component.translatable("commands.dreams.started", target.getDisplayName()), true);
        return 1;
    }

    private static int start(CommandContext<CommandSourceStack> ctx, ServerPlayer target, int round) {
        if (!DreamManager.forceStart(target, round)) {
            ctx.getSource().sendFailure(Component.translatable("commands.dreams.busy", target.getDisplayName()));
            return 0;
        }
        ctx.getSource().sendSuccess(() -> Component.translatable("commands.dreams.started", target.getDisplayName()), true);
        if (target.getData(ModAttachments.DREAM_STATE).bed == null) {
            ctx.getSource().sendSuccess(() -> Component.translatable("commands.dreams.nobed"), false);
        }
        return 1;
    }

    private static int stop(CommandContext<CommandSourceStack> ctx, ServerPlayer target) {
        DreamState s = target.getData(ModAttachments.DREAM_STATE);
        if (s.phase == DreamState.Phase.IDLE) {
            ctx.getSource().sendFailure(Component.translatable("commands.dreams.idle", target.getDisplayName()));
            return 0;
        }
        DreamManager.end(target, s, DreamManager.Result.ABORT, true);
        ctx.getSource().sendSuccess(() -> Component.translatable("commands.dreams.stopped", target.getDisplayName()), true);
        return 1;
    }
}
