package com.example.dreams.attachment;

import com.example.dreams.Dreams;
import com.mojang.serialization.Codec;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

import java.util.function.Supplier;

public class ModAttachments {
    public static final DeferredRegister<AttachmentType<?>> ATTACHMENTS =
            DeferredRegister.create(NeoForgeRegistries.ATTACHMENT_TYPES, Dreams.MODID);

    // Без .serialize(...) -> не сохраняется и не копируется при смерти. Нам так и надо.
    public static final Supplier<AttachmentType<DreamState>> DREAM_STATE =
            ATTACHMENTS.register("dream_state", () -> AttachmentType.builder(DreamState::new).build());

    /** Игровое время последнего кошмара. Сохраняется в мир и переживает смерть (для кулдауна). */
    public static final Supplier<AttachmentType<Long>> LAST_NIGHTMARE =
            ATTACHMENTS.register("last_nightmare", () ->
                    AttachmentType.builder(() -> -1_000_000_000L).serialize(Codec.LONG).copyOnDeath().build());
}
