package com.example.dreams;

import net.neoforged.neoforge.common.ModConfigSpec;
import org.apache.commons.lang3.tuple.Pair;

public class DreamConfig {

    public static class Common {
        public final ModConfigSpec.DoubleValue nightmareChance;
        public final ModConfigSpec.BooleanValue applyDebuffs;
        public final ModConfigSpec.BooleanValue fakeBlocks;
        public final ModConfigSpec.BooleanValue fakeTime;
        public final ModConfigSpec.IntValue falseAwakeSeconds;
        public final ModConfigSpec.IntValue maxFakeBlocks;
        public final ModConfigSpec.BooleanValue watcherEnabled;
        public final ModConfigSpec.DoubleValue watcherSpeed;
        public final ModConfigSpec.IntValue cooldownNights;
        public final ModConfigSpec.DoubleValue repeatChance;
        public final ModConfigSpec.IntValue maxRepeats;
        public final ModConfigSpec.BooleanValue gaslight;
        public final ModConfigSpec.BooleanValue behindSounds;
        public final ModConfigSpec.BooleanValue serverFlashes;
        public final ModConfigSpec.BooleanValue watcherJump;
        public final ModConfigSpec.BooleanValue watcherOpensDoors;
        public final ModConfigSpec.BooleanValue otherworld;
        public final ModConfigSpec.BooleanValue sirenRush;
        public final ModConfigSpec.BooleanValue selfChat;
        public final ModConfigSpec.BooleanValue timeSpin;
        public final ModConfigSpec.BooleanValue nausea;
        public final ModConfigSpec.BooleanValue particles;

        Common(ModConfigSpec.Builder b) {
            nightmareChance = b.comment("Chance (0..1) that a sleep becomes a nightmare. 1.0 = always (for testing).")
                    .defineInRange("nightmareChance", 1.0, 0.0, 1.0);
            applyDebuffs = b.comment("Apply debuffs if the player fails to escape the nightmare.")
                    .define("applyDebuffs", true);
            fakeBlocks = b.comment("Send fake blocks (visible only to the dreamer). Disable if your anti-cheat complains.")
                    .define("fakeBlocks", true);
            fakeTime = b.comment("Fake the time of day (sun rushes to night) for the dreamer only.")
                    .define("fakeTime", true);
            falseAwakeSeconds = b.comment("How long the false awakening lasts before the player fails (seconds).")
                    .defineInRange("falseAwakeSeconds", 120, 30, 600);
            maxFakeBlocks = b.comment("Maximum number of fake blocks per dreamer.")
                    .defineInRange("maxFakeBlocks", 4000, 100, 20000);
            watcherEnabled = b.comment("Spawn the Watcher during the false awakening.")
                    .define("watcherEnabled", true);
            watcherSpeed = b.comment("Watcher speed multiplier (1.0 = a bit faster than walking, about sprint speed at the end).")
                    .defineInRange("watcherSpeed", 1.0, 0.3, 2.5);
            cooldownNights = b.comment("Minimum number of in-game days between two nightmares for one player (0 = no cooldown).")
                    .defineInRange("cooldownNights", 0, 0, 100);
            repeatChance = b.comment("Chance (0..1) that the FIRST escape is a false escape and the dream starts over. Each next loop adds +0.2.")
                    .defineInRange("repeatChance", 0.35, 0.0, 1.0);
            maxRepeats = b.comment("How many false escapes (dream loops) are possible in one nightmare. Each loop is faster and scarier. 0 = never.")
                    .defineInRange("maxRepeats", 3, 0, 5);
            gaslight = b.comment("Fake blocks you look at turn back to normal; only what is behind you changes.")
                    .define("gaslight", true);
            behindSounds = b.comment("Footsteps, doors, knocking and breathing from behind the dreamer (heard only by them).")
                    .define("behindSounds", true);
            serverFlashes = b.comment("Sudden black blinks during the dream (also needed for the Watcher jump). Client option 'flashes' can still hide them.")
                    .define("serverFlashes", true);
            watcherJump = b.comment("During a black blink the Watcher jumps several blocks closer.")
                    .define("watcherJump", true);
            watcherOpensDoors = b.comment("The Watcher can open (and close) real wooden doors on its way to the dreamer.")
                    .define("watcherOpensDoors", true);
            otherworld = b.comment("Silent Hill style 'Otherworld': ~40 s into the dream the world rusts over (metal plates, gratings, blood) in a spreading wave and stays that way.")
                    .define("otherworld", true);
            sirenRush = b.comment("In the Otherworld the siren sometimes sounds: for ~4 s the Watcher moves even while you look at it.")
                    .define("sirenRush", true);
            selfChat = b.comment("Creepy chat messages 'from' the dreamer themselves and glitchy action bar text.")
                    .define("selfChat", true);
            timeSpin = b.comment("At the end of the dream day and night spin faster and faster (fake time, only for the dreamer).")
                    .define("timeSpin", true);
            nausea = b.comment("Periodic waves of the vanilla Nausea effect (screen wobble) late in the dream.")
                    .define("nausea", true);
            particles = b.comment("Ash and reverse-portal particles around the dreamer.")
                    .define("particles", true);
        }
    }

    public static class Client {
        public final ModConfigSpec.BooleanValue cameraShake;
        public final ModConfigSpec.BooleanValue flashes;
        public final ModConfigSpec.BooleanValue scareSound;
        public final ModConfigSpec.BooleanValue reducedMotion;
        public final ModConfigSpec.DoubleValue effectScale;
        public final ModConfigSpec.BooleanValue doppelganger;
        public final ModConfigSpec.BooleanValue psychedelic;

        Client(ModConfigSpec.Builder b) {
            cameraShake = b.comment("Camera shake during nightmares.").define("cameraShake", true);
            flashes = b.comment("Sudden dark flashes during nightmares. Disable if sensitive.").define("flashes", true);
            scareSound = b.comment("Loud scare sound during nightmares.").define("scareSound", true);
            reducedMotion = b.comment("Accessibility: no camera shake, no flashes, no pulsing. Overrides the options above.")
                    .define("reducedMotion", false);
            effectScale = b.comment("Accessibility: overall strength of fog/red tint/vignette (0 = off, 1 = full).")
                    .defineInRange("effectScale", 1.0, 0.0, 1.0);
            doppelganger = b.comment("The Watcher wears your own skin (with black eyes). false = classic black figure.")
                    .define("doppelganger", true);
            psychedelic = b.comment("Psychedelic effects: breathing FOV, slow camera tilt, rainbow fog and tint. Off with reducedMotion.")
                    .define("psychedelic", true);
        }
    }

    public static final ModConfigSpec COMMON_SPEC;
    public static final Common COMMON;
    public static final ModConfigSpec CLIENT_SPEC;
    public static final Client CLIENT;

    static {
        Pair<Common, ModConfigSpec> c = new ModConfigSpec.Builder().configure(Common::new);
        COMMON = c.getLeft();
        COMMON_SPEC = c.getRight();
        Pair<Client, ModConfigSpec> cl = new ModConfigSpec.Builder().configure(Client::new);
        CLIENT = cl.getLeft();
        CLIENT_SPEC = cl.getRight();
    }
}
