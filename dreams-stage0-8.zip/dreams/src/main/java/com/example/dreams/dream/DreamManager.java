package com.example.dreams.dream;

import com.example.dreams.DreamConfig;
import com.example.dreams.attachment.DreamState;
import com.example.dreams.attachment.DreamState.Phase;
import com.example.dreams.attachment.ModAttachments;
import com.example.dreams.network.DreamFxPayload;
import com.example.dreams.network.DreamPhasePayload;
import com.example.dreams.entity.ModEntities;
import com.example.dreams.sound.ModSounds;
import com.example.dreams.entity.WatcherEntity;
import it.unimi.dsi.fastutil.longs.LongArrayList;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundBlockUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundSetTimePacket;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

public class DreamManager {

    public enum Result { ABORT, SUCCESS, FAIL, CAUGHT }

    private static final int RADIUS = 18;
    private static final int V_RADIUS = 8;

    // ------------------------------------------------------------------ главный тик

    public static void tick(ServerPlayer player) {
        DreamState s = player.getData(ModAttachments.DREAM_STATE);
        boolean sleeping = player.isSleeping();

        switch (s.phase) {
            case IDLE -> {
                if (sleeping) beginSleep(player, s);
            }
            case NORMAL -> {
                if (!sleeping) s.reset();
            }
            case SLEEP -> {
                if (sleeping) {
                    s.ticks++;
                } else if (s.ticks >= DreamTimeline.FULL_SLEEP_TICKS) {
                    beginFalseAwake(player, s);   // ванильный сон кончился -> "ложное пробуждение"
                } else {
                    end(player, s, Result.ABORT, true);
                }
            }
            case FALSE_AWAKE -> tickFalseAwake(player, s);
        }
    }

    // ------------------------------------------------------------------ фазы

    private static void beginSleep(ServerPlayer player, DreamState s) {
        long now = player.serverLevel().getGameTime();
        long cooldown = DreamConfig.COMMON.cooldownNights.get() * 24000L;
        boolean ready = now - player.getData(ModAttachments.LAST_NIGHTMARE) >= cooldown;
        boolean nightmare = ready && player.getRandom().nextDouble() < DreamConfig.COMMON.nightmareChance.get();
        if (!nightmare) {
            s.phase = Phase.NORMAL;
            return;
        }
        player.setData(ModAttachments.LAST_NIGHTMARE, now);
        s.phase = Phase.SLEEP;
        s.ticks = 0;
        s.bed = player.getSleepingPos().orElse(null);
        PacketDistributor.sendToPlayer(player, new DreamPhasePayload(DreamTimeline.PHASE_SLEEP, 0));
    }

    private static void beginFalseAwake(ServerPlayer player, DreamState s) {
        s.phase = Phase.FALSE_AWAKE;
        s.ticks = DreamTimeline.skip(s.repeats);   // каждый следующий круг стартует "с разгона"
        s.clearSchedule();
        PacketDistributor.sendToPlayer(player, new DreamPhasePayload(DreamTimeline.PHASE_FALSE_AWAKE, s.repeats));
    }

    private static void tickFalseAwake(ServerPlayer player, DreamState s) {
        ServerLevel level = player.serverLevel();
        int t = ++s.ticks;

        // 1) Солнце убегает: подменяем время суток только для этого игрока.
        if (DreamConfig.COMMON.fakeTime.get() && t >= DreamTimeline.SUN_RUSH_START) {
            if (t == DreamTimeline.SUN_RUSH_START) {
                s.timeFrom = level.getDayTime() % 24000L;
            }
            long target = s.timeFrom < 18000L ? 18000L : 42000L;
            float p = Mth.clamp((t - DreamTimeline.SUN_RUSH_START)
                    / (float) (DreamTimeline.SUN_RUSH_END - DreamTimeline.SUN_RUSH_START), 0f, 1f);
            float e = p * p * (3f - 2f * p);
            long fakeDay = (long) Mth.lerp(e, (float) s.timeFrom, (float) target);
            if (DreamConfig.COMMON.timeSpin.get() && !DreamConfig.COMMON.otherworld.get() && t > DreamTimeline.SPIN_START) {
                // под конец сутки раскручиваются: сначала ~1 оборот в 80 с, потом ~1 в 8 с
                int raw = t - DreamTimeline.SPIN_START;
                int u = Math.min(raw, 1800);                       // разгон до 156 тиков времени за тик
                long spin = (long) (12.0 * u + 0.04 * u * u) + Math.max(0, raw - 1800) * 156L;
                fakeDay = target + spin;
            }
            if (s.otherworld) fakeDay = target;   // Иная сторона: вечная ночь
            // tickDayTime=false -> клиент не двигает время сам; шлём каждый тик
            // (ванильная рассылка времени раз в секунду идёт ДО тика игроков, поэтому наш пакет всегда последний).
            player.connection.send(new ClientboundSetTimePacket(level.getGameTime(), fakeDay, false));
        }

        // 2) Дом начинает врать: волны фейковых блоков за спиной.
        if (DreamConfig.COMMON.fakeBlocks.get() && t >= DreamTimeline.WAVES_START && t % 5 == 0) {
            wave(player, level, s);
        }

        // 2a) Этап 8: Иная сторона (волна ржавчины от игрока, потом следует за ним).
        if (DreamConfig.COMMON.otherworld.get()) {
            if (!s.otherworld && t >= DreamTimeline.OTHERWORLD_START) startOtherworld(player, level, s, t);
            if (s.otherworld) sweepOtherworld(player, level, s);
        }

        // 2b) Этап 7: газлайтинг, звуки за спиной, свои сообщения, вспышки, частицы, тошнота.
        tickHorror(player, level, s, t);

        // 3) Кровать-выход светится.
        if (t >= DreamTimeline.BEACON_START && s.bed != null && t % 8 == 0) {
            level.sendParticles(player, ParticleTypes.END_ROD, true,
                    s.bed.getX() + 0.5, s.bed.getY() + 0.9, s.bed.getZ() + 0.5,
                    3, 0.3, 0.2, 0.3, 0.02);
        }

        // 3b) Смотритель.
        if (DreamConfig.COMMON.watcherEnabled.get() && t >= DreamTimeline.WATCHER_START) {
            tickWatcher(player, level, s);
            if (s.phase != Phase.FALSE_AWAKE) return;   // поймала -> сон уже завершён
        }

        // 4) Время вышло -> проигрыш.
        if (t >= DreamConfig.COMMON.falseAwakeSeconds.get() * 20) {
            end(player, s, Result.FAIL, true);
        }
    }

    // ------------------------------------------------------------------ фейковые блоки

    private static void wave(ServerPlayer player, ServerLevel level, DreamState s) {
        int max = DreamConfig.COMMON.maxFakeBlocks.get();
        if (s.fake.size() >= max) return;

        float progress = Mth.clamp((s.ticks - DreamTimeline.WAVES_START) / 1200f + 0.2f * s.repeats, 0f, 1f);
        int samples = (int) Mth.lerp(progress, 150f, 600f);
        int maxReplace = (int) Mth.lerp(progress, 25f, 80f);

        Vec3 look = player.getLookAngle();
        BlockPos base = player.blockPosition();
        RandomSource r = player.getRandom();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        int replaced = 0;

        for (int i = 0; i < samples && replaced < maxReplace && s.fake.size() < max; i++) {
            int dx = r.nextInt(RADIUS * 2 + 1) - RADIUS;
            int dy = r.nextInt(V_RADIUS * 2 + 1) - V_RADIUS;
            int dz = r.nextInt(RADIUS * 2 + 1) - RADIUS;
            if (dx * dx + dy * dy + dz * dz < 9) continue;           // не вплотную
            Vec3 dir = new Vec3(dx, dy, dz).normalize();
            if (dir.dot(look) > -0.15) continue;                      // только то, что у игрока ЗА СПИНОЙ

            pos.set(base.getX() + dx, base.getY() + dy, base.getZ() + dz);
            if (!level.hasChunkAt(pos)) continue;
            long key = pos.asLong();
            if (s.fake.containsKey(key)) continue;

            BlockState fake = DreamBlocks.replacement(level.getBlockState(pos), pos, s.otherworld);
            if (fake == null) continue;

            s.fake.put(key, fake);
            player.connection.send(new ClientboundBlockUpdatePacket(pos.immutable(), fake));
            replaced++;
        }
    }

    /** Чанк заново отправлен игроку (отошёл и вернулся) -> фейки в нём пропали, возвращаем. */
    public static void reapplyChunk(ServerPlayer player, ChunkPos cp) {
        DreamState s = player.getData(ModAttachments.DREAM_STATE);
        if (s.phase != Phase.FALSE_AWAKE) return;
        if (s.otherworld) {
            // чанк отправлен заново -> клиент забыл подмены: пусть свип пройдёт по нему ещё раз
            s.owCount -= removeOwChunk(s, cp, player.getBlockY());
        }
        if (s.fake.isEmpty()) return;
        ServerLevel level = player.serverLevel();

        var it = s.fake.long2ObjectEntrySet().iterator();
        while (it.hasNext()) {
            var entry = it.next();
            BlockPos pos = BlockPos.of(entry.getLongKey());
            if ((pos.getX() >> 4) != cp.x || (pos.getZ() >> 4) != cp.z) continue;
            BlockState fake = DreamBlocks.replacement(level.getBlockState(pos), pos, s.otherworld);
            if (fake == null || !fake.equals(entry.getValue())) {     // блок уже сломали/заменили -> забываем
                it.remove();
                continue;
            }
            player.connection.send(new ClientboundBlockUpdatePacket(pos, fake));
        }
    }

    // ------------------------------------------------------------------ этап 7: жуть

    private static final int SELF_MESSAGES = 8;     // message.dreams.self.0..7
    private static final int GLITCH_MESSAGES = 5;   // message.dreams.glitch.0..4

    private static void tickHorror(ServerPlayer player, ServerLevel level, DreamState s, int t) {
        DreamConfig.Common c = DreamConfig.COMMON;
        RandomSource r = player.getRandom();

        // Газлайтинг: то, на что посмотрели, снова нормальное.
        if (c.gaslight.get() && !s.otherworld && t % 4 == 0 && !s.fake.isEmpty()) {
            rollbackSeen(player, level, s);
        }
        if (t < DreamTimeline.SUN_RUSH_START) return;

        int total = Math.max(1, c.falseAwakeSeconds.get() * 20 - DreamTimeline.SUN_RUSH_START);
        float prog = Mth.clamp((t - DreamTimeline.SUN_RUSH_START) / (float) total, 0f, 1f);
        float k = Mth.clamp(prog + 0.2f * s.repeats, 0f, 1f);   // "накал": растёт со временем и с кругами
        if (s.otherworld) k = Math.max(k, 0.65f);
        tickSiren(player, s, t, r);

        // Звуки за спиной.
        if (c.behindSounds.get() && t >= DreamTimeline.SUN_RUSH_START + 40) {
            if (s.nextSoundAt == 0) {
                s.nextSoundAt = t + 40 + r.nextInt(60);
            } else if (t >= s.nextSoundAt) {
                playBehind(player, r, s.otherworld);
                s.nextSoundAt = t + (int) Mth.lerp(k, 260f, 70f) + r.nextInt(60);
            }
        }

        // Свои сообщения: чат "от себя" и глючный текст над хотбаром.
        if (c.selfChat.get() && t >= DreamTimeline.TEXT_START) {
            if (s.nextTextAt == 0) {
                s.nextTextAt = t + 40 + r.nextInt(80);
            } else if (t >= s.nextTextAt) {
                sendDreamText(player, r, s.otherworld);
                s.nextTextAt = t + (int) Mth.lerp(k, 600f, 220f) + r.nextInt(120);
            }
        }

        // Чёрное "моргание": экран гаснет, а Смотритель оказывается ближе.
        if (c.serverFlashes.get() && t >= DreamTimeline.FLASH_START) {
            if (s.nextFlashAt == 0) {
                s.nextFlashAt = t + 100 + r.nextInt(100);
            } else if (t >= s.nextFlashAt) {
                doFlash(player, level, s);
                s.nextFlashAt = t + (int) Mth.lerp(k, 400f, 140f) + r.nextInt(100);
            }
        }

        // Частицы вокруг: пепел, потом пурпурная муть, в конце души.
        if (c.particles.get() && t % 3 == 0) {
            Vec3 p = player.position();
            int n = (int) Mth.lerp(k, 1f, 6f);
            level.sendParticles(player, ParticleTypes.ASH, true, p.x, p.y + 1.5, p.z, n * 3, 6.0, 3.0, 6.0, 0.0);
            if (k > 0.4f) {
                level.sendParticles(player, ParticleTypes.REVERSE_PORTAL, true, p.x, p.y + 1.0, p.z, n, 4.0, 2.0, 4.0, 0.1);
            }
            if (k > 0.7f) {
                level.sendParticles(player, ParticleTypes.SCULK_SOUL, true, p.x, p.y + 0.5, p.z, n, 5.0, 1.0, 5.0, 0.02);
            }
            if (s.otherworld) {   // багровые споры и дым над ржавым миром
                level.sendParticles(player, ParticleTypes.CRIMSON_SPORE, true, p.x, p.y + 1.5, p.z, n * 4, 7.0, 3.0, 7.0, 0.0);
                if (t % 6 == 0) {
                    level.sendParticles(player, ParticleTypes.LARGE_SMOKE, true, p.x, p.y + 0.3, p.z, 2, 6.0, 0.5, 6.0, 0.01);
                }
            }
        }

        // Тошнота волнами (ванильный эффект: экран "плывёт").
        if (c.nausea.get() && prog > 0.45f && t >= s.nextNauseaAt) {
            player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 20 * 7, 0, false, false, false));
            s.nauseaOn = true;
            s.nextNauseaAt = t + 20 * (20 - (int) (10 * k));
        }
    }

    /** Фейки в конусе взгляда (и не дальше 20 блоков) возвращаются в настоящие блоки. */
    private static void rollbackSeen(ServerPlayer player, ServerLevel level, DreamState s) {
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        var it = s.fake.long2ObjectEntrySet().iterator();
        while (it.hasNext()) {
            var e = it.next();
            BlockPos p = BlockPos.of(e.getLongKey());
            Vec3 d = Vec3.atCenterOf(p).subtract(eye);
            double len2 = d.lengthSqr();
            if (len2 < 1e-6 || len2 > 400.0) continue;
            if (d.normalize().dot(look) > 0.6) {
                player.connection.send(new ClientboundBlockUpdatePacket(p, level.getBlockState(p)));
                it.remove();
            }
        }
    }

    /** Звук из точки позади игрока (слышит только он). */
    private static void playBehind(ServerPlayer player, RandomSource r, boolean ow) {
        Vec3 look = player.getLookAngle();
        Vec3 h = new Vec3(look.x, 0, look.z);
        if (h.lengthSqr() < 1e-4) h = new Vec3(0, 0, 1); else h = h.normalize();
        double dist = 2.5 + r.nextDouble() * 4.0;
        double side = (r.nextDouble() - 0.5) * 3.0;
        Vec3 p = player.position().add(h.scale(-dist)).add(-h.z * side, 0.5, h.x * side);

        Holder<SoundEvent> snd;
        float vol = 1.0f;
        float pitch = 0.8f + r.nextFloat() * 0.3f;
        if (ow) {   // Иная сторона: скрежет, лязг, цепи
            switch (r.nextInt(5)) {
                case 0 -> { snd = ModSounds.CLANG; vol = 1.3f; pitch = 0.5f + r.nextFloat() * 0.2f; }
                case 1 -> { snd = ModSounds.SCRAPE; vol = 1.1f; pitch = 0.5f + r.nextFloat() * 0.2f; }
                case 2 -> { snd = ModSounds.CHAIN; vol = 1.2f; pitch = 0.7f; }
                case 3 -> { snd = ModSounds.BEHIND_STEP; vol = 1.5f; pitch = 0.5f; }
                default -> { snd = ModSounds.BREATH; vol = 1.0f; pitch = 0.55f; }
            }
        } else {
            switch (r.nextInt(5)) {
                case 0 -> { snd = ModSounds.BEHIND_STEP; vol = 1.4f; pitch = 0.6f + r.nextFloat() * 0.2f; }
                case 1 -> snd = ModSounds.DOOR;
                case 2 -> { snd = ModSounds.KNOCK; vol = 1.2f; }
                case 3 -> { snd = ModSounds.BREATH; vol = 0.9f; pitch = 0.7f; }
                default -> { snd = ModSounds.WHISPER; vol = 0.8f; pitch = 0.5f + r.nextFloat() * 0.2f; }
            }
        }
        player.connection.send(new ClientboundSoundPacket(snd, SoundSource.HOSTILE,
                p.x, p.y, p.z, vol, pitch, r.nextLong()));
    }

    private static final int OW_MESSAGES = 6;       // message.dreams.ow.0..5
    private static final int OW_GLITCH = 3;          // message.dreams.glitch.ow.0..2

    private static void sendDreamText(ServerPlayer player, RandomSource r, boolean ow) {
        if (r.nextInt(3) == 0) {
            player.displayClientMessage(Component.empty()
                    .append(Component.translatable(ow ? "message.dreams.glitch.ow." + r.nextInt(OW_GLITCH)
                            : "message.dreams.glitch." + r.nextInt(GLITCH_MESSAGES))
                            .withStyle(ChatFormatting.DARK_RED))
                    .append(Component.literal(" ||||||").withStyle(ChatFormatting.DARK_RED, ChatFormatting.OBFUSCATED)), true);
        } else {
            // сообщение "от самого игрока"
            player.sendSystemMessage(Component.literal("<" + player.getName().getString() + "> ")
                    .append(Component.translatable(ow ? "message.dreams.ow." + r.nextInt(OW_MESSAGES)
                            : "message.dreams.self." + r.nextInt(SELF_MESSAGES))));
        }
    }

    private static void doFlash(ServerPlayer player, ServerLevel level, DreamState s) {
        PacketDistributor.sendToPlayer(player, new DreamFxPayload(DreamTimeline.FX_FLASH, 9));
        player.playNotifySound(ModSounds.BLINK.get(), SoundSource.HOSTILE, 0.6f, 0.5f);
        if (DreamConfig.COMMON.watcherJump.get()) {
            jumpWatcher(player, level, s);
        }
    }

    /**
     * Пока экран чёрный, Смотритель перепрыгивает ближе. Если игрок в помещении, а Смотритель снаружи
     * (за окном/дверью), он появляется ВНУТРИ, в 4.5-9 блоках от игрока. Иначе прыгает по прямой (до 6 блоков, не ближе 4).
     */
    private static void jumpWatcher(ServerPlayer player, ServerLevel level, DreamState s) {
        if (s.watcherId == null) return;
        if (!(level.getEntity(s.watcherId) instanceof WatcherEntity w) || !w.isAlive()) return;

        boolean playerIndoors = !level.canSeeSky(player.blockPosition().above());
        boolean watcherOutdoors = level.canSeeSky(w.blockPosition().above());
        RandomSource r = player.getRandom();
        BlockPos g = null;

        if (playerIndoors && watcherOutdoors) {
            for (int i = 0; i < 24 && g == null; i++) {
                double ang = r.nextDouble() * Math.PI * 2;
                double dist = 4.5 + r.nextDouble() * 4.5;
                int x = Mth.floor(player.getX() + Math.cos(ang) * dist);
                int z = Mth.floor(player.getZ() + Math.sin(ang) * dist);
                BlockPos c = findGround(level, x, z, player.getBlockY());
                if (c != null && !level.canSeeSky(c.above(2))) g = c;   // под крышей
            }
        }
        if (g == null) {
            double dx = player.getX() - w.getX();
            double dz = player.getZ() - w.getZ();
            double dist = Math.sqrt(dx * dx + dz * dz);
            if (dist < 8.0) return;
            double len = Math.min(6.0, dist - 4.0);
            g = findGround(level, Mth.floor(w.getX() + dx / dist * len), Mth.floor(w.getZ() + dz / dist * len), w.getBlockY());
        }
        if (g == null) return;
        w.getNavigation().stop();
        w.moveTo(g.getX() + 0.5, g.getY(), g.getZ() + 0.5, w.getYRot(), w.getXRot());
    }

    @javax.annotation.Nullable
    private static BlockPos findGround(ServerLevel level, int x, int z, int aroundY) {
        for (int y = aroundY + 3; y >= aroundY - 4; y--) {
            BlockPos pos = new BlockPos(x, y, z);
            if (!level.hasChunkAt(pos)) return null;
            if (level.isEmptyBlock(pos) && level.isEmptyBlock(pos.above()) && level.isEmptyBlock(pos.above(2))
                    && level.getBlockState(pos.below()).isFaceSturdy(level, pos.below(), Direction.UP)) {
                return pos;
            }
        }
        return null;
    }

    // ------------------------------------------------------------------ этап 8: Иная сторона

    private static final int OW_RADIUS = 26;
    private static final int OW_BUDGET = 34;        // колонок за тик (волна расходится ~1 блок/тик)
    private static final int OW_MAX_BLOCKS = 600_000;
    private static final int[] OW_DX;
    private static final int[] OW_DZ;
    static {
        List<int[]> l = new ArrayList<>();
        for (int dx = -OW_RADIUS; dx <= OW_RADIUS; dx++) {
            for (int dz = -OW_RADIUS; dz <= OW_RADIUS; dz++) {
                if (dx * dx + dz * dz <= OW_RADIUS * OW_RADIUS) l.add(new int[]{dx, dz});
            }
        }
        l.sort(Comparator.comparingInt(a -> a[0] * a[0] + a[1] * a[1]));   // от игрока наружу
        OW_DX = new int[l.size()];
        OW_DZ = new int[l.size()];
        for (int i = 0; i < l.size(); i++) {
            OW_DX[i] = l.get(i)[0];
            OW_DZ[i] = l.get(i)[1];
        }
    }

    private static void startOtherworld(ServerPlayer player, ServerLevel level, DreamState s, int t) {
        s.otherworld = true;
        s.owDone.clear();
        s.nextSirenAt = t + 360 + player.getRandom().nextInt(200);
        PacketDistributor.sendToPlayer(player, new DreamFxPayload(DreamTimeline.FX_OTHERWORLD, 0));
        PacketDistributor.sendToPlayer(player, new DreamFxPayload(DreamTimeline.FX_FLASH, 14));
        player.playNotifySound(ModSounds.OW_BREAK.get(), SoundSource.HOSTILE, 1.2f, 0.8f);
        player.playNotifySound(ModSounds.SIREN.get(), SoundSource.HOSTILE, 1.0f, 0.65f);
        player.displayClientMessage(Component.translatable("message.dreams.otherworld")
                .withStyle(ChatFormatting.DARK_RED), true);
    }

    /**
     * Волна ржавчины: колонки вокруг игрока по порядку расстояния. Расходится от игрока наружу,
     * а потом, пока он идёт, достраивает новые колонки спереди. Высота колонки: полоса в 48 блоков вокруг игрока.
     */
    private static void sweepOtherworld(ServerPlayer player, ServerLevel level, DreamState s) {
        if (s.owCount >= OW_MAX_BLOCKS) return;
        int px = player.getBlockX();
        int pz = player.getBlockZ();
        int band = Math.floorDiv(player.getBlockY(), 16);
        int minY = Math.max(level.getMinBuildHeight(), band * 16 - 16);
        int maxY = Math.min(level.getMaxBuildHeight() - 1, band * 16 + 31);
        int budget = OW_BUDGET;
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

        for (int i = 0; i < OW_DX.length && budget > 0; i++) {
            int x = px + OW_DX[i];
            int z = pz + OW_DZ[i];
            long key = BlockPos.asLong(x, band, z);
            if (s.owDone.contains(key)) continue;
            pos.set(x, player.getBlockY(), z);
            if (!level.hasChunkAt(pos)) continue;          // ещё не загружено: попробуем позже
            s.owDone.add(key);
            budget--;
            long ck = ChunkPos.asLong(x >> 4, z >> 4);
            LongArrayList list = null;
            for (int y = minY; y <= maxY; y++) {
                pos.set(x, y, z);
                BlockState fake = DreamBlocks.replacement(level.getBlockState(pos), pos, true);
                if (fake == null) continue;
                player.connection.send(new ClientboundBlockUpdatePacket(pos.immutable(), fake));
                if (list == null) {
                    list = s.owPos.get(ck);
                    if (list == null) {
                        list = new LongArrayList();
                        s.owPos.put(ck, list);
                    }
                }
                list.add(pos.asLong());
                s.owCount++;
            }
        }
    }

    /** Чанк отправлен клиенту заново: забываем его подмены и колонки, чтобы свип прошёл по нему снова. */
    private static int removeOwChunk(DreamState s, ChunkPos cp, int playerY) {
        LongArrayList list = s.owPos.remove(ChunkPos.asLong(cp.x, cp.z));
        int band = Math.floorDiv(playerY, 16);
        for (int b = band - 3; b <= band + 3; b++) {
            for (int dx = 0; dx < 16; dx++) {
                for (int dz = 0; dz < 16; dz++) {
                    s.owDone.remove(BlockPos.asLong(cp.getMinBlockX() + dx, b, cp.getMinBlockZ() + dz));
                }
            }
        }
        return list == null ? 0 : list.size();
    }

    /** Сирена: несколько секунд Смотритель идёт, даже когда на него смотрят. */
    private static void tickSiren(ServerPlayer player, DreamState s, int t, RandomSource r) {
        if (!s.otherworld || !DreamConfig.COMMON.sirenRush.get()) return;
        if (t >= s.nextSirenAt) {
            s.sirenUntil = t + 80;
            s.nextSirenAt = t + 700 + r.nextInt(400);
            PacketDistributor.sendToPlayer(player, new DreamFxPayload(DreamTimeline.FX_SIREN, 80));
            player.playNotifySound(ModSounds.SIREN.get(), SoundSource.HOSTILE, 1.0f, 0.9f);
        }
    }

    /** Вернуть игроку настоящие блоки (обычные фейки + Иная сторона; последнее только для чанков, которые у него загружены). */
    private static void restoreWorldBlocks(ServerPlayer player, ServerLevel level, DreamState s) {
        for (long key : s.fake.keySet()) {
            BlockPos pos = BlockPos.of(key);
            player.connection.send(new ClientboundBlockUpdatePacket(pos, level.getBlockState(pos)));
        }
        if (!s.owPos.isEmpty()) {
            int vd = level.getServer().getPlayerList().getViewDistance() + 1;
            ChunkPos pc = player.chunkPosition();
            for (var e : s.owPos.long2ObjectEntrySet()) {
                long ck = e.getLongKey();
                if (Math.abs(ChunkPos.getX(ck) - pc.x) > vd || Math.abs(ChunkPos.getZ(ck) - pc.z) > vd) continue;
                LongArrayList list = e.getValue();
                for (int i = 0; i < list.size(); i++) {
                    BlockPos pos = BlockPos.of(list.getLong(i));
                    player.connection.send(new ClientboundBlockUpdatePacket(pos, level.getBlockState(pos)));
                }
            }
        }
        s.owPos.clear();
        s.owDone.clear();
        s.owCount = 0;
    }

    // ------------------------------------------------------------------ Смотритель

    private static void tickWatcher(ServerPlayer player, ServerLevel level, DreamState s) {
        WatcherEntity w = null;
        if (s.watcherId != null && level.getEntity(s.watcherId) instanceof WatcherEntity found && found.isAlive()) {
            w = found;
        }
        if (w == null) {
            s.watcherId = null;
            if (s.ticks % 20 == 0) trySpawnWatcher(player, level, s);
            return;
        }
        if (w.distanceTo(player) > 40f) {          // потерялась/застряла -> заспавним заново
            w.discard();
            s.watcherId = null;
            return;
        }

        int total = Math.max(1, DreamConfig.COMMON.falseAwakeSeconds.get() * 20 - DreamTimeline.WATCHER_START);
        float progress = Mth.clamp((s.ticks - DreamTimeline.WATCHER_START) / (float) total, 0f, 1f);
        boolean siren = s.ticks < s.sirenUntil;   // сирена: двигается даже под взглядом, быстрее
        double speed = (0.8 + 0.35 * progress) * DreamConfig.COMMON.watcherSpeed.get() * (1.0 + 0.1 * s.repeats)
                * (siren ? 1.5 : 1.0);

        // Всегда лицом к игроку.
        double dx = player.getX() - w.getX();
        double dz = player.getZ() - w.getZ();
        float yaw = (float) (Mth.atan2(dz, dx) * (180.0 / Math.PI)) - 90f;
        w.setYRot(yaw);
        w.setYHeadRot(yaw);
        w.setYBodyRot(yaw);

        if (!siren && isSeen(player, w)) {
            // Пока на неё смотрят - замирает намертво.
            w.getNavigation().stop();
            w.getMoveControl().setWantedPosition(w.getX(), w.getY(), w.getZ(), 0.0);
            w.setDeltaMovement(0.0, w.getDeltaMovement().y, 0.0);
        } else if (s.ticks % 10 == 0 || (siren && s.ticks % 4 == 0) || (w.getNavigation().isDone() && s.ticks % 4 == 0)) {
            w.getNavigation().moveTo(player, speed);
        }

        if (w.distanceTo(player) < 1.7f) {
            end(player, s, Result.CAUGHT, true);
        }
    }

    /** "Смотрит": объект в конусе ~60 градусов от взгляда и между вами нет блоков. */
    private static boolean isSeen(ServerPlayer player, WatcherEntity w) {
        Vec3 eye = player.getEyePosition();
        Vec3 target = w.position().add(0, w.getBbHeight() * 0.6, 0);
        Vec3 dir = target.subtract(eye).normalize();
        if (dir.dot(player.getLookAngle()) < 0.5) return false;
        return player.hasLineOfSight(w);
    }

    private static void trySpawnWatcher(ServerPlayer player, ServerLevel level, DreamState s) {
        Vec3 look = player.getLookAngle();
        Vec3 lookH = new Vec3(look.x, 0, look.z);
        double ll = lookH.length();
        if (ll > 1e-3) lookH = lookH.scale(1.0 / ll);
        RandomSource r = player.getRandom();

        for (int i = 0; i < 24; i++) {
            double ang = r.nextDouble() * Math.PI * 2;
            double dist = 14 + r.nextDouble() * 6;
            double dx = Math.cos(ang) * dist;
            double dz = Math.sin(ang) * dist;
            if (ll > 1e-3 && new Vec3(dx, 0, dz).normalize().dot(lookH) > 0.3) continue; // не на глазах

            int x = Mth.floor(player.getX() + dx);
            int z = Mth.floor(player.getZ() + dz);
            for (int y = player.getBlockY() + 6; y >= player.getBlockY() - 6; y--) {
                BlockPos pos = new BlockPos(x, y, z);
                if (!level.hasChunkAt(pos)) break;
                if (level.isEmptyBlock(pos) && level.isEmptyBlock(pos.above()) && level.isEmptyBlock(pos.above(2))
                        && level.getBlockState(pos.below()).isFaceSturdy(level, pos.below(), Direction.UP)) {
                    WatcherEntity w = ModEntities.WATCHER.get().create(level);
                    if (w == null) return;
                    w.setOwner(player.getUUID());
                    w.moveTo(x + 0.5, y, z + 0.5, 0f, 0f);
                    level.addFreshEntity(w);
                    s.watcherId = w.getUUID();
                    return;
                }
            }
        }
    }

    private static void discardWatcher(ServerPlayer player, DreamState s) {
        if (s.watcherId != null) {
            Entity e = player.serverLevel().getEntity(s.watcherId);
            if (e != null) e.discard();
            s.watcherId = null;
        }
    }

    // ------------------------------------------------------------------ второй круг и команды

    /** "Ложный выход": игрок думает, что проснулся, а сон начинается заново. */
    private static void restartFalseAwake(ServerPlayer player, DreamState s) {
        ServerLevel level = player.serverLevel();
        discardWatcher(player, s);
            restoreWorldBlocks(player, level, s);
        player.connection.send(new ClientboundSetTimePacket(level.getGameTime(), level.getDayTime(),
                level.getGameRules().getBoolean(GameRules.RULE_DAYLIGHT)));
        if (s.nauseaOn) {
            player.removeEffect(MobEffects.CONFUSION);
        }
        s.fake.clear();
        s.repeats++;
        s.ticks = DreamTimeline.skip(s.repeats);
        s.timeFrom = 0L;
        s.clearSchedule();
        player.playNotifySound(ModSounds.WAKE.get(), SoundSource.PLAYERS, 1.0f, 1.0f);
        player.displayClientMessage(Component.translatable("message.dreams.woke_up"), true);
        PacketDistributor.sendToPlayer(player, new DreamPhasePayload(DreamTimeline.PHASE_FALSE_AWAKE, s.repeats));
    }

    /** Для команды /dreams nightmare: сразу в ложное пробуждение. */
    public static boolean forceStart(ServerPlayer player) {
        return forceStart(player, 0);
    }

    /** /dreams otherworld: старт сразу перед переходом в Иную сторону. */
    public static boolean forceStartAt(ServerPlayer player, int tick) {
        if (!forceStart(player, 0)) return false;
        player.getData(ModAttachments.DREAM_STATE).ticks = tick;
        return true;
    }

    /** /dreams loop N: сразу N-й круг (0 = обычный первый). */
    public static boolean forceStart(ServerPlayer player, int round) {
        DreamState s = player.getData(ModAttachments.DREAM_STATE);
        if (s.phase != Phase.IDLE || player.isSleeping()) return false;
        s.reset();
        s.repeats = Math.max(0, round);
        s.bed = findBed(player);
        beginFalseAwake(player, s);
        return true;
    }

    @javax.annotation.Nullable
    private static BlockPos findBed(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        BlockPos respawn = player.getRespawnPosition();
        if (respawn != null && player.getRespawnDimension() == level.dimension()
                && level.getBlockState(respawn).getBlock() instanceof BedBlock) {
            return respawn;
        }
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        BlockPos c = player.blockPosition();
        for (BlockPos p : BlockPos.betweenClosed(c.offset(-12, -6, -12), c.offset(12, 6, 12))) {
            if (level.getBlockState(p).getBlock() instanceof BedBlock) {
                double d = p.distSqr(c);
                if (d < bestDist) { bestDist = d; best = p.immutable(); }
            }
        }
        return best;
    }

    // ------------------------------------------------------------------ выход

    public static void tryEscape(ServerPlayer player, DreamState s, BlockPos clicked) {
        if (s.phase != Phase.FALSE_AWAKE) return;
        if (s.ticks < DreamTimeline.BEACON_START || s.bed == null) return;
        if (!clicked.closerThan(s.bed, 2.5)) return;
        double chance = Math.min(0.95, DreamConfig.COMMON.repeatChance.get() + 0.2 * s.repeats);
        if (s.repeats < DreamConfig.COMMON.maxRepeats.get() && player.getRandom().nextDouble() < chance) {
            restartFalseAwake(player, s);   // ложный выход: сон начинается заново, каждый круг быстрее и злее
            return;
        }
        end(player, s, Result.SUCCESS, true);
    }

    /**
     * Завершить сон.
     * @param restoreWorld вернуть игроку настоящие блоки и время (false при смене измерения).
     */
    public static void end(ServerPlayer player, DreamState s, Result result, boolean restoreWorld) {
        boolean wasDreaming = s.phase == Phase.SLEEP || s.phase == Phase.FALSE_AWAKE;
        discardWatcher(player, s);
        if (wasDreaming) {
            PacketDistributor.sendToPlayer(player, new DreamPhasePayload(DreamTimeline.PHASE_NONE, 0));
        }
        if (s.nauseaOn) {
            player.removeEffect(MobEffects.CONFUSION);
        }

        if (restoreWorld && s.phase == Phase.FALSE_AWAKE) {
            ServerLevel level = player.serverLevel();
            restoreWorldBlocks(player, level, s);
            player.connection.send(new ClientboundSetTimePacket(level.getGameTime(), level.getDayTime(),
                    level.getGameRules().getBoolean(GameRules.RULE_DAYLIGHT)));
        }

        if (result == Result.CAUGHT) {
            player.playNotifySound(SoundEvents.ENDERMAN_SCREAM, SoundSource.HOSTILE, 1.5f, 0.6f);
            player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 20 * 6, 0));
        }

        switch (result) {
            case SUCCESS -> {
                player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 20 * 10, 1));
                player.playNotifySound(ModSounds.WAKE.get(), SoundSource.PLAYERS, 1.0f, 1.0f);
                player.displayClientMessage(Component.translatable("message.dreams.woke_up"), true);
            }
            case FAIL, CAUGHT -> {
                if (DreamConfig.COMMON.applyDebuffs.get()) {
                    player.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 20 * 30, 0));
                    player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 20 * 15, 0));
                    player.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 20 * 8, 0));
                }
                player.displayClientMessage(Component.translatable(result == Result.CAUGHT ? "message.dreams.caught" : "message.dreams.exhausted"), true);
            }
            case ABORT -> { }
        }

        s.reset();
    }
}
