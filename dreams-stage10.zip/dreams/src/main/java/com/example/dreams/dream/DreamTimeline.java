package com.example.dreams.dream;

/** Тайминги сна в тиках. Используются и сервером, и клиентом. */
public class DreamTimeline {
    /** Сколько тиков в кровати считается "досмотрел" (ванильный сон = 100). */
    public static final int FULL_SLEEP_TICKS = 80;

    // Всё ниже считается от начала фазы FALSE_AWAKE.
    public static final int CALM_END = 200;          // 10 с: обычное утро, ничего странного
    public static final int SUN_RUSH_START = 200;    // солнце начинает "убегать"
    public static final int SUN_RUSH_END = 400;      // стало ночью
    public static final int WAVES_START = 300;       // дом начинает меняться (за спиной)
    public static final int BEACON_START = 400;      // кровать-выход начинает светиться, на неё можно нажать
    public static final int WATCHER_START = 450;     // появляется Смотритель
    public static final int TEXT_START = 480;        // "свои" сообщения в чате / на экране
    public static final int SCARE_TICK = 520;        // громкий звук
    public static final int SILENCE_LEAD = 50;       // за столько тиков до него клиент глушит сердцебиение
    public static final int FLASH_START = 600;       // начинаются чёрные "моргания" (+ прыжок Смотрителя)
    public static final int SPIN_START = 900;        // время суток начинает раскручиваться (если Иная сторона выключена)
    public static final int RITUAL_EXTRA = 3600;     // +3 мин ко сну, если в Иной стороне есть печати
    public static final int OTHERWORLD_START = 440;  // мир ржавеет: "Иная сторона" (только в сне вида OTHERWORLD)

    // Фазы для пакета
    public static final int PHASE_NONE = 0;
    public static final int PHASE_SLEEP = 1;
    public static final int PHASE_FALSE_AWAKE = 2;

    // Виды сна (передаются клиенту в DreamPhasePayload)
    public static final int KIND_NIGHTMARE = 0;      // кошмар: ложные выходы, Смотритель-двойник, газлайтинг
    public static final int KIND_OTHERWORLD = 1;     // Иная сторона: ржавый мир, ритуал печатей, Палач
    public static final int KIND_GOOD = 2;           // добрый сон: воспоминания, плитки, невесомость, Древо снов

    // Добрый сон (тики от начала сна)
    public static final int GOOD_LIGHTS_TOTAL = 5;   // огней всего: 4 воспоминания + 1 мелодия плиток
    public static final int GOOD_TREE_MIN = 3;       // сколько огней нужно, чтобы Древо проснулось
    public static final int GOOD_MEMORIES_AT = 60;   // появляются воспоминания
    public static final int GOOD_WIND_AT = 140;      // ленты ветра и парящий остров
    public static final int GOOD_TILES_AT = 220;     // звенящая поляна
    public static final int GOOD_TREE_AT = 320;      // Древо снов
    public static final int GOOD_FINALE_TICKS = 260; // длина финала у Древа

    // Типы эффектов для DreamFxPayload
    public static final int FX_FLASH = 1;
    public static final int FX_OTHERWORLD = 2;       // начался переход в Иную сторону
    public static final int FX_SIREN = 3;            // сирена: arg = длительность в тиках
    public static final int FX_GOOD_LIGHTS = 4;      // добрый сон: arg = сколько огней собрано
    public static final int FX_GOOD_FINALE = 5;      // добрый сон: Древо проснулось, финал

    /** С какого тика начинается круг сна: кошмар стартует с разгона, остальные виды с нуля. */
    public static int startTick(int kind, int round) {
        return kind == KIND_NIGHTMARE ? skip(round) : 0;
    }

    /**
     * С каждым ложным выходом сон "ускоряется": следующий круг начинается не с нуля,
     * а уже с этого тика (спокойное утро короче, жуть начинается раньше). Максимум 180 < SUN_RUSH_START.
     */
    public static int skip(int round) {
        return Math.min(Math.max(round, 0), 3) * 60;
    }
}
