package com.example.dreams.block;

import com.example.dreams.Dreams;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Блоки кошмара. Предметов нет: в мир они попадают только как фейк, видимый одному игроку.
 * Прочность подобрана под оригиналы, чтобы ломание не рассинхронизировалось.
 * lightLevel работает только на клиенте сновидца (фейк-блок): лёгкое красное свечение.
 */
public class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(Dreams.MODID);

    public static final DeferredBlock<Block> VEINED_STONE = BLOCKS.registerSimpleBlock("veined_stone",
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_RED).strength(1.5f, 6.0f).sound(SoundType.STONE));

    public static final DeferredBlock<Block> ROTTEN_PLANKS = BLOCKS.registerSimpleBlock("rotten_planks",
            BlockBehaviour.Properties.of().mapColor(MapColor.WOOD).strength(2.0f, 3.0f).sound(SoundType.WOOD));

    public static final DeferredBlock<Block> ASHEN_DIRT = BLOCKS.registerSimpleBlock("ashen_dirt",
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_GRAY).strength(0.5f).sound(SoundType.GRAVEL));

    /** Стена с глазами (вместо камня): анимированная текстура, глаза моргают и бегают. */
    public static final DeferredBlock<Block> EYE_STONE = BLOCKS.registerSimpleBlock("eye_stone",
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_RED).strength(1.5f, 6.0f).sound(SoundType.STONE)
                    .lightLevel(state -> 4));

    // ---- этап 8: Иная сторона. Металл: шаги по ним на клиенте звучат как по ржавому железу. ----

    /** Ржавая пластина (вместо камня, досок, брёвен). */
    public static final DeferredBlock<Block> RUST_PLATE = BLOCKS.registerSimpleBlock("rust_plate",
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_ORANGE).strength(1.5f, 6.0f).sound(SoundType.METAL)
                    .lightLevel(state -> 2));

    /** Ржавая пластина в крови. */
    public static final DeferredBlock<Block> RUST_BLOODY = BLOCKS.registerSimpleBlock("rust_bloody",
            BlockBehaviour.Properties.of().mapColor(MapColor.CRIMSON_NYLIUM).strength(1.5f, 6.0f).sound(SoundType.METAL)
                    .lightLevel(state -> 3));

    /** Решётка над багровой бездной (вместо земли, песка, гравия). Анимированная, светится. */
    public static final DeferredBlock<Block> RUST_GRATE = BLOCKS.registerSimpleBlock("rust_grate",
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BROWN).strength(0.5f).sound(SoundType.CHAIN)
                    .lightLevel(state -> 5));

    // ---- этап 9: печати ритуала. Фейк в воздухе, без коллизии: проходишь насквозь, но ПКМ по ним работает. ----

    /** Непогашенная печать: красный светящийся столб с рунами. */
    public static final DeferredBlock<Block> SEAL = BLOCKS.registerSimpleBlock("seal",
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_RED).noCollission().noOcclusion()
                    .strength(-1.0f, 3600000.0f).lightLevel(state -> 12));

    /** Погашенная печать: холодный, тусклый столб. */
    public static final DeferredBlock<Block> SEAL_DONE = BLOCKS.registerSimpleBlock("seal_done",
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_LIGHT_BLUE).noCollission().noOcclusion()
                    .strength(-1.0f, 3600000.0f).lightLevel(state -> 3));

    /** Пульсирующая плоть (вместо земли). */
    public static final DeferredBlock<Block> FLESH = BLOCKS.registerSimpleBlock("flesh",
            BlockBehaviour.Properties.of().mapColor(MapColor.CRIMSON_NYLIUM).strength(0.5f).sound(SoundType.SLIME_BLOCK)
                    .lightLevel(state -> 2));
}
