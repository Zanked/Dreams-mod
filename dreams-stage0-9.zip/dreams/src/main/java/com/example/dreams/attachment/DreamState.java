package com.example.dreams.attachment;

import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongArrayList;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;
import java.util.UUID;

/** Изменяемое состояние сна игрока. Живёт только на сервере, не сохраняется. */
public class DreamState {

    public enum Phase {
        IDLE,        // не спит
        NORMAL,      // спит, кошмар не выпал
        SLEEP,       // кошмар: лежит в кровати
        FALSE_AWAKE  // "ложное пробуждение": уже встал, но сон продолжается
    }

    public Phase phase = Phase.IDLE;
    public int ticks = 0;
    @Nullable public BlockPos bed = null;
    public long timeFrom = 0L;
    public int repeats = 0;   // сколько раз уже был ложный выход
    @Nullable public UUID watcherId = null;
    // расписание эффектов (тик внутри сна; 0 = ещё не назначено)
    public int nextSoundAt = 0;
    public int nextTextAt = 0;
    public int nextFlashAt = 0;
    public int nextNauseaAt = 0;
    public boolean nauseaOn = false;
    // этап 8: Иная сторона
    public boolean otherworld = false;
    public int nextSirenAt = 0;
    public int sirenUntil = 0;
    /** Уже обработанные "колонки" (x, полоса высоты 16, z). */
    public final LongOpenHashSet owDone = new LongOpenHashSet();
    /** chunk.asLong() -> позиции, подменённые в Иной стороне (нужны, чтобы вернуть мир после сна). */
    public final Long2ObjectOpenHashMap<LongArrayList> owPos = new Long2ObjectOpenHashMap<>();
    public int owCount = 0;
    // этап 9: ритуал, Палач, фигуры
    /** Позиции оснований печатей (столб = основание + блок выше). */
    public final LongArrayList seals = new LongArrayList();
    public int sealMask = 0;                    // бит i = печать i погашена
    @Nullable public UUID executionerId = null;
    public boolean execArmed = false;           // пора выпускать Палача
    public int sirenCount = 0;
    public double execLastX = 0;
    public double execLastZ = 0;
    public int execStuck = 0;
    public final java.util.List<UUID> figures = new java.util.ArrayList<>();
    /** pos.asLong() -> фейковый блок, отправленный игроку. */
    public final Long2ObjectOpenHashMap<BlockState> fake = new Long2ObjectOpenHashMap<>();

    public void reset() {
        phase = Phase.IDLE;
        ticks = 0;
        bed = null;
        timeFrom = 0L;
        watcherId = null;
        repeats = 0;
        clearSchedule();
        fake.clear();
    }

    /** Сбросить расписание эффектов (новый круг сна). */
    public void clearSchedule() {
        nextSoundAt = 0;
        nextTextAt = 0;
        nextFlashAt = 0;
        nextNauseaAt = 0;
        nauseaOn = false;
        otherworld = false;
        nextSirenAt = 0;
        sirenUntil = 0;
        owDone.clear();
        owPos.clear();
        owCount = 0;
        seals.clear();
        sealMask = 0;
        executionerId = null;
        execArmed = false;
        sirenCount = 0;
        execStuck = 0;
        figures.clear();
    }
}
