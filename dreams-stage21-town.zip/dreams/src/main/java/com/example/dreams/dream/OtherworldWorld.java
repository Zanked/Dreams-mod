package com.example.dreams.dream;

import com.example.dreams.attachment.DreamState;
import com.example.dreams.dream.world.OtherworldGen;
import com.example.dreams.dream.world.OtherworldGenerator;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;

/**
 * Измерение Иной стороны (\"dreams:otherworld\"): городок на краю пропасти. Для каждого сна своя область 512x512
 * (городок, повёрнутый на случайную четверть). Вход: DreamManager.startOtherworldDim, выход: DreamWorld.leave
 * (точка возврата общая с добрым сном), падение в пропасть: rescue.
 */
public final class OtherworldWorld {
    private OtherworldWorld() {}

    /** Ниже этой высоты игрок упал в пропасть: возвращаем на площадь. */
    public static final int RESCUE_Y = 9;

    public static boolean isOtherworld(Level level) {
        return level.dimension().equals(DreamWorld.OW_KEY);
    }

    @Nullable
    public static ServerLevel level(ServerPlayer player) {
        return player.server.getLevel(DreamWorld.OW_KEY);
    }

    /** Переносит игрока в городок. Возвращает метки (старт, кровать, места печатей) или null, если измерения нет. */
    @Nullable
    static OtherworldGen.Marks enter(ServerPlayer player, DreamState s) {
        ServerLevel ow = player.server.getLevel(DreamWorld.OW_KEY);
        if (ow == null || !(ow.getChunkSource().getGenerator() instanceof OtherworldGenerator gen)) return null;
        long seed = gen.seed();
        int rx = player.getRandom().nextInt(4000) - 2000, rz = player.getRandom().nextInt(4000) - 2000;
        OtherworldGen.Marks m = OtherworldGen.marks(seed, rx, rz);
        if (m.start == null || m.bed == null) return null;

        // чанки вокруг старта и вокруг кровати генерируем сразу, чтобы не падать сквозь пустоту
        for (BlockPos c : new BlockPos[]{m.start, m.bed}) {
            for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) ow.getChunk((c.getX() >> 4) + dx, (c.getZ() >> 4) + dz);
        }
        DreamWorld.saveReturn(player);
        s.dreamHome = m.start.immutable();
        s.bed = m.bed.immutable();
        s.transferring = true;
        try {
            player.teleportTo(ow, m.start.getX() + 0.5, m.start.getY(), m.start.getZ() + 0.5, OtherworldGen.startYaw(m.rot), 8.0f);
        } finally {
            s.transferring = false;
        }
        player.fallDistance = 0.0f;
        return m;
    }

    /** Отладка: переносит игрока в городок области (0, 0) без сна. Назад: DreamWorld.leaveStray. */
    public static boolean visit(ServerPlayer player) {
        ServerLevel ow = player.server.getLevel(DreamWorld.OW_KEY);
        if (ow == null || !(ow.getChunkSource().getGenerator() instanceof OtherworldGenerator gen)) return false;
        OtherworldGen.Marks m = OtherworldGen.marks(gen.seed(), 0, 0);
        if (m.start == null) return false;
        for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) ow.getChunk((m.start.getX() >> 4) + dx, (m.start.getZ() >> 4) + dz);
        if (!isOtherworld(player.level())) DreamWorld.saveReturn(player);
        player.teleportTo(ow, m.start.getX() + 0.5, m.start.getY(), m.start.getZ() + 0.5, OtherworldGen.startYaw(m.rot), 8.0f);
        player.fallDistance = 0.0f;
        return true;
    }

    /** Упал в пропасть: вернуть на площадь (во сне не умирают). */
    static void rescue(ServerPlayer player, DreamState s) {
        BlockPos h = s.dreamHome;
        if (h == null) return;
        player.teleportTo(player.serverLevel(), h.getX() + 0.5, h.getY(), h.getZ() + 0.5, player.getYRot(), 0.0f);
        player.fallDistance = 0.0f;
        player.setDeltaMovement(0, 0, 0);
    }
}
