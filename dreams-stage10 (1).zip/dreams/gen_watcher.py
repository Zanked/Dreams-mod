"""Плейсхолдер текстуры Смотрителя: 64x64 (раскладка ванильного гуманоида). Перерисуй своей."""
import zlib, struct, random, sys, os
OUT = sys.argv[1] if len(sys.argv) > 1 else "watcher.png"
random.seed(5)
W = 64
rows = []
for y in range(W):
    row = []
    for x in range(W):
        if x >= 32 and y < 16:           # слой шляпы: прозрачный, иначе закроет глаза
            row.append((0, 0, 0, 0)); continue
        n = random.randint(-4, 4)
        row.append((14 + n, 14 + n, 18 + n, 255))
    rows.append(row)
for (ex, ey) in [(9, 11), (10, 11), (9, 12), (10, 12), (13, 11), (14, 11), (13, 12), (14, 12)]:
    rows[ey][ex] = (240, 240, 255, 255)   # лицо: x 8..15, y 8..15
raw = b"".join(b"\x00" + bytes(c for px in r for c in px) for r in rows)
def chunk(t, d):
    c = struct.pack(">I", len(d)) + t + d
    return c + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
png = (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", W, W, 8, 6, 0, 0, 0))
       + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b""))
open(OUT, "wb").write(png)
