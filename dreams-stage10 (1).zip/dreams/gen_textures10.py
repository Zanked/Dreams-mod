"""Этап 10: текстуры доброго сна, 32x32. Нужны Pillow, numpy, scipy.
Запуск: python3 gen_textures10.py src/main/resources/assets/dreams/textures [--preview файл.png]

Блоки:  cloud_stone, dream_moss, honey_planks, dream_leaves, tree_log, tree_blossom
Анимация (кадры стопкой по вертикали + .mcmeta): chime_tile (4 кадра), chime_tile_lit (4), memory (8), memory_done (4)
Цветы (прозрачность, модель cross): bloom_gold, bloom_blue, bloom_pink
Все полнокубные текстуры бесшовные (шум считается с заворотом краёв)."""
import os, sys, json, math
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy.ndimage import zoom

S = 32
args = [a for a in sys.argv[1:] if not a.startswith("--")]
OUT = os.path.join(args[0] if args else ".", "block")
PREVIEW = sys.argv[sys.argv.index("--preview") + 1] if "--preview" in sys.argv else None
os.makedirs(OUT, exist_ok=True)

# ------------------------------------------------------------ инструменты
def tnoise(gy, gx, seed):
    """Бесшовный шум 0..1: случайная сетка gy x gx, бикубически растянутая до S x S с заворотом краёв."""
    r = np.random.default_rng(seed)
    g = r.random((gy, gx))
    z = zoom(g, (S / gy, S / gx), order=3, mode="grid-wrap", grid_mode=True)
    z = z[:S, :S]
    return (z - z.min()) / max(1e-6, z.max() - z.min())

def fbm(seed, octs=((4, 4, 1.0), (8, 8, 0.5), (16, 16, 0.25), (32, 32, 0.12))):
    acc = np.zeros((S, S)); tot = 0
    for i, (gy, gx, w) in enumerate(octs):
        acc += tnoise(gy, gx, seed * 31 + i) * w; tot += w
    a = acc / tot
    return (a - a.min()) / max(1e-6, a.max() - a.min())

def smoothstep(a, b, x):
    t = np.clip((x - a) / (b - a), 0, 1)
    return t * t * (3 - 2 * t)

def ramp(v, stops):
    """v (S,S) 0..1 -> цвет (S,S,3) по ступеням [(t,(r,g,b)),...]."""
    ts = [s[0] for s in stops]
    out = np.zeros(v.shape + (3,))
    for c in range(3):
        out[..., c] = np.interp(v, ts, [s[1][c] for s in stops])
    return out

def mixc(a, b, t):
    t = np.asarray(t)[..., None] if np.ndim(t) == 2 else t
    return a * (1 - t) + b * t

def to_img(arr):
    return Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8), "RGB")

def sparkles(arr, n, color, seed, glow=0.45):
    r = np.random.default_rng(seed)
    for _ in range(n):
        x, y = r.integers(0, S), r.integers(0, S)
        arr[y, x] = color
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            arr[(y + dy) % S, (x + dx) % S] = mixc(arr[(y + dy) % S, (x + dx) % S], np.array(color, float), glow)
    return arr

def voronoi(npts, seed):
    r = np.random.default_rng(seed)
    pts = r.random((npts, 2)) * S
    yy, xx = np.mgrid[0:S, 0:S] + 0.5
    d = np.zeros((S, S, npts))
    for i, (px, py) in enumerate(pts):
        dx = np.abs(xx - px); dx = np.minimum(dx, S - dx)
        dy = np.abs(yy - py); dy = np.minimum(dy, S - dy)
        d[:, :, i] = np.sqrt(dx * dx + dy * dy)
    idx = np.argsort(d, axis=2)
    d1 = np.take_along_axis(d, idx[:, :, :1], 2)[:, :, 0]
    d2 = np.take_along_axis(d, idx[:, :, 1:2], 2)[:, :, 0]
    return idx[:, :, 0], d1, d2

def save(name, arr_or_img, frames=None, frametime=None, interpolate=False):
    img = arr_or_img if isinstance(arr_or_img, Image.Image) else to_img(arr_or_img)
    img.save(os.path.join(OUT, name + ".png"))
    if frametime:
        json.dump({"animation": {"frametime": frametime, "interpolate": interpolate}},
                  open(os.path.join(OUT, name + ".png.mcmeta"), "w"))
    return img

SHEET = {}   # для превью: имя -> Image

# ------------------------------------------------------------ cloud_stone: жемчужный мрамор с золотыми прожилками
def cloud_stone():
    n = fbm(1)
    pearl = ramp(n, [(0, (192, 186, 222)), (0.45, (226, 224, 242)), (1, (252, 250, 254))])
    tint = fbm(2, ((4, 4, 1.0), (8, 8, 0.4)))
    pearl = mixc(pearl, np.array([246, 224, 236.0]), smoothstep(0.55, 0.95, tint) * 0.5)    # розовый отлив
    pearl = mixc(pearl, np.array([210, 232, 250.0]), smoothstep(0.45, 0.05, tint) * 0.5)    # голубой отлив
    # прожилки: тонкая линия вдоль изолинии искажённого шума
    warp = tnoise(8, 8, 41) * 6
    v = fbm(3, ((4, 4, 1.0), (8, 8, 0.35)))
    yy, xx = np.mgrid[0:S, 0:S]
    v2 = np.roll(np.roll(v, 2, 0), 1, 1) * 0.5 + v * 0.5
    vein = smoothstep(0.075, 0.0, np.abs(v2 - 0.5))
    pearl = mixc(pearl, np.array([234, 196, 120.0]), vein * 0.85)
    core = smoothstep(0.03, 0.0, np.abs(v2 - 0.5))
    pearl = mixc(pearl, np.array([255, 238, 190.0]), core * 0.8)
    pearl += (np.random.default_rng(5).random((S, S, 1)) - 0.5) * 8
    pearl = sparkles(pearl, 9, (255, 255, 255), 6, 0.4)
    return save("cloud_stone", pearl)

# ------------------------------------------------------------ dream_moss: мягкий светящийся мох
def dream_moss():
    n = fbm(11, ((8, 8, 1.0), (16, 16, 0.7), (32, 32, 0.5)))
    base = ramp(n, [(0, (34, 100, 84)), (0.35, (66, 150, 108)), (0.7, (126, 200, 130)), (1, (196, 236, 156))])
    fine = tnoise(32, 32, 12)
    base = mixc(base, np.array([248, 236, 150.0]), smoothstep(0.86, 1.0, fine) * 0.85)      # золотые кончики
    base = mixc(base, np.array([22, 74, 66.0]), smoothstep(0.18, 0.0, n) * 0.7)            # тёмные ямки
    base = mixc(base, np.array([96, 188, 172.0]), smoothstep(0.55, 0.9, tnoise(4, 4, 13)) * 0.18)  # бирюзовые пятна
    base = sparkles(base, 16, (190, 255, 228), 14, 0.35)                                    # светящиеся споры
    return save("dream_moss", base)

# ------------------------------------------------------------ honey_planks: медовые доски с живой текстурой
def honey_planks():
    out = np.zeros((S, S, 3))
    r = np.random.default_rng(21)
    for p in range(4):
        y0 = p * 8
        grain = tnoise(32, 4, 100 + p)                # вытянуто вдоль доски
        fine = tnoise(32, 8, 130 + p)
        n = np.clip(grain * 0.65 + fine * 0.35, 0, 1)
        shade = 0.92 + 0.16 * (p % 2) + r.uniform(-0.04, 0.04)
        col = ramp(n, [(0, (170, 100, 36)), (0.5, (226, 158, 58)), (1, (255, 210, 110))]) * shade
        # волокна: тонкие тёмные линии
        lines = smoothstep(0.06, 0.0, np.abs(tnoise(32, 6, 160 + p) - 0.5))
        col = mixc(col, np.array([140, 78, 26.0]), lines * 0.45)
        out[y0:y0 + 8] = col[y0:y0 + 8]
        # шов между досками и блик под ним
        out[y0] = out[y0] * 0.55
        out[(y0 + 1) % S] = mixc(out[(y0 + 1) % S], np.array([255, 232, 160.0]), 0.28)
        # торцевой стык
        jx = r.integers(4, 28)
        out[y0 + 1:y0 + 8, jx] *= 0.6
        # маленький сучок
        if p in (1, 3):
            cx, cy = r.integers(6, 26), y0 + 4
            for yy in range(y0 + 1, y0 + 8):
                for xx in range(S):
                    dx = min(abs(xx - cx), S - abs(xx - cx)); dy = (yy - cy) * 1.6
                    d = math.hypot(dx, dy)
                    if d < 3.2:
                        out[yy, xx] = mixc(out[yy, xx], np.array([120, 66, 22.0]), 0.65 * (1 - abs(d - 2.0) / 2.0 if d > 1 else 0.75))
    out += (np.random.default_rng(22).random((S, S, 1)) - 0.5) * 8
    out = sparkles(out, 5, (255, 240, 190), 23, 0.3)
    return save("honey_planks", out)

# ------------------------------------------------------------ лепестковая листва и крона Древа (клетки-лепестки)
def petals(name, palette, edge, spark, seed, npts=34, glow=0.0, sparks=8):
    idx, d1, d2 = voronoi(npts, seed)
    pal = np.array(palette, float)
    col = pal[idx % len(pal)]
    center = np.clip(1.10 - d1 / 9.0, 0.78, 1.12)[..., None]
    col = col * center
    e = np.clip((d2 - d1) / 1.8, 0, 1)
    col = mixc(col, np.array(edge, float), (1 - e) * 0.5)
    n = tnoise(16, 16, seed + 3)
    col = col * (0.94 + 0.12 * n[..., None])
    if glow:
        col = mixc(col, np.array([255, 250, 230.0]), np.clip(1.0 - d1 / 3.0, 0, 1) * glow)
    col = sparkles(col, sparks, spark, seed + 4, 0.35)
    return save(name, col)

# ------------------------------------------------------------ tree_log: ствол Древа снов
def tree_log():
    g = tnoise(4, 32, 51)                              # вертикальные борозды
    g2 = tnoise(8, 32, 52)
    n = np.clip(g * 0.6 + g2 * 0.4, 0, 1)
    base = ramp(n, [(0, (170, 146, 122)), (0.5, (226, 210, 180)), (1, (248, 238, 214))])
    pink = smoothstep(0.55, 0.95, tnoise(6, 6, 53))
    base = mixc(base, np.array([240, 200, 196.0]), pink * 0.35)
    # светящиеся золотые трещины
    crack = smoothstep(0.085, 0.0, np.abs(tnoise(8, 32, 54) * 0.7 + tnoise(2, 16, 55) * 0.3 - 0.5))
    base = mixc(base, np.array([255, 214, 118.0]), crack * 0.9)
    base = mixc(base, np.array([255, 244, 200.0]), smoothstep(0.02, 0.0, np.abs(tnoise(8, 32, 54) * 0.7 + tnoise(2, 16, 55) * 0.3 - 0.5)) * 0.9)
    deep = smoothstep(0.30, 0.0, g)
    base = mixc(base, np.array([112, 90, 78.0]), deep * 0.7)
    base = sparkles(base, 6, (255, 244, 210), 56, 0.3)
    return save("tree_log", base)

# ------------------------------------------------------------ звенящие плитки (анимация)
def tile_frame(f, nframes, lit):
    yy, xx = np.mgrid[0:S, 0:S] + 0.5
    cx = cy = S / 2
    d = np.hypot(xx - cx, yy - cy)
    n = tnoise(16, 16, 61 if not lit else 62)
    if lit:
        base = ramp(n, [(0, (255, 226, 160)), (0.5, (255, 240, 196)), (1, (255, 252, 232))])
        ring_c, core_c, line_c = np.array([255, 196, 84.0]), np.array([255, 255, 240.0]), np.array([255, 222, 130.0])
        edge_c, hi_c = np.array([214, 160, 82.0]), np.array([255, 246, 208.0])
    else:
        base = ramp(n, [(0, (156, 178, 214)), (0.5, (178, 198, 228)), (1, (204, 220, 242))])
        ring_c, core_c, line_c = np.array([226, 212, 168.0]), np.array([246, 238, 208.0]), np.array([206, 200, 190.0])
        edge_c, hi_c = np.array([112, 132, 178.0]), np.array([228, 238, 252.0])
    pulse = 0.5 + 0.5 * math.sin(2 * math.pi * f / nframes)
    # скос по краям плитки
    ed = np.minimum(np.minimum(xx, S - xx), np.minimum(yy, S - yy))
    base = mixc(base, edge_c, smoothstep(2.2, 0.8, ed) * 0.85)
    base = mixc(base, hi_c, smoothstep(3.4, 2.4, ed) * smoothstep(1.4, 2.4, ed) * 0.6)
    # кольцо и руна
    ring = smoothstep(1.6, 0.2, np.abs(d - 10.0))
    base = mixc(base, ring_c, ring * (0.8 + 0.2 * pulse))
    ring2 = smoothstep(1.0, 0.1, np.abs(d - 13.2))
    base = mixc(base, line_c, ring2 * 0.5)
    ang = np.arctan2(yy - cy, xx - cx)
    for k in range(8):                                   # засечки по кольцу
        a = k * math.pi / 4 + math.pi / 8
        da = np.abs(((ang - a + math.pi) % (2 * math.pi)) - math.pi)
        base = mixc(base, line_c, (smoothstep(0.09, 0.0, da) * smoothstep(1.2, 0.0, np.abs(d - 11.6) - 0.8) * (d > 10.4)) * 0.8)
    core = smoothstep(4.2, 2.6, d)
    base = mixc(base, core_c, core * (0.75 + 0.25 * pulse))
    cross = (smoothstep(0.9, 0.0, np.abs(xx - cx)) + smoothstep(0.9, 0.0, np.abs(yy - cy))) * (d < 7.0) * (d > 2.4)
    base = mixc(base, line_c, np.clip(cross, 0, 1) * 0.55)
    # блик, бегущий по диагонали
    sweep = (xx + yy) / (2 * S) * 2.0 - 0.0
    pos = (f / nframes) * 2.4 - 0.2
    band = smoothstep(0.22, 0.0, np.abs(sweep - pos))
    base = base + band[..., None] * (46 if not lit else 26)
    return base

def chime(name, lit):
    n = 4
    frames = [tile_frame(f, n, lit) for f in range(n)]
    arr = np.concatenate(frames, axis=0)
    return save(name, arr, frametime=5, interpolate=True)

# ------------------------------------------------------------ memory: столб тёплого света (анимация, прозрачность)
def memory_frames(f, nframes, speed, color_c, color_e, alpha_k):
    img = np.zeros((S, S, 4))
    yy, xx = np.mgrid[0:S, 0:S] + 0.5
    # колонна света в середине текстуры (модель берёт пиксели 10..22 по горизонтали)
    sway = 0.3 * np.sin((yy + f * speed) * 2 * math.pi / 16.0)
    dx = (xx - 16.0) - sway
    col = np.exp(-(dx / 4.8) ** 2)
    core = np.exp(-(dx / 2.1) ** 2)
    bands = 0.62 + 0.38 * np.sin(((yy - f * speed) * 2 * math.pi / 16.0) + xx * 0.25)
    a = col * (0.60 + 0.40 * bands) * 0.80 + core * 0.30
    rgb = mixc(np.broadcast_to(np.array(color_e, float), (S, S, 3)), np.array(color_c, float), np.clip(core * 1.2 + col * 0.35, 0, 1))
    img[..., :3] = rgb
    img[..., 3] = np.clip(a, 0, 1) * 255 * alpha_k
    # поднимающиеся искры: сдвигаются вверх на speed пикселей за кадр, цикл по высоте S
    r = np.random.default_rng(71)
    for _ in range(9):
        mx = int(round(16 + r.normal(0, 2.6)))
        my0 = r.integers(0, S)
        my = int((my0 - f * speed) % S)
        for dxm, dym, w in ((0, 0, 1.0), (1, 0, 0.45), (-1, 0, 0.45), (0, 1, 0.55), (0, -1, 0.3)):
            px, py = mx + dxm, (my + dym) % S
            if 0 <= px < S:
                img[py, px, :3] = np.array([255, 252, 236.0])
                img[py, px, 3] = max(img[py, px, 3], 255 * w * min(1.0, alpha_k * 1.1))
    return img

def memory(name, nframes, speed, c, e, alpha_k, frametime):
    frames = [memory_frames(f, nframes, speed, c, e, alpha_k) for f in range(nframes)]
    arr = np.clip(np.concatenate(frames, axis=0), 0, 255).astype(np.uint8)
    im = Image.fromarray(arr, "RGBA")
    return save(name, im, frametime=frametime, interpolate=True)

# ------------------------------------------------------------ цветы (прозрачные, 128 -> 32 с усреднением цвета)
def flower(name, kind):
    W = 128
    im = Image.new("RGBA", (W, W), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    green, green2 = (72, 168, 98, 255), (116, 204, 120, 255)
    # стебель с лёгким изгибом
    pts = [(64, 127), (62, 112), (65, 96), (64, 80), (63, 66)]
    for i in range(len(pts) - 1):
        d.line([pts[i], pts[i + 1]], fill=green, width=5)
    d.line([(65, 124), (65, 100)], fill=green2, width=1)
    # листья
    d.ellipse([66, 96, 92, 106], fill=green2); d.ellipse([36, 104, 62, 114], fill=green)
    cx, cy = 64, 46
    if kind == "gold":
        for k in range(10):
            a = k * 2 * math.pi / 10
            px, py = cx + math.cos(a) * 19, cy + math.sin(a) * 19
            for (rx, ry, c) in ((11, 6, (255, 208, 72, 255)), (8, 4, (255, 232, 130, 255))):
                pts_e = [(px + math.cos(a) * rx * math.cos(t) - math.sin(a) * ry * math.sin(t),
                          py + math.sin(a) * rx * math.cos(t) + math.cos(a) * ry * math.sin(t)) for t in np.linspace(0, 2 * math.pi, 18)]
                d.polygon(pts_e, fill=c)
        d.ellipse([cx - 10, cy - 10, cx + 10, cy + 10], fill=(222, 128, 36, 255))
        d.ellipse([cx - 6, cy - 7, cx + 4, cy + 2], fill=(255, 176, 70, 255))
        d.ellipse([cx - 3, cy - 5, cx + 1, cy - 1], fill=(255, 236, 170, 255))
    elif kind == "blue":
        for k in range(6):
            a = k * 2 * math.pi / 6 - math.pi / 2
            tip = (cx + math.cos(a) * 30, cy + math.sin(a) * 30)
            l = (cx + math.cos(a - 0.5) * 12, cy + math.sin(a - 0.5) * 12)
            r_ = (cx + math.cos(a + 0.5) * 12, cy + math.sin(a + 0.5) * 12)
            d.polygon([tip, l, r_], fill=(112, 172, 255, 255))
            mid = (cx + math.cos(a) * 20, cy + math.sin(a) * 20)
            d.polygon([mid, l, r_], fill=(160, 204, 255, 255))
            d.line([(cx, cy), tip], fill=(150, 126, 240, 255), width=2)
        d.ellipse([cx - 8, cy - 8, cx + 8, cy + 8], fill=(246, 252, 255, 255))
        d.ellipse([cx - 4, cy - 4, cx + 4, cy + 4], fill=(255, 226, 150, 255))
    else:  # pink: чаша тюльпана
        d.polygon([(cx - 24, cy - 12), (cx - 14, cy + 22), (cx + 14, cy + 22), (cx + 24, cy - 12), (cx + 10, cy - 2), (cx, cy - 20), (cx - 10, cy - 2)],
                  fill=(255, 128, 176, 255))
        d.polygon([(cx - 16, cy - 6), (cx - 8, cy + 20), (cx + 2, cy + 22), (cx - 2, cy - 14)], fill=(255, 176, 208, 255))
        d.polygon([(cx + 24, cy - 12), (cx + 14, cy + 22), (cx + 4, cy + 22), (cx + 10, cy - 2)], fill=(232, 96, 150, 255))
        d.polygon([(cx, cy - 20), (cx + 10, cy - 2), (cx, cy + 6), (cx - 10, cy - 2)], fill=(255, 204, 226, 255))
        d.ellipse([cx - 4, cy - 4, cx + 4, cy + 4], fill=(255, 236, 170, 255))
    a = np.array(im, float)
    out = np.zeros((S, S, 4), np.uint8)
    k = W // S
    for y in range(S):
        for x in range(S):
            blk = a[y * k:(y + 1) * k, x * k:(x + 1) * k]
            m = blk[..., 3] > 0
            if m.sum() >= (k * k) // 2:
                out[y, x, :3] = blk[m][:, :3].mean(axis=0)
                out[y, x, 3] = 255
    img = Image.fromarray(out, "RGBA")
    return save(name, img)

# ------------------------------------------------------------ сборка
def main():
    SHEET["cloud_stone"] = cloud_stone()
    SHEET["dream_moss"] = dream_moss()
    SHEET["honey_planks"] = honey_planks()
    SHEET["dream_leaves"] = petals("dream_leaves",
        [(252, 224, 232), (248, 200, 216), (255, 238, 240), (240, 186, 210), (250, 214, 222)],
        (228, 150, 190), (255, 238, 170), 81, npts=34, glow=0.18, sparks=8)
    SHEET["tree_blossom"] = petals("tree_blossom",
        [(255, 228, 176), (255, 206, 172), (255, 238, 200), (250, 192, 176), (255, 220, 190)],
        (246, 176, 140), (255, 250, 220), 91, npts=30, glow=0.5, sparks=12)
    SHEET["tree_log"] = tree_log()
    SHEET["chime_tile"] = chime("chime_tile", False)
    SHEET["chime_tile_lit"] = chime("chime_tile_lit", True)
    SHEET["memory"] = memory("memory", 8, 4, (255, 246, 220), (255, 206, 128), 1.0, 3)
    SHEET["memory_done"] = memory("memory_done", 4, 8, (226, 240, 255), (150, 180, 230), 0.55, 6)
    SHEET["bloom_gold"] = flower("bloom_gold", "gold")
    SHEET["bloom_blue"] = flower("bloom_blue", "blue")
    SHEET["bloom_pink"] = flower("bloom_pink", "pink")
    print("готово:", len(SHEET), "текстур ->", OUT)
    if PREVIEW:
        preview()

def preview():
    """Контактный лист: x4, бесшовные в 2x2, анимации кадрами, цветы на тёмном и светлом фоне."""
    names = list(SHEET)
    cell = 4 * S
    pad = 16
    cols = 4
    full = ["cloud_stone", "dream_moss", "honey_planks", "dream_leaves", "tree_log", "tree_blossom"]
    rows = []
    sheet = Image.new("RGB", (cols * (cell * 2 + pad * 3) // 1, 0), (28, 26, 40))
    W = (cell * 2 + pad) * 3 + pad * 4
    H = 40 + 2 * (cell * 2 + pad + 28) + (cell + 60) * 2 + 40
    sheet = Image.new("RGB", (W, H), (30, 28, 42))
    d = ImageDraw.Draw(sheet)
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 14)
    except Exception:
        font = ImageFont.load_default()
    y = 16
    d.text((pad, y), "Бесшовные блоки (2x2, x4)", fill=(255, 236, 180), font=font)
    y += 26
    for i, n in enumerate(full):
        col, row = i % 3, i // 3
        im = SHEET[n].convert("RGB")
        t = Image.new("RGB", (S * 2, S * 2))
        for ty in range(2):
            for tx in range(2):
                t.paste(im, (tx * S, ty * S))
        t = t.resize((cell * 2, cell * 2), Image.NEAREST)
        x0 = pad + col * (cell * 2 + pad)
        y0 = y + row * (cell * 2 + pad + 24)
        sheet.paste(t, (x0, y0))
        d.text((x0, y0 + cell * 2 + 4), n, fill=(230, 230, 240), font=font)
    y += 2 * (cell * 2 + pad + 24) + 8
    d.text((pad, y), "Анимации (кадры слева направо) и столбы на тёмном фоне", fill=(255, 236, 180), font=font)
    y += 24
    x = pad
    for n, nf in (("chime_tile", 4), ("chime_tile_lit", 4)):
        im = SHEET[n].convert("RGB")
        for f in range(nf):
            fr = im.crop((0, f * S, S, (f + 1) * S)).resize((cell // 2 + 24, cell // 2 + 24), Image.NEAREST)
            sheet.paste(fr, (x, y)); x += cell // 2 + 28
        x += 16
    d.text((pad, y + cell // 2 + 28), "chime_tile (4)  /  chime_tile_lit (4)", fill=(230, 230, 240), font=font)
    y += cell // 2 + 52
    x = pad
    for n, nf in (("memory", 8), ("memory_done", 4)):
        im = SHEET[n].convert("RGBA")
        for f in range(nf):
            fr = im.crop((0, f * S, S, (f + 1) * S))
            bg = Image.new("RGBA", (S, S), (26, 30, 56, 255)); bg.alpha_composite(fr)
            sheet.paste(bg.convert("RGB").resize((cell // 2, cell // 2), Image.NEAREST), (x, y)); x += cell // 2 + 4
        x += 16
    d.text((pad, y + cell // 2 + 4), "memory (8)  /  memory_done (4)", fill=(230, 230, 240), font=font)
    y += cell // 2 + 34
    d.text((pad, y), "Цветы (тёмный и светлый фон)", fill=(255, 236, 180), font=font)
    y += 24
    x = pad
    for n in ("bloom_gold", "bloom_blue", "bloom_pink"):
        im = SHEET[n].convert("RGBA")
        for bgc in ((34, 90, 70, 255), (190, 214, 170, 255)):
            bg = Image.new("RGBA", (S, S), bgc); bg.alpha_composite(im)
            sheet.paste(bg.convert("RGB").resize((cell, cell), Image.NEAREST), (x, y)); x += cell + 8
        x += 8
    sheet.save(PREVIEW)

if __name__ == "__main__":
    main()
