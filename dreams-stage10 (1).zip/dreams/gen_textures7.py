"""Этап 7: генерирует ТОЛЬКО новые плейсхолдеры (flesh, eye_stone, watcher_face). Старые текстуры не трогает.
Запуск: python3 gen_textures7.py src/main/resources/assets/dreams/textures
Перерисуй своими: имена и размеры кадров должны совпасть."""
import zlib, struct, random, math, os, sys

OUT = sys.argv[1] if len(sys.argv) > 1 else "."
W = 32

def write_png(path, w, h, rows):
    raw = b"".join(b"\x00" + bytes(c for px in row for c in px) for row in rows)
    def chunk(t, d):
        c = struct.pack(">I", len(d)) + t + d
        return c + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
    png = (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0))
           + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b""))
    with open(path, "wb") as f:
        f.write(png)

def cl(v): return max(0, min(255, int(v)))
def lerp(a, b, t): return a + (b - a) * t

os.makedirs(os.path.join(OUT, "block"), exist_ok=True)
os.makedirs(os.path.join(OUT, "entity"), exist_ok=True)

# ---------- flesh: 4 кадра пульсации ----------
random.seed(41)
base = [[random.randint(-12, 12) for _ in range(W)] for _ in range(W)]
veins = set()
for _ in range(9):
    x, y = random.uniform(0, W), random.uniform(0, W)
    ang = random.uniform(0, 6.283)
    for _ in range(random.randint(16, 30)):
        veins.add((int(x) % W, int(y) % W))
        ang += random.uniform(-0.7, 0.7)
        x += math.cos(ang); y += math.sin(ang)
shine = {(random.randrange(W), random.randrange(W)) for _ in range(26)}
rows = []
for f in range(4):
    pulse = 0.5 + 0.5 * math.sin(2 * math.pi * f / 4)
    for y in range(W):
        row = []
        for x in range(W):
            n = base[y][x]
            if (x, y) in veins:
                row.append((cl(lerp(64, 150, pulse)), cl(lerp(8, 24, pulse)), cl(lerp(34, 58, pulse)), 255))
            elif (x, y) in shine:
                row.append((cl(205 + 20 * pulse), cl(110 + 10 * pulse), cl(112), 255))
            else:
                row.append((cl(lerp(118, 158, pulse) + n), cl(lerp(30, 44, pulse) + n * 0.4), cl(lerp(40, 52, pulse) + n * 0.4), 255))
        rows.append(row)
write_png(os.path.join(OUT, "block", "flesh.png"), W, W * 4, rows)
with open(os.path.join(OUT, "block", "flesh.png.mcmeta"), "w") as f:
    f.write('{ "animation": { "frametime": 8, "interpolate": true } }\n')

# ---------- eye_stone: 6 кадров (закрыт, прищур, открыт, влево, вправо, прищур) ----------
random.seed(53)
stone = [[random.randint(-10, 10) for _ in range(W)] for _ in range(W)]
cracks = set()
for _ in range(4):
    x, y = random.uniform(0, W), random.uniform(0, W)
    ang = random.uniform(0, 6.283)
    for _ in range(random.randint(10, 20)):
        cracks.add((int(x) % W, int(y) % W))
        ang += random.uniform(-0.6, 0.6)
        x += math.cos(ang); y += math.sin(ang)

# (раскрытие 0..1, смещение зрачка по x)
frames = [(0.0, 0), (0.45, 0), (1.0, 0), (1.0, -4), (1.0, 4), (0.5, 0)]
CX, CY, RX, RY = 16, 16, 11, 6
rows = []
for (o, look) in frames:
    for y in range(W):
        row = []
        for x in range(W):
            g = 96 + stone[y][x]
            px = (g, g - 2, g - 3, 255)
            if (x, y) in cracks:
                px = (cl(g - 40), cl(g - 52), cl(g - 52), 255)
            tx = (x - CX) / RX
            half = RY * o * math.sqrt(max(0.0, 1 - tx * tx)) if abs(tx) <= 1 else -1
            dy = abs(y - CY)
            if half >= 0 and o > 0 and dy <= half:
                px = (226, 216, 206, 255)                              # белок
                if abs(tx) > 0.75 or dy > half - 1:                     # красные прожилки у краёв
                    px = (206, 120, 118, 255)
                d = math.hypot(x - (CX + look), y - CY)
                if d <= 3.4:
                    px = (176, 22, 22, 255)                             # радужка
                if d <= 1.6:
                    px = (8, 4, 4, 255)                                 # зрачок
            else:
                edge = (half >= 0 and dy <= max(half, 0) + 1.2) or (o == 0 and dy <= 0 and abs(tx) <= 1)
                if edge and abs(tx) <= 1:
                    px = (34, 10, 12, 255)                              # веко / контур
            row.append(px)
        rows.append(row)
write_png(os.path.join(OUT, "block", "eye_stone.png"), W, W * len(frames), rows)
with open(os.path.join(OUT, "block", "eye_stone.png.mcmeta"), "w") as f:
    f.write('{ "animation": { "frametime": 10, "frames": ['
            '{"index":0,"time":70},{"index":1,"time":6},{"index":2,"time":50},'
            '{"index":3,"time":16},{"index":4,"time":16},{"index":2,"time":40},{"index":5,"time":6}] } }\n')

# ---------- watcher_face: чёрные глаза и рот на лице (x 8..15, y 8..15), остальное прозрачно ----------
rows = [[(0, 0, 0, 0)] * 64 for _ in range(64)]
black = (0, 0, 0, 255)
for (x0, y0, x1, y1) in [(9, 11, 10, 12), (13, 11, 14, 12), (10, 14, 13, 14)]:
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            rows[y][x] = black
write_png(os.path.join(OUT, "entity", "watcher_face.png"), 64, 64, rows)
print("ok")
