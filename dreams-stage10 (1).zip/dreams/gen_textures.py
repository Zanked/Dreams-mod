"""Генерирует плейсхолдеры 32x32. Перерисуй своими (veined_stone: 4 кадра в столбик 32x128)."""
import zlib, struct, random, math, os, sys

OUT = sys.argv[1] if len(sys.argv) > 1 else "."
W = 32

def write_png(path, w, h, rows):
    raw = b"".join(b"\x00" + bytes(c for px in row for c in px) for row in rows)
    def chunk(t, d):
        c = struct.pack(">I", len(d)) + t + d
        return c + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
    png = (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0))
           + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b""))
    with open(path, "wb") as f:
        f.write(png)

def cl(v): return max(0, min(255, int(v)))
def lerp(a, b, t): return a + (b - a) * t

# ---------- veined stone (анимация: 4 кадра) ----------
random.seed(7)
base = [[random.randint(-11, 11) for _ in range(W)] for _ in range(W)]
veins = set()
for _ in range(7):
    x, y = random.uniform(0, W), random.uniform(0, W)
    ang = random.uniform(0, 6.283)
    for _ in range(random.randint(18, 34)):
        veins.add((int(x) % W, int(y) % W))
        if random.random() < 0.18:
            veins.add(((int(x) + 1) % W, int(y) % W))
        ang += random.uniform(-0.6, 0.6)
        x += math.cos(ang); y += math.sin(ang)
glow = set()
for (vx, vy) in veins:
    for dx in (-1, 0, 1):
        for dy in (-1, 0, 1):
            p = ((vx + dx) % W, (vy + dy) % W)
            if p not in veins: glow.add(p)

rows = []
for f in range(4):
    pulse = 0.5 + 0.5 * math.sin(2 * math.pi * f / 4)
    for y in range(W):
        row = []
        for x in range(W):
            g = 92 + base[y][x]
            if (x, y) in veins:
                row.append((cl(lerp(70, 205, pulse)), cl(lerp(12, 42, pulse)), cl(lerp(16, 48, pulse)), 255))
            elif (x, y) in glow:
                row.append((cl(g + 25 * pulse), cl(g - 8), cl(g - 8), 255))
            else:
                row.append((g, g - 2, g - 2, 255))
        rows.append(row)
write_png(os.path.join(OUT, "veined_stone.png"), W, W * 4, rows)

# ---------- rotten planks ----------
random.seed(11)
board_col = [(random.randint(-8, 8)) for _ in range(4)]
rows = []
for y in range(W):
    b = y // 8
    row = []
    for x in range(W):
        n = random.randint(-7, 7) + board_col[b]
        c = (cl(98 + n), cl(70 + n * 0.8), cl(44 + n * 0.6), 255)
        if y % 8 == 0: c = (40, 28, 18, 255)
        if x == (b * 13 + 5) % W: c = (46, 32, 22, 255)
        row.append(c)
    rows.append(row)
for _ in range(10):  # гниль
    x, y = random.randrange(W - 1), random.randrange(W - 1)
    for dx in (0, 1):
        for dy in (0, 1):
            rows[y + dy][x + dx] = (30, 24, 20, 255)
for _ in range(14):  # мох
    rows[random.randrange(W)][random.randrange(W)] = (62, 88, 48, 255)
write_png(os.path.join(OUT, "rotten_planks.png"), W, W, rows)

# ---------- ashen dirt ----------
random.seed(23)
rows = []
for y in range(W):
    row = []
    for x in range(W):
        n = random.randint(-12, 12)
        row.append((cl(74 + n), cl(66 + n), cl(62 + n), 255))
    rows.append(row)
for _ in range(45):
    rows[random.randrange(W)][random.randrange(W)] = (132, 128, 124, 255)
for _ in range(30):
    rows[random.randrange(W)][random.randrange(W)] = (38, 33, 31, 255)
write_png(os.path.join(OUT, "ashen_dirt.png"), W, W, rows)
