"""Этап 8: плейсхолдеры Иной стороны (rust_plate, rust_bloody, rust_grate). Старые текстуры не трогает.
Запуск: python3 gen_textures8.py src/main/resources/assets/dreams/textures"""
import zlib, struct, random, math, os, sys

OUT = sys.argv[1] if len(sys.argv) > 1 else "."
W = 32

def write_png(path, w, h, rows):
    raw = b"".join(b"\x00" + bytes(c for px in row for c in px) for row in rows)
    def chunk(t, d):
        c = struct.pack(">I", len(d)) + t + d
        return c + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
    with open(path, "wb") as f:
        f.write(b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0))
                + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b""))

def cl(v): return max(0, min(255, int(v)))
def lerp(a, b, t): return a + (b - a) * t
def mix(c1, c2, t): return tuple(lerp(a, b, t) for a, b in zip(c1, c2))

def value_noise(seed, cells=6):
    """Плавный шум 0..1, бесшовный по краям."""
    rnd = random.Random(seed)
    g = [[rnd.random() for _ in range(cells)] for _ in range(cells)]
    out = [[0.0] * W for _ in range(W)]
    for y in range(W):
        for x in range(W):
            fx, fy = x / W * cells, y / W * cells
            x0, y0 = int(fx) % cells, int(fy) % cells
            x1, y1 = (x0 + 1) % cells, (y0 + 1) % cells
            tx, ty = fx - int(fx), fy - int(fy)
            tx, ty = tx * tx * (3 - 2 * tx), ty * ty * (3 - 2 * ty)
            out[y][x] = lerp(lerp(g[y0][x0], g[y0][x1], tx), lerp(g[y1][x0], g[y1][x1], tx), ty)
    return out

os.makedirs(os.path.join(OUT, "block"), exist_ok=True)

RUST_DARK = (58, 25, 15)
RUST_MID = (100, 50, 27)
RUST_LIGHT = (146, 82, 43)
BLOOD_DARK = (58, 4, 6)
BLOOD_MID = (112, 10, 12)

def rust_plate(seed, bloody):
    rnd = random.Random(seed)
    n1 = value_noise(seed, 5)
    n2 = value_noise(seed + 7, 9)
    n3 = value_noise(seed + 13, 4)
    streaks = {}
    for _ in range(7):                       # потёки от швов
        x = rnd.randrange(W); y0 = rnd.choice([0, 16]); ln = rnd.randint(5, 13)
        streaks[x] = (y0, ln)
    rows = []
    for y in range(W):
        row = []
        for x in range(W):
            v = n1[y][x] * 0.6 + n2[y][x] * 0.4
            col = mix(RUST_DARK, RUST_LIGHT, v)
            col = mix(col, RUST_MID, 0.25)
            # облупленная краска: тёмные пятна
            if n3[y][x] > 0.52:
                col = mix(col, (52, 22, 14), min(1, (n3[y][x] - 0.52) * 4))
            # швы панелей 16x16
            if y % 16 == 0:
                col = (34, 14, 9)
            elif y % 16 == 1:
                col = mix(col, (190, 120, 70), 0.35)
            if x % 16 == 0:
                col = (38, 15, 10)
            elif x % 16 == 1:
                col = mix(col, (170, 105, 62), 0.25)
            # заклёпки
            for cx, cy in ((4, 4), (11, 4), (4, 11), (11, 11)):
                for ox, oy in ((0, 0),):
                    pass
            row.append(col)
        rows.append(row)
    # заклёпки в каждом углу каждой панели
    for py in (0, 16):
        for px_ in (0, 16):
            for (rx, ry) in ((3, 3), (12, 3), (3, 12), (12, 12)):
                cx, cy = px_ + rx, py + ry
                for dy in range(-1, 2):
                    for dx in range(-1, 2):
                        d = abs(dx) + abs(dy)
                        xx, yy = (cx + dx) % W, (cy + dy) % W
                        if d <= 1:
                            rows[yy][xx] = (206, 128, 74) if (dx, dy) == (-1, -1) or (dx, dy) == (0, -1) or (dx, dy) == (-1, 0) \
                                else (54, 22, 14) if (dx, dy) in ((1, 0), (0, 1)) else (140, 74, 40)
    # потёки
    for x, (y0, ln) in streaks.items():
        for i in range(ln):
            yy = (y0 + 2 + i) % W
            c = rows[yy][x]
            rows[yy][x] = tuple(cl(ch * (0.62 + 0.02 * i)) for ch in c)
    if bloody:
        nb = value_noise(seed + 31, 4)
        drips = [(rnd.randrange(W), rnd.randint(2, 14), rnd.randint(6, 16)) for _ in range(6)]
        for y in range(W):
            for x in range(W):
                if nb[y][x] > 0.58:
                    t = min(1, (nb[y][x] - 0.58) * 5)
                    base = mix(BLOOD_MID, BLOOD_DARK, ((x * 7 + y * 3) % 5) / 8 + (0.2 if nb[y][x] > 0.72 else 0))
                    rows[y][x] = mix(rows[y][x], base, 0.55 + 0.45 * t)
        for x, y0, ln in drips:
            for i in range(ln):
                yy = (y0 + i) % W
                rows[yy][x] = mix(rows[yy][x], BLOOD_MID if i % 4 else BLOOD_DARK, 0.9)
            rows[(y0 + ln) % W][x] = (176, 24, 28)             # влажная капля
        for _ in range(10):
            x, y = rnd.randrange(W), rnd.randrange(W)
            if nb[y][x] > 0.6:
                rows[y][x] = (188, 40, 40)                       # блик на крови
    return [[(cl(c[0]), cl(c[1]), cl(c[2]), 255) for c in row] for row in rows]

write_png(os.path.join(OUT, "block", "rust_plate.png"), W, W, rust_plate(101, False))
write_png(os.path.join(OUT, "block", "rust_bloody.png"), W, W, rust_plate(202, True))

# ---------- rust_grate: решётка над багровой бездной, 4 кадра свечения ----------
glow_noise = value_noise(303, 6)
rnd = random.Random(404)
speck = [[rnd.random() for _ in range(W)] for _ in range(W)]
frames = [0.55, 0.85, 1.0, 0.75]
rows = []
BAR = 3
STEP = 8
for gi, g in enumerate(frames):
    for y in range(W):
        row = []
        for x in range(W):
            on_h = (y % STEP) < BAR
            on_v = (x % STEP) < BAR
            if on_h or on_v:
                lx, ly = x % STEP, y % STEP
                base = mix(RUST_DARK, RUST_LIGHT, 0.25 + 0.5 * speck[y][x])
                if (on_h and ly == 0) or (on_v and lx == 0 and not on_h):
                    base = mix(base, (210, 140, 92), 0.45)       # блик сверху/слева
                if (on_h and ly == BAR - 1) or (on_v and lx == BAR - 1 and not on_h):
                    base = mix(base, (30, 12, 8), 0.55)          # тень снизу/справа
                if on_h and on_v:
                    base = mix(base, (60, 28, 18), 0.25)
                row.append((cl(base[0]), cl(base[1]), cl(base[2]), 255))
            else:
                # бездна: багровое свечение, глубже = темнее, мерцает по кадрам
                hx = (x % STEP) - BAR - 2.0
                hy = (y % STEP) - BAR - 2.0
                depth = math.hypot(hx, hy) / 3.0
                glow = (0.35 + 0.65 * glow_noise[y][x]) * g * (1.0 - 0.45 * min(1, depth))
                row.append((cl(30 + 170 * glow), cl(2 + 22 * glow), cl(4 + 16 * glow), 255))
        rows.append(row)
write_png(os.path.join(OUT, "block", "rust_grate.png"), W, W * len(frames), rows)
with open(os.path.join(OUT, "block", "rust_grate.png.mcmeta"), "w") as f:
    f.write('{ "animation": { "frametime": 7, "interpolate": true } }\n')
print("ok")
