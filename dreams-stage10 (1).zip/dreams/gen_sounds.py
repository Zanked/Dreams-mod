"""Этап 9: синтез звуков мода кодом (numpy/scipy) -> .ogg (нужен ffmpeg с libvorbis).
Запуск: python3 gen_sounds.py src/main/resources/assets/dreams/sounds
Все файлы МОНО (иначе Minecraft не делает их позиционными). Хочешь свои: положи .ogg с тем же именем."""
import os, sys, subprocess, tempfile
import numpy as np
from scipy import signal
from scipy.io import wavfile

SR = 44100
OUT = sys.argv[1] if len(sys.argv) > 1 else "."
os.makedirs(OUT, exist_ok=True)
RNG = np.random.default_rng(1337)

def T(d): return np.arange(int(SR * d)) / SR
def noise(d): return RNG.standard_normal(int(SR * d))
def sos(kind, fc, order=4):
    return signal.butter(order, np.array(fc) / (SR / 2), kind, output="sos")
def lp(x, fc, o=4): return signal.sosfilt(sos("low", min(fc, SR / 2 - 100), o), x)
def hp(x, fc, o=4): return signal.sosfilt(sos("high", fc, o), x)
def bp(x, lo, hi, o=3): return signal.sosfilt(sos("band", [lo, min(hi, SR / 2 - 100)], o), x)
def fade(x, fi, fo):
    x = x.copy(); n = len(x)
    a, b = int(fi * SR), int(fo * SR)
    if a: x[:a] *= np.linspace(0, 1, a) ** 1.5
    if b: x[-b:] *= np.linspace(1, 0, b) ** 1.5
    return x
def expdec(t, tau): return np.exp(-t / tau)
def norm(x, peak=0.9):
    m = np.max(np.abs(x)) or 1.0
    return x / m * peak
def place(buf, x, at):
    i = int(at * SR); n = min(len(x), len(buf) - i)
    if n > 0: buf[i:i + n] += x[:n]
def reverb(x, wet=0.3, length=1.4, hf=3500):
    n = int(length * SR)
    ir = RNG.standard_normal(n) * np.exp(-np.arange(n) / (SR * length / 4.5))
    ir = lp(ir, hf, 2); ir /= np.sqrt(np.sum(ir ** 2))
    y = signal.fftconvolve(x, ir)[:len(x)]
    return x * (1 - wet) + y * wet * 2.2
def sweep_lp(x, f0, f1, win=2048):
    """Шум с плавно меняющейся частотой среза (STFT)."""
    hop = win // 2; w = np.hanning(win); out = np.zeros(len(x) + win)
    n_fr = (len(x) - win) // hop
    freqs = np.fft.rfftfreq(win, 1 / SR)
    for i in range(max(1, n_fr)):
        seg = x[i * hop:i * hop + win]
        if len(seg) < win: break
        fc = f0 * (f1 / f0) ** (i / max(1, n_fr - 1))
        S = np.fft.rfft(seg * w) * (1 / (1 + (freqs / fc) ** 4))
        out[i * hop:i * hop + win] += np.fft.irfft(S)
    return out[:len(x)]
def phase_from_freq(f): return 2 * np.pi * np.cumsum(f) / SR
def saw(ph): return 2 * ((ph / (2 * np.pi)) % 1.0) - 1
def formant(x, centers, widths=None, weights=None):
    widths = widths or [0.25] * len(centers); weights = weights or [1.0] * len(centers)
    y = np.zeros_like(x)
    for c, w, g in zip(centers, widths, weights):
        y += g * bp(x, c * (1 - w), c * (1 + w), 2)
    return y
def metal(t, parts, rnd=True):
    y = np.zeros_like(t)
    for f, a, tau in parts:
        y += a * np.sin(2 * np.pi * f * t + (RNG.uniform(0, 6.28) if rnd else 0)) * expdec(t, tau)
    return y

def save(name, x, peak=0.9):
    x = np.nan_to_num(x); x = norm(x, peak)
    x = np.tanh(x * 1.0) if peak > 0.97 else x
    pcm = (np.clip(x, -1, 1) * 32767).astype(np.int16)
    with tempfile.TemporaryDirectory() as d:
        wav = os.path.join(d, name + ".wav")
        wavfile.write(wav, SR, pcm)
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-ac", "1", "-ar", str(SR),
                        "-c:a", "libvorbis", "-q:a", "4", os.path.join(OUT, name + ".ogg")], check=True)
    print(f"{name:14s} {len(x)/SR:5.2f}s  rms={np.sqrt(np.mean(x**2)):.3f}")

# ---------------------------------------------------------------- звуки

def siren():
    d = 4.6; t = T(d)
    tri = np.abs(((t / 2.3) % 1.0) * 2 - 1)                 # 0..1..0, период 2.3 с
    f = 280 + 260 * tri ** 1.2
    ph = phase_from_freq(f)
    x = np.sin(ph) + 0.55 * np.sin(2 * ph) + 0.3 * np.sin(3 * ph + 0.4) + 0.12 * saw(ph)
    x *= 0.85 + 0.15 * np.sin(2 * np.pi * 5.5 * t)
    x = lp(x, 3200, 2)
    x = fade(x, 0.35, 0.9)
    save("siren", reverb(x, 0.35, 1.8), 0.9)

def drone():
    d = 14.0; t = T(d); x = np.zeros_like(t)
    for f, a in [(41.2, 1.0), (55.0, 0.9), (82.4, 0.6), (110.0, 0.4), (164.8, 0.18)]:
        lfo = 1 + 0.004 * np.sin(2 * np.pi * RNG.uniform(0.05, 0.2) * t + RNG.uniform(0, 6))
        amp = 0.6 + 0.4 * np.sin(2 * np.pi * RNG.uniform(0.04, 0.12) * t + RNG.uniform(0, 6))
        x += a * amp * np.sin(phase_from_freq(f * lfo * np.ones_like(t)))
    x += 0.35 * lp(noise(d), 180, 2) * (0.6 + 0.4 * np.sin(2 * np.pi * 0.08 * t))
    x += 0.10 * bp(noise(d), 900, 1300, 2) * (0.5 + 0.5 * np.sin(2 * np.pi * 0.31 * t + 1))
    x += 0.05 * np.sin(2 * np.pi * 1240 * t) * (0.5 + 0.5 * np.sin(2 * np.pi * 0.17 * t))
    save("drone", fade(x, 3.0, 4.0), 0.75)

def radio_static():
    d = 0.55; n = int(SR * d)
    steps = np.repeat(RNG.random(int(d / 0.012) + 2) ** 2, int(0.012 * SR))[:n]
    x = bp(noise(d), 600, 7000, 2) * steps
    for _ in range(14):
        i = RNG.integers(0, n - 80); x[i:i + 60] += RNG.uniform(-1, 1) * np.hanning(60) * 2.0
    x += 0.15 * np.sin(2 * np.pi * 1000 * T(d)) * (steps > 0.5)
    save("static", fade(x, 0.004, 0.06), 0.8)

def scrape():
    d = 1.8; t = T(d)
    stick = np.clip(np.sin(2 * np.pi * (31 + 9 * np.sin(2 * np.pi * 0.7 * t)) * t) + 0.4 * RNG.standard_normal(len(t)) * 0.3, -1, 1) * 0.5 + 0.5
    f = 760 - 190 * (t / d) + 25 * np.sin(2 * np.pi * 13 * t) + 18 * RNG.standard_normal(len(t)).cumsum() / np.sqrt(len(t)) * 8
    sq = saw(phase_from_freq(f))
    x = (0.55 * lp(sq, 4500, 2) + 0.7 * bp(noise(d), 1500, 5200, 2)) * stick
    x = fade(x, 0.12, 0.6)
    save("scrape", reverb(x, 0.2, 1.0), 0.85)

def clang():
    d = 1.7; t = T(d)
    x = metal(t, [(215, 1.0, 0.55), (411, 0.7, 0.42), (587, 0.5, 0.35), (1130, 0.45, 0.3), (1790, 0.3, 0.24), (2760, 0.22, 0.16), (4120, 0.12, 0.1)])
    x += 1.1 * hp(noise(d), 1500, 2) * expdec(t, 0.012)
    save("clang", reverb(fade(x, 0.0, 0.2), 0.3, 1.5), 0.9)

def chain():
    d = 1.5; buf = np.zeros(int(SR * d))
    for at in sorted(RNG.uniform(0, 1.15, 8)):
        tt = T(0.22); f0 = RNG.uniform(2400, 6200)
        hit = metal(tt, [(f0, 1.0, 0.03), (f0 * 1.51, 0.6, 0.022), (f0 * 2.3, 0.4, 0.015), (f0 * 0.37, 0.5, 0.05)])
        hit += 0.6 * hp(noise(0.22), 2000, 2) * expdec(tt, 0.008)
        place(buf, hit * RNG.uniform(0.35, 1.0), at)
    save("chain", reverb(hp(buf, 700, 2), 0.25, 0.9), 0.8)

def heartbeat():
    d = 0.8; buf = np.zeros(int(SR * d))
    def thump(f0, f1, tau, amp):
        t = T(0.4); f = f1 + (f0 - f1) * np.exp(-t / 0.05)
        return amp * (np.sin(phase_from_freq(f)) * expdec(t, tau) + 0.25 * lp(noise(0.4), 220, 2) * expdec(t, 0.02))
    place(buf, thump(95, 48, 0.11, 1.0), 0.0)
    place(buf, thump(85, 44, 0.12, 0.72), 0.27)
    save("heartbeat", lp(buf, 220, 2), 0.95)

def scare():
    d = 2.6; t = T(d)
    x = 1.6 * bp(noise(d), 300, 6000, 2) * expdec(t, 0.12)                 # удар
    for f, a in [(233, 0.5), (329.6, 0.5), (466, 0.35), (698.5, 0.25)]:     # диссонанс
        x += a * np.sin(2 * np.pi * f * t) * expdec(t, 0.9)
    fs = 2300 - 650 * np.minimum(t / 1.4, 1) + 40 * np.sin(2 * np.pi * 9 * t)
    x += 0.7 * np.sin(phase_from_freq(fs)) * expdec(t, 0.8) * (1 + 0.5 * np.sin(2 * np.pi * 31 * t))   # визг
    x += 1.4 * np.sin(2 * np.pi * 46 * t) * expdec(t, 0.5)                  # сабы
    save("scare", reverb(fade(x, 0.0, 0.5), 0.3, 1.6), 0.97)

def ow_break():
    d = 3.6; t = T(d)
    f = 28 + 18 * np.exp(-t / 0.4)
    x = 1.5 * np.sin(phase_from_freq(f)) * expdec(t, 0.9)
    tear = sweep_lp(noise(d), 9000, 350) * (np.minimum(t / 0.05, 1)) * expdec(t, 1.1)
    x += 0.9 * tear
    x += 1.0 * hp(noise(d), 2500, 2) * expdec(t, 0.02)                      # треск
    gf = 72 - 22 * (t / d)
    x += 0.5 * lp(saw(phase_from_freq(gf)), 420, 2) * expdec(t, 1.2) * (1 + 0.4 * np.sin(2 * np.pi * 6 * t))
    save("ow_break", reverb(fade(x, 0.0, 0.6), 0.3, 2.0), 0.97)

def breath():
    d = 1.8; t = T(d)
    env = np.exp(-((t - 0.38) / 0.22) ** 2) * 0.7 + np.exp(-((t - 1.15) / 0.3) ** 2)
    n = noise(d)
    x = (bp(n, 700, 3600, 2) * 0.8 + bp(n, 250, 700, 2) * (np.exp(-((t - 1.15) / 0.3) ** 2))) * env
    save("breath", reverb(fade(x, 0.05, 0.3), 0.25, 0.9), 0.55)

def whisper():
    d = 2.3; buf = np.zeros(int(SR * d)); at = 0.05
    vowels = [(700, 1200, 2600), (300, 2300, 3000), (500, 1000, 2400), (400, 800, 2300)]
    while at < d - 0.3:
        ln = RNG.uniform(0.12, 0.3)
        seg = noise(ln); fa, fb, fc = vowels[RNG.integers(len(vowels))]
        y = formant(seg, [fa, fb, fc], [0.2, 0.18, 0.15], [1.0, 0.8, 0.45]) * np.hanning(len(seg)) ** 0.7
        place(buf, y, at); at += ln + RNG.uniform(0.02, 0.12)
    save("whisper", reverb(hp(buf, 300, 2), 0.35, 1.2), 0.6)

def step(t0, f0, f1, tau, mid=True):
    t = T(0.5); f = f1 + (f0 - f1) * np.exp(-t / 0.04)
    x = np.sin(phase_from_freq(f)) * expdec(t, tau)
    if mid: x += 0.9 * lp(noise(0.5), 700, 2) * expdec(t, 0.045)
    x += 0.3 * bp(noise(0.5), 1500, 4000, 2) * expdec(t, 0.012)
    return x

def behind_step():
    buf = np.zeros(int(SR * 1.1))
    place(buf, step(0, 88, 56, 0.12), 0.0); place(buf, step(0, 80, 52, 0.12) * 0.85, 0.52)
    save("behind_step", buf, 0.9)

def watcher_step():
    x = step(0, 70, 42, 0.17) * 1.0
    t = T(0.5); x += 0.2 * bp(noise(0.5), 300, 900, 2) * expdec(t, 0.12)
    save("watcher_step", x, 0.95)

def exec_step():
    d = 0.9; t = T(d); f = 30 + 40 * np.exp(-t / 0.05)
    x = 1.2 * np.sin(phase_from_freq(f)) * expdec(t, 0.28)
    x += 0.5 * metal(t, [(300, 1.0, 0.2), (740, 0.7, 0.16), (1900, 0.35, 0.1)])
    x += 0.9 * lp(noise(d), 800, 2) * expdec(t, 0.08)
    save("exec_step", reverb(x, 0.2, 0.9), 0.97)

def exec_drag():
    d = 1.5; t = T(d)
    am = 0.55 + 0.45 * np.abs(np.sin(2 * np.pi * (9 + 2 * np.sin(2 * np.pi * 0.9 * t)) * t))
    x = lp(noise(d), 900, 2) * am + 0.7 * lp(saw(phase_from_freq(np.full_like(t, 58))), 300, 2) * am
    sq = 0.25 * np.sin(phase_from_freq(1180 + 120 * np.sin(2 * np.pi * 3 * t))) * (np.sin(2 * np.pi * 1.7 * t) > 0.6)
    save("exec_drag", fade(x + sq, 0.15, 0.3), 0.8)

def exec_roar():
    d = 2.8; t = T(d)
    f = 60 + 22 * np.sin(2 * np.pi * 0.8 * t) + 6 * np.sin(2 * np.pi * 6.5 * t) + 30 * np.exp(-t / 0.3)
    x = saw(phase_from_freq(f)) + 0.5 * saw(phase_from_freq(f * 1.01))
    x = formant(x, [260, 820, 2100], [0.25, 0.2, 0.2], [1.0, 0.7, 0.3])
    x = np.tanh(3.5 * norm(x, 1.0))
    x += 0.35 * bp(noise(d), 1500, 3500, 2) * (0.5 + 0.5 * np.sin(2 * np.pi * 14 * t))
    env = np.minimum(t / 0.3, 1) * expdec(np.maximum(t - 0.4, 0), 1.3)
    save("exec_roar", reverb(x * env, 0.3, 1.8), 0.97)

def figure_moan():
    d = 2.3; t = T(d)
    f = 150 - 62 * (t / d) ** 0.8 + 9 * np.sin(2 * np.pi * 5.5 * t) + 4 * RNG.standard_normal(len(t)).cumsum() / np.sqrt(len(t))
    x = saw(phase_from_freq(f))
    x = formant(x, [660, 1100, 2500], [0.18, 0.15, 0.12], [1.0, 0.6, 0.25])
    x += 0.5 * formant(noise(d), [900, 2000], [0.3, 0.25])
    x *= (0.8 + 0.2 * np.sin(2 * np.pi * 7 * t)) * np.minimum(t / 0.3, 1) * expdec(np.maximum(t - 0.3, 0), 1.4)
    save("figure_moan", reverb(x, 0.3, 1.4), 0.65)

def seal_hum():
    d = 3.2; t = T(d)
    x = (np.sin(2 * np.pi * 110 * t) + 0.8 * np.sin(2 * np.pi * 110.7 * t) + 0.55 * np.sin(2 * np.pi * 165 * t)
         + 0.35 * np.sin(2 * np.pi * 220.4 * t) + 0.08 * np.sin(2 * np.pi * 880 * t))
    x *= 0.7 + 0.3 * np.sin(2 * np.pi * 0.62 * t)
    save("seal_hum", fade(x, 0.9, 1.3), 0.8)

def seal_activate():
    d = 3.2; t = T(d); x = np.zeros_like(t)
    for root in (196.0, 233.1, 293.7):                     # мрачный минорный аккорд-колокол
        x += metal(t, [(root, 1.0, 1.4), (root * 2.76, 0.4, 0.9), (root * 5.4, 0.2, 0.5), (root * 8.9, 0.1, 0.3)], rnd=False)
    x += 0.9 * np.sin(2 * np.pi * 55 * t) * expdec(t, 0.9)
    up = sweep_lp(noise(d), 600, 9000) * np.minimum(t / 0.8, 1) * expdec(np.maximum(t - 0.8, 0), 0.4) * 0.25
    save("seal_activate", reverb(fade(x + up, 0.0, 0.5), 0.35, 2.0), 0.92)

def unseal():
    d = 3.6; t = T(d)
    x = metal(t, [(110, 1.0, 2.0), (110 * 2.76, 0.5, 1.4), (110 * 5.4, 0.3, 0.9), (110 * 8.9, 0.15, 0.5), (55, 0.8, 1.6)], rnd=False)
    f = 110 + 220 * np.minimum(t / 1.6, 1) ** 2
    x += 0.35 * np.sin(phase_from_freq(f)) * np.minimum(t / 0.4, 1) * expdec(np.maximum(t - 1.2, 0), 0.7)
    save("unseal", reverb(fade(x, 0.0, 0.7), 0.4, 2.2), 0.92)

for fn in (siren, drone, radio_static, scrape, clang, chain, heartbeat, scare, ow_break, breath, whisper,
           behind_step, watcher_step, exec_step, exec_drag, exec_roar, figure_moan, seal_hum, seal_activate, unseal):
    fn()
print("ok")
