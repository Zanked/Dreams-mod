package com.example.dreams.entity;

import com.example.dreams.attachment.DreamState;
import com.example.dreams.attachment.ModAttachments;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.UUID;

/**
 * Лежащая фигура (как в Silent Hill 2): лежит неподвижно; если подойти, оживает, дёргается и ползёт,
 * но замирает под взглядом. Видна только своему сновидцу. Логика в DreamManager.
 */
public class FigureEntity extends PathfinderMob {

    private static final EntityDataAccessor<Boolean> DATA_AWAKE =
            SynchedEntityData.defineId(FigureEntity.class, EntityDataSerializers.BOOLEAN);

    @Nullable
    private UUID owner;
    /** Серверное: до какого тика сна фигура не может проснуться (после того как схватила). */
    public int dormantUntil = 0;

    public FigureEntity(EntityType<? extends FigureEntity> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
        this.xpReward = 0;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_AWAKE, false);
    }

    public boolean isAwake() {
        return this.entityData.get(DATA_AWAKE);
    }

    public void setAwake(boolean awake) {
        this.entityData.set(DATA_AWAKE, awake);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 10.0)
                .add(Attributes.MOVEMENT_SPEED, 0.05)   // ползёт ~2 блока/с
                .add(Attributes.FOLLOW_RANGE, 32.0);
    }

    public void setOwner(UUID owner) {
        this.owner = owner;
    }

    @Override
    public boolean broadcastToPlayer(ServerPlayer player) {
        return owner != null && owner.equals(player.getUUID());
    }

    @Override public boolean shouldBeSaved() { return false; }
    @Override public boolean isInvulnerableTo(DamageSource source) { return true; }
    @Override public boolean isAttackable() { return false; }
    @Override public boolean isPickable() { return false; }
    @Override public boolean isPushable() { return false; }
    @Override public boolean removeWhenFarAway(double distanceSqr) { return false; }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide || tickCount % 10 != 0) return;
        ServerPlayer p = owner == null || !(level() instanceof ServerLevel sl) ? null
                : sl.getServer().getPlayerList().getPlayer(owner);
        boolean valid = p != null
                && p.level() == level()
                && p.getData(ModAttachments.DREAM_STATE).phase == DreamState.Phase.FALSE_AWAKE;
        if (!valid) discard();
    }
}
