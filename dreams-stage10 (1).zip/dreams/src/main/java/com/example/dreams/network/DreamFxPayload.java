package com.example.dreams.network;

import com.example.dreams.Dreams;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Сервер -> клиент: разовый эффект. kind см. DreamTimeline.FX_*, arg - длительность/параметр. */
public record DreamFxPayload(int kind, int arg) implements CustomPacketPayload {

    public static final Type<DreamFxPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(Dreams.MODID, "dream_fx"));

    public static final StreamCodec<ByteBuf, DreamFxPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, DreamFxPayload::kind,
            ByteBufCodecs.VAR_INT, DreamFxPayload::arg,
            DreamFxPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
