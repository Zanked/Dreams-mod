package com.example.dreams.dream;

import com.example.dreams.block.ModBlocks;
import net.minecraft.core.BlockPos;
import com.example.dreams.attachment.DreamState;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.LanternBlock;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

/**
 * Правила подмены: настоящий блок -> кошмарный фейк.
 * ВАЖНО: форма коллизии фейка должна совпадать с оригиналом, иначе сервер откатит движение игрока.
 * Вариант фейка зависит от позиции (hash), а не от случая: так повторная подмена даёт тот же блок.
 */
public class DreamBlocks {

    private static int hash(BlockPos pos) {
        long x = pos.asLong() * -7046029254386353131L;
        x ^= x >>> 32;
        return (int) (x & 0x7fffffffL);
    }

    /** Иная сторона (SH3): ржавый металл, решётки, кровь. Всё полные кубы, как и оригиналы. */
    @Nullable
    private static BlockState otherworld(BlockState s, BlockPos pos) {
        int h = hash(pos);
        if (s.is(BlockTags.BASE_STONE_OVERWORLD) || s.is(BlockTags.TERRACOTTA)
                || s.is(Blocks.COBBLESTONE) || s.is(Blocks.STONE_BRICKS)) {
            return (h % 6 == 0 ? ModBlocks.RUST_BLOODY : ModBlocks.RUST_PLATE).get().defaultBlockState();
        }
        if (s.is(BlockTags.PLANKS) || s.is(BlockTags.LOGS)) {
            return (h % 4 == 0 ? ModBlocks.RUST_BLOODY : ModBlocks.RUST_PLATE).get().defaultBlockState();
        }
        if ((s.is(BlockTags.DIRT) && !s.is(Blocks.MUD)) || s.is(BlockTags.SAND) || s.is(Blocks.GRAVEL)) {
            return (h % 5 == 0 ? ModBlocks.RUST_PLATE : ModBlocks.RUST_GRATE).get().defaultBlockState();
        }
        return null;
    }

    /** Добрый сон: жемчужный камень, мох, мёд, лепестки, светящиеся цветы. Коллизии те же, что у оригиналов. */
    @Nullable
    public static BlockState good(BlockState s, BlockPos pos) {
        if (s.is(BlockTags.BASE_STONE_OVERWORLD) || s.is(BlockTags.TERRACOTTA)
                || s.is(Blocks.COBBLESTONE) || s.is(Blocks.STONE_BRICKS)) {
            return ModBlocks.CLOUD_STONE.get().defaultBlockState();
        }
        if (s.is(BlockTags.PLANKS) || s.is(BlockTags.LOGS)) {
            return ModBlocks.HONEY_PLANKS.get().defaultBlockState();
        }
        if (s.is(BlockTags.LEAVES)) {
            return ModBlocks.DREAM_LEAVES.get().defaultBlockState();
        }
        if ((s.is(BlockTags.DIRT) && !s.is(Blocks.MUD)) || s.is(BlockTags.SAND) || s.is(Blocks.GRAVEL)) {
            return ModBlocks.DREAM_MOSS.get().defaultBlockState();
        }
        if (s.is(Blocks.SHORT_GRASS) || s.is(Blocks.TALL_GRASS) || s.is(Blocks.FERN) || s.is(Blocks.LARGE_FERN)
                || s.is(BlockTags.SMALL_FLOWERS)) {
            return bloom(pos);
        }
        return null;
    }

    /** Вырастает ли цветок над этим блоком мха (примерно каждый седьмой). */
    public static boolean sprinkle(BlockPos pos) {
        return hash(pos) % 7 == 0;
    }

    /** Цветок по позиции: золотой, синий или розовый. */
    public static BlockState bloom(BlockPos pos) {
        int v = hash(pos) % 3;
        return (v == 0 ? ModBlocks.BLOOM_GOLD : v == 1 ? ModBlocks.BLOOM_BLUE : ModBlocks.BLOOM_PINK).get().defaultBlockState();
    }

    /** Палитра мира по виду сна (для волны подмены). */
    @Nullable
    public static BlockState worldFor(DreamState.Kind kind, BlockState s, BlockPos pos) {
        if (kind == DreamState.Kind.GOOD) return good(s, pos);
        return otherworld(s, pos);
    }

    @Nullable
    public static BlockState replacement(BlockState s, BlockPos pos, boolean inOtherworld) {
        if (inOtherworld) {
            BlockState o = otherworld(s, pos);
            if (o != null) return o;
        }
        return replacement(s, pos);
    }

    @Nullable
    public static BlockState replacement(BlockState s, BlockPos pos) {
        if (s.is(BlockTags.BASE_STONE_OVERWORLD) || s.is(Blocks.COBBLESTONE) || s.is(Blocks.STONE_BRICKS)) {
            // каждый 13-й камень - стена с глазами
            return (hash(pos) % 13 == 0 ? ModBlocks.EYE_STONE : ModBlocks.VEINED_STONE).get().defaultBlockState();
        }
        if (s.is(BlockTags.PLANKS)) {
            return ModBlocks.ROTTEN_PLANKS.get().defaultBlockState();
        }
        // грязь (MUD) пониже обычного блока -> коллизия не совпала бы, пропускаем
        if (s.is(BlockTags.DIRT) && !s.is(Blocks.MUD)) {
            // каждая 4-я земля - пульсирующая плоть
            return (hash(pos) % 4 == 0 ? ModBlocks.FLESH : ModBlocks.ASHEN_DIRT).get().defaultBlockState();
        }
        if (s.is(Blocks.TORCH)) {
            return Blocks.SOUL_TORCH.defaultBlockState();
        }
        if (s.is(Blocks.WALL_TORCH)) {
            return Blocks.SOUL_WALL_TORCH.defaultBlockState()
                    .setValue(HorizontalDirectionalBlock.FACING, s.getValue(HorizontalDirectionalBlock.FACING));
        }
        if (s.is(Blocks.LANTERN)) {
            return Blocks.SOUL_LANTERN.defaultBlockState()
                    .setValue(LanternBlock.HANGING, s.getValue(LanternBlock.HANGING))
                    .setValue(LanternBlock.WATERLOGGED, s.getValue(LanternBlock.WATERLOGGED));
        }
        if (s.is(Blocks.SHORT_GRASS)) {
            return Blocks.DEAD_BUSH.defaultBlockState();
        }
        if (s.is(BlockTags.SMALL_FLOWERS)) {
            return Blocks.WITHER_ROSE.defaultBlockState();
        }
        return null;
    }
}
