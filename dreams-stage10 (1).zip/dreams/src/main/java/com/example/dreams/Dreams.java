package com.example.dreams;

import com.example.dreams.attachment.ModAttachments;
import com.example.dreams.block.ModBlocks;
import com.example.dreams.entity.ModEntities;
import com.example.dreams.sound.ModSounds;
import com.example.dreams.network.ModNetwork;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;

@Mod(Dreams.MODID)
public class Dreams {
    public static final String MODID = "dreams";

    public Dreams(IEventBus modBus, ModContainer container) {
        ModAttachments.ATTACHMENTS.register(modBus);
        ModBlocks.BLOCKS.register(modBus);
        ModEntities.ENTITIES.register(modBus);
        ModSounds.SOUNDS.register(modBus);
        modBus.addListener(ModEntities::registerAttributes);
        modBus.addListener(ModNetwork::register);

        container.registerConfig(ModConfig.Type.COMMON, DreamConfig.COMMON_SPEC);
        container.registerConfig(ModConfig.Type.CLIENT, DreamConfig.CLIENT_SPEC);
    }
}
