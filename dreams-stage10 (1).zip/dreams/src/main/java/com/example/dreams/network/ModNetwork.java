package com.example.dreams.network;

import com.example.dreams.client.NightmareClient;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

public class ModNetwork {
    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("4");
        registrar.playToClient(
                DreamPhasePayload.TYPE,
                DreamPhasePayload.STREAM_CODEC,
                (payload, context) -> context.enqueueWork(() -> NightmareClient.setPhase(payload.phase(), payload.round(), payload.kind()))
        );
        registrar.playToClient(
                DreamFxPayload.TYPE,
                DreamFxPayload.STREAM_CODEC,
                (payload, context) -> context.enqueueWork(() -> NightmareClient.onFx(payload.kind(), payload.arg()))
        );
    }
}
