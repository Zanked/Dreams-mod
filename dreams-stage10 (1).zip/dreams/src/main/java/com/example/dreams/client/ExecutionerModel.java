package com.example.dreams.client;

import com.example.dreams.Dreams;
import com.example.dreams.entity.ExecutionerEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;

/**
 * Гуманоид + ступенчатая пирамида на голове + огромный клинок в правой руке (волочится по земле).
 * Текстура 128x128: классическая раскладка в левом верхнем углу 64x64, шлем и клинок справа (см. gen_textures9.py).
 */
public class ExecutionerModel extends HumanoidModel<ExecutionerEntity> {

    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(Dreams.MODID, "executioner"), "main");

    public ExecutionerModel(ModelPart root) {
        super(root);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = HumanoidModel.createMesh(CubeDeformation.NONE, 0.0F);
        PartDefinition root = mesh.getRoot();

        PartDefinition head = root.getChild("head");
        head.addOrReplaceChild("helm0", CubeListBuilder.create().texOffs(64, 0)
                .addBox(-5.0F, -9.0F, -5.0F, 10.0F, 9.0F, 10.0F), PartPose.ZERO);
        head.addOrReplaceChild("helm1", CubeListBuilder.create().texOffs(64, 20)
                .addBox(-4.0F, -13.0F, -4.0F, 8.0F, 4.0F, 8.0F), PartPose.ZERO);
        head.addOrReplaceChild("helm2", CubeListBuilder.create().texOffs(64, 33)
                .addBox(-3.0F, -17.0F, -3.0F, 6.0F, 4.0F, 6.0F), PartPose.ZERO);
        head.addOrReplaceChild("helm3", CubeListBuilder.create().texOffs(64, 44)
                .addBox(-2.0F, -21.0F, -2.0F, 4.0F, 4.0F, 4.0F), PartPose.ZERO);

        root.getChild("right_arm").addOrReplaceChild("blade", CubeListBuilder.create().texOffs(104, 0)
                .addBox(-1.5F, 10.0F, -3.0F, 1.0F, 15.0F, 6.0F), PartPose.ZERO);   // кончик ~3 px ниже ступней: чертит по земле

        return LayerDefinition.create(mesh, 128, 128);
    }
}
