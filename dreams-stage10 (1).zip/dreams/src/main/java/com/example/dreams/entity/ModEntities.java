package com.example.dreams.entity;

import com.example.dreams.Dreams;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.function.Supplier;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, Dreams.MODID);

    public static final Supplier<EntityType<WatcherEntity>> WATCHER = ENTITIES.register("watcher",
            () -> EntityType.Builder.of(WatcherEntity::new, MobCategory.MONSTER)
                    .sized(0.6f, 2.3f)
                    .clientTrackingRange(10)
                    .noSummon()
                    .build("watcher"));

    public static final Supplier<EntityType<ExecutionerEntity>> EXECUTIONER = ENTITIES.register("executioner",
            () -> EntityType.Builder.of(ExecutionerEntity::new, MobCategory.MONSTER)
                    .sized(0.8f, 1.95f)
                    .clientTrackingRange(10)
                    .noSummon()
                    .build("executioner"));

    public static final Supplier<EntityType<FigureEntity>> FIGURE = ENTITIES.register("figure",
            () -> EntityType.Builder.of(FigureEntity::new, MobCategory.MONSTER)
                    .sized(0.7f, 0.6f)
                    .clientTrackingRange(10)
                    .noSummon()
                    .build("figure"));

    public static void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(WATCHER.get(), WatcherEntity.createAttributes().build());
        event.put(EXECUTIONER.get(), ExecutionerEntity.createAttributes().build());
        event.put(FIGURE.get(), FigureEntity.createAttributes().build());
    }
}
