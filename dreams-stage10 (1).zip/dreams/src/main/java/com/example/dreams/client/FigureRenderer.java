package com.example.dreams.client;

import com.example.dreams.Dreams;
import com.example.dreams.entity.FigureEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Лежит на боку, как павший моб. Проснувшись, дёргается: руки и ноги бьются, голова ходит ходуном. */
public class FigureRenderer extends HumanoidMobRenderer<FigureEntity, HumanoidModel<FigureEntity>> {

    private static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath(Dreams.MODID, "textures/entity/figure.png");

    public FigureRenderer(EntityRendererProvider.Context context) {
        super(context, new FigureModel(context.bakeLayer(ModelLayers.ZOMBIE)), 0.0f);
    }

    @Override
    public ResourceLocation getTextureLocation(FigureEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void setupRotations(FigureEntity entity, PoseStack poseStack, float bob, float yBodyRot,
                                  float partialTick, float scale) {
        super.setupRotations(entity, poseStack, bob, yBodyRot, partialTick, scale);
        poseStack.translate(0.0F, 0.2F, 0.0F);
        poseStack.mulPose(Axis.ZP.rotationDegrees(90.0F));
        if (entity.isAwake()) {
            poseStack.mulPose(Axis.XP.rotationDegrees(Mth.sin((entity.tickCount + partialTick) * 1.3F) * 4.0F));
        }
    }

    private static class FigureModel extends HumanoidModel<FigureEntity> {
        FigureModel(ModelPart root) {
            super(root);
        }

        @Override
        public void setupAnim(FigureEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                              float netHeadYaw, float headPitch) {
            super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
            if (entity.isAwake()) {   // судороги
                this.rightArm.xRot = Mth.sin(ageInTicks * 1.7F) * 1.4F;
                this.leftArm.xRot = Mth.sin(ageInTicks * 1.9F + 2.0F) * 1.4F;
                this.rightLeg.xRot = Mth.sin(ageInTicks * 1.5F + 1.0F) * 0.9F;
                this.leftLeg.xRot = Mth.sin(ageInTicks * 1.6F + 4.0F) * 0.9F;
                this.head.zRot = Mth.sin(ageInTicks * 0.9F) * 0.45F;
            } else {
                this.rightArm.xRot = -0.3F;
                this.leftArm.xRot = -0.3F;
            }
        }
    }
}
