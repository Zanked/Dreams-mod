package com.example.dreams.dream;

import com.example.dreams.DreamConfig;
import com.example.dreams.attachment.DreamState;
import com.example.dreams.block.ModBlocks;
import com.example.dreams.network.DreamFxPayload;
import com.example.dreams.sound.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.GlobalPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundBlockUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundGameEventPacket;
import net.minecraft.network.protocol.game.ClientboundSetTimePacket;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;
import org.joml.Vector3f;

import javax.annotation.Nullable;

/**
 * Добрый сон. Мир остаётся твоим, но он тёплый: жемчужный камень, мох, мёд, лепестки, золотой рассвет.
 * Пять огней: четыре воспоминания (по твоей реальной истории: место гибели, дом мира, друг рядом, небо)
 * и мелодия звенящих плиток. Три огня будят Древо снов; чем больше огней, тем щедрее благословение.
 * Невесомость: медленное падение, высокий прыжок, ленты ветра, парящий остров (нужен goodFlight).
 * Всё построено на фейк-блоках: настоящий мир не меняется. Кровать открыта всегда.
 */
public final class GoodDream {

    private GoodDream() {}

    /** С какого тика светится кровать и из сна можно выйти. */
    public static final int BED_GLOW_AT = 100;

    /** Пометка в данных игрока: если сервер упал во сне, при входе полёт снимается. */
    public static final String TAG_MAYFLY = "dreams_mayfly";

    private static final int MEMORY_COUNT = 4;
    /** Пентатоника ре мажор в полутонах нотного блока (12 = фа-диез, питч 1.0): ре, ми, фа#, ля, си. */
    private static final int[] NOTE_SEMITONES = {8, 10, 12, 15, 17};
    private static final int TREE_HEIGHT = 22;
    private static final int TREE_SEND_PER_TICK = 160;

    // ------------------------------------------------------------------ начало и конец

    static void begin(ServerPlayer player, ServerLevel level, DreamState s) {
        s.lights = 0;
        s.whaleSeed = player.getRandom().nextDouble() * Math.PI * 2;
        s.lastX = player.getX();
        s.lastZ = player.getZ();
        PacketDistributor.sendToPlayer(player, new DreamFxPayload(DreamTimeline.FX_GOOD_LIGHTS, 0));
        if (DreamConfig.COMMON.goodFlight.get() && !s.mayflyGiven) {
            var ab = player.getAbilities();
            s.hadMayfly = ab.mayfly;
            ab.mayfly = true;
            player.onUpdateAbilities();
            s.mayflyGiven = true;
            if (!s.hadMayfly) player.getPersistentData().putBoolean(TAG_MAYFLY, true);
        }
        if (level.isRaining()) {
            player.connection.send(new ClientboundGameEventPacket(ClientboundGameEventPacket.STOP_RAINING, 0.0F));
            s.rainStopped = true;
        }
        player.playNotifySound(ModSounds.CHIME.get(), SoundSource.AMBIENT, 1.0f, 1.1f);
        player.displayClientMessage(Component.translatable("message.dreams.good.begin")
                .withStyle(ChatFormatting.GOLD), true);
    }

    /** Любой конец доброго сна (успех, смерть, смена измерения): вернуть полёт, дождь, эффекты. */
    static void cleanup(ServerPlayer player, DreamState s) {
        if (s.mayflyGiven) {
            var ab = player.getAbilities();
            boolean keep = s.hadMayfly || player.isCreative() || player.isSpectator();
            ab.mayfly = keep;
            if (!keep) ab.flying = false;
            player.onUpdateAbilities();
            player.getPersistentData().remove(TAG_MAYFLY);
            s.mayflyGiven = false;
            s.hadMayfly = false;
        }
        if (s.phase == DreamState.Phase.FALSE_AWAKE) {
            // проснулся высоко над землёй: не разбиться
            player.fallDistance = 0.0f;
            player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 20 * 20, 0, false, false, false));
            MobEffectInstance jump = player.getEffect(MobEffects.JUMP);
            if (jump != null && jump.getAmplifier() == 1 && jump.getDuration() <= 62) {
                player.removeEffect(MobEffects.JUMP);
            }
        }
        if (s.rainStopped) {
            s.rainStopped = false;
            ServerLevel level = player.serverLevel();
            if (level.isRaining()) {
                player.connection.send(new ClientboundGameEventPacket(ClientboundGameEventPacket.START_RAINING, 0.0F));
                player.connection.send(new ClientboundGameEventPacket(ClientboundGameEventPacket.RAIN_LEVEL_CHANGE, level.getRainLevel(1.0F)));
                player.connection.send(new ClientboundGameEventPacket(ClientboundGameEventPacket.THUNDER_LEVEL_CHANGE, level.getThunderLevel(1.0F)));
            }
        }
    }

    /** При входе в игру: если в прошлый раз сервер остановили во сне, снять выданный полёт. */
    public static void revokeStrayFlight(ServerPlayer player) {
        if (!player.getPersistentData().getBoolean(TAG_MAYFLY)) return;
        player.getPersistentData().remove(TAG_MAYFLY);
        var ab = player.getAbilities();
        if (!player.isCreative() && !player.isSpectator()) {
            ab.mayfly = false;
            ab.flying = false;
            player.onUpdateAbilities();
        }
    }

    /** ПКМ по кровати: проснуться. Награда по числу огней. */
    static void leave(ServerPlayer player, DreamState s) {
        if (s.lights > 0) {
            player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 20 * 5 * s.lights, 0));
        }
        DreamManager.end(player, s, DreamManager.Result.SUCCESS, true);
    }

    // ------------------------------------------------------------------ тик

    static void tick(ServerPlayer player, ServerLevel level, DreamState s, int t) {
        DreamConfig.Common c = DreamConfig.COMMON;
        RandomSource r = player.getRandom();

        // Золотой рассвет, который медленно поднимается над твоим миром.
        if (c.fakeTime.get()) {
            if (t == 1) s.timeFrom = level.getDayTime() / 24000L * 24000L;
            long fake = dawnTime(s, t);
            if (s.finale) {   // вознесение: рассвет проносится в звёздную ночь
                double e = Mth.clamp((t - s.finaleAt) / 140.0, 0.0, 1.0);
                e = e * e * (3.0 - 2.0 * e);
                fake = (long) Mth.lerp(e, (double) s.finaleTime, (double) (s.timeFrom + 42000L));
            }
            player.connection.send(new ClientboundSetTimePacket(level.getGameTime(), fake, false));
        }

        // Невесомость: мягкое падение и высокий прыжок.
        if (t % 20 == 1) {
            player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 60, 0, false, false, false));
            player.addEffect(new MobEffectInstance(MobEffects.JUMP, 60, 1, false, false, false));
        }
        player.fallDistance = 0.0f;

        // Мир теплеет волной от игрока наружу.
        if (c.fakeBlocks.get() && t >= 10) DreamManager.sweepOtherworld(player, level, s);

        // Расстановка по стадиям. Чанк мог быть не загружен: повторяем раз в секунду, пока не выйдет.
        if (t % 20 == 0 && t < 1800) {
            BlockPos origin = player.blockPosition();
            if (!s.memPlaced && t >= DreamTimeline.GOOD_MEMORIES_AT) s.memPlaced = placeMemories(player, level, s, origin);
            if (!s.windPlaced && t >= DreamTimeline.GOOD_WIND_AT) s.windPlaced = !c.goodWind.get() || placeWinds(player, level, s, origin);
            if (!s.tilesPlaced && t >= DreamTimeline.GOOD_TILES_AT) s.tilesPlaced = !c.goodTiles.get() || placeTiles(player, level, s, origin, t);
            if (!s.treePlaced && t >= DreamTimeline.GOOD_TREE_AT) s.treePlaced = !c.goodTree.get() || placeTree(player, level, s, origin);
        }

        if (t % 2 == 0) tickMemories(player, level, s);
        tickWinds(player, level, s, t);
        tickTiles(player, level, s, t);
        tickTree(player, level, s, t);
        tickWhales(player, level, s, t);
        if (c.goodPlayful.get() && !s.finale) tickPlayful(player, level, s, t);

        // Свет над кроватью: отсюда можно проснуться.
        if (t >= BED_GLOW_AT && s.bed != null && t % 8 == 0) {
            level.sendParticles(player, ParticleTypes.END_ROD, true,
                    s.bed.getX() + 0.5, s.bed.getY() + 1.2, s.bed.getZ() + 0.5, 3, 0.3, 0.4, 0.3, 0.01);
        }
        if (c.goodParticles.get() && t % 3 == 0) ambientParticles(player, level, r);

        if (s.finale) {
            tickFinale(player, level, s, t);
            return;
        }
        if (t >= c.goodSeconds.get() * 20) {   // сон закончился сам, мягко и без штрафов
            DreamManager.end(player, s, DreamManager.Result.SUCCESS, true);
        }
    }

    private static void ambientParticles(ServerPlayer player, ServerLevel level, RandomSource r) {
        double px = player.getX(), py = player.getY(), pz = player.getZ();
        for (int i = 0; i < 2; i++) {
            level.sendParticles(player, ParticleTypes.CHERRY_LEAVES, true,
                    px + (r.nextDouble() - 0.5) * 18, py + r.nextDouble() * 6 - 1, pz + (r.nextDouble() - 0.5) * 18,
                    1, 0.0, 0.0, 0.0, 0.0);
        }
        level.sendParticles(player, ParticleTypes.END_ROD, true,
                px + (r.nextDouble() - 0.5) * 14, py + r.nextDouble() * 4, pz + (r.nextDouble() - 0.5) * 14,
                1, 0.0, 0.03, 0.0, 0.01);
    }

    // ------------------------------------------------------------------ вспомогательное

    private static void fakeSet(ServerPlayer player, DreamState s, BlockPos pos, BlockState st) {
        BlockPos p = pos.immutable();
        s.fake.put(p.asLong(), st);
        player.connection.send(new ClientboundBlockUpdatePacket(p, st));
    }

    private static boolean tooClose(DreamState s, int x, int z, double spacing) {
        double sq = spacing * spacing;
        for (int i = 0; i < s.memories.size(); i++) {
            BlockPos p = BlockPos.of(s.memories.getLong(i));
            if (sq > (double) (p.getX() - x) * (p.getX() - x) + (double) (p.getZ() - z) * (p.getZ() - z)) return true;
        }
        for (int i = 0; i < s.winds.size(); i++) {
            BlockPos p = BlockPos.of(s.winds.getLong(i));
            if (sq > (double) (p.getX() - x) * (p.getX() - x) + (double) (p.getZ() - z) * (p.getZ() - z)) return true;
        }
        if (s.tileCenter != null) {
            BlockPos p = s.tileCenter;
            if (sq > (double) (p.getX() - x) * (p.getX() - x) + (double) (p.getZ() - z) * (p.getZ() - z)) return true;
        }
        if (s.tree != null) {
            BlockPos p = s.tree;
            if (sq > (double) (p.getX() - x) * (p.getX() - x) + (double) (p.getZ() - z) * (p.getZ() - z)) return true;
        }
        return false;
    }

    /** Свободное место на земле на расстоянии dmin..dmax от origin; toward (необязательно) задаёт сторону. */
    @Nullable
    private static BlockPos pickSpot(ServerLevel level, RandomSource r, DreamState s, BlockPos origin,
                                     double dmin, double dmax, double spacing, int up, int down, @Nullable Vec3 toward) {
        double baseAng = r.nextDouble() * Math.PI * 2;
        double dist = dmin + r.nextDouble() * (dmax - dmin);
        if (toward != null) {
            double dx = toward.x - origin.getX();
            double dz = toward.z - origin.getZ();
            double len = Math.sqrt(dx * dx + dz * dz);
            if (len > 1.0) {
                baseAng = Math.atan2(dz, dx);
                dist = Mth.clamp(len, dmin, dmax);
            }
        }
        for (int tries = 0; tries < 40; tries++) {
            double ang = toward != null ? baseAng + (r.nextDouble() - 0.5) * 0.6 : r.nextDouble() * Math.PI * 2;
            double d = toward != null ? dist + (r.nextDouble() - 0.5) * 8 : dmin + r.nextDouble() * (dmax - dmin);
            d = Mth.clamp(d, dmin, dmax + 6);
            int x = Mth.floor(origin.getX() + Math.cos(ang) * d);
            int z = Mth.floor(origin.getZ() + Math.sin(ang) * d);
            if (tooClose(s, x, z, spacing)) continue;
            BlockPos found = DreamManager.findGround(level, x, z, origin.getY(), up, down);
            if (found != null && level.getFluidState(found.below()).isEmpty()) return found;
        }
        return null;
    }

    private static void gainLight(ServerPlayer player, ServerLevel level, DreamState s, Component msg,
                                  double x, double y, double z) {
        s.lights++;
        PacketDistributor.sendToPlayer(player, new DreamFxPayload(DreamTimeline.FX_GOOD_LIGHTS, s.lights));
        player.playNotifySound(ModSounds.MEMORY.get(), SoundSource.PLAYERS, 1.2f, 0.75f + 0.12f * s.lights);
        level.sendParticles(player, ParticleTypes.END_ROD, true, x, y, z, 40, 0.5, 1.0, 0.5, 0.08);
        level.sendParticles(player, ParticleTypes.HAPPY_VILLAGER, true, x, y, z, 14, 0.6, 0.8, 0.6, 0.0);
        player.heal(2.0f);
        player.displayClientMessage(msg, true);
    }

    // ------------------------------------------------------------------ воспоминания

    private static boolean placeMemories(ServerPlayer player, ServerLevel level, DreamState s, BlockPos origin) {
        RandomSource r = player.getRandom();
        boolean sky = DreamConfig.COMMON.goodFlight.get() && DreamConfig.COMMON.goodWind.get();
        int ground = sky ? MEMORY_COUNT - 1 : MEMORY_COUNT;

        // Куда тянет каждое воспоминание: из твоей реальной истории (если она есть рядом).
        Vec3 death = null;
        var last = player.getLastDeathLocation();
        if (last.isPresent()) {
            GlobalPos gp = last.get();
            if (gp.dimension().equals(level.dimension())) {
                death = Vec3.atCenterOf(gp.pos());
            }
        }
        Vec3 home = Vec3.atCenterOf(level.getSharedSpawnPos());
        Vec3 friend = null;
        for (Mob m : level.getEntitiesOfClass(Mob.class, player.getBoundingBox().inflate(64.0),
                e -> (e instanceof TamableAnimal ta && ta.isOwnedBy(player)) || e instanceof AbstractVillager)) {
            friend = m.position();
            if (m instanceof TamableAnimal) break;   // питомец важнее жителя
        }
        Vec3[] towards = {death, home, friend, null};

        for (int i = 0; i < ground; i++) {
            Vec3 tw = towards[i];
            if (tw != null && origin.distSqr(BlockPos.containing(tw)) < 14 * 14) tw = null;   // уже рядом: пусть будет в стороне
            BlockPos spot = pickSpot(level, r, s, origin, 18, 40, 14, 6, 10, tw);
            if (spot == null) continue;
            addMemory(player, s, spot, i);
        }
        return !s.memories.isEmpty();
    }

    private static void addMemory(ServerPlayer player, DreamState s, BlockPos spot, int type) {
        s.memories.add(spot.asLong());
        s.memTypes.add(type);
        sendMemory(player, s, s.memories.size() - 1);
    }

    private static void sendMemory(ServerPlayer player, DreamState s, int i) {
        BlockPos p = BlockPos.of(s.memories.getLong(i));
        BlockState st = ((s.memMask & (1 << i)) != 0 ? ModBlocks.MEMORY_DONE : ModBlocks.MEMORY).get().defaultBlockState();
        fakeSet(player, s, p, st);
        fakeSet(player, s, p.above(), st);
    }

    private static void tickMemories(ServerPlayer player, ServerLevel level, DreamState s) {
        for (int i = 0; i < s.memories.size(); i++) {
            if ((s.memMask & (1 << i)) != 0) continue;
            BlockPos p = BlockPos.of(s.memories.getLong(i));
            double dx = player.getX() - (p.getX() + 0.5);
            double dz = player.getZ() - (p.getZ() + 0.5);
            double dy = player.getY() - p.getY();
            if (dx * dx + dz * dz <= 2.8 * 2.8 && dy > -3.0 && dy < 3.5) {
                s.memMask |= 1 << i;
                sendMemory(player, s, i);
                int type = Mth.clamp(s.memTypes.getInt(i), 0, MEMORY_COUNT - 1);
                gainLight(player, level, s,
                        Component.translatable("message.dreams.good.memory." + type).withStyle(ChatFormatting.GOLD),
                        p.getX() + 0.5, p.getY() + 1.2, p.getZ() + 0.5);
            }
        }
        // Невидимые, но хорошо различимые: тёплые искры над несобранными воспоминаниями.
        if (s.ticks % 6 == 0) {
            for (int i = 0; i < s.memories.size(); i++) {
                if ((s.memMask & (1 << i)) != 0) continue;
                BlockPos p = BlockPos.of(s.memories.getLong(i));
                if (player.distanceToSqr(p.getX() + 0.5, p.getY(), p.getZ() + 0.5) > 80.0 * 80.0) continue;
                level.sendParticles(player, ParticleTypes.END_ROD, true,
                        p.getX() + 0.5, p.getY() + 1.0 + (s.ticks % 30) * 0.15, p.getZ() + 0.5, 1, 0.15, 0.0, 0.15, 0.01);
            }
        }
    }

    // ------------------------------------------------------------------ ленты ветра и парящий остров

    private static boolean placeWinds(ServerPlayer player, ServerLevel level, DreamState s, BlockPos origin) {
        RandomSource r = player.getRandom();
        boolean island = DreamConfig.COMMON.goodFlight.get();
        int placed = 0;
        for (int k = 0; k < 3; k++) {
            BlockPos base = pickSpot(level, r, s, origin, 12, 38, 12, 6, 10, null);
            if (base == null) continue;
            int height = 30;
            if (k == 0 && island) {
                int islandY = base.getY() + 20;
                if (islandY < level.getMaxBuildHeight() - 6) {
                    double ang = r.nextDouble() * Math.PI * 2;
                    BlockPos centre = new BlockPos(base.getX() + (int) Math.round(Math.cos(ang) * 5),
                            islandY, base.getZ() + (int) Math.round(Math.sin(ang) * 5));
                    if (level.hasChunkAt(centre) && buildIsland(player, s, centre, level)) {
                        height = islandY - base.getY() + 3;
                    }
                }
            }
            s.winds.add(base.asLong());
            s.windHeights.add(height);
            placed++;
        }
        return placed > 0;
    }

    /** Остров из облачного камня и цветов; наверху воспоминание «небо». */
    private static boolean buildIsland(ServerPlayer player, DreamState s, BlockPos c, ServerLevel level) {
        BlockState stone = ModBlocks.CLOUD_STONE.get().defaultBlockState();
        BlockState moss = ModBlocks.DREAM_MOSS.get().defaultBlockState();
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                int d2 = dx * dx + dz * dz;
                if (d2 > 10) continue;
                BlockPos top = c.offset(dx, 0, dz);
                if (!level.hasChunkAt(top)) continue;
                fakeSet(player, s, top, moss);
                if (d2 <= 5) fakeSet(player, s, top.below(), stone);
                if (d2 <= 1) fakeSet(player, s, top.below(2), stone);
                if (d2 >= 2 && d2 <= 8 && DreamBlocks.sprinkle(top.above())) {
                    fakeSet(player, s, top.above(), DreamBlocks.bloom(top.above()));
                }
            }
        }
        addMemory(player, s, c.above(), MEMORY_COUNT - 1);
        return true;
    }

    private static void tickWinds(ServerPlayer player, ServerLevel level, DreamState s, int t) {
        if (s.winds.isEmpty()) return;
        RandomSource r = player.getRandom();
        for (int i = 0; i < s.winds.size(); i++) {
            BlockPos b = BlockPos.of(s.winds.getLong(i));
            int h = s.windHeights.getInt(i);
            double cx = b.getX() + 0.5, cz = b.getZ() + 0.5;
            double dx = player.getX() - cx, dz = player.getZ() - cz;
            double d2 = dx * dx + dz * dz;
            if (d2 > 72.0 * 72.0) continue;
            if (t % 2 == 0) {
                for (int k = 0; k < 4; k++) {
                    double hy = b.getY() + r.nextDouble() * h;
                    double ang = t * 0.15 + hy * 0.35 + k * 1.57;
                    double rad = 0.5 + r.nextDouble() * 0.7;
                    level.sendParticles(player, (k & 1) == 0 ? ParticleTypes.END_ROD : ParticleTypes.CLOUD, true,
                            cx + Math.cos(ang) * rad, hy, cz + Math.sin(ang) * rad, 1, 0.0, 0.05, 0.0, 0.02);
                }
            }
            if (d2 < 1.9 * 1.9 && player.getY() > b.getY() - 1.0 && player.getY() < b.getY() + h) {
                Vec3 v = player.getDeltaMovement();
                player.setDeltaMovement(v.x * 0.92, Math.min(v.y + 0.11, 0.55), v.z * 0.92);
                player.hurtMarked = true;
                player.fallDistance = 0.0f;
            }
        }
    }

    // ------------------------------------------------------------------ звенящие плитки

    private static boolean placeTiles(ServerPlayer player, ServerLevel level, DreamState s, BlockPos origin, int t) {
        RandomSource r = player.getRandom();
        BlockPos spot = pickSpot(level, r, s, origin, 14, 32, 14, 4, 8, null);
        if (spot == null) return false;
        double base = r.nextDouble() * Math.PI * 2;
        BlockPos[] ground = new BlockPos[NOTE_SEMITONES.length];
        for (int i = 0; i < ground.length; i++) {
            double ang = base + i * (Math.PI * 0.42);
            int x = spot.getX() + (int) Math.round(Math.cos(ang) * 3.0);
            int z = spot.getZ() + (int) Math.round(Math.sin(ang) * 3.0);
            BlockPos stand = DreamManager.findGround(level, x, z, spot.getY(), 3, 4);
            if (stand == null) return false;
            BlockPos under = stand.below();
            if (!level.getBlockState(under).isCollisionShapeFullBlock(level, under)) return false;   // форма должна совпасть с плиткой
            ground[i] = under;
        }
        s.tileCenter = spot;
        for (int i = 0; i < ground.length; i++) {
            s.tiles.add(ground[i].asLong());
            s.tileLit.add(0);
            fakeSet(player, s, ground[i], ModBlocks.CHIME_TILE.get().defaultBlockState());
        }
        s.melody.clear();
        int prev = -1;
        for (int i = 0; i < 4; i++) {
            int n;
            do { n = r.nextInt(NOTE_SEMITONES.length); } while (n == prev);
            s.melody.add(n);
            prev = n;
        }
        s.melodyStep = 0;
        s.hintStep = 99;
        s.nextHintAt = t;
        return true;
    }

    private static float pitch(int idx) {
        return (float) Math.pow(2.0, (NOTE_SEMITONES[idx] - 12) / 12.0);
    }

    private static void setTile(ServerPlayer player, DreamState s, int i, boolean lit) {
        BlockPos pos = BlockPos.of(s.tiles.getLong(i));
        fakeSet(player, s, pos, (lit ? ModBlocks.CHIME_TILE_LIT : ModBlocks.CHIME_TILE).get().defaultBlockState());
    }

    private static void tickTiles(ServerPlayer player, ServerLevel level, DreamState s, int t) {
        if (s.tiles.isEmpty()) return;
        // подсветка гаснет
        for (int i = 0; i < s.tiles.size(); i++) {
            int v = s.tileLit.getInt(i);
            if (v > 0) {
                v--;
                s.tileLit.set(i, v);
                if (v == 0 && !s.melodyDone) setTile(player, s, i, false);
            }
        }
        if (s.tileCooldown > 0) s.tileCooldown--;

        // шаг на плитку
        if (player.onGround()) {
            BlockPos under = BlockPos.containing(player.getX(), player.getY() - 0.1, player.getZ());
            int idx = s.tiles.indexOf(under.asLong());
            if (idx >= 0) {
                if (idx != s.lastTile || s.tileCooldown <= 0) {
                    stepTile(player, level, s, idx, t);
                    s.lastTile = idx;
                    s.tileCooldown = 12;
                }
            } else {
                s.lastTile = -1;
            }
        }

        // подсказка: плитки сами проигрывают мелодию, когда ты рядом
        if (!s.melodyDone && s.tileCenter != null && !s.melody.isEmpty()) {
            double dx = player.getX() - s.tileCenter.getX();
            double dz = player.getZ() - s.tileCenter.getZ();
            if (dx * dx + dz * dz < 18.0 * 18.0) {
                if (s.hintStep >= s.melody.size() && t >= s.nextHintAt) {
                    s.hintStep = 0;
                    s.hintNext = t;
                }
                if (s.hintStep < s.melody.size() && t >= s.hintNext) {
                    int idx = s.melody.getInt(s.hintStep);
                    BlockPos p = BlockPos.of(s.tiles.getLong(idx));
                    s.tileLit.set(idx, 10);
                    setTile(player, s, idx, true);
                    player.connection.send(new ClientboundSoundPacket(ModSounds.TILE_NOTE, SoundSource.RECORDS,
                            p.getX() + 0.5, p.getY() + 1.0, p.getZ() + 0.5, 2.5f, pitch(idx), player.getRandom().nextLong()));
                    s.hintStep++;
                    s.hintNext = t + 16;
                    if (s.hintStep >= s.melody.size()) s.nextHintAt = t + 220;
                }
            }
        }
    }

    private static void stepTile(ServerPlayer player, ServerLevel level, DreamState s, int idx, int t) {
        BlockPos p = BlockPos.of(s.tiles.getLong(idx));
        player.playNotifySound(ModSounds.TILE_NOTE.get(), SoundSource.PLAYERS, 1.3f, pitch(idx));
        s.tileLit.set(idx, 8);
        setTile(player, s, idx, true);
        level.sendParticles(player, ParticleTypes.NOTE, true, p.getX() + 0.5, p.getY() + 1.4, p.getZ() + 0.5,
                0, idx / 4.0, 0.0, 0.0, 1.0);
        level.sendParticles(player, ParticleTypes.END_ROD, true, p.getX() + 0.5, p.getY() + 1.1, p.getZ() + 0.5,
                6, 0.3, 0.1, 0.3, 0.03);
        if (s.melodyDone || s.melody.isEmpty()) return;
        if (idx == s.melody.getInt(s.melodyStep)) {
            s.melodyStep++;
            if (s.melodyStep >= s.melody.size()) melodyDone(player, level, s);
        } else {
            s.melodyStep = idx == s.melody.getInt(0) ? 1 : 0;   // сбился: начни сначала, плитки напомнят
            s.nextHintAt = Math.min(s.nextHintAt, t + 50);
            if (s.hintStep >= s.melody.size()) s.hintStep = 99;
        }
    }

    private static void melodyDone(ServerPlayer player, ServerLevel level, DreamState s) {
        s.melodyDone = true;
        for (int i = 0; i < s.tiles.size(); i++) setTile(player, s, i, true);
        BlockPos c = s.tileCenter;
        if (c != null) {
            fakeSet(player, s, c, ModBlocks.BLOOM_GOLD.get().defaultBlockState());
            for (int i = 0; i < 4; i++) {
                BlockPos around = c.offset((i & 1) == 0 ? (i == 0 ? 1 : -1) : 0, 0, (i & 1) == 1 ? (i == 1 ? 1 : -1) : 0);
                if (level.isEmptyBlock(around) && !s.fake.containsKey(around.asLong())) {
                    fakeSet(player, s, around, DreamBlocks.bloom(around));
                }
            }
            gainLight(player, level, s, Component.translatable("message.dreams.good.melody").withStyle(ChatFormatting.GOLD),
                    c.getX() + 0.5, c.getY() + 1.2, c.getZ() + 0.5);
        }
    }

    // ------------------------------------------------------------------ Древо снов

    private static int mix(int x, int y, int z) {
        int h = x * 73856093 ^ y * 19349663 ^ z * 83492791;
        h ^= h >>> 13;
        h *= 0x5bd1e995;
        h ^= h >>> 15;
        return h & 0x7fffffff;
    }

    private static boolean placeTree(ServerPlayer player, ServerLevel level, DreamState s, BlockPos origin) {
        RandomSource r = player.getRandom();
        BlockPos b = pickSpot(level, r, s, origin, 46, 60, 20, 10, 14, null);
        if (b == null) return false;
        s.treeLogs.clear();
        s.treeLeaves.clear();
        s.treeSent = 0;
        for (int dy = 0; dy < TREE_HEIGHT; dy++) {
            double rr = dy == 0 ? 3.0 : dy < 3 ? 2.3 : 1.5;
            int ri = (int) Math.ceil(rr);
            for (int dx = -ri; dx <= ri; dx++) {
                for (int dz = -ri; dz <= ri; dz++) {
                    if (dx * dx + dz * dz <= rr * rr) {
                        s.treeLogs.add(BlockPos.asLong(b.getX() + dx, b.getY() + dy, b.getZ() + dz));
                    }
                }
            }
        }
        int cy = b.getY() + TREE_HEIGHT + 2;
        for (int dx = -10; dx <= 10; dx++) {
            for (int dy = -6; dy <= 6; dy++) {
                for (int dz = -10; dz <= 10; dz++) {
                    double e = (dx / 9.5) * (dx / 9.5) + (dy / 6.0) * (dy / 6.0) + (dz / 9.5) * (dz / 9.5);
                    if (e > 1.0) continue;
                    if (dx * dx + dz * dz <= 2 && dy < 0) continue;   // ствол проходит сквозь крону
                    if (mix(b.getX() + dx, cy + dy, b.getZ() + dz) % 100 < 80) {
                        s.treeLeaves.add(BlockPos.asLong(b.getX() + dx, cy + dy, b.getZ() + dz));
                    }
                }
            }
        }
        s.tree = b;
        return true;
    }

    private static void tickTree(ServerPlayer player, ServerLevel level, DreamState s, int t) {
        BlockPos b = s.tree;
        if (b == null) return;
        RandomSource r = player.getRandom();
        int total = s.treeLogs.size() + s.treeLeaves.size();

        // Древо вырастает постепенно, а не одним пакетом.
        if (s.treeSent < total) {
            BlockState logSt = ModBlocks.TREE_LOG.get().defaultBlockState();
            BlockState leafSt = ModBlocks.TREE_BLOSSOM.get().defaultBlockState();
            for (int n = 0; n < TREE_SEND_PER_TICK && s.treeSent < total; n++, s.treeSent++) {
                boolean isLog = s.treeSent < s.treeLogs.size();
                long key = isLog ? s.treeLogs.getLong(s.treeSent) : s.treeLeaves.getLong(s.treeSent - s.treeLogs.size());
                BlockPos p = BlockPos.of(key);
                if (level.hasChunkAt(p)) fakeSet(player, s, p, isLog ? logSt : leafSt);
            }
        }

        double dx = player.getX() - (b.getX() + 0.5);
        double dz = player.getZ() - (b.getZ() + 0.5);
        double d2 = dx * dx + dz * dz;
        double crownY = b.getY() + TREE_HEIGHT + 2;

        if (!s.treeAwake && s.lights >= DreamTimeline.GOOD_TREE_MIN && s.treeSent >= total) {
            s.treeAwake = true;
            player.displayClientMessage(Component.translatable("message.dreams.good.tree_awake")
                    .withStyle(ChatFormatting.GOLD), true);
            level.sendParticles(player, ParticleTypes.END_ROD, true, b.getX() + 0.5, crownY, b.getZ() + 0.5,
                    80, 6.0, 3.0, 6.0, 0.05);
            player.playNotifySound(ModSounds.TREE_HUM.get(), SoundSource.AMBIENT, 1.5f, 1.0f);
        }

        // Маяк: чем дальше сон, тем ярче свет над кроной; слышно из-за тумана.
        if (d2 < 100.0 * 100.0) {
            if (t % 4 == 0) {
                int sparks = s.treeAwake ? 4 : 1;
                for (int i = 0; i < sparks; i++) {
                    level.sendParticles(player, ParticleTypes.END_ROD, true,
                            b.getX() + 0.5 + (r.nextDouble() - 0.5) * 3, crownY + 4 + r.nextDouble() * (s.treeAwake ? 40 : 8),
                            b.getZ() + 0.5 + (r.nextDouble() - 0.5) * 3, 1, 0.0, 0.1, 0.0, 0.02);
                }
                if (s.treeAwake) {
                    level.sendParticles(player, ParticleTypes.CHERRY_LEAVES, true,
                            b.getX() + 0.5 + (r.nextDouble() - 0.5) * 16, crownY + 3, b.getZ() + 0.5 + (r.nextDouble() - 0.5) * 16,
                            1, 0.0, 0.0, 0.0, 0.0);
                }
            }
            if (t % 100 == 50 && d2 < 80.0 * 80.0) {
                player.connection.send(new ClientboundSoundPacket(ModSounds.TREE_HUM, SoundSource.AMBIENT,
                        b.getX() + 0.5, crownY, b.getZ() + 0.5, s.treeAwake ? 4.0f : 2.5f, s.treeAwake ? 1.0f : 0.7f, r.nextLong()));
            }
        }

        // Ты у ствола.
        if (!s.finale && d2 <= 7.0 * 7.0 && Math.abs(player.getY() - b.getY()) < 30.0 && s.treeSent >= total) {
            if (s.treeAwake) {
                startFinale(player, level, s, t);
            } else if (t >= s.nextTreeHintAt) {
                s.nextTreeHintAt = t + 120;
                player.displayClientMessage(Component.translatable("message.dreams.good.tree_sleeps",
                        s.lights, DreamTimeline.GOOD_TREE_MIN).withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC), true);
            }
        }
    }

    // ------------------------------------------------------------------ финал: вознесение

    private static void startFinale(ServerPlayer player, ServerLevel level, DreamState s, int t) {
        BlockPos b = s.tree;
        s.finale = true;
        s.finaleAt = t;
        s.finaleTime = dawnTime(s, t);
        s.finaleStartY = player.getY();
        s.finaleTeleported = false;
        double dx = b == null ? 0.0 : player.getX() - (b.getX() + 0.5);
        double dz = b == null ? 0.0 : player.getZ() - (b.getZ() + 0.5);
        s.finaleAng = Math.atan2(dz, dx);
        s.finaleRad = Mth.clamp(Math.sqrt(dx * dx + dz * dz), 4.5, 8.0);
        var ab = player.getAbilities();
        if (!ab.mayfly) {   // подъём в воздухе: без полёта сервер кикнул бы за «полёт»
            s.hadMayfly = false;
            ab.mayfly = true;
            player.onUpdateAbilities();
            s.mayflyGiven = true;
            player.getPersistentData().putBoolean(TAG_MAYFLY, true);
        }
        PacketDistributor.sendToPlayer(player, new DreamFxPayload(DreamTimeline.FX_GOOD_FINALE, DreamTimeline.GOOD_FINALE_TICKS));
        player.displayClientMessage(Component.translatable("message.dreams.good.finale")
                .withStyle(ChatFormatting.GOLD), true);
    }

    private static void tickFinale(ServerPlayer player, ServerLevel level, DreamState s, int t) {
        int ft = t - s.finaleAt;
        RandomSource r = player.getRandom();
        BlockPos b = s.tree;
        if (b == null) {
            DreamManager.end(player, s, DreamManager.Result.SUCCESS, true);
            return;
        }
        double cx = b.getX() + 0.5, cz = b.getZ() + 0.5;
        double topY = b.getY() + TREE_HEIGHT + 8 + 20.0;   // над кроной

        // Древо поднимает тебя по спирали рядом со стволом; крона расступается.
        if (ft >= 20 && ft < DreamTimeline.GOOD_FINALE_TICKS - 14) {
            double e = Mth.clamp((ft - 20) / 180.0, 0.0, 1.0);
            double ease = e * e * (3.0 - 2.0 * e);
            double yT = s.finaleStartY + (topY - s.finaleStartY) * ease;
            double ang = s.finaleAng + (ft - 20) * 0.018;
            double rad = Mth.lerp(Math.min(1.0, e * 3.0), s.finaleRad, 4.4);
            double tx = cx + Math.cos(ang) * rad, tz = cz + Math.sin(ang) * rad;
            double vy = Mth.clamp((yT - player.getY()) * 0.2, -0.1, 0.45);
            player.setDeltaMovement((tx - player.getX()) * 0.12, vy, (tz - player.getZ()) * 0.12);
            player.hurtMarked = true;
            player.fallDistance = 0.0f;
            if (e < 1.0) dissolveCrown(player, level, s);
        }

        if (ft % 2 == 0) {   // искры и лепестки вокруг
            double px = player.getX(), py = player.getY() + 1.0, pz = player.getZ();
            level.sendParticles(player, ParticleTypes.END_ROD, true, px, py, pz, 6, 3.0, 2.0, 3.0, 0.05);
            level.sendParticles(player, ParticleTypes.CHERRY_LEAVES, true, px, py + 2, pz, 6, 5.0, 3.0, 5.0, 0.0);
        }
        if (ft >= 70 && ft % 4 == 0) drawStars(player, level, s, ft);

        if (ft == 190) grantBlessing(player, s);   // в такт аккорду, на который хор разрешается
        if (ft == DreamTimeline.GOOD_FINALE_TICKS - 12 && !s.finaleTeleported) {   // экран уже белый: тихо вернуть на землю
            s.finaleTeleported = true;
            double gx = cx + Math.cos(s.finaleAng) * 6.0, gz = cz + Math.sin(s.finaleAng) * 6.0;
            BlockPos g = DreamManager.findGround(level, Mth.floor(gx), Mth.floor(gz), b.getY(), 8, 14);
            player.connection.teleport(gx, g != null ? g.getY() : b.getY(), gz, player.getYRot(), player.getXRot());
            player.setDeltaMovement(Vec3.ZERO);
            player.hurtMarked = true;
            player.fallDistance = 0.0f;
        }
        if (ft >= DreamTimeline.GOOD_FINALE_TICKS) {
            DreamManager.end(player, s, DreamManager.Result.SUCCESS, true);
        }
    }

    /** Крона расступается вокруг поднимающегося игрока (на клиенте; настоящих блоков тут нет). */
    private static void dissolveCrown(ServerPlayer player, ServerLevel level, DreamState s) {
        double px = player.getX(), py = player.getY(), pz = player.getZ();
        BlockState air = Blocks.AIR.defaultBlockState();
        for (int i = 0; i < s.treeLeaves.size(); i++) {
            long key = s.treeLeaves.getLong(i);
            BlockState cur = s.fake.get(key);
            if (cur == null || !cur.is(ModBlocks.TREE_BLOSSOM.get())) continue;
            BlockPos p = BlockPos.of(key);
            double dx = p.getX() + 0.5 - px, dz = p.getZ() + 0.5 - pz;
            if (dx * dx + dz * dz > 2.8 * 2.8 || p.getY() < py - 1.5 || p.getY() > py + 4.0) continue;
            fakeSet(player, s, p, air);
            level.sendParticles(player, ParticleTypes.END_ROD, true, p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5,
                    1, 0.25, 0.25, 0.25, 0.02);
        }
    }

    /** Каждое собранное воспоминание загорается звездой; звёзды соединяются в созвездие. */
    private static void drawStars(ServerPlayer player, ServerLevel level, DreamState s, int ft) {
        double px = player.getX(), py = player.getY(), pz = player.getZ();
        Vec3[] pos = new Vec3[DreamTimeline.GOOD_LIGHTS_TOTAL];
        int shown = 0;
        for (int i = 0; i < Math.min(s.lights, pos.length); i++) {
            if (ft < 70 + i * 14) break;
            double az = s.whaleSeed + i * 1.2566;
            double el = 0.50 + 0.22 * Math.sin(i * 2.4 + 1.0);
            pos[i] = new Vec3(px + 48.0 * Math.cos(el) * Math.cos(az), py + 48.0 * Math.sin(el), pz + 48.0 * Math.cos(el) * Math.sin(az));
            shown++;
        }
        DustParticleOptions gold = new DustParticleOptions(new Vector3f(1.0f, 0.92f, 0.55f), 3.0f);
        for (int i = 0; i < shown; i++) {
            level.sendParticles(player, gold, true, pos[i].x, pos[i].y, pos[i].z, 3, 0.25, 0.25, 0.25, 0.0);
            level.sendParticles(player, ParticleTypes.END_ROD, true, pos[i].x, pos[i].y, pos[i].z, 5, 0.9, 0.9, 0.9, 0.02);
            if (i > 0) {
                Vec3 a = pos[i - 1], c = pos[i];
                int points = (int) (a.distanceTo(c) / 2.4);
                for (int j = 1; j < points; j++) {
                    double f = j / (double) points;
                    level.sendParticles(player, ParticleTypes.END_ROD, true,
                            Mth.lerp(f, a.x, c.x), Mth.lerp(f, a.y, c.y), Mth.lerp(f, a.z, c.z), 1, 0.0, 0.0, 0.0, 0.0);
                }
            }
        }
    }

    /** Благословение растёт с числом огней. */
    private static void grantBlessing(ServerPlayer player, DreamState s) {
        int l = Mth.clamp(s.lights, 1, DreamTimeline.GOOD_LIGHTS_TOTAL);
        player.setHealth(player.getMaxHealth());
        player.getFoodData().setFoodLevel(20);
        player.getFoodData().setSaturation(20.0f);
        player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 20 * (10 + 6 * l), 1));
        player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 20 * 240, l >= 5 ? 2 : 1));
        if (l >= 4) player.addEffect(new MobEffectInstance(MobEffects.LUCK, 20 * 300, 0));
        if (l >= 5) player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 20 * 60, 0));
    }

    // ------------------------------------------------------------------ небесные киты

    private static long dawnTime(DreamState s, int t) {
        return s.timeFrom + 22600L + (long) (t * 0.5);   // золотой час тянется долго
    }

    /** Цвет китов: от бело-голубого к лавандовому и золотому по числу огней. */
    private static Vector3f whaleColor(int lights) {
        float k = Mth.clamp(lights / 5.0f, 0.0f, 1.0f);
        if (k < 0.6f) {
            float u = k / 0.6f;
            return new Vector3f(Mth.lerp(u, 0.70f, 0.86f), Mth.lerp(u, 0.92f, 0.80f), 1.0f);
        }
        float u = (k - 0.6f) / 0.4f;
        return new Vector3f(Mth.lerp(u, 0.86f, 1.0f), Mth.lerp(u, 0.80f, 0.90f), Mth.lerp(u, 1.0f, 0.55f));
    }

    private static void tickWhales(ServerPlayer player, ServerLevel level, DreamState s, int t) {
        if (!DreamConfig.COMMON.goodWhales.get() || t < 300 || t % 2 != 0) return;
        int count = s.finale || s.lights >= 4 ? 3 : s.lights >= 2 ? 2 : 1;
        double fin = s.finale ? Mth.clamp((t - s.finaleAt) / 120.0, 0.0, 1.0) : 0.0;   // в финале подплывают ближе
        DustParticleOptions dust = new DustParticleOptions(whaleColor(s.lights), 1.6f + 0.15f * s.lights);
        for (int k = 0; k < count; k++) {
            if (s.whaleBorn[k] < 0) s.whaleBorn[k] = t;
            double appear = Mth.clamp((t - s.whaleBorn[k]) / 120.0, 0.0, 1.0);   // появляются из ничего
            drawWhale(player, level, s, t, k, fin, appear, dust);
        }
    }

    /** Кит: цепочка мягких светящихся шаров вдоль волнистой дуги в небе, грудные плавники, хвост, звёздная пыль. */
    private static void drawWhale(ServerPlayer player, ServerLevel level, DreamState s, int t, int k,
                                  double fin, double appear, DustParticleOptions dust) {
        RandomSource r = player.getRandom();
        double dir = (k % 2 == 0) ? 1.0 : -1.0;
        double radius = (68 + 12 * k) * (1.0 - 0.40 * fin);
        double height = (42 + 9 * k) * (1.0 - 0.25 * fin);
        double omega = dir * (0.0030 - 0.0004 * k);
        double theta = s.whaleSeed + k * 2.1 + omega * t;
        double step = dir * 2.8 / radius;
        final int n = 22;
        double px = player.getX(), py = player.getY(), pz = player.getZ();
        double headX = 0, headY = 0, headZ = 0;
        for (int i = 0; i < n; i++) {
            double th = theta - i * step;
            double rr = radius + 2.0 * Math.sin(t * 0.03 - i * 0.3 + k);
            double ux = Math.cos(th), uz = Math.sin(th);                 // от игрока наружу
            double x = px + rr * ux, z = pz + rr * uz;
            double y = py + height + 3.2 * Math.sin(t * 0.045 - i * 0.45 + k);
            double u = i / (double) (n - 1);
            double body = Math.max(0.6, 4.6 * Math.pow(Math.sin(Math.PI * Math.pow(u, 0.8)), 0.7));
            if (i == 0) { headX = x; headY = y; headZ = z; }
            if (r.nextDouble() <= appear) {
                level.sendParticles(player, dust, true, x, y, z, 3, body * 0.45, body * 0.40, body * 0.45, 0.0);
            }
            if (i == 6 && r.nextDouble() <= appear) {   // грудные плавники
                for (int side = -1; side <= 1; side += 2) {
                    for (int j = 1; j <= 4; j++) {
                        level.sendParticles(player, dust, true, x + ux * side * j * 1.3, y - 0.5 - j * 0.5, z + uz * side * j * 1.3,
                                1, 0.1, 0.1, 0.1, 0.0);
                    }
                }
            }
            if (i == n - 1 && r.nextDouble() <= appear) {   // хвост: лопасти в стороны с загибом назад
                double tx = -Math.sin(th) * dir, tz = Math.cos(th) * dir;   // куда плывёт
                for (int side = -1; side <= 1; side += 2) {
                    for (int j = 1; j <= 5; j++) {
                        level.sendParticles(player, dust, true, x + ux * side * j * 1.2 - tx * 0.5 * j, y + 0.3 * j, z + uz * side * j * 1.2 - tz * 0.5 * j,
                                1, 0.1, 0.1, 0.1, 0.0);
                    }
                }
            }
        }
        if (r.nextDouble() <= appear) {   // звёздная пыль тянется следом
            level.sendParticles(player, ParticleTypes.END_ROD, true, headX, headY - 2.0, headZ, 2, 4.0, 1.0, 4.0, 0.01);
        }
        if (s.lights >= 1 && appear > 0.5 && t % 160 == 40 * k) {   // песня: низкий гул из точки, где плывёт голова
            player.connection.send(new ClientboundSoundPacket(ModSounds.TREE_HUM, SoundSource.AMBIENT,
                    headX, headY, headZ, 6.0f, 0.45f, r.nextLong()));
        }
    }

    // ------------------------------------------------------------------ играющий мир

    /** Пентатоника ре мажор в полутонах нотного блока (12 = питч 1.0): ля, си, ре, ми, фа#, ля, си, ре, ми, фа#. */
    private static final int[] DEG = {3, 5, 8, 10, 12, 15, 17, 20, 22, 24};

    private static float degPitch(int idx) {
        return (float) Math.pow(2.0, (DEG[Mth.clamp(idx, 0, DEG.length - 1)] - 12) / 12.0);
    }

    /** Шаги звенят блуждающей мелодией, прыжок разыгрывает арпеджио, приземление отзывается аккордом. */
    private static void tickPlayful(ServerPlayer player, ServerLevel level, DreamState s, int t) {
        RandomSource r = player.getRandom();
        boolean flying = player.getAbilities().flying;
        boolean ground = player.onGround() && !flying;
        double dx = player.getX() - s.lastX, dz = player.getZ() - s.lastZ;
        s.lastX = player.getX();
        s.lastZ = player.getZ();
        double moved = Math.sqrt(dx * dx + dz * dz);

        if (ground) {
            if (!s.wasGround && s.airTicks >= 8) {   // приземление: мягкий аккорд и лепестки
                for (int off = 0; off <= 4; off += 2) {
                    player.playNotifySound(ModSounds.STEP_NOTE.get(), SoundSource.PLAYERS, 0.4f, degPitch(s.noteIdx + off));
                }
                level.sendParticles(player, ParticleTypes.CHERRY_LEAVES, true, player.getX(), player.getY() + 0.2, player.getZ(),
                        8, 0.5, 0.2, 0.5, 0.05);
            }
            s.airTicks = 0;
            if (moved < 3.0) s.stepDist += moved;
            if (s.stepDist >= 1.45) {
                s.stepDist = 0.0;
                BlockPos under = BlockPos.containing(player.getX(), player.getY() - 0.1, player.getZ());
                if (s.tiles.indexOf(under.asLong()) < 0) {   // на звенящих плитках играют они сами
                    int[] moves = {-2, -1, -1, 0, 1, 1, 2};
                    s.noteIdx = Mth.clamp(s.noteIdx + moves[r.nextInt(moves.length)], 0, DEG.length - 1);
                    player.playNotifySound(ModSounds.STEP_NOTE.get(), SoundSource.PLAYERS, 0.5f, degPitch(s.noteIdx));
                    level.sendParticles(player, ParticleTypes.NOTE, true, player.getX(), player.getY() + 1.1, player.getZ(),
                            0, s.noteIdx / 9.0, 0.0, 0.0, 1.0);
                }
            }
        } else {
            if (s.wasGround && !flying && player.getDeltaMovement().y > 0.1) {   // оттолкнулся: арпеджио вверх
                s.arpLeft = 4;
                s.arpNext = t;
                s.arpIdx = s.noteIdx;
            }
            s.airTicks++;
        }
        s.wasGround = ground;

        if (s.arpLeft > 0 && t >= s.arpNext) {
            player.playNotifySound(ModSounds.JUMP_NOTE.get(), SoundSource.PLAYERS, 0.45f, degPitch(s.arpIdx));
            level.sendParticles(player, ParticleTypes.END_ROD, true, player.getX(), player.getY() + 0.3, player.getZ(),
                    2, 0.2, 0.1, 0.2, 0.02);
            s.arpIdx += 2;
            s.arpNext = t + 2;
            s.arpLeft--;
        }
    }

    // ------------------------------------------------------------------ чанк отправлен заново

    static void reapplyChunk(ServerPlayer player, DreamState s, ChunkPos cp) {
        s.owCount -= DreamManager.removeOwChunk(s, cp, player.getBlockY());   // тёплая волна пройдёт по чанку ещё раз
        var it = s.fake.long2ObjectEntrySet().iterator();
        while (it.hasNext()) {
            var entry = it.next();
            BlockPos pos = BlockPos.of(entry.getLongKey());
            if ((pos.getX() >> 4) != cp.x || (pos.getZ() >> 4) != cp.z) continue;
            player.connection.send(new ClientboundBlockUpdatePacket(pos, entry.getValue()));
        }
    }
}
