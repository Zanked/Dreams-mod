package com.example.dreams.network;

import com.example.dreams.Dreams;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/**
 * Сервер -> клиент: в какой фазе сна сейчас игрок (0 = сон закончился). См. DreamTimeline.PHASE_*.
 * round = номер круга (0 = первый, 1+ = после ложных выходов).
 * kind = вид сна, см. DreamTimeline.KIND_*.
 */
public record DreamPhasePayload(int phase, int round, int kind) implements CustomPacketPayload {

    public static final Type<DreamPhasePayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(Dreams.MODID, "dream_phase"));

    public static final StreamCodec<ByteBuf, DreamPhasePayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, DreamPhasePayload::phase,
            ByteBufCodecs.VAR_INT, DreamPhasePayload::round,
            ByteBufCodecs.VAR_INT, DreamPhasePayload::kind,
            DreamPhasePayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
