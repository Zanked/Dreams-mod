package com.example.dreams.client;

import com.example.dreams.DreamConfig;
import com.example.dreams.Dreams;
import com.example.dreams.entity.WatcherEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;

/**
 * Смотритель. По умолчанию это ДВОЙНИК: ваш собственный скин, вытянутый по росту, с чёрными глазами и ртом.
 * (Видим он только своему сновидцу, так что "локальный игрок" всегда и есть хозяин.)
 * Конфиг клиента doppelganger=false возвращает классическую чёрную фигуру.
 */
public class WatcherRenderer extends HumanoidMobRenderer<WatcherEntity, HumanoidModel<WatcherEntity>> {

    private static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath(Dreams.MODID, "textures/entity/watcher.png");
    private static final ResourceLocation FACE =
            ResourceLocation.fromNamespaceAndPath(Dreams.MODID, "textures/entity/watcher_face.png");

    public WatcherRenderer(EntityRendererProvider.Context context) {
        super(context, new HumanoidModel<>(context.bakeLayer(ModelLayers.ZOMBIE)), 0.0f);
        this.addLayer(new FaceLayer(this));
    }

    @Override
    public ResourceLocation getTextureLocation(WatcherEntity entity) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && DreamConfig.CLIENT.doppelganger.get()) {
            return mc.player.getSkin().texture();
        }
        return TEXTURE;
    }

    @Override
    protected void scale(WatcherEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(0.95f, 1.3f, 0.95f); // выше и тоньше человека
    }

    /** Всегда полный свет блока: фигура видна даже в тумане. */
    @Override
    protected int getBlockLightLevel(WatcherEntity entity, BlockPos pos) {
        return 15;
    }

    /** Чёрные глаза и рот поверх скина (рисуется только у двойника). Остальная текстура прозрачна. */
    private static class FaceLayer extends RenderLayer<WatcherEntity, HumanoidModel<WatcherEntity>> {
        FaceLayer(RenderLayerParent<WatcherEntity, HumanoidModel<WatcherEntity>> parent) {
            super(parent);
        }

        @Override
        public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, WatcherEntity entity,
                           float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                           float netHeadYaw, float headPitch) {
            if (!DreamConfig.CLIENT.doppelganger.get()) return;
            getParentModel().renderToBuffer(poseStack, buffer.getBuffer(RenderType.entityTranslucent(FACE)),
                    LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, -1);
        }
    }
}
