package com.example.dreams.attachment;

import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongArrayList;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;
import java.util.UUID;

/** Изменяемое состояние сна игрока. Живёт только на сервере, не сохраняется. */
public class DreamState {

    public enum Phase {
        IDLE,        // не спит
        NORMAL,      // спит, кошмар не выпал
        SLEEP,       // кошмар: лежит в кровати
        FALSE_AWAKE  // "ложное пробуждение": уже встал, но сон продолжается
    }

    /** Вид сна: выбирается при засыпании. */
    public enum Kind { NIGHTMARE, OTHERWORLD, GOOD }

    public Kind kind = Kind.NIGHTMARE;
    public Phase phase = Phase.IDLE;
    public int ticks = 0;
    @Nullable public BlockPos bed = null;
    public long timeFrom = 0L;
    public int repeats = 0;   // сколько раз уже был ложный выход
    @Nullable public UUID watcherId = null;
    // расписание эффектов (тик внутри сна; 0 = ещё не назначено)
    public int nextSoundAt = 0;
    public int nextTextAt = 0;
    public int nextFlashAt = 0;
    public int nextNauseaAt = 0;
    public boolean nauseaOn = false;
    // этап 8: Иная сторона
    public boolean otherworld = false;
    public int nextSirenAt = 0;
    public int sirenUntil = 0;
    /** Уже обработанные "колонки" (x, полоса высоты 16, z). */
    public final LongOpenHashSet owDone = new LongOpenHashSet();
    /** chunk.asLong() -> позиции, подменённые в Иной стороне (нужны, чтобы вернуть мир после сна). */
    public final Long2ObjectOpenHashMap<LongArrayList> owPos = new Long2ObjectOpenHashMap<>();
    public int owCount = 0;
    // этап 9: ритуал, Палач, фигуры
    /** Позиции оснований печатей (столб = основание + блок выше). */
    public final LongArrayList seals = new LongArrayList();
    public int sealMask = 0;                    // бит i = печать i погашена
    @Nullable public UUID executionerId = null;
    public boolean execArmed = false;           // пора выпускать Палача
    public int sirenCount = 0;
    public double execLastX = 0;
    public double execLastZ = 0;
    public int execStuck = 0;
    public final java.util.List<UUID> figures = new java.util.ArrayList<>();
    // добрый сон
    /** Основания столбов-воспоминаний (столб = основание + блок выше). */
    public final LongArrayList memories = new LongArrayList();
    public final IntArrayList memTypes = new IntArrayList();
    public int memMask = 0;                     // бит i = воспоминание i собрано
    /** Звенящие плитки (позиция земли под ногами) и индекс ноты каждой. */
    public final LongArrayList tiles = new LongArrayList();
    public final IntArrayList tileLit = new IntArrayList();   // тиков подсветки осталось
    public final IntArrayList melody = new IntArrayList();
    @Nullable public BlockPos tileCenter = null;
    public int melodyStep = 0;
    public boolean melodyDone = false;
    public int hintStep = 99;
    public int hintNext = 0;
    public int nextHintAt = 0;
    public int tileCooldown = 0;
    public int lastTile = -1;
    /** Ленты ветра: основание и высота. */
    public final LongArrayList winds = new LongArrayList();
    public final IntArrayList windHeights = new IntArrayList();
    // Древо снов
    @Nullable public BlockPos tree = null;
    public final LongArrayList treeLogs = new LongArrayList();
    public final LongArrayList treeLeaves = new LongArrayList();
    public int treeSent = 0;
    public boolean treeAwake = false;
    public int nextTreeHintAt = 0;
    public int lights = 0;                      // собрано огней
    public boolean finale = false;
    public int finaleAt = 0;
    public int placeTry = 0;                    // счётчик попыток расстановки (чанк мог быть не загружен)
    public boolean memPlaced = false;
    public boolean windPlaced = false;
    public boolean tilesPlaced = false;
    public boolean treePlaced = false;
    public boolean mayflyGiven = false;
    public boolean hadMayfly = false;
    public boolean rainStopped = false;
    // киты, вознесение, играющий мир
    public double whaleSeed = 0.0;
    public final int[] whaleBorn = {-1, -1, -1};
    public double finaleAng = 0.0, finaleStartY = 0.0, finaleRad = 6.0;
    public long finaleTime = 0L;
    public boolean finaleTeleported = false;
    public int noteIdx = 4;
    public double stepDist = 0.0, lastX = 0.0, lastZ = 0.0;
    public boolean wasGround = true;
    public int airTicks = 0, arpLeft = 0, arpNext = 0, arpIdx = 0;

    /** pos.asLong() -> фейковый блок, отправленный игроку. */
    public final Long2ObjectOpenHashMap<BlockState> fake = new Long2ObjectOpenHashMap<>();

    public void reset() {
        phase = Phase.IDLE;
        kind = Kind.NIGHTMARE;
        ticks = 0;
        bed = null;
        timeFrom = 0L;
        watcherId = null;
        repeats = 0;
        clearSchedule();
        fake.clear();
    }

    /** Сбросить расписание эффектов (новый круг сна). */
    public void clearSchedule() {
        nextSoundAt = 0;
        nextTextAt = 0;
        nextFlashAt = 0;
        nextNauseaAt = 0;
        nauseaOn = false;
        otherworld = false;
        nextSirenAt = 0;
        sirenUntil = 0;
        owDone.clear();
        owPos.clear();
        owCount = 0;
        seals.clear();
        sealMask = 0;
        executionerId = null;
        execArmed = false;
        sirenCount = 0;
        execStuck = 0;
        figures.clear();
        memories.clear(); memTypes.clear(); memMask = 0;
        tiles.clear(); tileLit.clear(); melody.clear(); tileCenter = null;
        melodyStep = 0; melodyDone = false; hintStep = 99; hintNext = 0; nextHintAt = 0; tileCooldown = 0; lastTile = -1;
        winds.clear(); windHeights.clear();
        tree = null; treeLogs.clear(); treeLeaves.clear(); treeSent = 0; treeAwake = false; nextTreeHintAt = 0;
        lights = 0; finale = false; finaleAt = 0; placeTry = 0;
        java.util.Arrays.fill(whaleBorn, -1);
        finaleTeleported = false; noteIdx = 4; stepDist = 0.0; wasGround = true; airTicks = 0; arpLeft = 0; arpNext = 0; arpIdx = 0;
        memPlaced = false; windPlaced = false; tilesPlaced = false; treePlaced = false;
        // mayflyGiven / hadMayfly / rainStopped НЕ трогаем: их снимает GoodDream.cleanup
    }
}
