"""Этап 9: плейсхолдеры (executioner 128x128, figure 64x64, seal, seal_done). Нужен Pillow.
Запуск: python3 gen_textures9.py src/main/resources/assets/dreams/textures
Раскладка executioner.png: слева сверху 64x32 - обычный гуманоид, справа шлем (4 ступени) и клинок (см. ExecutionerModel)."""
import os, sys, random, math
from PIL import Image, ImageDraw

OUT = sys.argv[1] if len(sys.argv) > 1 else "."
os.makedirs(os.path.join(OUT, "entity"), exist_ok=True)
os.makedirs(os.path.join(OUT, "block"), exist_ok=True)
R = random.Random(909)

def cl(v): return max(0, min(255, int(v)))
def mulc(c, k): return tuple(cl(x * k) for x in c)
def mix(a, b, t): return tuple(cl(x + (y - x) * t) for x, y in zip(a, b))

def noise_fill(img, box, base, var=14, k=1.0):
    x0, y0, w, h = box
    px = img.load()
    for y in range(y0, y0 + h):
        for x in range(x0, x0 + w):
            n = R.randint(-var, var)
            px[x, y] = (cl(base[0] * k + n), cl(base[1] * k + n * 0.8), cl(base[2] * k + n * 0.8), 255)

def blobs(img, box, color, count, rmin, rmax, alpha=0.8):
    x0, y0, w, h = box
    px = img.load()
    for _ in range(count):
        cx, cy, r = R.randint(x0, x0 + w - 1), R.randint(y0, y0 + h - 1), R.randint(rmin, rmax)
        for y in range(max(y0, cy - r), min(y0 + h, cy + r + 1)):
            for x in range(max(x0, cx - r), min(x0 + w, cx + r + 1)):
                if (x - cx) ** 2 + (y - cy) ** 2 <= r * r and R.random() < alpha:
                    px[x, y] = mix(px[x, y][:3], color, 0.75) + (255,)

def paint_box(img, u, v, w, h, d, base, var=12, top=1.25, side=0.85, streaks=True, edge=0.55):
    """Красит все 6 граней блока w x h x d с UV-раскладкой Minecraft."""
    faces = [((u + d, v, w, d), top), ((u + d + w, v, w, d), 0.6),
             ((u, v + d, d, h), side), ((u + d, v + d, w, h), 1.0),
             ((u + d + w, v + d, d, h), side * 0.9), ((u + 2 * d + w, v + d, w, h), 0.8)]
    px = img.load()
    for (x0, y0, fw, fh), k in faces:
        noise_fill(img, (x0, y0, fw, fh), base, var, k)
        if streaks:
            for _ in range(max(1, fw // 3)):
                sx = R.randint(x0, x0 + fw - 1); sy = R.randint(y0, y0 + fh - 1)
                for i in range(R.randint(3, 9)):
                    if sy + i < y0 + fh:
                        px[sx, sy + i] = mulc(px[sx, sy + i][:3], 0.7) + (255,)
        for x in range(x0, x0 + fw):                       # тёмные рёбра граней
            px[x, y0] = mulc(px[x, y0][:3], edge) + (255,); px[x, y0 + fh - 1] = mulc(px[x, y0 + fh - 1][:3], edge) + (255,)
        for y in range(y0, y0 + fh):
            px[x0, y] = mulc(px[x0, y][:3], edge) + (255,); px[x0 + fw - 1, y] = mulc(px[x0 + fw - 1, y][:3], edge) + (255,)

# ---------------------------------------------------------------- Палач
ex = Image.new("RGBA", (128, 128), (0, 0, 0, 0))
noise_fill(ex, (0, 0, 64, 32), (58, 38, 36), 10)              # тёмная плоть/ткань
blobs(ex, (0, 0, 64, 32), (92, 12, 14), 26, 1, 3, 0.9)         # кровь
noise_fill(ex, (0, 0, 32, 16), (14, 10, 10), 4)                # голова (под шлемом)
noise_fill(ex, (20, 20, 8, 12), (88, 58, 38), 10)              # кожаный фартук на груди
blobs(ex, (20, 20, 8, 12), (84, 10, 12), 9, 1, 3, 0.9)
d = ImageDraw.Draw(ex)
d.line([(20, 21), (27, 21)], fill=(30, 20, 14, 255)); d.line([(21, 20), (21, 31)], fill=(40, 26, 18, 255))
# шлем: ржавое железо, тёмнее и грязнее к основанию
RUSTI = (104, 62, 40)
paint_box(ex, 64, 0, 10, 9, 10, RUSTI, 10, 1.3, 0.8)
paint_box(ex, 64, 20, 8, 4, 8, RUSTI, 10, 1.3, 0.85)
paint_box(ex, 64, 33, 6, 4, 6, mulc(RUSTI, 1.1), 10, 1.3, 0.9)
paint_box(ex, 64, 44, 4, 4, 4, mulc(RUSTI, 1.2), 10, 1.3, 0.9)
blobs(ex, (64, 0, 40, 19), (82, 10, 12), 8, 1, 3, 0.9)         # кровь на основании шлема
# клинок: тёмная сталь, кровь у острия
paint_box(ex, 104, 0, 1, 18, 6, (92, 88, 86), 8, 1.2, 0.9)
blobs(ex, (104, 12, 14, 12), (96, 10, 12), 10, 1, 2, 0.9)
ex.save(os.path.join(OUT, "entity", "executioner.png"))

# ---------------------------------------------------------------- Лежащая фигура
fg = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
noise_fill(fg, (0, 0, 64, 32), (166, 162, 154), 9)             # пепельная кожа
BAND = (206, 200, 184)
for y in range(16, 32, 3):                                      # бинты на теле, руках, ногах
    for (x0, x1) in ((16, 40), (40, 56), (0, 16)):
        for x in range(x0, x1):
            if R.random() < 0.96:
                fg.putpixel((x, y), BAND + (255,)); fg.putpixel((x, y + 1), mulc(BAND, 0.8) + (255,))
for y in range(0, 16, 3):                                       # бинты на голове
    for x in range(0, 32):
        if not (8 <= x < 16 and 8 <= y < 16):
            fg.putpixel((x, y), BAND + (255,)); fg.putpixel((x, min(15, y + 1)), mulc(BAND, 0.8) + (255,))
blobs(fg, (0, 16, 56, 16), (96, 14, 16), 22, 1, 3, 0.9)
blobs(fg, (0, 0, 32, 16), (96, 14, 16), 6, 1, 2, 0.9)
# лицо (8..15, 8..15): пустые глаза и грубо зашитый рот
for (x, y) in [(9, 11), (10, 11), (9, 12), (10, 12), (13, 11), (14, 11), (13, 12), (14, 12)]:
    fg.putpixel((x, y), (6, 4, 4, 255))
for x in range(10, 14): fg.putpixel((x, 14), (40, 18, 18, 255))
for x in (10, 12): fg.putpixel((x, 13), (40, 18, 18, 255)); fg.putpixel((x, 15), (40, 18, 18, 255))
noise_fill(fg, (32, 0, 32, 16), (0, 0, 0), 0)                   # hat-слой: прозрачный
for x in range(32, 64):
    for y in range(0, 16): fg.putpixel((x, y), (0, 0, 0, 0))
fg.save(os.path.join(OUT, "entity", "figure.png"))

# ---------------------------------------------------------------- Печати (32x32 x 4 кадра)
def seal_frames(done):
    img = Image.new("RGBA", (32, 128), (0, 0, 0, 255))
    px = img.load()
    for f in range(4):
        oy = f * 32
        pulse = [0.6, 0.8, 1.0, 0.8][f] if done else 1.0
        base = (22, 26, 34) if done else (26, 3, 5)
        core = (150, 176, 204) if done else (255, 74, 50)
        for y in range(32):
            for x in range(32):
                n = R.randint(-5, 5)
                c = (cl(base[0] + n), cl(base[1] + n), cl(base[2] + n))
                dx = abs(x - 16)
                glow = max(0.0, 1.0 - dx / 7.0) ** 1.6 * pulse        # свечение от оси
                c = mix(c, core, glow * (0.5 if done else 0.75))
                if dx <= 1: c = mix(c, core, 0.85 * pulse)             # яркая жила
                # руны: короткие поперечные метки, едут вверх по кадрам
                yy = (y + (0 if done else f * 8)) % 32
                if yy % 8 in (2, 3) and 11 <= x <= 21 and (x + yy // 8) % 3 != 0:
                    c = mix(c, core, 0.9 * pulse)
                px[x, oy + y] = c + (255,)
        # верх/низ (область 10..22): круг-печать
        cx, cy = 16, 16
        for y in range(10, 22):
            for x in range(10, 22):
                r = math.hypot(x - cx + 0.5, y - cy + 0.5)
                if 4.2 <= r <= 5.2 or (abs(x - cx) <= 0 and r < 5) or (abs(y - cy) <= 0 and r < 5):
                    px[x, oy + y] = mix(px[x, oy + y][:3], core, 0.95 * pulse) + (255,)
    return img
seal_frames(False).save(os.path.join(OUT, "block", "seal.png"))
seal_frames(True).save(os.path.join(OUT, "block", "seal_done.png"))
open(os.path.join(OUT, "block", "seal.png.mcmeta"), "w").write('{ "animation": { "frametime": 3, "interpolate": true } }\n')
open(os.path.join(OUT, "block", "seal_done.png.mcmeta"), "w").write('{ "animation": { "frametime": 14, "interpolate": true } }\n')
print("ok")
