"""Добрый сон: синтез сакрального хора кодом (numpy/scipy) -> стерео .ogg
Запуск:  python3 gen_choir.py src/main/resources/assets/dreams/sounds [--preview <папка>]

Выход:
  choir_base.ogg   - 4 партии (бас/тенор/альт/сопрано), формантные гласные, вибрато, детюн
  choir_organ.ogg  - церковный орган (педаль 16', принципал, октава, квинта, микстура) и далёкий колокол
  choir_high.ogg   - дескант (высокие голоса, октавой выше сопрано)
  choir_finale.ogg - финал у Древа: Asus - A - G (аминь, плагаль) - D, полный состав, длинный хвост

Три слоя одинаковой длины и сворачиваются в петлю без стыка (хвост реверберации ложится на начало),
клиент запускает их одновременно и ведёт громкость каждого по прогрессу сна.
Тональность D. Цикл: D - A/C# - Bm - F#m/A - G - D/F# - Em7 - Asus4 - A (и снова D).
Свой хор: положи .ogg с теми же именами (для музыки можно стерео)."""
import os, sys, subprocess, tempfile, time
import numpy as np
from scipy import signal
from scipy.io import wavfile
from scipy.ndimage import uniform_filter1d

SR = 32000
args = [a for a in sys.argv[1:] if not a.startswith("--")]
OUT = args[0] if args else "."
PREVIEW = None
if "--preview" in sys.argv:
    i = sys.argv.index("--preview")
    PREVIEW = sys.argv[i + 1] if i + 1 < len(sys.argv) else "."
os.makedirs(OUT, exist_ok=True)
if PREVIEW:
    os.makedirs(PREVIEW, exist_ok=True)
T0 = time.time()

def log(m): print(f"[{time.time() - T0:5.1f}s] {m}", flush=True)
def mtof(m): return 440.0 * 2 ** ((np.asarray(m, dtype=float) - 69) / 12)
def sosf(kind, fc, o=2): return signal.butter(o, np.array(fc) / (SR / 2), kind, output="sos")
def lp(x, fc, o=4): return signal.sosfilt(sosf("low", min(fc, SR / 2 - 200), o), x)
def hp(x, fc, o=2): return signal.sosfilt(sosf("high", fc, o), x)
def bp(x, c, rel): return signal.sosfilt(sosf("band", [c * (1 - rel), min(c * (1 + rel), SR / 2 - 200)], 2), x)
def smooth(y, k):
    w = np.hanning(k * 2 + 1); w /= w.sum()
    return signal.fftconvolve(np.pad(y, k, mode="edge"), w, mode="same")[k:-k]

# --------------------------------------------------------------- партитуры (midi)
# (длительность, бас, тенор, альт, сопрано, гласные, накал 0..1)
LOOP = [
    (8.0, 38, 57, 66, 74, ("oo", "ah"), 0.80),   # D
    (8.0, 37, 57, 64, 73, ("ah", "ah"), 0.82),   # A/C#
    (8.0, 47, 54, 62, 71, ("ah", "oh"), 0.84),   # Bm
    (8.0, 45, 54, 61, 69, ("oh", "ah"), 0.84),   # F#m/A
    (8.0, 43, 59, 67, 74, ("ah", "ah"), 0.88),   # G
    (8.0, 42, 62, 69, 78, ("ah", "ah"), 0.92),   # D/F#
    (8.0, 40, 62, 67, 76, ("ah", "oh"), 0.92),   # Em7
    (4.0, 45, 57, 64, 74, ("ah", "ah"), 0.94),   # Asus4
    (4.0, 45, 57, 64, 73, ("ah", "ah"), 0.90),   # A  -> снова D
]
FINALE = [
    (3.0, 45, 57, 64, 74, ("ah", "ah"), 0.95),   # Asus4
    (3.0, 45, 57, 64, 73, ("ah", "ah"), 1.00),   # A
    (3.5, 43, 59, 67, 74, ("ah", "oh"), 1.00),   # G (аминь: плагаль)
    (7.0, 38, 57, 66, 74, ("oh", "oo"), 0.90),   # D, тает
]
PARTS = ["bass", "tenor", "alto", "sop", "desc"]
VOW = {
    "bass":  {"ah": (600, 1040, 2250), "oh": (400, 750, 2400), "oo": (350, 600, 2400)},
    "tenor": {"ah": (650, 1080, 2650), "oh": (400, 800, 2600), "oo": (290, 610, 2150)},
    "alto":  {"ah": (800, 1150, 2800), "oh": (450, 800, 2830), "oo": (325, 700, 2530)},
    "sop":   {"ah": (850, 1220, 2810), "oh": (450, 800, 2830), "oo": (325, 700, 2700)},
}
VOW["desc"] = VOW["sop"]
LEVEL = {"bass": 1.1, "tenor": 0.85, "alto": 0.8, "sop": 0.72, "desc": 0.55}
COPIES = {"bass": 3, "tenor": 3, "alto": 4, "sop": 5, "desc": 5}

class Piece:
    def __init__(self, ch, seed):
        self.ch = ch
        self.seed = seed
        self.rng = np.random.default_rng(seed)
        self.total = sum(c[0] for c in ch)
        self.N = int(self.total * SR)
        self.t = np.arange(self.N) / SR
        self.starts = np.cumsum([0] + [c[0] for c in ch])
        self.intens = self.curve([c[6] for c in ch], 2.5)
        self.wts = self.vowel_weights()

    def curve(self, vals, glide):
        y = np.zeros(self.N)
        for i, v in enumerate(vals):
            y[int(self.starts[i] * SR):int(self.starts[i + 1] * SR)] = v
        return smooth(y, int(glide * SR))

    def vowel_weights(self):
        w = {"ah": np.zeros(self.N), "oh": np.zeros(self.N), "oo": np.zeros(self.N)}
        for i, c in enumerate(self.ch):
            a = int(self.starts[i] * SR); b = int(self.starts[i + 1] * SR); m = (a + b) // 2
            v1, v2 = c[5]
            w[v1][a:m] += 1.0; w[v2][m:b] += 1.0
        for key in w:
            w[key] = smooth(w[key], int(1.4 * SR))
        return w

    def breaths(self):
        e = np.ones(self.N)
        for i in range(len(self.ch)):
            a = int(self.starts[i] * SR); k = int(0.8 * SR)
            e[a:a + k] *= 0.88 + 0.12 * np.linspace(0, 1, k)
        return e

    def voice_source(self, f_curve, copies, seed):
        r = np.random.default_rng(seed)
        t = self.t
        out = np.zeros(self.N)
        for c in range(copies):
            cents = r.uniform(-7, 7)
            vr = r.uniform(4.6, 5.6)
            vd = r.uniform(0.09, 0.16) * np.clip((t - 1.0) / 3.0, 0, 1)
            drift = np.cumsum(r.standard_normal(self.N)) * 0.0000025
            drift = drift - uniform_filter1d(drift, 30000, mode="nearest")
            vib = np.sin(2 * np.pi * vr * t + r.uniform(0, 6.28)) * vd * 0.0595 + drift * 6
            f = f_curve * 2 ** (cents / 1200) * (1 + vib)
            ph = 2 * np.pi * np.cumsum(f) / SR
            s = 2 * ((ph / (2 * np.pi)) % 1.0) - 1
            s = lp(s, 6500, 2)
            sw = 1 + 0.08 * np.sin(2 * np.pi * r.uniform(0.06, 0.15) * t + r.uniform(0, 6.28))
            out += s * sw / np.sqrt(copies)
        return out

    def render_part(self, pi, part):
        if part == "desc":
            midi = self.curve([c[4] + 12 for c in self.ch], 0.6)
        else:
            midi = self.curve([c[1 + pi] for c in self.ch], 0.4 + 0.08 * pi)
        src = self.voice_source(mtof(midi), COPIES[part], self.seed * 7 + pi)
        y = np.zeros(self.N)
        for v in ("ah", "oh", "oo"):
            f1, f2, f3 = VOW[part][v]
            f = 1.0 * bp(src, f1, 0.14) + 0.55 * bp(src, f2, 0.14) + 0.28 * bp(src, f3, 0.14) + 0.14 * bp(src, 3100, 0.18)
            y += f * self.wts[v]
        air = bp(self.rng.standard_normal(self.N), 4200, 0.5) * 0.02 * np.abs(y).max()
        return (y + air) * LEVEL[part]

    def organ(self, dynamic):
        def pipes(midi, hs, gain):
            ph = 2 * np.pi * np.cumsum(mtof(midi)) / SR
            return gain * sum(a * np.sin(h * ph + self.rng.uniform(0, 6.28)) for h, a in hs)
        full = [(1, 1.0), (2, 0.7), (3, 0.45), (4, 0.35), (5, 0.18), (6, 0.12), (8, 0.07)]
        c = self.ch
        out = pipes(self.curve([x[1] - 12 for x in c], 0.5), [(1, 1.0), (2, 0.5), (3, 0.2)], 0.55)
        out += pipes(self.curve([x[1] for x in c], 0.5), full[:4], 0.28)
        for pi in (1, 2, 3):
            out += pipes(self.curve([x[1 + pi] for x in c], 0.5), full[:5], 0.15)
        out += pipes(self.curve([x[4] + 12 for x in c], 0.5), [(1, 1.0), (2, 0.4)], 0.07) * self.intens ** 2
        out = lp(out, 3200, 2)
        return out * ((0.25 + 0.75 * self.intens) if dynamic else 0.7)

    def bells(self, times, base_midi=50, gain=0.07):
        b = np.zeros(self.N)
        f0 = mtof(base_midi)
        for at, g in times:
            d = 14.0
            tt = np.arange(int(d * SR)) / SR
            parts = ((1.0, 1.0, 5.0), (2.0, 0.6, 3.5), (2.4, 0.45, 3.0), (3.0, 0.4, 2.2), (4.0, 0.3, 1.6), (5.95, 0.18, 0.9))
            s = sum(a * np.sin(2 * np.pi * f0 * m * tt + self.rng.uniform(0, 6.28)) * np.exp(-tt / tau) for m, a, tau in parts)
            s *= np.clip(tt / 0.004, 0, 1)
            i = int(at * SR); n = min(len(s), self.N - i)
            if n > 0:
                b[i:i + n] += s[:n] * gain * g
        return b

def cathedral(x, wet=0.6, length=8.0, predelay=0.06, seed=9000):
    """Стерео соборная реверберация. Возвращает ПОЛНЫЙ результат с хвостом, shape (n + ir, 2)."""
    outs = []
    n_ir = int(length * SR)
    for ch in range(2):
        r = np.random.default_rng(seed + ch)
        tt = np.arange(n_ir) / SR
        ir = r.standard_normal(n_ir) * np.exp(-tt / (length / 5.4))
        ir = hp(lp(ir, 3200, 2), 100, 1)
        ir[:int(predelay * SR)] = 0
        ir /= np.sqrt(np.sum(ir ** 2))
        wetsig = signal.fftconvolve(x, ir)
        dry = np.zeros_like(wetsig)
        dry[:len(x)] = x
        outs.append(dry * (1 - wet) * 0.75 + wetsig * wet * 2.7)
    return np.stack(outs, axis=1)

def fold_loop(st, n):
    """Хвост реверберации ложится на начало: цикл без стыка."""
    out = st[:n].copy()
    tail = st[n:]
    k = min(len(tail), n)
    out[:k] += tail[:k]
    return out

def edge(x, sec=0.35):
    k = int(sec * SR)
    x = x.copy()
    x[:k] *= np.linspace(0, 1, k) ** 1.5
    x[-k:] *= np.linspace(1, 0, k) ** 1.5
    return x

def _wav(stereo, d):
    wav = os.path.join(d, "x.wav")
    wavfile.write(wav, SR, (np.clip(stereo, -1, 1) * 32767).astype(np.int16))
    return wav

def to_ogg(stereo, path, q=4):
    with tempfile.TemporaryDirectory() as d:
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", _wav(stereo, d), "-c:a", "libvorbis", "-q:a", str(q), path], check=True)

def to_mp3(stereo, path):
    with tempfile.TemporaryDirectory() as d:
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", _wav(stereo, d), "-c:a", "libmp3lame", "-q:a", "3", path], check=True)

def build_loop():
    P = Piece(LOOP, 11)
    log(f"цикл {P.total:.0f} с")
    base = np.zeros(P.N)
    for pi, part in enumerate(PARTS[:4]):
        base += P.render_part(pi, part)
        log("  " + part)
    base *= P.breaths() * (0.55 + 0.45 * P.intens)
    organ = P.organ(dynamic=False) + P.bells([(0.5, 0.8), (32.5, 0.6)])
    high = P.render_part(4, "desc") * (0.55 + 0.45 * P.intens)
    stems = {}
    for name, x, wet in (("choir_base", base, 0.6), ("choir_organ", organ, 0.55), ("choir_high", high, 0.7)):
        x = lp(edge(x), 8500, 2)
        stems[name] = fold_loop(cathedral(x, wet=wet), P.N)
    # общий коэффициент: при полной громкости всех слоёв пик ~0.85
    peak = np.max(np.abs(sum(stems.values())))
    k = 0.85 / max(peak, 1e-6)
    for name in list(stems):
        out = np.tanh(np.nan_to_num(stems[name]) * k)
        to_ogg(out, os.path.join(OUT, name + ".ogg"))
        stems[name] = out
        log(name)
    if PREVIEW:
        mix = stems["choir_base"] * 0.8 + stems["choir_organ"] * 0.55 + stems["choir_high"] * 0.5
        mix = np.concatenate([mix, mix])   # две петли подряд: слышно, что стыка нет
        to_mp3(mix / max(1.0, np.max(np.abs(mix))), os.path.join(PREVIEW, "choir_loop_x2_preview.mp3"))

def build_finale():
    P = Piece(FINALE, 23)
    log(f"финал {P.total:.1f} с")
    mix = np.zeros(P.N)
    for pi, part in enumerate(PARTS):
        mix += P.render_part(pi, part)
        log("  " + part)
    mix *= P.breaths() * (0.5 + 0.5 * P.intens)
    mix += P.organ(dynamic=True)
    mix = lp(mix, 8500, 2)
    k = int(0.5 * SR)
    mix[:k] *= np.linspace(0, 1, k) ** 1.5
    st = cathedral(mix, wet=0.62, length=9.0)
    bell = cathedral(P.bells([(0.2, 1.0), (6.5, 0.9)], gain=0.09), wet=0.55, length=9.0)
    n = max(len(st), len(bell))
    full = np.zeros((n, 2))
    full[:len(st)] += st
    full[:len(bell)] += bell
    tail = int(2.0 * SR)
    full[-tail:] *= np.linspace(1, 0, tail)[:, None]
    full = np.tanh(np.nan_to_num(full) / max(np.max(np.abs(full)), 1e-6) * 0.86)
    to_ogg(full, os.path.join(OUT, "choir_finale.ogg"))
    log("choir_finale")
    if PREVIEW:
        to_mp3(full, os.path.join(PREVIEW, "choir_finale_preview.mp3"))

if __name__ == "__main__":
    build_loop()
    build_finale()
    log("готово")
