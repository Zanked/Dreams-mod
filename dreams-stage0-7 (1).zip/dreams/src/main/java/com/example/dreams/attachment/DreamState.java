package com.example.dreams.attachment;

import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;
import java.util.UUID;

/** Изменяемое состояние сна игрока. Живёт только на сервере, не сохраняется. */
public class DreamState {

    public enum Phase {
        IDLE,        // не спит
        NORMAL,      // спит, кошмар не выпал
        SLEEP,       // кошмар: лежит в кровати
        FALSE_AWAKE  // "ложное пробуждение": уже встал, но сон продолжается
    }

    public Phase phase = Phase.IDLE;
    public int ticks = 0;
    @Nullable public BlockPos bed = null;
    public long timeFrom = 0L;
    public int repeats = 0;   // сколько раз уже был ложный выход
    @Nullable public UUID watcherId = null;
    // расписание эффектов (тик внутри сна; 0 = ещё не назначено)
    public int nextSoundAt = 0;
    public int nextTextAt = 0;
    public int nextFlashAt = 0;
    public int nextNauseaAt = 0;
    public boolean nauseaOn = false;
    /** pos.asLong() -> фейковый блок, отправленный игроку. */
    public final Long2ObjectOpenHashMap<BlockState> fake = new Long2ObjectOpenHashMap<>();

    public void reset() {
        phase = Phase.IDLE;
        ticks = 0;
        bed = null;
        timeFrom = 0L;
        watcherId = null;
        repeats = 0;
        clearSchedule();
        fake.clear();
    }

    /** Сбросить расписание эффектов (новый круг сна). */
    public void clearSchedule() {
        nextSoundAt = 0;
        nextTextAt = 0;
        nextFlashAt = 0;
        nextNauseaAt = 0;
        nauseaOn = false;
    }
}
