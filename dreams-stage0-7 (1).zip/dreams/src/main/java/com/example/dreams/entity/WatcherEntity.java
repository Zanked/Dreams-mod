package com.example.dreams.entity;

import com.example.dreams.attachment.DreamState;
import com.example.dreams.attachment.ModAttachments;
import com.example.dreams.sound.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;
import java.util.UUID;

/**
 * Смотритель. Настоящая сущность, но видна ТОЛЬКО своему сновидцу (broadcastToPlayer).
 * Вся логика движения ("двигается, пока не смотришь") живёт в DreamManager;
 * здесь только невидимость для других, неуязвимость и самоуничтожение вместе со сном.
 */
public class WatcherEntity extends PathfinderMob {

    @Nullable
    private UUID owner;

    public WatcherEntity(EntityType<? extends WatcherEntity> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
        this.xpReward = 0;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0)
                .add(Attributes.MOVEMENT_SPEED, 0.12)
                .add(Attributes.FOLLOW_RANGE, 48.0);
    }

    public void setOwner(UUID owner) {
        this.owner = owner;
    }

    /** Остальные игроки её вообще не получают. */
    @Override
    public boolean broadcastToPlayer(ServerPlayer player) {
        return owner != null && owner.equals(player.getUUID());
    }

    @Override public boolean shouldBeSaved() { return false; }
    @Override public boolean isInvulnerableTo(DamageSource source) { return true; }
    @Override public boolean isAttackable() { return false; }
    @Override public boolean isPickable() { return false; }
    @Override public boolean isPushable() { return false; }
    @Override public boolean removeWhenFarAway(double distanceSqr) { return false; }

    @Nullable
    private ServerPlayer getOwnerPlayer() {
        if (owner == null || !(level() instanceof ServerLevel sl)) return null;
        return sl.getServer().getPlayerList().getPlayer(owner);
    }

    /** Тяжёлые шаги слышит только сновидец. */
    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        ServerPlayer p = getOwnerPlayer();
        if (p == null) return;
        p.connection.send(new ClientboundSoundPacket(
                ModSounds.WATCHER_STEP,
                SoundSource.HOSTILE, getX(), getY(), getZ(), 1.6f, 0.7f, random.nextLong()));
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide || tickCount % 10 != 0) return;
        // Сон кончился / игрок ушёл / сменил измерение -> исчезаем.
        ServerPlayer p = getOwnerPlayer();
        boolean valid = p != null
                && p.level() == level()
                && p.getData(ModAttachments.DREAM_STATE).phase == DreamState.Phase.FALSE_AWAKE;
        if (!valid) discard();
    }
}
