package com.example.dreams.dream;

import com.example.dreams.block.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.LanternBlock;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

/**
 * Правила подмены: настоящий блок -> кошмарный фейк.
 * ВАЖНО: форма коллизии фейка должна совпадать с оригиналом, иначе сервер откатит движение игрока.
 * Вариант фейка зависит от позиции (hash), а не от случая: так повторная подмена даёт тот же блок.
 */
public class DreamBlocks {

    private static int hash(BlockPos pos) {
        long x = pos.asLong() * -7046029254386353131L;
        x ^= x >>> 32;
        return (int) (x & 0x7fffffffL);
    }

    @Nullable
    public static BlockState replacement(BlockState s, BlockPos pos) {
        if (s.is(BlockTags.BASE_STONE_OVERWORLD) || s.is(Blocks.COBBLESTONE) || s.is(Blocks.STONE_BRICKS)) {
            // каждый 13-й камень - стена с глазами
            return (hash(pos) % 13 == 0 ? ModBlocks.EYE_STONE : ModBlocks.VEINED_STONE).get().defaultBlockState();
        }
        if (s.is(BlockTags.PLANKS)) {
            return ModBlocks.ROTTEN_PLANKS.get().defaultBlockState();
        }
        // грязь (MUD) пониже обычного блока -> коллизия не совпала бы, пропускаем
        if (s.is(BlockTags.DIRT) && !s.is(Blocks.MUD)) {
            // каждая 4-я земля - пульсирующая плоть
            return (hash(pos) % 4 == 0 ? ModBlocks.FLESH : ModBlocks.ASHEN_DIRT).get().defaultBlockState();
        }
        if (s.is(Blocks.TORCH)) {
            return Blocks.SOUL_TORCH.defaultBlockState();
        }
        if (s.is(Blocks.WALL_TORCH)) {
            return Blocks.SOUL_WALL_TORCH.defaultBlockState()
                    .setValue(HorizontalDirectionalBlock.FACING, s.getValue(HorizontalDirectionalBlock.FACING));
        }
        if (s.is(Blocks.LANTERN)) {
            return Blocks.SOUL_LANTERN.defaultBlockState()
                    .setValue(LanternBlock.HANGING, s.getValue(LanternBlock.HANGING))
                    .setValue(LanternBlock.WATERLOGGED, s.getValue(LanternBlock.WATERLOGGED));
        }
        if (s.is(Blocks.SHORT_GRASS)) {
            return Blocks.DEAD_BUSH.defaultBlockState();
        }
        if (s.is(BlockTags.SMALL_FLOWERS)) {
            return Blocks.WITHER_ROSE.defaultBlockState();
        }
        return null;
    }
}
