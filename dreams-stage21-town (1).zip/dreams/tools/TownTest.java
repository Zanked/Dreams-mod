import com.example.dreams.dream.world.town.Town;
import com.example.dreams.dream.world.town.Town.B;
import java.io.*;
import java.util.*;

/** Запуск вне игры: java -cp out TownTest.java-скомпилированный. Пишет /tmp/ttest/town.bin и legend.txt для tools/town_preview.py. */
public class TownTest {
    static final int U0 = -125, V0 = -140, Y0 = 40, NU = 251, NV = 260, NY = 100;
    static byte[][][] g = new byte[NU][NY][NV];   // [u][y][v]
    static List<String> marks = new ArrayList<>();

    static void set(int u, int y, int v, B b) {
        int a = u - U0, c = v - V0, yy = y - Y0;
        if (a < 0 || a >= NU || c < 0 || c >= NV || yy < 0 || yy >= NY) return;
        g[a][yy][c] = (byte) (b.ordinal() + 1);
    }

    public static void main(String[] args) throws Exception {
        long seed = args.length > 0 ? Long.parseLong(args[0]) : 20261124L;
        // рельеф: плато и пропасть
        for (int u = U0; u < U0 + NU; u++) for (int v = V0; v < V0 + NV; v++) {
            int top = Town.groundForTest(seed, u, v);
            boolean ab = Town.inAbyssForTest(seed, u, v);
            if (ab) {
                for (int y = Y0; y < Town.G - 4; y++) if (Town.ledgeForTest(seed, u, v, y)) set(u, y, v, B.STONE_V);
                continue;
            }
            for (int y = Y0; y <= top; y++) set(u, y, v, y == top ? B.GRASS : y > top - 3 ? B.DIRT_C : B.STONE_V);
        }
        Town.build(new Town.Sink() {
            public void put(int x, int y, int z, B b) { set(x, y, z, b); }
            public void face(int x, int y, int z, B b, int d) { set(x, y, z, b); }
            public void stair(int x, int y, int z, B f, int d, boolean top, int sh) { set(x, y, z, f); }
            public void slab(int x, int y, int z, B f, boolean top) { set(x, y, z, f); }
            public void door(int x, int y, int z, B k, int d, boolean h) { set(x, y, z, k); set(x, y + 1, z, k); }
            public void conn(int x, int y, int z, B b, int m) { set(x, y, z, b); }
            public void bed(int x, int y, int z, B c, int d) { set(x, y, z, c); set(x + Town.dx(d), y, z + Town.dz(d), c); }
            public void car(int x, int y, int z, int v, int d, int cell) { set(x, y, z, B.CAR); }
            public void log(int x, int y, int z, int a) { set(x, y, z, B.LOG); }
            public void trapdoor(int x, int y, int z, B k, int d, boolean o, boolean t) { set(x, y, z, k); }
            public void mark(String n, int x, int y, int z) { marks.add(n + " " + x + " " + y + " " + z); }
        }, seed, Town.Clip.ALL);
        new File("/tmp/ttest").mkdirs();
        try (DataOutputStream o = new DataOutputStream(new BufferedOutputStream(new FileOutputStream("/tmp/ttest/town.bin")))) {
            o.writeInt(U0); o.writeInt(V0); o.writeInt(Y0); o.writeInt(NU); o.writeInt(NV); o.writeInt(NY);
            for (int a = 0; a < NU; a++) for (int y = 0; y < NY; y++) o.write(g[a][y]);
        }
        try (PrintWriter w = new PrintWriter("/tmp/ttest/legend.txt")) {
            for (B b : B.values()) w.println((b.ordinal() + 1) + " " + b.name());
            for (String m : marks) w.println("# " + m);
        }
        // проверка меток: в точке и над ней воздух, под ней твёрдое
        for (String m : marks) {
            String[] t = m.split(" ");
            int u = Integer.parseInt(t[1]), y = Integer.parseInt(t[2]), v = Integer.parseInt(t[3]);
            if (t[0].equals("bed")) { System.out.println("bed at " + m + " block=" + B.values()[(g[u - U0][y - Y0][v - V0] & 0xff) - 1]); continue; }
            int a = g[u - U0][y - Y0][v - V0] & 0xff, b = g[u - U0][y + 1 - Y0][v - V0] & 0xff, c = g[u - U0][y - 1 - Y0][v - V0] & 0xff;
            String sa = a == 0 ? "air" : B.values()[a - 1].name(), sb = b == 0 ? "air" : B.values()[b - 1].name(), sc = c == 0 ? "NONE" : B.values()[c - 1].name();
            System.out.println(t[0] + " (" + u + "," + y + "," + v + ") at=" + sa + " above=" + sb + " below=" + sc + ((a != 0 && !sa.equals("AIR")) || (b != 0 && !sb.equals("AIR")) || c == 0 ? "   <<< PROBLEM" : ""));
        }
    }
}
