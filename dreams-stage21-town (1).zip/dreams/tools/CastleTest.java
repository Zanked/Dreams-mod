import com.example.dreams.dream.world.Castle;
import java.io.*;

public class CastleTest {
    static final int N = 120, H = 120;
    static byte[][][] g = new byte[N][H][N];   // [x][y][z]
    public static void main(String[] a) throws Exception {
        int cx = N / 2, cz = N / 2, y0 = 20;
        // остров: земля до y0 (трава=250) в радиусе 44
        for (int x = 0; x < N; x++) for (int z = 0; z < N; z++) {
            if (Math.hypot(x - cx, z - cz) < 44) { for (int y = 5; y < y0; y++) g[x][y][z] = 90; g[x][y0][z] = (byte) 91; }
        }
        Castle.build(new Castle.Sink() {
            public void put(int x, int y, int z, Castle.B b) { if (x >= 0 && x < N && y >= 0 && y < H && z >= 0 && z < N) g[x][y][z] = (byte) (b.ordinal() + 1); }
            public void stair(int x, int y, int z, int adx, int adz) { put(x, y, z, Castle.B.MARBLE2); g[x][y][z] = (byte) 80; }
            public void tree(int x, int z, int top) { for (int k = 1; k <= 6; k++) put(x, top + k, z, Castle.B.PILLAR); for (int dx = -3; dx <= 3; dx++) for (int dz = -3; dz <= 3; dz++) for (int dy = 0; dy <= 3; dy++) if (dx*dx+dz*dz+dy*dy*2 < 12 && g[x+dx][top+6+dy][z+dz]==0) g[x+dx][top+6+dy][z+dz] = (byte) 81; }
        }, cx, y0, cz);
        try (DataOutputStream o = new DataOutputStream(new BufferedOutputStream(new FileOutputStream("/tmp/ctest/castle.bin")))) {
            o.writeInt(N); o.writeInt(H); o.writeInt(y0);
            for (int x = 0; x < N; x++) for (int y = 0; y < H; y++) o.write(g[x][y]);
        }
        StringBuilder sb = new StringBuilder();
        for (Castle.B b : Castle.B.values()) sb.append(b.ordinal() + 1).append('=').append(b.name()).append(' ');
        System.out.println(sb);
    }
}
