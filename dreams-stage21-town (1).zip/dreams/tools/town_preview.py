"""Рендер /tmp/ttest/town.bin (вывод TownTest): план сверху и виды. python3 town_preview.py [имя=камера...]
Виды: plan, over (с юго-запада), abyss (с пирса на город), church, hospital, ... см. VIEWS внизу."""
import struct, math, sys
import numpy as np
from PIL import Image
raw = open("/tmp/ttest/town.bin", "rb").read()
U0, V0, Y0, NU, NV, NY = struct.unpack(">6i", raw[:24])
g = np.frombuffer(raw[24:], dtype=np.uint8).reshape(NU, NY, NV)      # [u][y][v]
names = {}
for line in open("/tmp/ttest/legend.txt"):
    if line.startswith("#"): continue
    i, n = line.split(); names[n] = int(i)
RGB = dict(ASPHALT=(52,48,50), CURB=(108,100,98), COBBLE=(84,56,52), COBBLE_BLOOD=(110,30,32), DIRT_C=(70,50,44), ASH=(80,76,74), GRASS=(88,92,60), STONE_V=(96,94,94),
 DEEPSLATE=(60,60,64), ROAD_YELLOW=(170,150,60), ROAD_WHITE=(200,200,200), BRICK=(130,58,46), BRICK_DARK=(92,40,38), BRICK_BLOOD=(110,30,30), BEAM=(70,64,66),
 PLASTER=(188,176,154), PLASTER_GREEN=(150,166,150), SIDING=(104,122,130), SIDING_DARK=(104,80,64), TILE_WHITE=(200,206,202), TILE_GREEN=(120,156,134),
 CHECKER=(110,108,104), METAL_ROOF=(130,96,80), ROOF=(60,60,70), ROOF_RED=(140,64,46), STONE=(128,122,118), WOOD=(80,58,46), CONCRETE=(118,116,112),
 RUST_PLATE=(160,90,50), RUST_BLOODY=(130,40,30), RUST_GRATE=(170,70,50), VEINED=(130,80,80), FLESH=(150,50,60), EYE=(200,60,60),
 WIN_A=(40,50,70), WIN_B=(30,34,44), WIN_C=(110,36,40), DOOR_STEEL_L=(90,84,84), DOOR_STEEL_R=(90,84,84),
 GLASS=(150,190,200), GLASS_RED=(180,40,50), GLASS_BLUE=(50,80,190), GLASS_PURPLE=(120,50,170), GLASS_AMBER=(220,160,50), GLASS_GREEN=(60,150,80), GLASS_GRAY=(120,120,130),
 PANE=(150,190,200), BARS=(110,110,116), DOOR_OAK=(110,80,50), DOOR_DARK=(60,44,34), DOOR_SPRUCE=(90,66,44), DOOR_IRON=(180,180,184),
 PLANKS_ROT=(110,84,56), PLANKS_DARK=(60,44,34), PLANKS_SPRUCE=(100,74,48), STONE_BRICKS=(120,118,116), CRACKED_BRICKS=(112,110,108), MOSSY_BRICKS=(100,112,92),
 POLISHED=(150,150,150), SMOOTH_STONE=(160,160,160), QUARTZ=(235,232,226), QUARTZ_PILLAR=(228,224,218), DEEPSLATE_TILES=(50,50,56), IRON_BLOCK=(210,210,214), COAL_BLOCK=(30,30,32),
 CONCRETE_WHITE=(225,225,225), CONCRETE_BLACK=(20,20,24), CONCRETE_RED=(160,40,40), CONCRETE_GRAY=(100,100,100), CONCRETE_BLUE=(40,60,160), CONCRETE_YELLOW=(220,190,40),
 WOOL_RED=(170,40,40), WOOL_WHITE=(230,230,230), WOOL_GRAY=(110,110,110), CARPET_RED=(150,30,30), CARPET_GRAY=(100,100,100), CARPET_WHITE=(220,220,220), CARPET_GREEN=(50,110,50),
 BOOKSHELF=(120,90,60), CRAFTING=(130,100,60), BARREL_V=(110,80,50), CAULDRON=(60,60,66), LECTERN=(130,100,60), CHEST=(150,110,50), FURNACE=(110,110,110), BELL=(230,190,60), LADDER=(120,90,60),
 LANTERN=(255,200,90), LANTERN_HANG=(255,200,90), SOUL_LANTERN=(90,200,230), SOUL_HANG=(90,200,230), CHAIN=(60,60,64), SEA_LANTERN=(200,235,230), GLOW=(255,230,150), CANDLE=(240,230,200),
 FENCE_SPRUCE=(100,74,48), FENCE_DARK=(60,44,34), FENCE_GATE_DARK=(60,44,34), BED_WHITE=(235,235,235), BED_RED=(190,40,40), BED_GRAY=(130,130,130),
 V_SPRUCE=(100,74,48), V_DARK=(60,44,34), V_QUARTZ=(235,232,226), V_STONEBRICK=(120,118,116), V_OAK=(150,120,70),
 LAMP_BASE=(60,60,64), LAMP_POLE=(60,60,64), LAMP_TOP=(60,60,64), LAMP_HEAD=(255,210,110), LAMP_HEAD_DEAD=(70,70,70), SIGNAL_HEAD=(200,40,40), HYDRANT=(190,40,40), BARREL=(120,70,50), BIN=(60,70,60), BARRIER=(200,120,40),
 FENCE_CHAIN_LOW=(140,140,150), FENCE_CHAIN_UP=(140,140,150), CAR=(150,60,50), LOG=(60,44,34), DEAD_BUSH=(100,80,50), GRASS_SHORT=(90,100,60), COBWEB=(220,220,220), SEAL_STONE=(200,40,40), GRAVE=(130,130,130), BUTTON=(130,130,130), PRESSURE=(130,130,130))
EMIT = {"LANTERN","LANTERN_HANG","SOUL_LANTERN","SOUL_HANG","LAMP_HEAD","SEA_LANTERN","GLOW","CANDLE"}
pal = np.zeros((256, 3)); em = np.zeros(256, bool)
for n, i in names.items():
    pal[i] = RGB.get(n, (255, 0, 255)); em[i] = n in EMIT
SKY = np.array([58, 30, 34.0])

def plan(scale=4, name="plan"):
    top = np.zeros((NU, NV), np.uint8); hgt = np.zeros((NU, NV))
    for y in range(NY):
        m = g[:, y, :] != 0
        top = np.where(m, g[:, y, :], top); hgt = np.where(m, y, hgt)
    img = pal[top] * (0.55 + 0.45 * np.clip(hgt / NY * 1.6, 0, 1))[..., None]
    img[top == 0] = (14, 6, 8)
    im = Image.fromarray(np.clip(img.transpose(1, 0, 2), 0, 255).astype(np.uint8)).resize((NU * scale, NV * scale), Image.NEAREST)
    im.save(f"/home/claude/{name}.png")

def render(cam, look, fov=60, W=1000, Hh=620, cut=None, name="x", maxd=330, fogd=300):
    cam = np.array(cam, float); look = np.array(look, float)
    fw = look - cam; fw /= np.linalg.norm(fw); up = np.array([0, 1.0, 0]); rt = np.cross(fw, up); rt /= np.linalg.norm(rt); up2 = np.cross(rt, fw)
    f = (Hh / 2) / math.tan(math.radians(fov) / 2)
    ys, xs = np.mgrid[0:Hh, 0:W]
    d = (fw[None, None, :] + ((xs - W / 2 + .5) / f)[..., None] * rt + (-(ys - Hh / 2 + .5) / f)[..., None] * up2).reshape(-1, 3)
    d /= np.linalg.norm(d, axis=1, keepdims=True)
    P = len(d); col = np.zeros((P, 3)); col[:] = SKY
    t = np.zeros(P); active = np.arange(P)
    gg = g
    if cut:
        gg = g.copy()
        if 'u' in cut: gg[int(cut['u']) - U0:, :, :] = 0
        if 'v' in cut: gg[:, :, int(cut['v']) - V0:] = 0
        if 'y' in cut: gg[:, int(cut['y']) - Y0:, :] = 0
    step = 0.45
    for it in range(int(maxd / step)):
        t[active] += step
        pos = cam[None, :] + d[active] * t[active][:, None]
        iu = np.floor(pos[:, 0]).astype(int) - U0; iy = np.floor(pos[:, 1]).astype(int) - Y0; iv = np.floor(pos[:, 2]).astype(int) - V0
        inb = (iu >= 0) & (iu < NU) & (iy >= 0) & (iy < NY) & (iv >= 0) & (iv < NV)
        blk = np.zeros(len(active), np.uint8); blk[inb] = gg[iu[inb], iy[inb], iv[inb]]
        h = blk != 0
        if h.any():
            idx = active[h]; b = blk[h]
            c = pal[b].copy(); a, yy, v = iu[h], iy[h], iv[h]
            tex = 0.88 + 0.24 * (((a * 7 + yy * 13 + v * 17) % 5) / 5.0)
            upn = np.zeros(len(idx), bool); m = yy + 1 < NY
            upn[m] = gg[a[m], yy[m] + 1, v[m]] == 0
            light = np.where(upn, 1.1, 0.7)
            c = c * (light * tex)[:, None]
            e = em[b]; c[e] = pal[b[e]]
            fk = np.clip(t[idx] / fogd, 0, 1)[:, None] ** 1.5
            c = c * (1 - fk) + SKY * fk
            col[idx] = c
            keep = np.ones(len(active), bool); keep[h] = False; active = active[keep]
        if len(active) == 0: break
        active = active[t[active] < maxd]
        if len(active) == 0: break
    Image.fromarray(np.clip(col.reshape(Hh, W, 3), 0, 255).astype(np.uint8)).save(f"/home/claude/{name}.png")

VIEWS = {
 "over":     lambda: render((-120, 150, 120), (0, 80, -10), fov=62, name="town_over"),
 "street":   lambda: render((0, 76, 40), (0, 80, -30), fov=70, name="town_street"),
 "abyss":    lambda: render((0, 80, -118), (0, 74, 20), fov=75, name="town_abyss"),
 "church":   lambda: render((10, 100, 40), (14, 85, -20), fov=60, name="town_church"),
 "churchin":  lambda: render((14, 79, -12), (14, 79, -36), fov=75, name="town_churchin", cut={"y": 100}),
 "hospital": lambda: render((26, 95, -25), (26, 82, 25), fov=60, name="town_hospital"),
 "police":   lambda: render((-26, 90, 22), (-26, 80, -20), fov=60, name="town_police"),
 "hotel":    lambda: render((-74, 82, 12), (-74, 85, -20), fov=65, name="town_hotel"),
 "south":    lambda: render((0, 90, 120), (0, 75, 30), fov=65, name="town_south"),
 "east":     lambda: render((130, 95, 0), (60, 78, 10), fov=65, name="town_east"),
}
if __name__ == "__main__":
    plan()
    for n in (sys.argv[1:] or ["over"]):
        if n in VIEWS: VIEWS[n]()
