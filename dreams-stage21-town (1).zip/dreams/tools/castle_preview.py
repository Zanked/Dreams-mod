"""Рендер castle.bin (вывод CastleTest): вид снаружи и разрезы. python3 castle_preview.py"""
import struct, math, sys
import numpy as np
from PIL import Image
raw = open("/tmp/ctest/castle.bin", "rb").read()
N, H, Y0 = struct.unpack(">iii", raw[:12])
g = np.frombuffer(raw[12:], dtype=np.uint8).reshape(N, H, N)   # [x][y][z]
COL = {2:(236,232,244),3:(250,248,252),4:(214,204,226),5:(226,222,238),6:(150,100,225),7:(255,205,80),8:(255,225,140),9:(255,225,140),10:(90,80,90),
 11:(255,235,170),12:(150,90,220),13:(255,130,200),14:(120,190,255),15:(220,90,230),16:(255,255,255),17:(130,60,170),18:(210,60,170),19:(235,200,70),
 20:(110,170,230),21:(130,90,60),22:(190,120,255),23:(205,140,255),24:(205,140,255),25:(110,170,255),26:(205,205,210),27:(255,170,210),28:(200,110,230),29:(90,150,52),
 80:(228,224,236),81:(214,120,196),90:(112,78,52),91:(88,150,52)}
pal = np.zeros((256,3)); 
for k,v in COL.items(): pal[k]=v
EM = {8,9,11,22,23,24,25}
def render(cam, look, fov=60, W=900, Hh=560, cut=None, name="x", sky=(235,170,215)):
    cam=np.array(cam,float); look=np.array(look,float)
    fw=look-cam; fw/=np.linalg.norm(fw); up=np.array([0,1.0,0]); rt=np.cross(fw,up); rt/=np.linalg.norm(rt); up2=np.cross(rt,fw)
    f=(Hh/2)/math.tan(math.radians(fov)/2)
    ys,xs=np.mgrid[0:Hh,0:W]
    d=(fw[None,None,:]+((xs-W/2+.5)/f)[...,None]*rt+(-(ys-Hh/2+.5)/f)[...,None]*up2).reshape(-1,3)
    d/=np.linalg.norm(d,axis=1,keepdims=True)
    P=len(d); col=np.zeros((P,3)); col[:]=sky
    t=np.zeros(P); active=np.arange(P)
    gg=g.copy()
    if cut:
        if 'x' in cut: gg[int(cut['x']):,:,:]=0
        if 'z' in cut: gg[:,:,int(cut['z']):]=0
        if 'y' in cut: gg[:,int(cut['y']):,:]=0
    step=0.4
    for it in range(int(260/step)):
        t[active]+=step
        pos=cam[None,:]+d[active]*t[active][:,None]
        ix=np.floor(pos[:,0]).astype(int); iy=np.floor(pos[:,1]).astype(int); iz=np.floor(pos[:,2]).astype(int)
        inb=(ix>=0)&(ix<N)&(iy>=0)&(iy<H)&(iz>=0)&(iz<N)
        blk=np.zeros(len(active),np.uint8); blk[inb]=gg[ix[inb],iy[inb],iz[inb]]
        h=(blk!=0)&(blk!=1)
        if h.any():
            idx=active[h]; b=blk[h]
            c=pal[b].copy()
            ixx,iyy,izz=ix[h],iy[h],iz[h]
            tex=0.9+0.2*(((ixx*7+iyy*13+izz*17)%5)/5.0)
            # затенение по соседу сверху и дальности
            upn=np.zeros(len(idx),bool); m=iyy+1<H
            upn[m]=(gg[ixx[m],iyy[m]+1,izz[m]]==0)|(gg[ixx[m],iyy[m]+1,izz[m]]==1)
            light=np.where(upn,1.05,0.74)
            c=c*(light*tex)[:,None]
            em=np.isin(b,list(EM)); c[em]=pal[b[em]]
            fogk=np.clip(t[idx]/230,0,1)[:,None]**1.6
            c=c*(1-fogk)+np.array(sky)*fogk
            col[idx]=c
            keep=np.ones(len(active),bool); keep[h]=False; active=active[keep]
        if len(active)==0: break
        active=active[t[active]<260]
        if len(active)==0: break
    Image.fromarray(np.clip(col.reshape(Hh,W,3),0,255).astype(np.uint8)).save(f"/home/claude/{name}.png")
c=N//2
if __name__=="__main__":
    render((c-70,Y0+55,c+95),(c,Y0+22,c),fov=62,name="castle_out")
    render((c+95,Y0+14,c-18),(c,Y0+10,c-2),fov=70,cut={'x':c},name="castle_hall")
    render((c+10,Y0+42,c+70),(c,Y0+30,c),fov=70,cut={'z':c},name="castle_tower")
