package com.example.dreams.dream.world.town;

import com.example.dreams.dream.world.town.Town.B;
import com.example.dreams.dream.world.town.TownMap.Lot;

import static com.example.dreams.dream.world.town.Town.F0;
import static com.example.dreams.dream.world.town.Town.G;

/** Жилые дома: одно- и двухэтажные, с крыльцом, щипцовой крышей, трубой, забором и двором. Дом игрока (home) с кроватью-выходом. */
final class Houses {
    private Houses() {}

    static void house(Cx c, Lot lot, boolean home) {
        long sd = lot.seed;
        int v = (int) (Town.rand(sd, 1, 2, 3, 4) * 3);
        int storeys = home ? 2 : (v == 0 ? 1 : v == 1 ? 2 : (Town.rand(sd, 5, 6, 7, 8) < 0.5 ? 1 : 2));
        int w = home ? 13 : 11 + (int) (Town.rand(sd, 9, 9, 9, 9) * 2) * 1;
        int d = home ? 11 : 9 + (storeys == 2 ? 1 : 0);
        int lotW = Math.abs(lot.front) >= 0 ? 0 : 0;
        // фасад: у участков с фронтом N/S ширина вдоль u, у E/W вдоль v
        int along = 0;
        Cx h = Buildings.place(c, lot, w, d, along);
        B[] walls = {B.SIDING, B.SIDING_DARK, B.PLASTER, B.BRICK};
        B wall = home ? B.SIDING : walls[(int) (Town.rand(sd, 11, 12, 13, 14) * walls.length)];
        B roofFam = Town.rand(sd, 15, 16, 17, 18) < 0.5 ? B.ROOF : B.ROOF_RED;
        B roofFull = roofFam;
        boolean porch = home || Town.rand(sd, 19, 20, 21, 22) < 0.7;
        build(h, sd, w, d, storeys, wall, roofFam, roofFull, porch, home);
        yard(h, sd, w, d, lot, home);
    }

    static void build(Cx h, long sd, int w, int d, int storeys, B wall, B roofFam, B roofFull, boolean porch, boolean home) {
        int yc = F0 + 4 * storeys;
        // фундамент и пол
        h.box(0, F0, 0, w - 1, F0, d - 1, B.PLANKS_ROT);
        h.walls(0, 0, w - 1, d - 1, F0, F0, B.STONE);
        // стены
        h.rwalls(0, 0, w - 1, d - 1, F0 + 1, yc, wall, wall == B.BRICK ? B.BRICK_DARK : B.PLASTER, 0.06, 31);
        for (int k = 0; k < storeys; k++) {
            int y = F0 + 4 * k;
            for (int yy = y + 1; yy <= y + 4 && yy <= yc; yy++) {
                for (int[] p : new int[][]{{0, 0}, {w - 1, 0}, {0, d - 1}, {w - 1, d - 1}}) h.p(p[0], yy, p[1], B.WOOD);
            }
            if (k > 0) {
                h.walls(0, 0, w - 1, d - 1, y, y, B.WOOD);   // пояс между этажами
                h.box(1, y, 1, w - 2, y, d - 2, B.PLANKS_ROT);
            }
        }
        h.box(1, yc, 1, w - 2, yc, d - 2, B.PLANKS_DARK);   // потолок
        h.walls(0, 0, w - 1, d - 1, yc, yc, B.WOOD);
        // окна
        for (int k = 0; k < storeys; k++) {
            int y = F0 + 4 * k + 2;
            h.winRow(0, d - 1, 1, w, y, 2, 3, 2, 40 + k);       // фасад (z = d-1)
            h.winRow(0, 0, 1, w, y, 2, 3, 2, 50 + k);           // тыл
            h.winRow(0, 0, 2, d, y, 2, 4, 2, 60 + k);           // торцы
            h.winRow(w - 1, 0, 2, d, y, 2, 4, 2, 70 + k);
        }
        // дверь по центру фасада
        int dx = w / 2;
        Buildings.doorway(h, dx, d - 1, 2, B.DOOR_DARK, !porch);
        h.p(dx - 1, F0 + 2, d - 1, B.WIN_C); h.p(dx + 1, F0 + 2, d - 1, B.WIN_C);
        h.p(dx - 1, F0 + 3, d - 1, wall); h.p(dx + 1, F0 + 3, d - 1, wall);
        if (porch) porch(h, w, d, dx);
        // крыша
        int ridge = Buildings.gable(h, w, d, yc, roofFam, roofFull, wall == B.BRICK ? B.BRICK : wall, false);
        // окно в щипце
        h.p(0, yc + 2, d / 2, B.WIN_A); h.p(w - 1, yc + 2, d / 2, B.WIN_A);
        // труба
        int cz = (d - 1) / 2;
        h.box(w - 4, yc + 1, cz - 1, w - 3, ridge + 2, cz, B.BRICK);
        h.slab(w - 4, ridge + 3, cz - 1, B.CURB, false); h.slab(w - 3, ridge + 3, cz - 1, B.CURB, false);
        h.slab(w - 4, ridge + 3, cz, B.CURB, false); h.slab(w - 3, ridge + 3, cz, B.CURB, false);
        interior(h, sd, w, d, storeys, yc, home);
    }

    static void porch(Cx h, int w, int d, int dx) {
        int x0 = dx - 2, x1 = dx + 2;
        h.box(x0, F0, d, x1, F0, d + 2, B.WOOD);
        for (int x = dx - 1; x <= dx + 1; x++) h.stair(x, F0, d + 3, B.WOOD, 0, false);
        for (int x : new int[]{x0, x1}) { h.box(x, F0 + 1, d + 2, x, F0 + 3, d + 2, B.WOOD); }
        h.box(x0, F0 + 4, d, x1, F0 + 4, d + 2, B.WOOD);
        h.slab(x0 - 1, F0 + 4, d + 3, B.ROOF, false);
        for (int x = x0; x <= x1; x++) h.slab(x, F0 + 4, d + 3, B.ROOF, false);
        h.slab(x1 + 1, F0 + 4, d + 3, B.ROOF, false);
        h.p(dx, F0 + 3, d + 2, B.LANTERN_HANG);
        // перила
        h.p(x0, F0 + 1, d + 1, B.FENCE_DARK); h.p(x1, F0 + 1, d + 1, B.FENCE_DARK);
        h.p(x0, F0 + 1, d, B.FENCE_DARK); h.p(x1, F0 + 1, d, B.FENCE_DARK);
    }

    // ------------------------------------------------------------------ двор: забор, деревья, почтовый ящик
    static void yard(Cx h, long sd, int w, int d, Lot lot, boolean home) {
        Cx.Net fence = h.net(B.FENCE_DARK);
        fence.rect(-3, -3, w + 2, d + 4);
        int gx = w / 2;
        for (int x = gx - 1; x <= gx + 1; x++) fence.remove(x, d + 4);
        for (Cx.Net n : new Cx.Net[]{fence}) {
            for (int z = -3; z <= d + 4; z++) for (int x = -3; x <= w + 2; x++) {
                if (n.has(x, z) && Town.rand(sd, x, z, 0, 33) < 0.18) n.remove(x, z);   // дыры в заборе
            }
        }
        fence.flush(F0, F0);
        // дорожка к калитке
        for (int z = d; z <= d + 4; z++) h.p(gx, G, z, B.COBBLE);
        h.pf(w / 2 + 3, F0, d + 5, B.BIN, 0);
        if (Town.rand(sd, 3, 3, 3, 33) < 0.6) h.p(2, F0, d + 2, B.DEAD_BUSH);
        if (Town.rand(sd, 4, 4, 4, 33) < 0.5) h.p(w - 3, F0, d + 2, B.DEAD_BUSH);
    }

    // ------------------------------------------------------------------ интерьер
    static void interior(Cx h, long sd, int w, int d, int storeys, int yc, boolean home) {
        int zp = d / 2;
        for (int k = 0; k < storeys; k++) {
            int y = F0 + 4 * k;                    // уровень пола
            int ceil = y + 4;
            // перегородка по z = zp
            h.box(1, y + 1, zp, w - 2, y + 3, zp, B.PLASTER);
            h.box(w / 2 - 1, y + 1, zp, w / 2, y + 2, zp, B.AIR);
            for (int x = w / 2 - 1; x <= w / 2; x++) h.p(x, y + 3, zp, B.WOOD);
            // перегородка по x в передней части
            Buildings.lamp(h, 3, ceil, zp + 2);
            Buildings.lamp(h, w - 4, ceil, zp - 2);
            if (k == 0) {
                // гостиная (перед): стол, стулья, книжные шкафы
                Buildings.table(h, w - 4, y + 1, d - 3);
                Buildings.chair(h, w - 5, y + 1, d - 3, 1); Buildings.chair(h, w - 3, y + 1, d - 3, 3);
                h.p(1, y + 1, d - 2, B.BOOKSHELF); h.p(1, y + 2, d - 2, B.BOOKSHELF);
                h.p(1, y + 1, d - 3, B.BOOKSHELF); h.p(1, y + 2, d - 3, B.BOOKSHELF);
                h.p(2, y + 1, d - 2, B.CARPET_RED); h.p(3, y + 1, d - 2, B.CARPET_RED);
                // кухня (тыл)
                h.p(w - 2, y + 1, 1, B.FURNACE); h.p(w - 3, y + 1, 1, B.CRAFTING); h.p(w - 2, y + 1, 2, B.BARREL_V);
                h.p(2, y + 1, 1, B.CAULDRON);
                if (storeys == 1) {
                    h.bed(w - 3, y + 1, zp - 1, B.BED_GRAY, 0);
                }
            } else {
                // верхний этаж: спальни
                h.bed(w - 3, y + 1, 2, home ? B.BED_WHITE : B.BED_RED, 0);
                h.p(w - 2, y + 1, 1, B.CHEST);
                h.bed(2, y + 1, d - 2, B.BED_GRAY, 1);
                h.p(3, y + 1, 1, B.BOOKSHELF);
            }
        }
        if (storeys == 2) {
            // лестница вдоль западной стены, подъём на юг: x = 1, z = 1..4
            int a = 1;
            for (int i = 0; i < 4; i++) h.stair(1, F0 + 1 + i, a + i, B.V_SPRUCE, 2, false);
            for (int i = 0; i < 3; i++) h.p(1, F0 + 4, a + i, B.AIR);
            for (int i = 0; i < 4; i++) h.p(2, F0 + 1 + i, a + i, B.AIR);
            h.p(2, F0 + 1, 1, B.AIR);
            // перила наверху
            h.p(1, F0 + 5, a, B.FENCE_SPRUCE);
        }
        if (home) {
            h.mark("bed", w - 3, F0 + 5, 2);
            h.p(w - 3, F0 + 5, 3, B.CANDLE);
        }
    }
}
