package com.example.dreams.command;

import com.example.dreams.Dreams;
import com.example.dreams.attachment.DreamState;
import com.example.dreams.attachment.ModAttachments;
import com.example.dreams.dream.DreamManager;
import com.example.dreams.dream.DreamTimeline;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

/**
 * /dreams nightmare [игрок]  - сразу запустить "ложное пробуждение" (для тестов, без ожидания ночи)
 * /dreams loop <круг> [игрок] - сразу N-й круг сна (1-5: быстрее и злее, для теста ложных выходов)
 * /dreams stop [игрок]       - прервать сон
 * /dreams cutscene <имя>     - показать катсцену (good_prologue, whale_first, tree_wake, finale_rise, ow_enter, ow_executioner, ow_caught, ow_seal)
 */
@EventBusSubscriber(modid = Dreams.MODID)
public class DreamCommands {

    @SubscribeEvent
    public static void onRegister(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("dreams")
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("nightmare")
                        .executes(ctx -> start(ctx, ctx.getSource().getPlayerOrException()))
                        .then(Commands.argument("target", EntityArgument.player())
                                .executes(ctx -> start(ctx, EntityArgument.getPlayer(ctx, "target")))))
                .then(Commands.literal("otherworld")
                        .executes(ctx -> startAt(ctx, ctx.getSource().getPlayerOrException(), DreamTimeline.OTHERWORLD_START - 60))
                        .then(Commands.argument("target", EntityArgument.player())
                                .executes(ctx -> startAt(ctx, EntityArgument.getPlayer(ctx, "target"), DreamTimeline.OTHERWORLD_START - 60))))
                .then(Commands.literal("town")
                        .executes(ctx -> {
                            var player = ctx.getSource().getPlayerOrException();
                            if (!com.example.dreams.dream.OtherworldWorld.visit(player)) {
                                ctx.getSource().sendFailure(net.minecraft.network.chat.Component.literal("dimension dreams:otherworld not found"));
                                return 0;
                            }
                            ctx.getSource().sendSuccess(() -> net.minecraft.network.chat.Component.literal("Otherworld town. Back: /dreams townback"), false);
                            return 1;
                        }))
                .then(Commands.literal("townback")
                        .executes(ctx -> {
                            com.example.dreams.dream.DreamWorld.leaveStray(ctx.getSource().getPlayerOrException());
                            return 1;
                        }))
                .then(Commands.literal("good")
                        .executes(ctx -> startGood(ctx, ctx.getSource().getPlayerOrException()))
                        .then(Commands.argument("target", EntityArgument.player())
                                .executes(ctx -> startGood(ctx, EntityArgument.getPlayer(ctx, "target")))))
                .then(Commands.literal("executioner")
                        .executes(ctx -> {
                            ServerPlayer target = ctx.getSource().getPlayerOrException();
                            if (!DreamManager.forceExecutioner(target)) {
                                ctx.getSource().sendFailure(Component.translatable("commands.dreams.busy", target.getDisplayName()));
                                return 0;
                            }
                            ctx.getSource().sendSuccess(() -> Component.translatable("commands.dreams.started", target.getDisplayName()), true);
                            return 1;
                        }))
                .then(Commands.literal("loop")
                        .then(Commands.argument("round", IntegerArgumentType.integer(0, 5))
                                .executes(ctx -> start(ctx, ctx.getSource().getPlayerOrException(),
                                        IntegerArgumentType.getInteger(ctx, "round")))
                                .then(Commands.argument("target", EntityArgument.player())
                                        .executes(ctx -> start(ctx, EntityArgument.getPlayer(ctx, "target"),
                                                IntegerArgumentType.getInteger(ctx, "round"))))))
                .then(Commands.literal("cutscene")
                        .then(Commands.argument("name", StringArgumentType.word())
                                .executes(ctx -> cutscene(ctx, StringArgumentType.getString(ctx, "name")))))
                .then(Commands.literal("stop")
                        .executes(ctx -> stop(ctx, ctx.getSource().getPlayerOrException()))
                        .then(Commands.argument("target", EntityArgument.player())
                                .executes(ctx -> stop(ctx, EntityArgument.getPlayer(ctx, "target"))))));
    }

    private static final java.util.Set<String> SCENES = java.util.Set.of("good_prologue", "whale_first", "tree_wake", "finale_rise", "ow_enter", "ow_executioner", "ow_caught", "ow_seal");

    /** Проверка катсцены без сна: якорь для tree_wake ставится в 45 блоках перед игроком. */
    private static int cutscene(CommandContext<CommandSourceStack> ctx, String name) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        if (!SCENES.contains(name)) {
            ctx.getSource().sendFailure(Component.translatable("commands.dreams.cutscene.unknown", name));
            return 0;
        }
        ServerPlayer p = ctx.getSource().getPlayerOrException();
        double yaw = Math.toRadians(p.getYRot());
        net.neoforged.neoforge.network.PacketDistributor.sendToPlayer(p, new com.example.dreams.network.DreamCutscenePayload(
                name, p.getX() - Math.sin(yaw) * 45.0, p.getY(), p.getZ() + Math.cos(yaw) * 45.0));
        ctx.getSource().sendSuccess(() -> Component.translatable("commands.dreams.cutscene", name, p.getDisplayName()), false);
        return 1;
    }

    private static int startGood(CommandContext<CommandSourceStack> ctx, ServerPlayer target) {
        if (!DreamManager.forceGood(target)) {
            ctx.getSource().sendFailure(Component.translatable("commands.dreams.busy", target.getDisplayName()));
            return 0;
        }
        ctx.getSource().sendSuccess(() -> Component.translatable("commands.dreams.started_good", target.getDisplayName()), true);
        return 1;
    }

    private static int start(CommandContext<CommandSourceStack> ctx, ServerPlayer target) {
        return start(ctx, target, 0);
    }

    private static int startAt(CommandContext<CommandSourceStack> ctx, ServerPlayer target, int tick) {
        if (!DreamManager.forceStartAt(target, tick)) {
            ctx.getSource().sendFailure(Component.translatable("commands.dreams.busy", target.getDisplayName()));
            return 0;
        }
        ctx.getSource().sendSuccess(() -> Component.translatable("commands.dreams.started", target.getDisplayName()), true);
        return 1;
    }

    private static int start(CommandContext<CommandSourceStack> ctx, ServerPlayer target, int round) {
        if (!DreamManager.forceStart(target, round)) {
            ctx.getSource().sendFailure(Component.translatable("commands.dreams.busy", target.getDisplayName()));
            return 0;
        }
        ctx.getSource().sendSuccess(() -> Component.translatable("commands.dreams.started", target.getDisplayName()), true);
        if (target.getData(ModAttachments.DREAM_STATE).bed == null) {
            ctx.getSource().sendSuccess(() -> Component.translatable("commands.dreams.nobed"), false);
        }
        return 1;
    }

    private static int stop(CommandContext<CommandSourceStack> ctx, ServerPlayer target) {
        DreamState s = target.getData(ModAttachments.DREAM_STATE);
        if (s.phase == DreamState.Phase.IDLE) {
            ctx.getSource().sendFailure(Component.translatable("commands.dreams.idle", target.getDisplayName()));
            return 0;
        }
        DreamManager.end(target, s, DreamManager.Result.ABORT, true);
        ctx.getSource().sendSuccess(() -> Component.translatable("commands.dreams.stopped", target.getDisplayName()), true);
        return 1;
    }
}
