package com.example.dreams.dream.world.town;

/**
 * Городок Иной стороны на краю пропасти. Класс не знает про Minecraft: он пишет в Sink по смысловым идентификаторам
 * блоков (B), поэтому его можно запустить и нарисовать вне игры (tools/TownTest.java, tools/town_preview.py).
 *
 * Система координат города: u на восток, v на юг, y настоящая высота мира. Пропасть лежит на севере (v < -66),
 * центральный перекрёсток в (0, 0). Поворот города на 0..3 четверти делает Sink мира (OtherworldGen).
 * Земля (верхний блок улиц) на y = G, первый пол зданий на y = F0 = G + 1 (на ступеньку выше улицы).
 */
public final class Town {
    private Town() {}

    public static final int G = 70;
    public static final int F0 = G + 1;
    public static final int REGION = 512;          // сторона области, в которой живёт один городок

    /** Смысловые блоки. Перевод в настоящие блоки: OtherworldGen.state(). Семейства ступеней/плит: ROOF..BRICK, V_*. */
    public enum B {
        AIR,
        // улицы и земля
        ASPHALT, CURB, COBBLE, COBBLE_BLOOD, DIRT_C, ASH, GRASS, STONE_V, DEEPSLATE, COBBLE_V,
        ROAD_YELLOW, ROAD_WHITE,
        // стены и крыши (с семействами ступеней и плит)
        BRICK, BRICK_DARK, BRICK_BLOOD, BEAM, PLASTER, PLASTER_GREEN, SIDING, SIDING_DARK, TILE_WHITE, TILE_GREEN,
        CHECKER, METAL_ROOF, ROOF, ROOF_RED, STONE, WOOD, CONCRETE,
        // ржавчина и плоть
        RUST_PLATE, RUST_BLOODY, RUST_GRATE, VEINED, FLESH, EYE,
        // окна и двери
        WIN_A, WIN_B, WIN_C, DOOR_STEEL_L, DOOR_STEEL_R,
        GLASS, GLASS_RED, GLASS_BLUE, GLASS_PURPLE, GLASS_AMBER, GLASS_GREEN, GLASS_GRAY, PANE, BARS,
        DOOR_OAK, DOOR_DARK, DOOR_SPRUCE, DOOR_IRON,
        TRAPDOOR_DARK, TRAPDOOR_SPRUCE,
        // ваниль: отделка и мебель
        PLANKS_ROT, PLANKS_DARK, PLANKS_SPRUCE, STONE_BRICKS, CRACKED_BRICKS, MOSSY_BRICKS, POLISHED, SMOOTH_STONE,
        QUARTZ, QUARTZ_PILLAR, DEEPSLATE_TILES, IRON_BLOCK, COAL_BLOCK,
        CONCRETE_WHITE, CONCRETE_BLACK, CONCRETE_RED, CONCRETE_GRAY, CONCRETE_BLUE, CONCRETE_YELLOW,
        WOOL_RED, WOOL_WHITE, WOOL_GRAY, CARPET_RED, CARPET_GRAY, CARPET_WHITE, CARPET_GREEN,
        BOOKSHELF, CRAFTING, BARREL_V, CAULDRON, LECTERN, CHEST, FURNACE, BELL, LADDER,
        LANTERN, LANTERN_HANG, SOUL_LANTERN, SOUL_HANG, CHAIN, SEA_LANTERN, GLOW, CANDLE, FENCE_SPRUCE, FENCE_DARK, FENCE_GATE_DARK,
        BED_WHITE, BED_RED, BED_GRAY,
        // стыки из ступеней и плит одного семейства (V_* = ванильные)
        V_SPRUCE, V_DARK, V_QUARTZ, V_STONEBRICK, V_OAK,
        // уличная мелочь (модели мода)
        LAMP_BASE, LAMP_POLE, LAMP_TOP, LAMP_HEAD, LAMP_HEAD_DEAD, SIGNAL_HEAD, HYDRANT, BARREL, BIN, BARRIER,
        FENCE_CHAIN_LOW, FENCE_CHAIN_UP, CAR,
        // растительность и мелочи
        LOG, DEAD_BUSH, GRASS_SHORT, COBWEB, SEAL_STONE, GRAVE, BUTTON, PRESSURE
    }

    /** Запись блоков в мир города. Все координаты в системе города, направления: 0 = север (-v), 1 = восток, 2 = юг, 3 = запад. */
    public interface Sink {
        void put(int x, int y, int z, B b);

        /** Блок со свойством facing (уличная мелочь, лестница-ладдер, бочки). */
        void face(int x, int y, int z, B b, int dir);

        /** Ступень семейства fam; dir = сторона, В КОТОРУЮ ступень поднимается (там её высокая часть); shape 0 прямая, 1 внутр. левая, 2 внутр. правая, 3 внешн. левая, 4 внешн. правая. */
        void stair(int x, int y, int z, B fam, int dir, boolean top, int shape);

        void slab(int x, int y, int z, B fam, boolean top);

        /** Дверь (нижняя и верхняя половинки). dir = куда смотрит лицевая сторона двери. */
        void door(int x, int y, int z, B kind, int dir, boolean hingeRight);

        /** Блок со связями на четыре стороны (заборы, решётки, стёкла): mask 1 = север, 2 = восток, 4 = юг, 8 = запад. */
        void conn(int x, int y, int z, B b, int mask);

        /** Кровать: ножная часть в (x, y, z), изголовье на одну клетку дальше в сторону dir. */
        void bed(int x, int y, int z, B color, int dir);

        /** Клетка брошенной машины: variant 0..3, dir = куда смотрит капот, cell 0..11 (см. CarBlock). */
        void car(int x, int y, int z, int variant, int dir, int cell);

        /** Бревно: ось 0 = x, 1 = y, 2 = z. */
        void log(int x, int y, int z, int axis);

        void trapdoor(int x, int y, int z, B kind, int dir, boolean open, boolean top);

        /** Метка для игры: "start", "bed" (dir неважен), "seal" (место печати). */
        default void mark(String name, int x, int y, int z) {}
    }

    /** Окно просмотра: что нужно записать (в системе города). Здания вне окна пропускаются. */
    public static final class Clip {
        public final int u0, v0, u1, v1;
        public Clip(int u0, int v0, int u1, int v1) { this.u0 = u0; this.v0 = v0; this.u1 = u1; this.v1 = v1; }
        public boolean hits(int a0, int b0, int a1, int b1) { return a1 >= u0 && a0 <= u1 && b1 >= v0 && b0 <= v1; }
        public static final Clip ALL = new Clip(-100000, -100000, 100000, 100000);
    }

    // ------------------------------------------------------------------ направления
    public static int dx(int d) { return d == 1 ? 1 : d == 3 ? -1 : 0; }
    public static int dz(int d) { return d == 0 ? -1 : d == 2 ? 1 : 0; }
    public static int cw(int d) { return (d + 1) & 3; }
    public static int ccw(int d) { return (d + 3) & 3; }
    public static int opp(int d) { return (d + 2) & 3; }

    // ------------------------------------------------------------------ детерминированный шум
    static long mix(long h) {
        h ^= h >>> 33; h *= 0xff51afd7ed558ccdL; h ^= h >>> 33; h *= 0xc4ceb9fe1a85ec53L; h ^= h >>> 33;
        return h;
    }

    public static double rand(long seed, int a, int b, int c, int salt) {
        long h = mix(seed ^ (a * 0x9E3779B97F4A7C15L));
        h = mix(h ^ (b * 0xC2B2AE3D27D4EB4FL));
        h = mix(h ^ (c * 0x165667B19E3779F9L));
        h = mix(h ^ (salt * 0x27D4EB2F165667C5L));
        return (h >>> 11) * (1.0 / (1L << 53));
    }

    static double vnoise(long seed, int k, double x, double z, double scale) {
        double fx = x / scale, fz = z / scale;
        int ix = (int) Math.floor(fx), iz = (int) Math.floor(fz);
        double tx = fx - ix, tz = fz - iz;
        tx = tx * tx * (3 - 2 * tx); tz = tz * tz * (3 - 2 * tz);
        double a = rand(seed, ix, iz, k, 900), b = rand(seed, ix + 1, iz, k, 900);
        double c = rand(seed, ix, iz + 1, k, 900), d = rand(seed, ix + 1, iz + 1, k, 900);
        double top = a + (b - a) * tx, bot = c + (d - c) * tx;
        return top + (bot - top) * tz;
    }

    /** Шум с нулевым средним и разбросом около единицы. */
    public static double nz(long seed, int k, double x, double z, double scale) {
        return (vnoise(seed, k, x, z, scale) - 0.5) * 3.4;
    }

    // ------------------------------------------------------------------ рельеф (для игры и проверок)
    /** Верхний блок земли в мире на (u, v) (без пропасти). wx, wz = мировые координаты для шума; в тестах равны u, v. */
    public static int ground(long seed, int wx, int wz, int u, int v) { return TownMap.ground(seed, wx, wz, u, v); }
    public static boolean inAbyss(long seed, int u, int v) { return TownMap.inAbyss(seed, u, v); }
    public static boolean ledge(long seed, int u, int v, int y) { return TownMap.ledge(seed, u, v, y); }
    public static double rimDepth(long seed, int u, int v) { return TownMap.rimDepth(seed, u, v); }
    public static int groundForTest(long seed, int u, int v) { return TownMap.ground(seed, u, v, u, v); }
    public static boolean inAbyssForTest(long seed, int u, int v) { return TownMap.inAbyss(seed, u, v); }
    public static boolean ledgeForTest(long seed, int u, int v, int y) { return TownMap.ledge(seed, u, v, y); }

    // ------------------------------------------------------------------ вход
    /** Строит весь городок в окно clip. seed: сид области (стиль домов, цвета, мелочи). */
    public static void build(Sink s, long seed, Clip clip) {
        TownMap.build(s, seed, clip);
    }
}
