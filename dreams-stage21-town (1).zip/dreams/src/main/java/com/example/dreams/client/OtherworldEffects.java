package com.example.dreams.client;

import net.minecraft.client.renderer.DimensionSpecialEffects;
import net.minecraft.world.phys.Vec3;

/**
 * Небо Иной стороны ("dreams:otherworld" в dimension_type): вечная ночь без облаков и без рассветного свечения.
 * Цвет неба и тумана берётся из биома otherworld, а плотный красный туман, зерно и сирену даёт NightmareClient
 * (клиент получает FX_OTHERWORLD при входе в измерение).
 */
public class OtherworldEffects extends DimensionSpecialEffects {

    public OtherworldEffects() {
        super(Float.NaN, false, SkyType.NORMAL, false, false);
    }

    @Override
    public Vec3 getBrightnessDependentFogColor(Vec3 fogColor, float brightness) {
        return fogColor.multiply(brightness * 0.9F + 0.1F, brightness * 0.9F + 0.1F, brightness * 0.9F + 0.1F);
    }

    @Override
    public boolean isFoggyAt(int x, int y) {
        return true;
    }

    @Override
    public float[] getSunriseColor(float timeOfDay, float partialTicks) {
        return null;
    }
}
