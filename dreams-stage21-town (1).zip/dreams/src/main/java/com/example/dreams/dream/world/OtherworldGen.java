package com.example.dreams.dream.world;

import com.example.dreams.block.CarBlock;
import com.example.dreams.block.ModBlocks;
import com.example.dreams.dream.world.town.Town;
import com.example.dreams.dream.world.town.Town.B;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.*;
import net.minecraft.world.level.chunk.ChunkAccess;

import java.util.ArrayList;
import java.util.List;

/**
 * Мир Иной стороны: на каждую область 512x512 один городок на краю пропасти. Здесь рельеф (плато, холмы, пропасть
 * с карнизами), перевод смысловых блоков Town в настоящие и запись в чанк. Саму планировку и здания строит
 * dream.world.town.Town без зависимостей от Minecraft.
 */
public final class OtherworldGen {
    private OtherworldGen() {}

    public static final int HEIGHT = 256;
    public static final int REGION = Town.REGION;
    public static final int G = Town.G;

    // ------------------------------------------------------------------ область и поворот
    public static int regionOf(int w) { return Math.floorDiv(w, REGION); }

    public static long regionSeed(long seed, int rx, int rz) {
        long h = seed ^ (rx * 0x9E3779B97F4A7C15L) ^ (rz * 0xC2B2AE3D27D4EB4FL);
        h ^= h >>> 31; h *= 0xff51afd7ed558ccdL; h ^= h >>> 29;
        return h;
    }

    public static int rotOf(long regionSeed) { return (int) ((regionSeed >>> 40) & 3); }

    public static int centerX(int rx) { return rx * REGION + REGION / 2; }

    public static int centerZ(int rz) { return rz * REGION + REGION / 2; }

    /** Город -> мир. */
    public static int worldX(int cx, int rot, int u, int v) {
        for (int i = 0; i < rot; i++) { int t = u; u = -v; v = t; }
        return cx + u;
    }

    public static int worldZ(int cz, int rot, int u, int v) {
        for (int i = 0; i < rot; i++) { int t = u; u = -v; v = t; }
        return cz + v;
    }

    /** Мир -> город (обратный поворот). */
    static int localU(int cx, int cz, int rot, int wx, int wz) {
        int u = wx - cx, v = wz - cz;
        for (int i = 0; i < (4 - rot) % 4; i++) { int t = u; u = -v; v = t; }
        return u;
    }

    static int localV(int cx, int cz, int rot, int wx, int wz) {
        int u = wx - cx, v = wz - cz;
        for (int i = 0; i < (4 - rot) % 4; i++) { int t = u; u = -v; v = t; }
        return v;
    }

    static Direction dir(int d, int rot) {
        switch ((d + rot) & 3) {
            case 0: return Direction.NORTH;
            case 1: return Direction.EAST;
            case 2: return Direction.SOUTH;
            default: return Direction.WEST;
        }
    }

    // ------------------------------------------------------------------ метки города для игры (старт, кровать, печати)
    public static final class Marks {
        public BlockPos start, bed;
        public final List<BlockPos> seals = new ArrayList<>();
        public int rot;
    }

    /** Прогоняет город вхолостую и собирает метки в мировых координатах. Для входа в сон. */
    public static Marks marks(long seed, int rx, int rz) {
        long rs = regionSeed(seed, rx, rz);
        int rot = rotOf(rs), cx = centerX(rx), cz = centerZ(rz);
        Marks m = new Marks();
        m.rot = rot;
        Town.build(new Town.Sink() {
            public void put(int x, int y, int z, B b) {}
            public void face(int x, int y, int z, B b, int d) {}
            public void stair(int x, int y, int z, B f, int d, boolean t, int s) {}
            public void slab(int x, int y, int z, B f, boolean t) {}
            public void door(int x, int y, int z, B k, int d, boolean h) {}
            public void conn(int x, int y, int z, B b, int mk) {}
            public void bed(int x, int y, int z, B c, int d) {}
            public void car(int x, int y, int z, int v, int d, int c) {}
            public void log(int x, int y, int z, int a) {}
            public void trapdoor(int x, int y, int z, B k, int d, boolean o, boolean t) {}

            @Override
            public void mark(String name, int x, int y, int z) {
                BlockPos p = new BlockPos(worldX(cx, rot, x, z), y, worldZ(cz, rot, x, z));
                switch (name) {
                    case "start": m.start = p; break;
                    case "bed": m.bed = p; break;
                    case "seal": m.seals.add(p); break;
                    default: break;
                }
            }
        }, rs, Town.Clip.ALL);
        return m;
    }

    /** Направление, в которое лучше смотреть на старте: на церковь и пропасть (на север города). */
    public static float startYaw(int rot) {
        // город-север = мировое направление (0 + rot); yaw 180 = север, 270 = восток, 0 = юг, 90 = запад
        Direction d = dir(0, rot);
        return d.toYRot();
    }

    // ------------------------------------------------------------------ генерация чанка
    public static void generate(ChunkAccess chunk, long seed) {
        int x0 = chunk.getPos().getMinBlockX(), z0 = chunk.getPos().getMinBlockZ();
        int rx = regionOf(x0), rz = regionOf(z0);
        if (rx != 0 || rz != 0) return;   // остров ровно один (область 0,0); всё остальное пустота
        long rs = regionSeed(seed, rx, rz);
        int rot = rotOf(rs), cx = centerX(rx), cz = centerZ(rz);
        BlockState grass = Blocks.GRASS_BLOCK.defaultBlockState(), dirt = ModBlocks.CITY_DIRT.get().defaultBlockState();
        BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();

        for (int dx = 0; dx < 16; dx++) {
            for (int dz = 0; dz < 16; dz++) {
                int wx = x0 + dx, wz = z0 + dz;
                int u = localU(cx, cz, rot, wx, wz), v = localV(cx, cz, rot, wx, wz);
                int top = Town.ground(seed, wx, wz, u, v);
                boolean ab = Town.inAbyss(rs, u, v);
                int fill = top;
                if (ab) {
                    double s = Town.rimDepth(rs, u, v);
                    fill = -1;
                    if (s < 5.0) {   // осыпающаяся кромка: уступы быстро уходят вниз
                        double j = Town.rand(rs, wx, wz, 0, 88) * 2.0;
                        int t = top - 1 - (int) (s * s * 1.2 + j);
                        if (t > 14) fill = t;
                    }
                }
                for (int y = 1; y <= fill; y++) {
                    BlockState st;
                    if (!ab && y == top) st = grass;
                    else if (!ab && y > top - 3) st = dirt;
                    else st = rock(rs, wx, y, wz);
                    chunk.setBlockState(mp.set(wx, y, wz), st, false);
                }
                if (ab) {
                    int lo = Math.max(4, 14), hi = G - 4;
                    for (int y = lo; y <= hi; y++) {
                        if (y <= fill) continue;
                        if (Town.ledge(rs, u, v, y)) chunk.setBlockState(mp.set(wx, y, wz), rock(rs, wx, y, wz), false);
                    }
                }
            }
        }

        int rotInv = rot;
        ChunkSink sink = new ChunkSink(chunk, cx, cz, rotInv, x0, z0);
        // окно просмотра в системе города: углы чанка в обратном повороте
        int ua = localU(cx, cz, rot, x0, z0), va = localV(cx, cz, rot, x0, z0);
        int ub = localU(cx, cz, rot, x0 + 15, z0 + 15), vb = localV(cx, cz, rot, x0 + 15, z0 + 15);
        Town.Clip clip = new Town.Clip(Math.min(ua, ub), Math.min(va, vb), Math.max(ua, ub), Math.max(va, vb));
        Town.build(sink, rs, clip);
    }

    /** Порода: ярусы камня, ржавые и кровавые прожилки, глаз на стене пропасти. */
    static BlockState rock(long rs, int x, int y, int z) {
        double r = Town.rand(rs, x, y, z, 99);
        if (r < 0.025) return ModBlocks.VEINED_STONE.get().defaultBlockState();
        if (r < 0.035) return ModBlocks.RUST_PLATE.get().defaultBlockState();
        if (r < 0.0375) return ModBlocks.RUST_BLOODY.get().defaultBlockState();
        if (r < 0.04 && y < 50) return ModBlocks.FLESH.get().defaultBlockState();
        if (y < 30) return Blocks.DEEPSLATE.defaultBlockState();
        return ((y / 5) & 1) == 0 ? Blocks.STONE.defaultBlockState() : Blocks.ANDESITE.defaultBlockState();
    }

    // ------------------------------------------------------------------ запись в чанк
    static final class ChunkSink implements Town.Sink {
        final ChunkAccess chunk; final int cx, cz, rot, x0, z0;
        final BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();

        ChunkSink(ChunkAccess chunk, int cx, int cz, int rot, int x0, int z0) {
            this.chunk = chunk; this.cx = cx; this.cz = cz; this.rot = rot; this.x0 = x0; this.z0 = z0;
        }

        void set(int u, int y, int v, BlockState st) {
            if (y < 1 || y >= HEIGHT) return;
            int wx = worldX(cx, rot, u, v), wz = worldZ(cz, rot, u, v);
            if (wx < x0 || wx > x0 + 15 || wz < z0 || wz > z0 + 15) return;
            chunk.setBlockState(mp.set(wx, y, wz), st, false);
        }

        Direction d(int d) { return dir(d, rot); }

        @Override public void put(int x, int y, int z, B b) { set(x, y, z, state(b)); }

        @Override public void face(int x, int y, int z, B b, int dd) {
            BlockState st = state(b);
            if (st.hasProperty(HorizontalDirectionalBlock.FACING)) st = st.setValue(HorizontalDirectionalBlock.FACING, d(dd));
            else if (st.hasProperty(BlockStateProperties.HORIZONTAL_FACING)) st = st.setValue(BlockStateProperties.HORIZONTAL_FACING, d(dd));
            set(x, y, z, st);
        }

        @Override public void stair(int x, int y, int z, B fam, int dd, boolean top, int shape) {
            BlockState st = stairState(fam);
            st = st.setValue(StairBlock.FACING, d(dd)).setValue(StairBlock.HALF, top ? Half.TOP : Half.BOTTOM);
            StairsShape sh = switch (shape) {
                case 1 -> StairsShape.INNER_LEFT; case 2 -> StairsShape.INNER_RIGHT;
                case 3 -> StairsShape.OUTER_LEFT; case 4 -> StairsShape.OUTER_RIGHT; default -> StairsShape.STRAIGHT;
            };
            set(x, y, z, st.setValue(StairBlock.SHAPE, sh));
        }

        @Override public void slab(int x, int y, int z, B fam, boolean top) {
            set(x, y, z, slabState(fam).setValue(SlabBlock.TYPE, top ? SlabType.TOP : SlabType.BOTTOM));
        }

        @Override public void door(int x, int y, int z, B kind, int dd, boolean hingeRight) {
            Block b = switch (kind) {
                case DOOR_OAK -> Blocks.OAK_DOOR; case DOOR_SPRUCE -> Blocks.SPRUCE_DOOR;
                case DOOR_IRON -> Blocks.IRON_DOOR; default -> Blocks.DARK_OAK_DOOR;
            };
            BlockState lo = b.defaultBlockState().setValue(DoorBlock.FACING, d(dd))
                    .setValue(DoorBlock.HINGE, hingeRight ? DoorHingeSide.RIGHT : DoorHingeSide.LEFT)
                    .setValue(DoorBlock.OPEN, false).setValue(DoorBlock.POWERED, false);
            set(x, y, z, lo.setValue(DoorBlock.HALF, DoubleBlockHalf.LOWER));
            set(x, y + 1, z, lo.setValue(DoorBlock.HALF, DoubleBlockHalf.UPPER));
        }

        @Override public void conn(int x, int y, int z, B b, int mask) {
            int m = 0;
            for (int i = 0; i < 4; i++) if ((mask & (1 << i)) != 0) m |= 1 << ((i + rot) & 3);
            boolean n = (m & 1) != 0, e = (m & 2) != 0, s = (m & 4) != 0, w = (m & 8) != 0;
            BlockState st = switch (b) {
                case FENCE_SPRUCE -> Blocks.SPRUCE_FENCE.defaultBlockState();
                case FENCE_DARK -> Blocks.DARK_OAK_FENCE.defaultBlockState();
                case PANE -> Blocks.GLASS_PANE.defaultBlockState();
                case BARS -> Blocks.IRON_BARS.defaultBlockState();
                case FENCE_CHAIN_LOW -> ModBlocks.CITY_FENCE_LOW.get().defaultBlockState();
                default -> ModBlocks.CITY_FENCE_UP.get().defaultBlockState();
            };
            st = st.setValue(BlockStateProperties.NORTH, n).setValue(BlockStateProperties.EAST, e)
                    .setValue(BlockStateProperties.SOUTH, s).setValue(BlockStateProperties.WEST, w);
            set(x, y, z, st);
        }

        @Override public void bed(int x, int y, int z, B color, int dd) {
            Block b = color == B.BED_RED ? Blocks.RED_BED : color == B.BED_GRAY ? Blocks.GRAY_BED : Blocks.WHITE_BED;
            Direction f = d(dd);
            BlockState foot = b.defaultBlockState().setValue(BedBlock.FACING, f).setValue(BedBlock.PART, BedPart.FOOT);
            set(x, y, z, foot);
            // голова на соседней клетке (в системе города: на шаг dd)
            set(x + Town.dx(dd), y, z + Town.dz(dd), foot.setValue(BedBlock.PART, BedPart.HEAD));
        }

        @Override public void car(int x, int y, int z, int variant, int dd, int cell) {
            Block b = switch (variant & 3) {
                case 0 -> ModBlocks.CITY_CAR_A.get(); case 1 -> ModBlocks.CITY_CAR_B.get();
                case 2 -> ModBlocks.CITY_CAR_C.get(); default -> ModBlocks.CITY_CAR_D.get();
            };
            set(x, y, z, b.defaultBlockState().setValue(HorizontalDirectionalBlock.FACING, d(dd)).setValue(CarBlock.CELL, cell));
        }

        @Override public void log(int x, int y, int z, int axis) {
            // ось в системе города: поворот на нечётное число четвертей меняет x и z местами
            Direction.Axis a = axis == 1 ? Direction.Axis.Y : ((axis == 0) == ((rot & 1) == 0) ? Direction.Axis.X : Direction.Axis.Z);
            set(x, y, z, Blocks.DARK_OAK_LOG.defaultBlockState().setValue(RotatedPillarBlock.AXIS, a));
        }

        @Override public void trapdoor(int x, int y, int z, B kind, int dd, boolean open, boolean top) {
            Block b = kind == B.TRAPDOOR_SPRUCE ? Blocks.SPRUCE_TRAPDOOR : Blocks.DARK_OAK_TRAPDOOR;
            set(x, y, z, b.defaultBlockState().setValue(TrapDoorBlock.FACING, d(dd)).setValue(TrapDoorBlock.OPEN, open)
                    .setValue(TrapDoorBlock.HALF, top ? Half.TOP : Half.BOTTOM));
        }
    }

    // ------------------------------------------------------------------ смысловой блок -> настоящий
    static BlockState stairState(B fam) {
        Block b = switch (fam) {
            case ROOF -> ModBlocks.TOWN_ROOF_STAIRS.get(); case ROOF_RED -> ModBlocks.TOWN_ROOF_RED_STAIRS.get();
            case STONE -> ModBlocks.TOWN_STONE_STAIRS.get(); case WOOD -> ModBlocks.TOWN_WOOD_STAIRS.get();
            case CONCRETE -> ModBlocks.TOWN_CONCRETE_STAIRS.get(); case CURB -> ModBlocks.CITY_CURB_STAIRS.get();
            case BRICK -> ModBlocks.CITY_BRICK_STAIRS.get(); case V_SPRUCE -> Blocks.SPRUCE_STAIRS;
            case V_DARK -> Blocks.DARK_OAK_STAIRS; case V_QUARTZ -> Blocks.QUARTZ_STAIRS;
            case V_STONEBRICK -> Blocks.STONE_BRICK_STAIRS; default -> Blocks.OAK_STAIRS;
        };
        return b.defaultBlockState();
    }

    static BlockState slabState(B fam) {
        Block b = switch (fam) {
            case ROOF -> ModBlocks.TOWN_ROOF_SLAB.get(); case ROOF_RED -> ModBlocks.TOWN_ROOF_RED_SLAB.get();
            case STONE -> ModBlocks.TOWN_STONE_SLAB.get(); case WOOD -> ModBlocks.TOWN_WOOD_SLAB.get();
            case CONCRETE -> ModBlocks.TOWN_CONCRETE_SLAB.get(); case CURB -> ModBlocks.CITY_CURB_SLAB.get();
            case BRICK -> ModBlocks.CITY_BRICK_SLAB.get(); case V_SPRUCE -> Blocks.SPRUCE_SLAB;
            case V_DARK -> Blocks.DARK_OAK_SLAB; case V_QUARTZ -> Blocks.QUARTZ_SLAB;
            case V_STONEBRICK -> Blocks.STONE_BRICK_SLAB; default -> Blocks.OAK_SLAB;
        };
        return b.defaultBlockState();
    }

    static BlockState state(B b) {
        Block k = switch (b) {
            case AIR -> Blocks.AIR;
            case ASPHALT -> ModBlocks.CITY_ASPHALT.get(); case CURB -> ModBlocks.CITY_CURB.get();
            case COBBLE -> ModBlocks.CITY_COBBLE.get(); case COBBLE_BLOOD -> ModBlocks.CITY_COBBLE_BLOOD.get();
            case DIRT_C -> ModBlocks.CITY_DIRT.get(); case ASH -> ModBlocks.ASHEN_DIRT.get();
            case GRASS -> Blocks.GRASS_BLOCK; case STONE_V -> Blocks.STONE; case DEEPSLATE -> Blocks.DEEPSLATE;
            case COBBLE_V -> Blocks.COBBLESTONE;
            case ROAD_YELLOW -> Blocks.YELLOW_TERRACOTTA; case ROAD_WHITE -> Blocks.WHITE_TERRACOTTA;
            case BRICK -> ModBlocks.CITY_BRICK.get(); case BRICK_DARK -> ModBlocks.CITY_BRICK_DARK.get();
            case BRICK_BLOOD -> ModBlocks.CITY_BRICK_BLOOD.get(); case BEAM -> ModBlocks.CITY_BEAM.get();
            case PLASTER -> ModBlocks.TOWN_PLASTER.get(); case PLASTER_GREEN -> ModBlocks.TOWN_PLASTER_GREEN.get();
            case SIDING -> ModBlocks.TOWN_SIDING.get(); case SIDING_DARK -> ModBlocks.TOWN_SIDING_DARK.get();
            case TILE_WHITE -> ModBlocks.TOWN_TILE_WHITE.get(); case TILE_GREEN -> ModBlocks.TOWN_TILE_GREEN.get();
            case CHECKER -> ModBlocks.TOWN_FLOOR_CHECK.get(); case METAL_ROOF -> ModBlocks.TOWN_METAL_ROOF.get();
            case ROOF -> ModBlocks.TOWN_ROOF.get(); case ROOF_RED -> ModBlocks.TOWN_ROOF_RED.get();
            case STONE -> ModBlocks.TOWN_STONE.get(); case WOOD -> ModBlocks.TOWN_WOOD.get();
            case CONCRETE -> ModBlocks.TOWN_CONCRETE.get();
            case RUST_PLATE -> ModBlocks.RUST_PLATE.get(); case RUST_BLOODY -> ModBlocks.RUST_BLOODY.get();
            case RUST_GRATE -> ModBlocks.RUST_GRATE.get(); case VEINED -> ModBlocks.VEINED_STONE.get();
            case FLESH -> ModBlocks.FLESH.get(); case EYE -> ModBlocks.EYE_STONE.get();
            case WIN_A -> ModBlocks.CITY_WINDOW_A.get(); case WIN_B -> ModBlocks.CITY_WINDOW_B.get();
            case WIN_C -> ModBlocks.CITY_WINDOW_C.get();
            case DOOR_STEEL_L -> ModBlocks.CITY_DOOR_L.get(); case DOOR_STEEL_R -> ModBlocks.CITY_DOOR_R.get();
            case GLASS -> Blocks.GLASS; case GLASS_RED -> Blocks.RED_STAINED_GLASS; case GLASS_BLUE -> Blocks.BLUE_STAINED_GLASS;
            case GLASS_PURPLE -> Blocks.PURPLE_STAINED_GLASS; case GLASS_AMBER -> Blocks.ORANGE_STAINED_GLASS;
            case GLASS_GREEN -> Blocks.GREEN_STAINED_GLASS; case GLASS_GRAY -> Blocks.GRAY_STAINED_GLASS;
            case PANE -> Blocks.GLASS_PANE; case BARS -> Blocks.IRON_BARS;
            case PLANKS_ROT -> ModBlocks.ROTTEN_PLANKS.get(); case PLANKS_DARK -> Blocks.DARK_OAK_PLANKS;
            case PLANKS_SPRUCE -> Blocks.SPRUCE_PLANKS; case STONE_BRICKS -> Blocks.STONE_BRICKS;
            case CRACKED_BRICKS -> Blocks.CRACKED_STONE_BRICKS; case MOSSY_BRICKS -> Blocks.MOSSY_STONE_BRICKS;
            case POLISHED -> Blocks.POLISHED_ANDESITE; case SMOOTH_STONE -> Blocks.SMOOTH_STONE;
            case QUARTZ -> Blocks.QUARTZ_BLOCK; case QUARTZ_PILLAR -> Blocks.QUARTZ_PILLAR;
            case DEEPSLATE_TILES -> Blocks.DEEPSLATE_TILES; case IRON_BLOCK -> Blocks.IRON_BLOCK;
            case COAL_BLOCK -> Blocks.COAL_BLOCK;
            case CONCRETE_WHITE -> Blocks.WHITE_CONCRETE; case CONCRETE_BLACK -> Blocks.BLACK_CONCRETE;
            case CONCRETE_RED -> Blocks.RED_CONCRETE; case CONCRETE_GRAY -> Blocks.GRAY_CONCRETE;
            case CONCRETE_BLUE -> Blocks.BLUE_CONCRETE; case CONCRETE_YELLOW -> Blocks.YELLOW_CONCRETE;
            case WOOL_RED -> Blocks.RED_WOOL; case WOOL_WHITE -> Blocks.WHITE_WOOL; case WOOL_GRAY -> Blocks.GRAY_WOOL;
            case CARPET_RED -> Blocks.RED_CARPET; case CARPET_GRAY -> Blocks.GRAY_CARPET;
            case CARPET_WHITE -> Blocks.WHITE_CARPET; case CARPET_GREEN -> Blocks.GREEN_CARPET;
            case BOOKSHELF -> Blocks.BOOKSHELF; case CRAFTING -> Blocks.CRAFTING_TABLE; case BARREL_V -> Blocks.BARREL;
            case CAULDRON -> Blocks.CAULDRON; case LECTERN -> Blocks.LECTERN; case CHEST -> Blocks.CHEST;
            case FURNACE -> Blocks.FURNACE; case BELL -> Blocks.BELL; case LADDER -> Blocks.LADDER;
            case LANTERN, LANTERN_HANG -> Blocks.LANTERN; case SOUL_LANTERN, SOUL_HANG -> Blocks.SOUL_LANTERN;
            case CHAIN -> Blocks.CHAIN; case SEA_LANTERN -> Blocks.SEA_LANTERN; case GLOW -> Blocks.SHROOMLIGHT;
            case CANDLE -> Blocks.CANDLE;
            case FENCE_SPRUCE -> Blocks.SPRUCE_FENCE; case FENCE_DARK -> Blocks.DARK_OAK_FENCE;
            case FENCE_GATE_DARK -> Blocks.DARK_OAK_FENCE_GATE;
            case LAMP_BASE -> ModBlocks.CITY_LAMP_BASE.get(); case LAMP_POLE -> ModBlocks.CITY_LAMP_POLE.get();
            case LAMP_TOP -> ModBlocks.CITY_LAMP_TOP.get(); case LAMP_HEAD -> ModBlocks.CITY_LAMP_HEAD.get();
            case LAMP_HEAD_DEAD -> ModBlocks.CITY_LAMP_HEAD_DEAD.get(); case SIGNAL_HEAD -> ModBlocks.CITY_SIGNAL_HEAD.get();
            case HYDRANT -> ModBlocks.CITY_HYDRANT.get(); case BARREL -> ModBlocks.CITY_BARREL.get();
            case BIN -> ModBlocks.CITY_BIN.get(); case BARRIER -> ModBlocks.CITY_BARRIER.get();
            case FENCE_CHAIN_LOW -> ModBlocks.CITY_FENCE_LOW.get(); case FENCE_CHAIN_UP -> ModBlocks.CITY_FENCE_UP.get();
            case LOG -> Blocks.DARK_OAK_LOG; case DEAD_BUSH -> Blocks.DEAD_BUSH; case GRASS_SHORT -> Blocks.SHORT_GRASS;
            case COBWEB -> Blocks.COBWEB;
            case SEAL_STONE -> ModBlocks.SEAL.get(); case GRAVE -> Blocks.STONE_BRICKS;
            case BUTTON -> Blocks.STONE_BUTTON; case PRESSURE -> Blocks.STONE_PRESSURE_PLATE;
            case DOOR_OAK -> Blocks.OAK_DOOR; case DOOR_DARK -> Blocks.DARK_OAK_DOOR;
            case DOOR_SPRUCE -> Blocks.SPRUCE_DOOR; case DOOR_IRON -> Blocks.IRON_DOOR;
            case TRAPDOOR_DARK -> Blocks.DARK_OAK_TRAPDOOR; case TRAPDOOR_SPRUCE -> Blocks.SPRUCE_TRAPDOOR;
            case BED_WHITE -> Blocks.WHITE_BED; case BED_RED -> Blocks.RED_BED; case BED_GRAY -> Blocks.GRAY_BED;
            case V_SPRUCE, V_DARK, V_QUARTZ, V_STONEBRICK, V_OAK, CAR -> Blocks.STONE;
        };
        BlockState st = k.defaultBlockState();
        if (b == B.LANTERN_HANG || b == B.SOUL_HANG) st = st.setValue(LanternBlock.HANGING, true);
        if (b == B.CANDLE) st = st.setValue(CandleBlock.LIT, true);
        if (b == B.BELL) st = st.setValue(BellBlock.ATTACHMENT, BellAttachType.CEILING);
        return st;
    }
}
