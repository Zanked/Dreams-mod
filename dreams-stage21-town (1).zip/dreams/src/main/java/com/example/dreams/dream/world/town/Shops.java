package com.example.dreams.dream.world.town;

import com.example.dreams.dream.world.town.Town.B;
import com.example.dreams.dream.world.town.TownMap.Lot;

import static com.example.dreams.dream.world.town.Town.F0;
import static com.example.dreams.dream.world.town.Town.G;

/** Магазины на главной улице, закусочная и заправка. */
final class Shops {
    private Shops() {}

    static void shop(Cx c, Lot lot) {
        int w = lot.front == 0 || lot.front == 2 ? lot.u1 - lot.u0 + 1 : lot.v1 - lot.v0 + 1;
        w = 10; int d = 15;
        Cx h = Buildings.place(c, lot, w, d, 0, 1);
        long sd = lot.seed;
        B wall = Town.rand(sd, 1, 1, 1, 1) < 0.5 ? B.BRICK : B.PLASTER;
        int yc = F0 + 8;
        h.box(0, F0, 0, w - 1, F0, d - 1, B.PLANKS_ROT);
        h.rwalls(0, 0, w - 1, d - 1, F0 + 1, yc, wall, wall == B.BRICK ? B.BRICK_DARK : B.PLASTER_GREEN, 0.08, 701);
        h.walls(0, 0, w - 1, d - 1, F0, F0 + 1, B.CONCRETE);
        for (int y : new int[]{F0 + 4, yc}) { h.walls(-1, -1, w, d, y, y, B.STONE); }
        h.box(1, F0 + 4, 1, w - 2, F0 + 4, d - 2, B.PLANKS_DARK);
        h.box(1, yc, 1, w - 2, yc, d - 2, B.CONCRETE);
        h.walls(-1, -1, w, d, yc + 1, yc + 1, wall);
        h.walls(-1, -1, w, d, yc + 2, yc + 2, B.CURB);
        // витрина: большие окна и вход
        for (int x = 1; x < w - 1; x++) { for (int y = F0 + 1; y <= F0 + 3; y++) h.p(x, y, d - 1, B.GLASS); h.p(x, F0 + 1, d - 1, B.CONCRETE); }
        h.box(w / 2, F0 + 1, d - 1, w / 2, F0 + 3, d - 1, B.AIR);
        h.door(w / 2, F0 + 1, d - 1, B.DOOR_DARK, 2, false);
        h.stair(w / 2, F0, d, B.CURB, 0, false);
        // окна второго этажа
        for (int x = 2; x < w - 2; x += 3) { h.window(x, F0 + 6, d - 1, 710); h.window(x, F0 + 7, d - 1, 711); h.window(x, F0 + 6, 0, 712); h.window(x, F0 + 7, 0, 713); }
        for (int z = 3; z < d - 3; z += 4) for (int xx : new int[]{0, w - 1}) { h.window(xx, F0 + 2, z, 714); h.window(xx, F0 + 6, z, 715); h.window(xx, F0 + 7, z, 716); }
        // полосатый тент
        for (int x = 0; x < w; x++) {
            B col = x % 2 == 0 ? B.WOOL_RED : B.WOOL_WHITE;
            h.p(x, F0 + 4, d, col); h.p(x, F0 + 3, d + 1, col);
        }
        // вывеска и лампа
        h.box(2, F0 + 5, d, w - 3, F0 + 5, d, B.WOOD);
        h.p(w / 2, F0 + 2, d + 1, B.LANTERN_HANG);
        // внутри: прилавок и полки
        for (int x = 2; x < w - 2; x++) h.slab(x, F0 + 1, d - 6, B.V_DARK, false);
        for (int x = 1; x < w - 1; x++) { h.p(x, F0 + 1, 1, B.BOOKSHELF); h.p(x, F0 + 2, 1, B.BOOKSHELF); }
        h.p(2, F0 + 1, 4, B.BARREL_V); h.p(w - 3, F0 + 1, 4, B.BARREL_V);
        Buildings.lamp(h, w / 2, F0 + 4, d - 4);
        Buildings.lamp(h, w / 2, F0 + 4, 4);
        // второй этаж: склад и лестница
        for (int i = 0; i < 4; i++) h.stair(1, F0 + 1 + i, 3 + i, B.V_SPRUCE, 2, false);
        for (int i = 0; i < 3; i++) h.p(1, F0 + 4, 3 + i, B.AIR);
        for (int i = 0; i < 4; i++) { h.p(2, F0 + 1 + i, 3 + i, B.AIR); }
        h.p(5, F0 + 5, 3, B.CHEST); h.p(6, F0 + 5, 3, B.BARREL_V);
        h.bed(w - 3, F0 + 5, 6, B.BED_GRAY, 0);
        Buildings.lamp(h, w / 2, yc, 6);
    }

    static void diner(Cx c, Lot lot) {
        int w = 18, d = 11;
        Cx h = Buildings.place(c, lot, w, d, 0, 8);
        int yc = F0 + 4;
        h.box(0, F0, 0, w - 1, F0, d - 1, B.CHECKER);
        h.walls(0, 0, w - 1, d - 1, F0, F0 + 1, B.CONCRETE);
        h.rwalls(0, 0, w - 1, d - 1, F0 + 2, yc, B.PLASTER, B.PLASTER_GREEN, 0.1, 721);
        // сплошное остекление фасада и боков
        for (int x = 1; x < w - 1; x++) { h.p(x, F0 + 2, d - 1, B.GLASS); h.p(x, F0 + 3, d - 1, B.GLASS); }
        for (int z = 2; z < d - 1; z += 2) for (int xx : new int[]{0, w - 1}) { h.window(xx, F0 + 2, z, 722); h.window(xx, F0 + 3, z, 723); }
        h.box(w / 2, F0 + 1, d - 1, w / 2 + 1, F0 + 3, d - 1, B.AIR);
        h.door(w / 2, F0 + 1, d - 1, B.DOOR_DARK, 2, false); h.door(w / 2 + 1, F0 + 1, d - 1, B.DOOR_DARK, 2, true);
        h.stair(w / 2, F0, d, B.CURB, 0, false); h.stair(w / 2 + 1, F0, d, B.CURB, 0, false);
        h.box(-1, yc, -1, w, yc, d, B.CONCRETE);
        h.walls(-1, -1, w, d, yc + 1, yc + 1, B.CONCRETE_RED);
        // навес-козырёк
        for (int x = -1; x <= w; x++) h.p(x, yc, d, x % 2 == 0 ? B.WOOL_RED : B.WOOL_WHITE);
        // шест с вывеской
        h.box(w + 2, F0, d + 1, w + 2, F0 + 9, d + 1, B.BEAM);
        h.box(w + 1, F0 + 7, d + 1, w + 3, F0 + 9, d + 1, B.CONCRETE_RED);
        h.p(w + 2, F0 + 8, d + 1, B.SEA_LANTERN);
        // стойка со стульями у задней стены, кабинки у окон
        for (int x = 2; x < w - 2; x++) h.p(x, F0 + 1, 3, B.CONCRETE_RED);
        for (int x = 2; x < w - 2; x++) h.slab(x, F0 + 2, 3, B.QUARTZ, false);
        for (int x = 3; x < w - 3; x += 2) h.stair(x, F0 + 1, 5, B.V_DARK, 0, false);
        for (int x = 2; x < w - 3; x += 5) {
            h.stair(x, F0 + 1, d - 3, B.V_DARK, 1, false); h.stair(x + 2, F0 + 1, d - 3, B.V_DARK, 3, false);
            Buildings.table(h, x + 1, F0 + 1, d - 3);
        }
        h.p(2, F0 + 1, 1, B.FURNACE); h.p(3, F0 + 1, 1, B.FURNACE); h.p(w - 3, F0 + 1, 1, B.CAULDRON); h.p(w - 4, F0 + 1, 1, B.BARREL_V);
        for (int x = 4; x < w - 3; x += 5) Buildings.lamp(h, x, yc, 6);
        h.mark("seal", w / 2, F0 + 1, 7);
        // стоянка с машиной
        TownMap.car(c, lot.u0 + 1, lot.v0 + 1, true, true, 3);
    }

    static void gas(Cx c, Lot lot) {
        int w = 14, d = 9;
        Cx h = Buildings.place(c, lot, w, d, 8, 18);
        int yc = F0 + 4;
        h.box(0, F0, 0, w - 1, F0, d - 1, B.CHECKER);
        h.walls(0, 0, w - 1, d - 1, F0, F0 + 1, B.CONCRETE);
        h.rwalls(0, 0, w - 1, d - 1, F0 + 2, yc, B.CONCRETE, B.PLASTER, 0.12, 731);
        for (int x = 1; x < 8; x++) { h.p(x, F0 + 2, d - 1, B.GLASS); h.p(x, F0 + 3, d - 1, B.GLASS); }
        h.box(9, F0 + 1, d - 1, 9, F0 + 3, d - 1, B.AIR);
        h.door(9, F0 + 1, d - 1, B.DOOR_DARK, 2, false);
        // гараж: стальные ворота
        h.box(11, F0 + 1, d - 1, 12, F0 + 3, d - 1, B.DOOR_STEEL_L);
        h.box(-1, yc, -1, w, yc, d, B.CONCRETE);
        h.walls(-1, -1, w, d, yc + 1, yc + 1, B.CONCRETE);
        h.p(2, F0 + 1, 2, B.BARREL_V); h.p(3, F0 + 1, 2, B.BARREL_V); h.p(1, F0 + 1, 5, B.BOOKSHELF);
        for (int x = 3; x < 8; x++) h.slab(x, F0 + 1, 5, B.V_DARK, false);
        Buildings.lamp(h, 5, yc, 4);
        // навес на столбах перед магазином
        int cx0 = -2, cx1 = w + 1, cz0 = d + 4, cz1 = d + 11;
        for (int x = cx0; x <= cx1; x++) for (int z = cz0; z <= cz1; z++) h.p(x, F0 + 6, z, B.METAL_ROOF);
        for (int x : new int[]{cx0, cx1}) for (int z : new int[]{cz0, cz1}) h.box(x, F0 + 1, z, x, F0 + 5, z, B.BEAM);
        h.walls(cx0, cz0, cx1, cz1, F0 + 7, F0 + 7, B.CONCRETE_RED);
        for (int x = cx0; x <= cx1; x += 4) h.p(x + 1, F0 + 5, cz0 + 3, B.SEA_LANTERN);
        // острова с колонками
        for (int x : new int[]{3, 10}) {
            h.box(x - 1, F0, d + 7, x + 1, F0, d + 8, B.CURB);
            h.box(x, F0 + 1, d + 7, x, F0 + 2, d + 7, B.CONCRETE_RED);
            h.p(x, F0 + 2, d + 8, B.IRON_BLOCK);
            h.p(x, F0 + 3, d + 7, B.GLASS);
        }
        h.mark("seal", 6, F0, d + 6);
        // шест с ценником
        h.box(-5, F0, d + 3, -5, F0 + 10, d + 3, B.BEAM);
        h.box(-6, F0 + 8, d + 3, -4, F0 + 10, d + 3, B.CONCRETE_YELLOW);
        h.p(-5, F0 + 9, d + 3, B.SEA_LANTERN);
        // брошенная машина у колонки
        TownMap.car(c, lot.u0 + 4, lot.v0 + 2, false, true, 0);
    }
}
