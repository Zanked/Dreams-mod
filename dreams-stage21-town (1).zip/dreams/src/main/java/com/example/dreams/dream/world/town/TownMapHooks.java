package com.example.dreams.dream.world.town;

import com.example.dreams.dream.world.town.TownMap.Lot;

/** Мелочи участков, которые рисуются в системе города (машины на стоянках и т. п.). */
final class TownMapHooks {
    private TownMapHooks() {}

    static void hospitalCar(Cx c, Lot lot) {
        // скорая (жёлтая) и пара машин на стоянке перед больницей
        TownMap.car(c, lot.u0 + 3, lot.v0 + 1, false, true, 2);
        TownMap.car(c, lot.u0 + 10, lot.v0 + 1, false, false, 1);
    }
}
