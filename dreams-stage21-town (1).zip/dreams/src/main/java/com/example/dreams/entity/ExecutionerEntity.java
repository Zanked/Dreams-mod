package com.example.dreams.entity;

import com.example.dreams.DreamConfig;
import com.example.dreams.attachment.DreamState;
import com.example.dreams.attachment.ModAttachments;
import com.example.dreams.sound.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.OpenDoorGoal;
import net.minecraft.world.entity.ai.navigation.GroundPathNavigation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;
import java.util.UUID;

/**
 * Палач: огромный, быстрый и неотвратимый. НЕ боится взгляда (в отличие от Смотрителя). Тащит за собой клинок:
 * скрежет и тяжёлые шаги слышны издалека и позиционно. Видим только своему сновидцу. Вся логика в DreamManager.
 */
public class ExecutionerEntity extends PathfinderMob {

    @Nullable
    private UUID owner;

    public ExecutionerEntity(EntityType<? extends ExecutionerEntity> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
        this.xpReward = 0;
    }

    @Override
    protected void registerGoals() {
        if (DreamConfig.COMMON.watcherOpensDoors.get() && getNavigation() instanceof GroundPathNavigation nav) {
            nav.setCanOpenDoors(true);
            this.goalSelector.addGoal(1, new OpenDoorGoal(this, true));
        }
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 40.0)
                .add(Attributes.MOVEMENT_SPEED, 0.14)   // ~6 блоков/с: быстрее бегущего игрока (5.6); вблизи и в сирену ещё быстрее
                .add(Attributes.FOLLOW_RANGE, 64.0);
    }

    public void setOwner(UUID owner) {
        this.owner = owner;
    }

    @Override
    public boolean broadcastToPlayer(ServerPlayer player) {
        return owner != null && owner.equals(player.getUUID());
    }

    @Override public boolean shouldBeSaved() { return false; }
    @Override public boolean isInvulnerableTo(DamageSource source) { return true; }
    @Override public boolean isAttackable() { return false; }
    @Override public boolean isPickable() { return false; }
    @Override public boolean isPushable() { return false; }
    @Override public boolean removeWhenFarAway(double distanceSqr) { return false; }

    @Nullable
    private ServerPlayer getOwnerPlayer() {
        if (owner == null || !(level() instanceof ServerLevel sl)) return null;
        return sl.getServer().getPlayerList().getPlayer(owner);
    }

    /** Каждый шаг - удар, слышный на ~40 блоков и только сновидцу. */
    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        ServerPlayer p = getOwnerPlayer();
        if (p == null) return;
        p.connection.send(new ClientboundSoundPacket(
                ModSounds.EXEC_STEP, SoundSource.HOSTILE, getX(), getY(), getZ(),
                4.0f, 0.62f + random.nextFloat() * 0.12f, random.nextLong()));   // тяжелее и ниже: шаг гиганта
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        ServerPlayer p = getOwnerPlayer();
        // Скрежет клинка по земле, пока идёт
        if (p != null && tickCount % 12 == 0 && !getNavigation().isDone()) {
            p.connection.send(new ClientboundSoundPacket(
                    ModSounds.EXEC_DRAG, SoundSource.HOSTILE, getX(), getY(), getZ(),
                    3.2f, 0.7f + random.nextFloat() * 0.15f, random.nextLong()));
        }
        if (tickCount % 10 != 0) return;
        boolean valid = p != null
                && p.level() == level()
                && p.getData(ModAttachments.DREAM_STATE).phase == DreamState.Phase.FALSE_AWAKE;
        if (!valid) discard();
    }
}
