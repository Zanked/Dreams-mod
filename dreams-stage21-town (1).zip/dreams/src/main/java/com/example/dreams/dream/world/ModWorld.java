package com.example.dreams.dream.world;

import com.example.dreams.Dreams;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.function.Supplier;

/** Регистрация кодека генератора: "dreams:sky_islands" в data/dreams/dimension/good_dream.json. */
public final class ModWorld {
    private ModWorld() {}

    public static final DeferredRegister<MapCodec<? extends ChunkGenerator>> CHUNK_GENERATORS =
            DeferredRegister.create(Registries.CHUNK_GENERATOR, Dreams.MODID);

    public static final Supplier<MapCodec<SkyIslandsGenerator>> SKY_ISLANDS =
            CHUNK_GENERATORS.register("sky_islands", () -> SkyIslandsGenerator.CODEC);

    /** "dreams:otherworld_town" в data/dreams/dimension/otherworld.json: городок на краю пропасти. */
    public static final Supplier<MapCodec<OtherworldGenerator>> OTHERWORLD_TOWN =
            CHUNK_GENERATORS.register("otherworld_town", () -> OtherworldGenerator.CODEC);
}
