package com.example.dreams.dream.world.town;

import com.example.dreams.dream.world.town.Town.B;
import com.example.dreams.dream.world.town.TownMap.Lot;

import static com.example.dreams.dream.world.town.Town.F0;
import static com.example.dreams.dream.world.town.Town.G;

/** Крупные общественные здания: полиция, больница, школа, отель, многоэтажка. Общая коробка + коридорная планировка. */
final class Civic {
    private Civic() {}

    // роли комнат
    static final int OFFICE = 0, WARD = 1, CELL = 2, CLASS = 3, HOTEL = 4, APT = 5, OR = 6, STORE = 7;

    // ------------------------------------------------------------------ общая коробка
    /** Стены, пилястры, окна, пол, потолок и парапет. Возвращает yc (верх стен последнего этажа). w = 6n+1: перегородки попадают на пилястры. */
    static int shell(Cx h, int w, int d, int storeys, int sh, B wall, B pier, B base, B cornice, B floor, B roofTop, int salt) {
        int yc = F0 + sh * storeys;
        h.box(0, F0, 0, w - 1, F0, d - 1, floor);
        h.rwalls(0, 0, w - 1, d - 1, F0 + 1, yc, wall, wall == B.BRICK ? B.BRICK_DARK : wall, 0.05, salt);
        // цоколь
        h.walls(0, 0, w - 1, d - 1, F0, F0 + 1, base);
        for (int k = 0; k < storeys; k++) {
            int y = F0 + sh * k;
            if (k > 0) {
                h.box(1, y, 1, w - 2, y, d - 2, floor);
                h.walls(0, 0, w - 1, d - 1, y, y, cornice);              // межэтажный пояс
            }
            for (int x = 0; x < w; x += 3) {                              // пилястры
                h.box(x, y + 1, 0, x, y + sh, 0, pier);
                h.box(x, y + 1, d - 1, x, y + sh, d - 1, pier);
            }
            for (int z = 0; z < d; z += 3) {
                h.box(0, y + 1, z, 0, y + sh, z, pier);
                h.box(w - 1, y + 1, z, w - 1, y + sh, z, pier);
            }
            int wy = y + (k == 0 ? 3 : 2);
            for (int x = 0; x < w; x++) {
                if (x % 3 == 0) continue;
                for (int dy = 0; dy < 2; dy++) { h.window(x, wy + dy, 0, salt + 3 + dy); h.window(x, wy + dy, d - 1, salt + 5 + dy); }
                h.p(x, wy - 1, d - 1, base); h.p(x, wy - 1, 0, base);
            }
            for (int z = 0; z < d; z++) {
                if (z % 3 == 0) continue;
                for (int dy = 0; dy < 2; dy++) { h.window(0, wy + dy, z, salt + 9 + dy); h.window(w - 1, wy + dy, z, salt + 11 + dy); }
            }
        }
        // потолок/крыша и парапет
        h.box(1, yc, 1, w - 2, yc, d - 2, roofTop);
        h.walls(-1, -1, w, d, yc, yc, cornice);
        h.walls(-1, -1, w, d, yc + 1, yc + 1, wall);
        h.walls(-1, -1, w, d, yc + 2, yc + 2, B.CURB);
        return yc;
    }

    /** Коридор вдоль x посередине и комнаты по обе стороны. roleBack/roleFront: роль комнат (z < cz) и (z > cz). Двери в коридор. */
    static void layout(Cx h, int w, int d, int storeys, int sh, int roleBack, int roleFront, int stairX) {
        int cz = d / 2;
        for (int k = 0; k < storeys; k++) {
            int y = F0 + sh * k;
            int top = y + sh - 1;
            // стены коридора
            for (int x = 1; x < w - 1; x++) {
                h.box(x, y + 1, cz - 2, x, top, cz - 2, B.PLASTER);
                h.box(x, y + 1, cz + 2, x, top, cz + 2, B.PLASTER);
            }
            for (int x = 6; x < w - 1; x += 6) {
                h.box(x, y + 1, 1, x, top, cz - 3, B.PLASTER);
                h.box(x, y + 1, cz + 3, x, top, d - 2, B.PLASTER);
            }
            int n = 0;
            for (int x0 = 0; x0 + 6 < w; x0 += 6, n++) {
                int xa = x0 + 1, xb = x0 + 5;
                if (x0 + 6 >= w - 1) xb = x0 + 5;
                int dxm = x0 + 3;
                // двери: в коридор
                for (int side = 0; side < 2; side++) {
                    int zz = side == 0 ? cz - 2 : cz + 2;
                    h.box(dxm, y + 1, zz, dxm, y + 2, zz, B.AIR);
                    h.door(dxm, y + 1, zz, B.DOOR_DARK, side == 0 ? 2 : 0, false);
                }
                int role = k == 0 && roleBack == WARD && false ? OFFICE : roleBack;
                furnish(h, roleBack, xa, 1, xb, cz - 3, y, 2, k, n, 0);
                furnish(h, roleFront, xa, cz + 3, xb, d - 2, y, 0, k, n, 1);
            }
            // свет в коридоре
            for (int x = 3; x < w - 3; x += 6) Buildings.lamp(h, x, y + sh, cz);
            // лестница между этажами (в конце коридора)
            if (k < storeys - 1) {
                for (int i = 0; i < sh; i++) h.stair(stairX + i, y + 1 + i, cz, B.V_SPRUCE, 1, false);
                for (int i = 0; i < sh - 1; i++) h.p(stairX + i, y + sh, cz, B.AIR);
                for (int i = 0; i < sh; i++) { h.p(stairX + i, y + 1 + i, cz - 1, B.AIR); }
            }
        }
    }

    /** Мебель комнаты. doorSide: куда выходит дверь (2 = на юг, 0 = на север). */
    static void furnish(Cx h, int role, int x0, int z0, int x1, int z1, int y, int doorSide, int k, int n, int side) {
        boolean south = doorSide == 2;                 // дальняя стена на севере
        int far = south ? z0 : z1;
        int sgn = south ? 1 : -1;
        int bedDir = south ? 0 : 2;
        int cx = (x0 + x1) / 2;
        int ceil = y + 4;
        double rr = h.r(x0, y, z0, 500 + side);
        switch (role) {
            case WARD:
                h.bed(x0 + 1, y + 1, far + sgn, B.BED_WHITE, bedDir);
                h.bed(x1 - 1, y + 1, far + sgn, B.BED_WHITE, bedDir);
                h.p(cx, y + 1, far, B.GLASS_GRAY); h.p(cx, y + 2, far, B.GLASS_GRAY);
                h.p(cx, y + 1, far + sgn, B.CHEST);
                h.p(x0, y + 2, far + sgn * 2, B.SOUL_LANTERN);
                break;
            case CELL:
                h.bed(x0 + 1, y + 1, far + sgn, B.BED_GRAY, bedDir);
                h.p(x1 - 1, y + 1, far + sgn, B.CAULDRON);
                for (int x = x0; x <= x1; x++) { int zz = south ? z1 : z0; h.p(x, y + 1, zz, B.BARS); h.p(x, y + 2, zz, B.BARS); }
                h.p(cx, y + 1, south ? z1 : z0, B.AIR); h.p(cx, y + 2, south ? z1 : z0, B.AIR);
                h.door(cx, y + 1, south ? z1 : z0, B.DOOR_IRON, doorSide, false);
                break;
            case CLASS:
                h.box(cx - 1, y + 1, far, cx + 1, y + 2, far, B.CONCRETE_BLACK);
                for (int row = 0; row < 2; row++) for (int a = x0 + 1; a <= x1 - 1; a += 2) {
                    int zz = far + sgn * (2 + row * 2);
                    h.slab(a, y + 1, zz, B.V_SPRUCE, false);
                    Buildings.chair(h, a, y + 1, zz + sgn, south ? 0 : 2);
                }
                break;
            case HOTEL:
                h.bed(cx, y + 1, far + sgn, rr < 0.5 ? B.BED_RED : B.BED_WHITE, bedDir);
                h.p(cx + 1, y + 1, far + sgn, B.CHEST);
                h.p(cx - 1, y + 1, far + sgn, B.CHEST);
                h.p(x0, y + 1, far, B.BOOKSHELF);
                h.p(cx, y + 1, far + sgn * 3, B.CARPET_RED);
                break;
            case APT:
                h.bed(x0 + 1, y + 1, far + sgn, B.BED_GRAY, bedDir);
                Buildings.table(h, x1 - 1, y + 1, far + sgn * 2);
                h.p(x1, y + 1, far, B.FURNACE); h.p(x1 - 1, y + 1, far, B.BARREL_V);
                h.p(x0, y + 1, far + sgn * 3, B.BOOKSHELF);
                break;
            case OR:
                h.box(cx - 1, y + 1, far + sgn * 2, cx + 1, y + 1, far + sgn * 3, B.QUARTZ);
                h.p(cx, y + 3, far + sgn * 2, B.SEA_LANTERN);
                h.p(x0, y + 1, far, B.CAULDRON);
                break;
            case STORE:
                h.p(x0, y + 1, far, B.BOOKSHELF); h.p(x0, y + 2, far, B.BOOKSHELF);
                h.p(x1, y + 1, far, B.BOOKSHELF); h.p(x1, y + 2, far, B.BOOKSHELF);
                break;
            default:  // OFFICE
                Buildings.table(h, cx, y + 1, far + sgn * 2);
                Buildings.chair(h, cx, y + 1, far + sgn * 3, south ? 0 : 2);
                h.p(x0, y + 1, far, B.BOOKSHELF); h.p(x0, y + 2, far, B.BOOKSHELF);
                h.p(x1, y + 1, far, B.CHEST);
                break;
        }
        Buildings.lamp(h, cx, ceil, (z0 + z1) / 2);
    }

    // ------------------------------------------------------------------ вход с портиком
    static void portico(Cx h, int x, int z, int width, int height, B col, B roofFam, boolean steps) {
        int x0 = x - width / 2, x1 = x + width / 2;
        for (int xx : new int[]{x0, x1}) h.box(xx, F0, z + 3, xx, F0 + height, z + 3, col);
        h.box(x0, F0 + height + 1, z, x1, F0 + height + 1, z + 3, B.STONE);
        for (int xx = x0 - 1; xx <= x1 + 1; xx++) h.stair(xx, F0 + height + 2, z + 3, roofFam, 0, false);
        for (int xx = x0; xx <= x1; xx++) h.box(xx, F0, z + 1, xx, F0, z + 3, B.CURB);
        if (steps) for (int xx = x0; xx <= x1; xx++) h.stair(xx, F0, z + 4, B.CURB, 0, false);
        h.p(x0 + 1, F0 + height, z + 2, B.LANTERN_HANG); h.p(x1 - 1, F0 + height, z + 2, B.LANTERN_HANG);
    }

    // ------------------------------------------------------------------ ПОЛИЦИЯ
    static void police(Cx c, Lot lot) {
        int w = 25, d = 16;
        Cx h = Buildings.place(c, lot, w, d, 0, 4);
        int yc = shell(h, w, d, 2, 4, B.BRICK, B.STONE, B.CONCRETE, B.STONE, B.CHECKER, B.CONCRETE, 100);
        layout(h, w, d, 2, 4, CELL, OFFICE, w - 8);
        // главный вход: двустворчатая дверь по центру, вестибюль
        int cx = w / 2;
        h.box(cx - 1, F0 + 1, d - 1, cx, F0 + 3, d - 1, B.AIR);
        h.door(cx - 1, F0 + 1, d - 1, B.DOOR_DARK, 2, false); h.door(cx, F0 + 1, d - 1, B.DOOR_DARK, 2, true);
        h.box(cx - 1, F0 + 3, d - 1, cx, F0 + 3, d - 1, B.WIN_A);
        // стойка дежурного и вестибюль: убираем перегородки передней комнаты у входа
        h.box(cx - 2, F0 + 1, d - 2, cx + 2, F0 + 3, cz(d) + 3, B.AIR);
        for (int x = cx - 2; x <= cx + 2; x++) h.slab(x, F0 + 1, d - 6, B.STONE, false);
        h.p(cx, F0 + 1, d - 8, B.LECTERN);
        h.p(cx - 5, F0 + 1, d - 2, B.CHEST);
        portico(h, cx, d, 6, 4, B.QUARTZ_PILLAR, B.STONE, true);
        h.p(cx - 3, F0 + 3, d + 1, B.SOUL_HANG); h.p(cx + 3, F0 + 3, d + 1, B.SOUL_HANG);
        // башня-антенна и флагшток
        h.box(w - 4, yc + 3, 4, w - 4, yc + 13, 4, B.BEAM);
        for (int y = yc + 3; y <= yc + 13; y += 3) { h.p(w - 5, y, 4, B.BARS); h.p(w - 3, y, 4, B.BARS); }
        h.p(w - 4, yc + 14, 4, B.LANTERN);
        h.box(-3, F0, d + 2, -3, F0 + 11, d + 2, B.IRON_BLOCK);
        h.box(-2, F0 + 10, d + 2, 0, F0 + 11, d + 2, B.WOOL_RED);
        h.p(-3, F0 + 12, d + 2, B.LANTERN);
        // гараж и стоянка: машины сбоку
        Cx.Net f = h.net(B.FENCE_CHAIN_UP);
        f.line(-8, d + 6, w + 7, d + 6);
        for (int x = cx - 3; x <= cx + 3; x++) f.remove(x, d + 6);
        f.flush(F0, F0);
        h.mark("seal", 12, F0 + 1, 8 - 1 + 0 * d);
    }

    static int cz(int d) { return d / 2; }

    // ------------------------------------------------------------------ БОЛЬНИЦА
    static void hospital(Cx c, Lot lot) {
        int w = 37, d = 20;
        Cx h = Buildings.place(c, lot, w, d, 0, 6);
        int yc = shell(h, w, d, 3, 4, B.PLASTER_GREEN, B.TILE_WHITE, B.CONCRETE, B.QUARTZ, B.TILE_WHITE, B.CONCRETE, 200);
        layout(h, w, d, 3, 4, WARD, OFFICE, w - 8);
        int cx = w / 2;
        // центральный павильон: выступ вперёд с крестом
        int px0 = cx - 6, px1 = cx + 6;
        h.rwalls(px0, d - 1, px1, d + 3, F0 + 1, yc + 4, B.PLASTER_GREEN, B.TILE_WHITE, 0.0, 1);
        h.box(px0 + 1, F0, d, px1 - 1, F0, d + 2, B.TILE_WHITE);
        h.box(px0 + 1, F0 + 1, d, px1 - 1, yc + 4, d + 2, B.AIR);
        h.box(px0, F0 + 1, d - 1, px1, yc + 4, d - 1, B.AIR);
        h.box(px0 + 1, yc + 4, d - 1, px1 - 1, yc + 4, d + 2, B.CONCRETE);
        h.box(px0, F0 + 1, d + 3, px1, yc + 4, d + 3, B.PLASTER_GREEN);
        for (int x = px0; x <= px1; x += 3) h.box(x, F0 + 1, d + 3, x, yc + 4, d + 3, B.TILE_WHITE);
        h.walls(px0 - 1, d - 2, px1 + 1, d + 4, yc + 4, yc + 4, B.QUARTZ);
        h.walls(px0 - 1, d - 2, px1 + 1, d + 4, yc + 5, yc + 5, B.PLASTER_GREEN);
        // красный крест на лицевой стене павильона
        h.box(cx - 1, yc, d + 3, cx + 1, yc + 3, d + 3, B.CONCRETE_RED);
        h.box(cx - 2, yc + 1, d + 3, cx + 2, yc + 2, d + 3, B.CONCRETE_RED);
        // вход: большая двустворчатая дверь, навес на колоннах
        h.box(cx - 1, F0 + 1, d + 3, cx, F0 + 3, d + 3, B.AIR);
        h.door(cx - 1, F0 + 1, d + 3, B.DOOR_IRON, 2, false); h.door(cx, F0 + 1, d + 3, B.DOOR_IRON, 2, true);
        h.box(cx - 5, F0 + 5, d + 4, cx + 4, F0 + 5, d + 8, B.CONCRETE);
        for (int xx : new int[]{cx - 5, cx + 4}) for (int zz : new int[]{d + 4, d + 8}) h.box(xx, F0 + 1, zz, xx, F0 + 4, zz, B.QUARTZ_PILLAR);
        for (int xx = cx - 5; xx <= cx + 4; xx++) h.p(xx, F0 + 6, d + 8, B.QUARTZ);
        h.box(cx - 5, F0, d + 4, cx + 4, F0, d + 8, B.CURB);
        for (int xx = cx - 2; xx <= cx + 1; xx++) h.stair(xx, F0, d + 9, B.CURB, 0, false);
        h.p(cx - 3, F0 + 4, d + 6, B.SEA_LANTERN); h.p(cx + 2, F0 + 4, d + 6, B.SEA_LANTERN);
        // вестибюль: стойка, скамьи
        for (int xx = cx - 3; xx <= cx + 3; xx++) h.slab(xx, F0 + 1, d - 6, B.V_QUARTZ, false);
        for (int xx = cx - 9; xx <= cx - 5; xx += 2) Buildings.chair(h, xx, F0 + 1, d - 3, 2);
        for (int xx = cx + 5; xx <= cx + 9; xx += 2) Buildings.chair(h, xx, F0 + 1, d - 3, 2);
        // убираем перегородки вестибюля
        h.box(cx - 8, F0 + 1, d - 8, cx + 8, F0 + 3, d - 2, B.AIR);
        for (int xx = cx - 3; xx <= cx + 3; xx++) h.slab(xx, F0 + 1, d - 6, B.V_QUARTZ, false);
        h.mark("seal", cx, F0 + 1, d - 4);
        // посадочная площадка на крыше правого крыла
        int hx = w - 8, hz = 8;
        for (int x = hx - 5; x <= hx + 5; x++) for (int z = hz - 5; z <= hz + 5; z++) {
            int d2 = (x - hx) * (x - hx) + (z - hz) * (z - hz);
            if (d2 <= 30) h.p(x, yc + 1, z, d2 > 22 ? B.CONCRETE_YELLOW : B.CONCRETE_GRAY);
        }
        for (int z = hz - 2; z <= hz + 2; z++) { h.p(hx - 1, yc + 1, z, B.CONCRETE_WHITE); h.p(hx + 1, yc + 1, z, B.CONCRETE_WHITE); }
        h.p(hx, yc + 1, hz, B.CONCRETE_WHITE);
        // стоянка и скорая у крыльца
        TownMapHooks.hospitalCar(c, lot);
    }

    // ------------------------------------------------------------------ ШКОЛА
    static void school(Cx c, Lot lot) {
        int w = 31, d = 14;
        Cx h = Buildings.place(c, lot, w, d, 0, 4);
        int yc = shell(h, w, d, 2, 4, B.BRICK, B.CONCRETE, B.CONCRETE, B.STONE, B.CHECKER, B.CONCRETE, 300);
        layout(h, w, d, 2, 4, CLASS, CLASS, w - 8);
        int cx = w / 2;
        h.box(cx - 1, F0 + 1, d - 1, cx, F0 + 3, d - 1, B.AIR);
        h.door(cx - 1, F0 + 1, d - 1, B.DOOR_DARK, 2, false); h.door(cx, F0 + 1, d - 1, B.DOOR_DARK, 2, true);
        h.box(cx - 3, F0 + 1, d - 3, cx + 2, F0 + 3, d - 2, B.AIR);
        portico(h, cx, d, 6, 3, B.STONE, B.ROOF, true);
        // колокольня на крыше
        int by = yc + 3;
        h.box(cx - 2, yc + 3, 4, cx + 2, yc + 3, 8, B.STONE);
        for (int xx : new int[]{cx - 2, cx + 2}) for (int zz : new int[]{4, 8}) h.box(xx, by + 1, zz, xx, by + 4, zz, B.STONE);
        h.p(cx, by + 4, 6, B.WOOD); h.p(cx, by + 3, 6, B.BELL);
        h.box(cx - 3, by + 5, 3, cx + 3, by + 5, 9, B.ROOF);
        for (int i = 0; i < 3; i++) for (int xx = cx - 2 + i; xx <= cx + 2 - i; xx++) { h.stair(xx, by + 6 + i, 3 + i, B.ROOF, 2, false); h.stair(xx, by + 6 + i, 9 - i, B.ROOF, 0, false); }
        h.mark("seal", cx - 4, F0 + 1, d / 2);
        // двор: забор, футбольные ворота, флагшток
        Cx.Net f = h.net(B.FENCE_CHAIN_UP);
        f.rect(-4, d + 1, w + 3, d + 18);
        for (int x = cx - 2; x <= cx + 2; x++) f.remove(x, d + 1);
        f.flush(F0, F0);
        for (int z : new int[]{d + 8, d + 12}) h.box(w - 1, F0, z, w - 1, F0 + 2, z, B.FENCE_DARK);
        h.box(w - 1, F0 + 3, d + 8, w - 1, F0 + 3, d + 12, B.FENCE_DARK);
        h.box(cx + 5, F0, d + 5, cx + 5, F0 + 9, d + 5, B.IRON_BLOCK);
    }

    // ------------------------------------------------------------------ ОТЕЛЬ
    static void hotel(Cx c, Lot lot) {
        int w = 25, d = 18;
        Cx h = Buildings.place(c, lot, w, d, 0, 3);
        int yc = shell(h, w, d, 4, 4, B.BRICK_DARK, B.STONE, B.STONE, B.STONE, B.PLANKS_DARK, B.CONCRETE, 400);
        layout(h, w, d, 4, 4, HOTEL, HOTEL, w - 8);
        int cx = w / 2;
        // вестибюль на первом этаже: сносим перегородки у входа
        h.box(cx - 5, F0 + 1, d - 9, cx + 5, F0 + 3, d - 2, B.AIR);
        h.box(cx - 1, F0 + 1, d - 1, cx, F0 + 3, d - 1, B.AIR);
        h.door(cx - 1, F0 + 1, d - 1, B.DOOR_DARK, 2, false); h.door(cx, F0 + 1, d - 1, B.DOOR_DARK, 2, true);
        for (int xx = cx - 3; xx <= cx + 3; xx++) h.slab(xx, F0 + 1, d - 6, B.V_DARK, false);
        h.p(cx - 3, F0 + 2, d - 6, B.LANTERN); h.p(cx + 3, F0 + 2, d - 6, B.LANTERN);
        for (int xx = cx - 5; xx <= cx + 5; xx++) h.p(xx, F0 + 1, d - 3, B.CARPET_RED);
        h.mark("seal", cx, F0 + 1, d - 4);
        // маркиза у входа
        h.box(cx - 4, F0 + 4, d, cx + 3, F0 + 4, d + 3, B.GLASS_RED);
        for (int xx : new int[]{cx - 4, cx + 3}) h.box(xx, F0 + 1, d + 3, xx, F0 + 3, d + 3, B.BARS);
        h.box(cx - 4, F0, d, cx + 3, F0, d + 3, B.CURB);
        for (int xx = cx - 2; xx <= cx + 1; xx++) h.stair(xx, F0, d + 4, B.CURB, 0, false);
        h.p(cx - 1, F0 + 3, d + 2, B.LANTERN_HANG); h.p(cx, F0 + 3, d + 2, B.LANTERN_HANG);
        // вертикальная неоновая вывеска на углу
        h.box(w + 1, F0 + 5, d - 1, w + 1, yc + 5, d - 1, B.CONCRETE_RED);
        h.box(w + 1, F0 + 7, d, w + 1, yc + 3, d, B.GLASS_RED);
        h.box(w, F0 + 7, d - 1, w, yc + 3, d - 1, B.SEA_LANTERN);
        // мансардное кольцо
        for (int x = -1; x <= w; x++) { h.stair(x, yc + 3, -1, B.ROOF, 2, false); h.stair(x, yc + 3, d, B.ROOF, 0, false); }
        for (int z = 0; z < d; z++) { h.stair(-1, yc + 3, z, B.ROOF, 1, false); h.stair(w, yc + 3, z, B.ROOF, 3, false); }
        h.box(0, yc + 3, 0, w - 1, yc + 3, d - 1, B.ROOF);
        for (int x : new int[]{3, w - 4}) { h.box(x, yc + 4, 3, x + 1, yc + 8, 4, B.BRICK); h.slab(x, yc + 9, 3, B.CURB, false); h.slab(x + 1, yc + 9, 3, B.CURB, false); h.slab(x, yc + 9, 4, B.CURB, false); h.slab(x + 1, yc + 9, 4, B.CURB, false); }
    }

    // ------------------------------------------------------------------ МНОГОЭТАЖКА
    static void apartments(Cx c, Lot lot) {
        int w = 31, d = 14;
        Cx h = Buildings.place(c, lot, w, d, 0, 2);
        int yc = shell(h, w, d, 4, 4, B.BRICK, B.BEAM, B.CONCRETE, B.CONCRETE, B.PLANKS_ROT, B.CONCRETE, 500);
        layout(h, w, d, 4, 4, APT, APT, w - 8);
        int cx = w / 2;
        h.box(cx - 1, F0 + 1, d - 1, cx, F0 + 3, d - 1, B.AIR);
        h.door(cx - 1, F0 + 1, d - 1, B.DOOR_DARK, 2, false); h.door(cx, F0 + 1, d - 1, B.DOOR_DARK, 2, true);
        h.box(cx - 2, F0 + 1, d - 3, cx + 1, F0 + 3, d - 2, B.AIR);
        h.box(cx - 3, F0 + 4, d, cx + 2, F0 + 4, d + 2, B.CONCRETE);
        h.box(cx - 3, F0, d, cx + 2, F0, d + 2, B.CURB);
        for (int xx = cx - 1; xx <= cx; xx++) h.stair(xx, F0, d + 3, B.CURB, 0, false);
        // пожарная лестница спереди: площадки из решёток и лестницы
        for (int k = 1; k < 4; k++) {
            int y = F0 + 4 * k;
            for (int x = 7; x <= 11; x++) { h.p(x, y, d, B.RUST_GRATE); h.p(x, y, d + 1, B.RUST_GRATE); h.p(x, y + 1, d + 1, B.BARS); }
            h.p(7, y + 1, d, B.BARS); h.p(11, y + 1, d, B.BARS);
            h.box(9, y - 3, d + 1, 9, y - 1, d + 1, B.LADDER);
        }
        // водяной бак на крыше
        h.box(w - 8, yc + 3, 3, w - 5, yc + 3, 6, B.BEAM);
        for (int xx : new int[]{w - 8, w - 5}) for (int zz : new int[]{3, 6}) h.box(xx, yc + 3, zz, xx, yc + 5, zz, B.BEAM);
        h.box(w - 8, yc + 6, 3, w - 5, yc + 8, 6, B.WOOD);
        h.box(w - 7, yc + 9, 4, w - 6, yc + 9, 5, B.ROOF);
        h.mark("seal", cx - 4, F0 + 1, d / 2);
    }
}
