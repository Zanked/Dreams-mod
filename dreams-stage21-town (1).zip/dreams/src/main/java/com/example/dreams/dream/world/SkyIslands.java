package com.example.dreams.dream.world;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LanternBlock;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.chunk.ChunkAccess;

import java.util.ArrayList;
import java.util.List;

/**
 * Мир доброго сна: парящие острова. Всё детерминировано: остров = функция (seed, ячейка), блок = функция (seed, x, y, z).
 * Постройки (деревья, пагоды, замок, мосты, водопады) считаются целиком для каждого чанка, который они задевают,
 * и пишутся только внутрь этого чанка, поэтому на стыках чанков швов нет. Прототип с картинками: proto_islands.py.
 */
public final class SkyIslands {

    private SkyIslands() {}

    public static final int CELL = 64;          // шаг сетки островов
    public static final int HOME_STEP = 16;     // каждая 16-я клетка по обеим осям: домашний остров (стартовая точка сна)
    public static final int HOME_Y = 80;        // уровень травы на домашнем острове
    public static final int HEIGHT = 256;
    /** Мир один и конечный: архипелаг только в этом радиусе клеток от домашнего острова (0, 0), дальше пустота. */
    public static final double WORLD_RADIUS = 7.0;

    // ---- блоки
    private static final BlockState AIR = Blocks.AIR.defaultBlockState();
    private static final BlockState GRASS = Blocks.GRASS_BLOCK.defaultBlockState();
    private static final BlockState DIRT = Blocks.DIRT.defaultBlockState();
    private static final BlockState COARSE = Blocks.COARSE_DIRT.defaultBlockState();
    private static final BlockState STONE = Blocks.STONE.defaultBlockState();
    private static final BlockState ANDESITE = Blocks.ANDESITE.defaultBlockState();
    private static final BlockState CALCITE = Blocks.CALCITE.defaultBlockState();
    private static final BlockState MOSS = Blocks.MOSS_BLOCK.defaultBlockState();
    private static final BlockState LOG = Blocks.CHERRY_LOG.defaultBlockState();
    private static final BlockState LEAF = Blocks.CHERRY_LEAVES.defaultBlockState().setValue(LeavesBlock.PERSISTENT, true);
    private static final BlockState WATER = Blocks.WATER.defaultBlockState();
    private static final BlockState VINE = Blocks.CAVE_VINES_PLANT.defaultBlockState();
    private static final BlockState VINE_TIP = Blocks.CAVE_VINES.defaultBlockState();
    private static final BlockState MARBLE = Blocks.QUARTZ_BLOCK.defaultBlockState();
    private static final BlockState MARBLE2 = Blocks.SMOOTH_QUARTZ.defaultBlockState();
    private static final BlockState PILLAR = Blocks.QUARTZ_PILLAR.defaultBlockState();
    private static final BlockState ROOF = Blocks.AMETHYST_BLOCK.defaultBlockState();
    private static final BlockState LANTERN = Blocks.LANTERN.defaultBlockState();
    private static final BlockState LANTERN_HANG = Blocks.LANTERN.defaultBlockState().setValue(LanternBlock.HANGING, true);
    private static final BlockState CHAIN = Blocks.CHAIN.defaultBlockState();
    private static final BlockState WINDOW = Blocks.GLOWSTONE.defaultBlockState();
    private static final BlockState CRYSTAL = Blocks.AMETHYST_BLOCK.defaultBlockState();
    private static final BlockState CLUSTER_UP = Blocks.AMETHYST_CLUSTER.defaultBlockState().setValue(BlockStateProperties.FACING, Direction.UP);
    private static final BlockState CLUSTER_DOWN = Blocks.AMETHYST_CLUSTER.defaultBlockState().setValue(BlockStateProperties.FACING, Direction.DOWN);
    private static final BlockState[] FLOWERS = {
            Blocks.ALLIUM.defaultBlockState(), Blocks.AZURE_BLUET.defaultBlockState(), Blocks.PINK_PETALS.defaultBlockState(),
            Blocks.CORNFLOWER.defaultBlockState(), Blocks.LILAC.defaultBlockState().setValue(BlockStateProperties.DOUBLE_BLOCK_HALF, net.minecraft.world.level.block.state.properties.DoubleBlockHalf.LOWER)
    };

    // ---- острова
    public static final class Island {
        public int cx, cz;
        public double x, z, r, t;
        public int y;
        public boolean big, home;
        long key;
    }

    private static long mix(long h) {
        h ^= h >>> 33; h *= 0xff51afd7ed558ccdL; h ^= h >>> 33; h *= 0xc4ceb9fe1a85ec53L; h ^= h >>> 33;
        return h;
    }

    public static double rand(long seed, int a, int b, int c, int salt) {
        long h = mix(seed ^ (a * 0x9E3779B97F4A7C15L));
        h = mix(h ^ (b * 0xC2B2AE3D27D4EB4FL));
        h = mix(h ^ (c * 0x165667B19E3779F9L));
        h = mix(h ^ (salt * 0x27D4EB2F165667C5L));
        return (h >>> 11) * (1.0 / (1L << 53));
    }

    private static double vnoise(long seed, int k, double x, double z, double scale) {
        double fx = x / scale, fz = z / scale;
        int ix = (int) Math.floor(fx), iz = (int) Math.floor(fz);
        double tx = fx - ix, tz = fz - iz;
        tx = tx * tx * (3 - 2 * tx); tz = tz * tz * (3 - 2 * tz);
        double a = rand(seed, ix, iz, k, 900), b = rand(seed, ix + 1, iz, k, 900);
        double c = rand(seed, ix, iz + 1, k, 900), d = rand(seed, ix + 1, iz + 1, k, 900);
        double top = a + (b - a) * tx, bot = c + (d - c) * tx;
        return top + (bot - top) * tz;
    }

    /** Шум примерно с нулевым средним и единичным разбросом. */
    private static double nz(long seed, int k, double x, double z, double scale) {
        return (vnoise(seed, k, x, z, scale) - 0.5) * 3.4;
    }

    public static boolean isHomeCell(int cx, int cz) {
        return Math.floorMod(cx, HOME_STEP) == 0 && Math.floorMod(cz, HOME_STEP) == 0;
    }

    /** Центр домашнего острова клетки (cx, cz) (кратные HOME_STEP). */
    public static BlockPos homeCenter(int cx, int cz) {
        return new BlockPos(cx * CELL + CELL / 2, HOME_Y, cz * CELL + CELL / 2);
    }

    public static Island islandAt(long seed, int cx, int cz) {
        Island i = new Island();
        i.cx = cx; i.cz = cz;
        i.key = ((long) cx << 32) ^ (cz & 0xffffffffL);
        if (isHomeCell(cx, cz)) {
            i.home = true; i.x = cx * CELL + CELL / 2; i.z = cz * CELL + CELL / 2;
            i.r = 15; i.y = HOME_Y; i.t = 24;
            return i;
        }
        double rr = Math.hypot(cx, cz);
        if (rr > WORLD_RADIUS) return null;
        double edge = Math.max(0.0, Math.min(1.0, (rr - 4.5) / (WORLD_RADIUS - 4.5)));   // к краю архипелаг редеет
        if (rand(seed, cx, cz, 1, 0) < 0.18 + 0.6 * edge * edge) return null;
        i.x = cx * CELL + CELL * (0.2 + 0.6 * rand(seed, cx, cz, 2, 0));
        i.z = cz * CELL + CELL * (0.2 + 0.6 * rand(seed, cx, cz, 3, 0));
        i.big = rand(seed, cx, cz, 4, 0) > 0.94;
        if (i.big) {
            i.r = 34; i.y = 62 + (int) (10 * rand(seed, cx, cz, 6, 0)); i.t = 44;
            i.x = cx * CELL + CELL * 0.5; i.z = cz * CELL + CELL * 0.5;
        } else {
            i.r = 9 + 16 * Math.pow(rand(seed, cx, cz, 5, 0), 1.3);
            i.y = (int) (56 + 50 * rand(seed, cx, cz, 6, 0));
            i.t = i.r * (0.9 + 0.7 * rand(seed, cx, cz, 7, 0));
        }
        return i;
    }

    /** Остров в колонке (x, z): out = {верх, низ, d*1000}. false = колонка вне острова. */
    private static boolean column(long seed, Island i, int x, int z, int[] out) {
        double ang = Math.atan2(z - i.z, x - i.x);
        double calm = (i.home || i.big) ? 0.15 : 1.0;
        double wob = 1.0 + calm * (0.132 * nz(seed, 1, x, z, 24) + 0.1 * Math.sin(ang * 3 + i.cx) + 0.08 * Math.sin(ang * 5 + i.cz));
        double d = Math.hypot(x - i.x, z - i.z) / (i.r * wob);
        if (d >= 1.0) return false;
        int top = i.y;
        if (!i.home && !i.big) top += (int) Math.round(1.6 * nz(seed, 3, x, z, 40) * (1 - d));
        double depth = i.t * 1.55 * Math.pow(1 - d * d, 0.75)
                + 3.0 * nz(seed, 2, x, z, 8) * (1 - d) + 5.0 * Math.max(0, nz(seed, 1, x + 9, z + 5, 24)) * d;
        depth = Math.max(2, depth);
        out[0] = top; out[1] = (int) (top - depth); out[2] = (int) (d * 1000);
        return true;
    }

    // ---- запись в чанк
    private static final class Gen {
        final ChunkAccess chunk;
        final long seed;
        final int minX, minZ;
        final BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();

        Gen(ChunkAccess chunk, long seed) {
            this.chunk = chunk; this.seed = seed;
            this.minX = chunk.getPos().getMinBlockX(); this.minZ = chunk.getPos().getMinBlockZ();
        }

        void put(int x, int y, int z, BlockState b, boolean onlyAir) {
            if (x < minX || x > minX + 15 || z < minZ || z > minZ + 15 || y < 0 || y >= HEIGHT) return;
            mp.set(x, y, z);
            if (onlyAir && !chunk.getBlockState(mp).isAir()) return;
            chunk.setBlockState(mp, b, false);
        }

        boolean inReach(double cx, double cz, double reach) {
            return cx + reach >= minX && cx - reach <= minX + 15 && cz + reach >= minZ && cz - reach <= minZ + 15;
        }

        double r(int a, int b, int c, int salt) {
            return rand(seed, a, b, c, salt);
        }
    }

    // ---- главная функция
    public static void generate(ChunkAccess chunk, long seed) {
        Gen g = new Gen(chunk, seed);
        int c0x = Math.floorDiv(g.minX - 130, CELL), c1x = Math.floorDiv(g.minX + 15 + 130, CELL);
        int c0z = Math.floorDiv(g.minZ - 130, CELL), c1z = Math.floorDiv(g.minZ + 15 + 130, CELL);
        List<Island> all = new ArrayList<>();
        for (int cx = c0x; cx <= c1x; cx++) {
            for (int cz = c0z; cz <= c1z; cz++) {
                Island i = islandAt(seed, cx, cz);
                if (i != null) all.add(i);
            }
        }
        int[] o = new int[3];
        for (Island i : all) {
            if (g.inReach(i.x, i.z, i.r * 1.5)) terrain(g, i, o);
        }
        for (Island i : all) {
            if (g.inReach(i.x, i.z, i.r * 1.5 + 14)) decorate(g, i, o);
        }
        for (int a = 0; a < all.size(); a++) {
            for (int b = a + 1; b < all.size(); b++) bridge(g, all.get(a), all.get(b), o);
        }
    }

    private static void terrain(Gen g, Island i, int[] o) {
        int x0 = Math.max(g.minX, (int) Math.floor(i.x - i.r * 1.5)), x1 = Math.min(g.minX + 15, (int) Math.ceil(i.x + i.r * 1.5));
        int z0 = Math.max(g.minZ, (int) Math.floor(i.z - i.r * 1.5)), z1 = Math.min(g.minZ + 15, (int) Math.ceil(i.z + i.r * 1.5));
        for (int x = x0; x <= x1; x++) {
            for (int z = z0; z <= z1; z++) {
                if (!column(g.seed, i, x, z, o)) continue;
                int top = o[0], bot = Math.max(0, o[1]);
                boolean mossy = nz(g.seed, 1, x + 3, z + 7, 24) > 0.35;
                for (int y = bot; y <= top; y++) {
                    BlockState b;
                    if (y == top) b = GRASS;
                    else if (y >= top - 3) b = (g.r(x, y, z, 5) < 0.12) ? COARSE : DIRT;
                    else {
                        double h = g.r(x, y, z, 6);
                        b = h < 0.18 ? ANDESITE : h < 0.24 ? CALCITE : STONE;
                        if ((mossy && (y > top - 9 || y < bot + 4) && g.r(x, y, z, 7) > 0.35) || g.r(x, y, z, 8) > 0.965) b = MOSS;
                    }
                    g.put(x, y, z, b, false);
                }
                if (o[2] > 780 && o[1] > 2 && g.r(x, z, 0, 11) < 0.35) {              // лианы свисают с края
                    int len = 3 + (int) (9 * g.r(x, z, 0, 12));
                    for (int k = 1; k <= len; k++) {
                        g.put(x, o[1] - k, z, k == len ? VINE_TIP : VINE, true);
                    }
                }
            }
        }
    }

    private static int topAt(long seed, Island i, int x, int z, int[] o) {
        return column(seed, i, x, z, o) ? o[0] : Integer.MIN_VALUE;
    }

    private static void decorate(Gen g, Island i, int[] o) {
        long seed = g.seed;
        int cx = i.cx, cz = i.cz;
        // цветы, кристаллы
        int x0 = Math.max(g.minX, (int) Math.floor(i.x - i.r * 1.5)), x1 = Math.min(g.minX + 15, (int) Math.ceil(i.x + i.r * 1.5));
        int z0 = Math.max(g.minZ, (int) Math.floor(i.z - i.r * 1.5)), z1 = Math.min(g.minZ + 15, (int) Math.ceil(i.z + i.r * 1.5));
        for (int x = x0; x <= x1; x++) {
            for (int z = z0; z <= z1; z++) {
                if (!column(seed, i, x, z, o)) continue;
                int top = o[0], bot = o[1];
                double hx = Math.hypot(x - i.x, z - i.z);
                boolean spawnArea = i.home && hx < 7;
                double r1 = g.r(x, z, 0, 50);
                if (!spawnArea && !(i.big && hx < 28)) {
                    if (r1 < 0.06) {
                        BlockState f = FLOWERS[(int) (g.r(x, z, 0, 54) * FLOWERS.length) % FLOWERS.length];
                        g.put(x, top + 1, z, f, true);
                        if (f.is(Blocks.LILAC)) g.put(x, top + 2, z, Blocks.LILAC.defaultBlockState().setValue(BlockStateProperties.DOUBLE_BLOCK_HALF, net.minecraft.world.level.block.state.properties.DoubleBlockHalf.UPPER), true);
                    } else if (r1 > 0.995) {
                        crystal(g, x, top + 1, z, 2 + (int) (3 * g.r(x, z, 0, 51)), true);
                    }
                }
                if (bot > 3 && g.r(x, z, 0, 52) > 0.985) {
                    crystal(g, x, bot - 1, z, 3 + (int) (6 * g.r(x, z, 0, 53)), false);
                }
            }
        }
        // деревья
        int n = (int) (i.r * i.r / 55);
        for (int k = 0; k < n; k++) {
            double a = rand(seed, cx, cz, 100 + k, 1) * Math.PI * 2;
            double d = i.r * 0.7 * Math.sqrt(rand(seed, cx, cz, 200 + k, 1));
            int x = (int) Math.floor(i.x + d * Math.cos(a)), z = (int) Math.floor(i.z + d * Math.sin(a));
            if (i.home && d < 7) continue;
            if (i.big && d < 29) continue;
            int top = topAt(seed, i, x, z, o);
            if (top != Integer.MIN_VALUE) tree(g, x, z, top, false);
        }
        boolean giant = !i.big && !i.home && i.r > 12 && rand(seed, cx, cz, 60, 0) < 0.22;
        boolean pagoda = !i.big && !i.home && !giant && i.r > 11 && rand(seed, cx, cz, 61, 0) < 0.22;
        int cxm = (int) Math.floor(i.x), czm = (int) Math.floor(i.z);
        if (giant || pagoda || i.big) {
            int top = topAt(seed, i, cxm, czm, o);
            if (top != Integer.MIN_VALUE) {
                if (giant) tree(g, cxm, czm, top, true);
                else if (pagoda) pagoda(g, cxm, czm, top, 4);
                else castle(g, cxm, czm, top);
            }
        }
        if (i.home) {                                  // у домашнего острова: два цветущих дерева у края и пагода-беседка
            int top = topAt(seed, i, cxm - 9, czm + 3, o);
            if (top != Integer.MIN_VALUE) tree(g, cxm - 9, czm + 3, top, false);
            top = topAt(seed, i, cxm + 4, czm - 9, o);
            if (top != Integer.MIN_VALUE) tree(g, cxm + 4, czm - 9, top, false);
        }
        // фонарики на мраморных столбиках вдоль края острова
        int posts = Math.max(3, (int) (i.r * Math.PI * 2 * 0.88 / 9.0));
        for (int k = 0; k < posts; k++) {
            if (rand(seed, cx, cz, 400 + k, 2) > 0.62) continue;
            double a = (k + rand(seed, cx, cz, 450 + k, 2) * 0.6) * Math.PI * 2 / posts;
            int x = (int) Math.floor(i.x + i.r * 0.86 * Math.cos(a)), z = (int) Math.floor(i.z + i.r * 0.86 * Math.sin(a));
            int top = topAt(seed, i, x, z, o);
            if (top == Integer.MIN_VALUE) continue;
            g.put(x, top + 1, z, PILLAR, true);
            g.put(x, top + 2, z, PILLAR, true);
            g.put(x, top + 3, z, LANTERN, true);
        }
        // водопад с края
        if (!i.home && rand(seed, cx, cz, 300, 0) < 0.7) {
            double a = rand(seed, cx, cz, 301, 0) * Math.PI * 2;
            for (int s = 0; s < 40; s++) {
                double d = i.r * 1.3 * (1 - s / 40.0);
                int x = (int) Math.floor(i.x + d * Math.cos(a)), z = (int) Math.floor(i.z + d * Math.sin(a));
                int top = topAt(seed, i, x, z, o);
                if (top == Integer.MIN_VALUE) continue;
                int yb = (int) (top - 28 - 36 * rand(seed, cx, cz, 302, 0));
                for (int y = Math.max(0, yb); y <= top; y++) {
                    for (int dx = -1; dx <= 1; dx++) g.put(x + dx, y, z, WATER, false);
                }
                break;
            }
        }
    }

    private static void crystal(Gen g, int x, int y, int z, int h, boolean up) {
        for (int k = 0; k < h; k++) {
            int yy = up ? y + k : y - k;
            boolean tip = k == h - 1;
            g.put(x, yy, z, tip ? (up ? CLUSTER_UP : CLUSTER_DOWN) : CRYSTAL, false);
        }
    }

    private static void tree(Gen g, int x, int z, int y, boolean big) {
        int th = (int) ((big ? 14 : 5) + (big ? 6 : 3) * g.r(x, z, 0, 21));
        int w = big ? 2 : 1;
        for (int k = 0; k < th; k++) {
            for (int dx = 0; dx < w; dx++) for (int dz = 0; dz < w; dz++) g.put(x + dx, y + 1 + k, z + dz, LOG, false);
        }
        double rr = (big ? 8 : 3.6) + (big ? 2 : 1.2) * g.r(x, z, 0, 22);
        int cy = y + th;
        int ri = (int) rr + 2;
        for (int dx = -ri; dx <= ri; dx++) {
            for (int dz = -ri; dz <= ri; dz++) {
                if (x + dx < g.minX - 1 || x + dx > g.minX + 16 || z + dz < g.minZ - 1 || z + dz > g.minZ + 16) continue;
                for (int dy = -(int) (rr * 0.6) - 1; dy <= (int) (rr * 0.8) + 1; dy++) {
                    double e = (dx / rr) * (dx / rr) + (dy / (rr * 0.7)) * (dy / (rr * 0.7)) + (dz / rr) * (dz / rr);
                    if (e < 1 && g.r(x + dx, y + dy, z + dz, 23) > 0.12) g.put(x + dx, cy + dy, z + dz, LEAF, true);
                }
            }
        }
        if (big) {                                        // у огромного дерева целая гирлянда
            for (int k = 0; k < 6; k++) {
                double a = k * Math.PI / 3 + g.r(x, z, k, 25);
                hangLantern(g, x, z, cy, rr, (int) Math.round(Math.cos(a) * rr * 0.6), (int) Math.round(Math.sin(a) * rr * 0.6));
            }
        } else if (g.r(x, z, 0, 26) < 0.35) {
            hangLantern(g, x, z, cy, rr, 2, 0);
        }
    }

    /** Фонарик на цепи под кроной дерева на смещении (ox, oz) от ствола. */
    private static void hangLantern(Gen g, int x, int z, int cy, double rr, int ox, int oz) {
        double d = Math.hypot(ox, oz);
        if (d >= rr * 0.85) return;
        int ymin = cy + (int) Math.floor(-(rr * 0.7) * Math.sqrt(1 - (d / rr) * (d / rr)));
        g.put(x + ox, ymin - 1, z + oz, CHAIN, false);
        g.put(x + ox, ymin - 2, z + oz, CHAIN, false);
        g.put(x + ox, ymin - 3, z + oz, LANTERN_HANG, false);
    }

    private static void pagoda(Gen g, int x, int z, int y, int s) {
        for (int tier = 0; tier < 3; tier++) {
            int w = s - tier, yy = y + 1 + tier * 5;
            for (int dx = -w; dx <= w; dx++) for (int dz = -w; dz <= w; dz++) g.put(x + dx, yy - 1 + (tier == 0 ? 0 : 0), z + dz, MARBLE2, false);
            for (int dx = -w; dx <= w; dx += w) {
                for (int dz = -w; dz <= w; dz += w) {
                    if (dx == 0 && dz == 0) continue;
                    for (int k = 0; k < 3; k++) g.put(x + dx, yy + k, z + dz, PILLAR, false);
                }
            }
            for (int dx = -w - 1; dx <= w + 1; dx++) for (int dz = -w - 1; dz <= w + 1; dz++) g.put(x + dx, yy + 3, z + dz, ROOF, false);
            for (int dx = -w; dx <= w; dx++) for (int dz = -w; dz <= w; dz++) g.put(x + dx, yy + 4, z + dz, ROOF, false);
            g.put(x + w + 1, yy + 4, z + w + 1, LANTERN, false);
            g.put(x - w - 1, yy + 4, z - w - 1, LANTERN, false);
        }
        int top = y + 1 + 2 * 5 + 5;
        for (int k = 0; k < 3; k++) g.put(x, top + k, z, PILLAR, false);
        g.put(x, top + 3, z, LANTERN, false);
        g.put(x, y + 1, z, LANTERN, false);
    }

    /** Замок: вся постройка в Castle (чистая логика, проверена вне игры), здесь только перевод блоков. */
    private static void castle(Gen g, int x, int z, int y) {
        Castle.build(new Castle.Sink() {
            @Override
            public void put(int bx, int by, int bz, Castle.B b) {
                g.put(bx, by, bz, castleState(b), false);
            }

            @Override
            public void stair(int bx, int by, int bz, int adx, int adz) {
                // facing у ступеньки = сторона, куда смотрит её низ; поднимаемся в противоположную
                Direction f = adx > 0 ? Direction.WEST : adx < 0 ? Direction.EAST : adz > 0 ? Direction.NORTH : Direction.SOUTH;
                g.put(bx, by, bz, Blocks.QUARTZ_STAIRS.defaultBlockState().setValue(StairBlock.FACING, f), false);
            }

            @Override
            public void tree(int tx, int tz, int top) {
                SkyIslands.tree(g, tx, tz, top, false);
            }
        }, x, y, z);
    }

    private static BlockState castleState(Castle.B b) {
        switch (b) {
            case MARBLE: return MARBLE;
            case MARBLE2: return MARBLE2;
            case BRICK: return Blocks.QUARTZ_BRICKS.defaultBlockState();
            case PILLAR: return PILLAR;
            case ROOF: return ROOF;
            case GOLD: return Blocks.GOLD_BLOCK.defaultBlockState();
            case LANTERN: return LANTERN;
            case LANTERN_HANG: return LANTERN_HANG;
            case CHAIN: return CHAIN;
            case GLOW: return WINDOW;
            case GLASS_PURPLE: return Blocks.PURPLE_STAINED_GLASS.defaultBlockState();
            case GLASS_PINK: return Blocks.PINK_STAINED_GLASS.defaultBlockState();
            case GLASS_BLUE: return Blocks.LIGHT_BLUE_STAINED_GLASS.defaultBlockState();
            case GLASS_MAGENTA: return Blocks.MAGENTA_STAINED_GLASS.defaultBlockState();
            case GLASS_WHITE: return Blocks.WHITE_STAINED_GLASS.defaultBlockState();
            case CARPET_PURPLE: return Blocks.PURPLE_CARPET.defaultBlockState();
            case CARPET_MAGENTA: return Blocks.MAGENTA_CARPET.defaultBlockState();
            case CARPET_GOLD: return Blocks.YELLOW_CARPET.defaultBlockState();
            case CARPET_BLUE: return Blocks.LIGHT_BLUE_CARPET.defaultBlockState();
            case BOOKSHELF: return Blocks.BOOKSHELF.defaultBlockState();
            case CRYSTAL: return CRYSTAL;
            case CLUSTER_UP: return CLUSTER_UP;
            case CLUSTER_DOWN: return CLUSTER_DOWN;
            case WATER: return WATER;
            case FLOOR_B: return Blocks.POLISHED_DIORITE.defaultBlockState();
            case PETALS: return Blocks.PINK_PETALS.defaultBlockState();
            case ALLIUM: return Blocks.ALLIUM.defaultBlockState();
            case GRASS: return GRASS;
            case AIR:
            default: return AIR;
        }
    }

    private static void bridge(Gen g, Island a, Island b, int[] o) {
        if (a.cx == b.cx && a.cz == b.cz) return;
        if (Math.abs(a.cx - b.cx) > 1 || Math.abs(a.cz - b.cz) > 1) return;
        double dx = b.x - a.x, dz = b.z - a.z, L = Math.hypot(dx, dz);
        double gap = L - a.r - b.r;
        if (gap < 4 || gap > 34 || Math.abs(a.y - b.y) > 24) return;
        int lo = Math.min(a.cx, b.cx), hi = Math.max(a.cx, b.cx), lo2 = Math.min(a.cz, b.cz), hi2 = Math.max(a.cz, b.cz);
        if (rand(g.seed, lo * 31 + hi, lo2 * 31 + hi2, a.cx * 7 + b.cx + a.cz * 3 + b.cz, 77) > 0.5) return;
        if (!g.inReach((a.x + b.x) / 2, (a.z + b.z) / 2, L / 2 + 6)) return;
        double ux = dx / L, uz = dz / L;
        double p0x = a.x + ux * a.r * 0.8, p0z = a.z + uz * a.r * 0.8, p1x = b.x - ux * b.r * 0.8, p1z = b.z - uz * b.r * 0.8;
        int y0 = edgeTop(g.seed, a, p0x, p0z, ux, uz, o), y1 = edgeTop(g.seed, b, p1x, p1z, -ux, -uz, o);
        int n = (int) (Math.hypot(p1x - p0x, p1z - p0z) * 1.5);
        for (int s = 0; s <= n; s++) {
            double t = s / (double) Math.max(1, n);
            double px = p0x + (p1x - p0x) * t, pz = p0z + (p1z - p0z) * t;
            int py = (int) Math.round(y0 + (y1 - y0) * t + 3.5 * Math.sin(Math.PI * t));
            for (int w = -2; w <= 2; w++) {
                int x = (int) Math.round(px - uz * w), z = (int) Math.round(pz + ux * w);
                g.put(x, py, z, MARBLE, false);
                if (Math.abs(w) == 2) {
                    g.put(x, py + 1, z, MARBLE, false);
                    if (s % 6 == 0) { g.put(x, py + 2, z, MARBLE, false); g.put(x, py + 3, z, LANTERN, false); }
                }
            }
            if (s % 5 == 2) {
                for (int k = 1; k < 7; k++) g.put((int) Math.round(px), py - k, (int) Math.round(pz), MARBLE, true);
            }
        }
    }

    private static int edgeTop(long seed, Island i, double px, double pz, double ux, double uz, int[] o) {
        for (int rr = 0; rr <= 4; rr += 2) {
            int t = topAt(seed, i, (int) Math.floor(px - ux * rr), (int) Math.floor(pz - uz * rr), o);
            if (t != Integer.MIN_VALUE) return t;
        }
        return i.y;
    }
}
