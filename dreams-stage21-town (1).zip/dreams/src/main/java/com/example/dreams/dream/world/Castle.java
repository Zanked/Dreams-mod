package com.example.dreams.dream.world;

/**
 * Замок на самом большом острове мира доброго сна: внешние стены с воротами и угловыми башнями, двор с садом и
 * фонтаном, крепость с Тронным залом (колонны, ковёр, трон, роза-витраж, ланцетные витражи, галереи),
 * винтовыми лестницами в углах, садом на террасе и центральной башней с лестницей и обсерваторией-библиотекой.
 *
 * Класс не знает про Minecraft: он пишет в Sink по идентификаторам блоков. Поэтому его можно запустить и
 * нарисовать вне игры (см. castle_preview.py). Координаты: (cx, y0, cz) = центр и уровень земли на острове,
 * k = высота над землёй (k=0 пол первого этажа).
 */
public final class Castle {

    public enum B {
        AIR, MARBLE, MARBLE2, BRICK, PILLAR, ROOF, GOLD, LANTERN, LANTERN_HANG, CHAIN, GLOW,
        GLASS_PURPLE, GLASS_PINK, GLASS_BLUE, GLASS_MAGENTA, GLASS_WHITE,
        CARPET_PURPLE, CARPET_MAGENTA, CARPET_GOLD, CARPET_BLUE, BOOKSHELF,
        CRYSTAL, CLUSTER_UP, CLUSTER_DOWN, WATER, FLOOR_B, PETALS, ALLIUM, GRASS
    }

    public interface Sink {
        void put(int x, int y, int z, B b);

        /** Ступень, поднимающаяся в сторону (adx, adz). */
        void stair(int x, int y, int z, int adx, int adz);

        /** Цветущее дерево, top = высота верхнего блока земли под стволом. */
        void tree(int x, int z, int top);
    }

    private final Sink s;
    private final int cx, y0, cz;

    private Castle(Sink s, int cx, int y0, int cz) {
        this.s = s;
        this.cx = cx;
        this.y0 = y0;
        this.cz = cz;
    }

    public static void build(Sink s, int cx, int y0, int cz) {
        new Castle(s, cx, y0, cz).run();
    }

    private static final int R = 24;      // внешняя стена
    private static final int K = 11;      // крепость
    private static final int T = 6;       // центральная башня
    private static final int HALL = 12;   // высота зала (k=1..12), потолок k=13

    private void p(int dx, int k, int dz, B b) {
        s.put(cx + dx, y0 + k, cz + dz, b);
    }

    private void pillarFill(int dx, int dz, int k0, int k1, B b) {
        for (int k = k0; k <= k1; k++) p(dx, k, dz, b);
    }

    /** Основание под стеной: земля острова может быть ниже, не оставляем щелей. */
    private void foundation(int dx, int dz) {
        p(dx, 0, dz, B.MARBLE);
        p(dx, -1, dz, B.MARBLE);
        p(dx, -2, dz, B.MARBLE);
    }

    private static int hash(int a, int b, int c) {
        int x = a * 374761393 + b * 668265263 + c * 1103515245;
        x = (x ^ (x >>> 13)) * 1274126177;
        return (x ^ (x >>> 16)) & 0x7fffffff;
    }

    private void run() {
        outerWall();
        cornerTowers();
        keepShell();
        hall();
        galleries();
        spirals();
        terrace();
        centralTower();
        courtyard();
    }

    // ------------------------------------------------------------------ стена и башни

    private static int gateHeight(int adx) {
        return adx <= 1 ? 6 : adx == 2 ? 5 : 4;
    }

    private void outerWall() {
        for (int dx = -R; dx <= R; dx++) {
            for (int dz = -R; dz <= R; dz++) {
                int m = Math.max(Math.abs(dx), Math.abs(dz));
                if (m != R && m != R - 1) continue;
                if (Math.abs(dx) > R - 5 && Math.abs(dz) > R - 5) continue;          // здесь угловая башня
                boolean outer = m == R;
                int t = Math.abs(dx) == m ? dz : dx;                                  // координата вдоль стены
                boolean gateZone = dz >= R - 1 && Math.abs(dx) <= 3;
                foundation(dx, dz);
                int hgt = outer ? 8 : 7;
                for (int k = 1; k <= hgt; k++) {
                    if (gateZone && k <= gateHeight(Math.abs(dx))) continue;
                    boolean slit = (k == 4 || k == 5) && Math.floorMod(t, 6) == 3;
                    if (slit) continue;
                    p(dx, k, dz, k % 4 == 0 ? B.BRICK : B.MARBLE);
                }
                if (outer && !gateZone) {                                             // зубцы
                    if ((Math.floorDiv(t, 2) & 1) == 0) {
                        p(dx, 9, dz, B.MARBLE);
                        p(dx, 10, dz, B.MARBLE);
                    }
                }
                if (outer && gateZone) p(dx, 7, dz, Math.abs(dx) <= 1 ? B.GOLD : B.MARBLE);   // замковый камень арки
            }
        }
        // фонарь, висящий в арке ворот
        p(0, 6, R - 1, B.CHAIN);
        p(0, 5, R - 1, B.LANTERN_HANG);
        // фонари на гребне стены
        for (int t = -R + 8; t <= R - 8; t += 8) {
            p(t, 11, -R, B.LANTERN);
            p(-R, 11, t, B.LANTERN);
            p(R, 11, t, B.LANTERN);
            if (Math.abs(t) > 4) p(t, 11, R, B.LANTERN);
        }
    }

    private void cornerTowers() {
        int w = 4, h = 21;
        for (int sx = -1; sx <= 1; sx += 2) {
            for (int sz = -1; sz <= 1; sz += 2) {
                int tx = sx * R, tz = sz * R;
                for (int dx = -w; dx <= w; dx++) {
                    for (int dz = -w; dz <= w; dz++) {
                        boolean e = Math.max(Math.abs(dx), Math.abs(dz)) == w;
                        if (e) foundation(tx + dx, tz + dz);
                        for (int k = 1; k <= h; k++) {
                            boolean corner = Math.abs(dx) == w && Math.abs(dz) == w;
                            B b = e ? (corner ? B.PILLAR : (k % 5 == 0 ? B.BRICK : B.MARBLE)) : B.AIR;
                            p(tx + dx, k, tz + dz, b);
                        }
                    }
                }
                // пол верхней комнаты и дверь
                for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) p(tx + dx, 17, tz + dz, B.MARBLE2);
                p(tx - sx * w, 1, tz - sz * 3, B.AIR);
                p(tx - sx * w, 2, tz - sz * 3, B.AIR);
                // винтовая лестница по стенке: 24 клетки кольца радиуса 3, 17 ступеней
                int[][] ring = ringCells(3);
                for (int i = 0; i < 17; i++) {
                    int[] a = ring[i], b = ring[i + 1];
                    int ax = a[0] * sx, az = a[1] * sz;
                    int adx = (b[0] - a[0]) * sx, adz = (b[1] - a[1]) * sz;
                    for (int k = 1; k < 1 + i; k++) p(tx + ax, k, tz + az, B.MARBLE);
                    s.stair(cx + tx + ax, y0 + 1 + i, cz + tz + az, adx, adz);
                }
                // окна и фонарь в верхней комнате
                for (int j = 0; j < 2; j++) {
                    p(tx + (j == 0 ? -w : w), 19, tz, B.GLASS_BLUE);
                    p(tx + (j == 0 ? -w : w), 20, tz, B.GLASS_BLUE);
                    p(tx, 19, tz + (j == 0 ? -w : w), B.GLASS_BLUE);
                    p(tx, 20, tz + (j == 0 ? -w : w), B.GLASS_BLUE);
                }
                p(tx, 18, tz, B.LANTERN);
                // золотой пояс и крыша
                for (int dx = -w; dx <= w; dx++) {
                    for (int dz = -w; dz <= w; dz++) {
                        if (Math.max(Math.abs(dx), Math.abs(dz)) == w) {
                            p(tx + dx, 12, tz + dz, B.GOLD);
                            p(tx + dx, h + 1, tz + dz, B.MARBLE);
                        }
                    }
                }
                cone(tx, h + 2, tz, w + 1);
            }
        }
    }

    /** Клетки квадратного кольца радиуса r по порядку, начиная с (-r,-r): +x, +z, -x, -z. 8r клеток (+1 замыкающая). */
    private static int[][] ringCells(int r) {
        int n = 8 * r;
        int[][] out = new int[n + 1][];
        int i = 0;
        for (int x = -r; x < r; x++) out[i++] = new int[]{x, -r};
        for (int z = -r; z < r; z++) out[i++] = new int[]{r, z};
        for (int x = r; x > -r; x--) out[i++] = new int[]{x, r};
        for (int z = r; z > -r; z--) out[i++] = new int[]{-r, z};
        out[n] = out[0];
        return out;
    }

    private int cone(int x, int k0, int z, int r) {
        int k = 0;
        while (r >= 0) {
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    int d2 = dx * dx + dz * dz;
                    if (d2 <= r * r + r && (d2 >= (r - 1) * (r - 1) || r <= 1)) p(x + dx, k0 + k, z + dz, r > 0 ? B.ROOF : B.MARBLE);
                }
            }
            r--;
            k++;
        }
        for (int j = 0; j < 5; j++) p(x, k0 + k + j, z, j == 4 ? B.LANTERN : B.MARBLE);
        return k0 + k + 5;
    }

    // ------------------------------------------------------------------ крепость

    private void keepShell() {
        for (int dx = -K; dx <= K; dx++) {
            for (int dz = -K; dz <= K; dz++) {
                int m = Math.max(Math.abs(dx), Math.abs(dz));
                if (m == K) {
                    foundation(dx, dz);
                    int t = Math.abs(dx) == K ? dz : dx;
                    boolean rib = Math.abs(t) == K || Math.floorMod(t, 5) == 0;
                    for (int k = 1; k <= 13; k++) {
                        B b = rib ? B.PILLAR : (k % 6 == 0 ? B.BRICK : B.MARBLE);
                        if (k == 13) b = B.GOLD;                                      // золотой карниз
                        p(dx, k, dz, b);
                    }
                    if ((Math.floorDiv(t, 2) & 1) == 0) { p(dx, 14, dz, B.MARBLE); p(dx, 15, dz, B.MARBLE); }   // зубцы террасы
                } else {
                    p(dx, 0, dz, ((dx + dz) & 1) == 0 ? B.MARBLE2 : B.FLOOR_B);      // шахматный пол
                    for (int k = 1; k <= HALL; k++) p(dx, k, dz, B.AIR);
                    p(dx, 13, dz, B.MARBLE2);                                         // потолок = пол террасы
                    for (int k = 14; k <= 20; k++) p(dx, k, dz, B.AIR);               // очищаем террасу
                }
            }
        }
        // вход: арка с юга, золотая рамка
        for (int dx = -2; dx <= 2; dx++) {
            for (int k = 1; k <= 8; k++) {
                int half = k <= 6 ? 2 : k == 7 ? 1 : 0;
                if (Math.abs(dx) <= half) p(dx, k, K, B.AIR);
            }
        }
        for (int k = 1; k <= 8; k++) {
            int half = k <= 6 ? 2 : k == 7 ? 1 : 0;
            p(-half - 1, k, K, B.GOLD);
            p(half + 1, k, K, B.GOLD);
        }
        // угловые фонари на гребне
        for (int sx = -1; sx <= 1; sx += 2) {
            for (int sz = -1; sz <= -1; sz++) {
                p(sx * K, 14, sz * K, B.PILLAR);
                p(sx * K, 15, sz * K, B.PILLAR);
                p(sx * K, 16, sz * K, B.LANTERN);
            }
        }
    }

    // ------------------------------------------------------------------ Тронный зал

    private void hall() {
        int[] zs = {-8, -4, 0, 4, 8};
        for (int sx = -1; sx <= 1; sx += 2) {
            for (int z : zs) {
                pillarFill(sx * 5, z, 1, 12, B.PILLAR);
                p(sx * 5, 2, z, B.GOLD);
                p(sx * 5, 11, z, B.GOLD);
                p(sx * 5, 1, z, B.MARBLE2);
            }
        }
        // нервюры потолка
        for (int z : zs) for (int x = -10; x <= 10; x++) p(x, 12, z, B.MARBLE);
        for (int sx = -1; sx <= 1; sx += 2) for (int z = -10; z <= 10; z++) p(sx * 5, 12, z, B.MARBLE);

        // ковровая дорожка от входа до помоста
        for (int z = -5; z <= 10; z++) {
            p(0, 1, z, B.CARPET_MAGENTA);
            p(-1, 1, z, B.CARPET_PURPLE);
            p(1, 1, z, B.CARPET_PURPLE);
            p(-2, 1, z, B.CARPET_GOLD);
            p(2, 1, z, B.CARPET_GOLD);
        }
        // помост: два уровня, ступени спереди
        for (int x = -6; x <= 6; x++) for (int z = -10; z <= -6; z++) p(x, 1, z, B.MARBLE2);
        for (int x = -4; x <= 4; x++) for (int z = -10; z <= -8; z++) p(x, 2, z, B.MARBLE2);
        for (int x = -6; x <= 6; x++) s.stair(cx + x, y0 + 1, cz - 5, 0, -1);
        for (int x = -4; x <= 4; x++) s.stair(cx + x, y0 + 2, cz - 7, 0, -1);
        for (int x = -2; x <= 2; x++) {
            p(x, 2, -6, B.CARPET_GOLD);
            for (int z = -10; z <= -8; z++) p(x, 3, z, Math.abs(x) == 2 ? B.CARPET_GOLD : Math.abs(x) == 1 ? B.CARPET_PURPLE : B.CARPET_MAGENTA);
        }
        // трон
        p(0, 3, -9, B.GOLD);
        for (int sx = -1; sx <= 1; sx += 2) { p(sx, 3, -9, B.GOLD); p(sx, 4, -9, B.GOLD); }
        for (int x = -1; x <= 1; x++) for (int k = 3; k <= 8; k++) p(x, k, -10, Math.abs(x) == 1 || k == 8 ? B.GOLD : B.MARBLE2);
        p(0, 6, -10, B.CRYSTAL);
        p(0, 5, -10, B.CRYSTAL);
        p(0, 9, -10, B.CLUSTER_UP);

        // роза-витраж на северной стене
        for (int dx = -5; dx <= 5; dx++) {
            for (int dk = -5; dk <= 5; dk++) {
                double r = Math.sqrt(dx * dx + dk * dk);
                if (r > 4.4) continue;
                boolean spoke = r > 1.3 && (dx == 0 || dk == 0 || Math.abs(dx) == Math.abs(dk));
                B b = spoke ? B.MARBLE : r < 1.3 ? B.GLOW : r < 2.5 ? B.GLASS_PINK : r < 3.5 ? B.GLASS_PURPLE : B.GLASS_BLUE;
                p(dx, 10 + dk, -K, b);
            }
        }
        // ланцетные витражи на боковых стенах
        int[] wz = {-6, -2, 2, 6};
        B[] side = {B.GLASS_PURPLE, B.GLASS_BLUE, B.GLASS_PURPLE, B.GLASS_BLUE};
        for (int sx = -1; sx <= 1; sx += 2) {
            for (int wi = 0; wi < wz.length; wi++) {
                int z0 = wz[wi];
                for (int k = 3; k <= 10; k++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        if (k >= 9 && dz != 0) continue;                              // стрельчатая верхушка
                        B b = k >= 9 ? B.GLASS_MAGENTA : dz == 0 ? B.GLASS_PINK : side[wi];
                        p(sx * K, k, z0 + dz, b);
                    }
                }
            }
        }
        // люстры на цепях и огромный кристалл над ковром
        int[][] ch = {{0, -4}, {0, 4}, {-8, -2}, {8, -2}, {-8, 6}, {8, 6}};
        for (int[] c : ch) {
            p(c[0], 12, c[1], B.CHAIN);
            p(c[0], 11, c[1], B.CHAIN);
            p(c[0], 10, c[1], B.CHAIN);
            p(c[0], 9, c[1], B.LANTERN_HANG);
        }
        for (int k = 11; k >= 8; k--) p(0, k, 0, B.CRYSTAL);
        p(0, 7, 0, B.CLUSTER_DOWN);
        for (int sx = -1; sx <= 1; sx += 2) {
            p(sx * 2, 11, 0, B.CHAIN);
            p(sx * 2, 10, 0, B.LANTERN_HANG);
        }
        // светильники у колонн
        for (int sx = -1; sx <= 1; sx += 2) for (int z : zs) p(sx * 6, 1, z, B.LANTERN);
    }

    // ------------------------------------------------------------------ галереи и винтовые лестницы

    private void galleries() {
        for (int sx = -1; sx <= 1; sx += 2) {
            // лестница вдоль стены: z = 9..4, подъём на север, ступени на k = 1..6
            for (int j = 0; j < 6; j++) {
                int z = 9 - j;
                for (int xi = 8; xi <= 10; xi++) {
                    for (int k = 1; k < 1 + j; k++) p(sx * xi, k, z, B.MARBLE);
                    s.stair(cx + sx * xi, y0 + 1 + j, cz + z, 0, -1);
                }
            }
            // пол галереи z = 3..-7 на k = 6, опоры, перила и светильники
            for (int z = -7; z <= 3; z++) {
                for (int xi = 8; xi <= 10; xi++) p(sx * xi, 6, z, B.MARBLE2);
                p(sx * 8, 7, z, Math.floorMod(z, 2) == 0 ? B.PILLAR : B.AIR);
                if (Math.floorMod(z, 4) == 0) p(sx * 8, 8, z, B.LANTERN);
            }
            for (int z : new int[]{-7, -3, 1, 3}) pillarFill(sx * 8, z, 1, 5, B.PILLAR);
        }
    }

    private void spirals() {
        int[][] base = {{0, 1}, {-1, 1}, {-1, 0}, {-1, -1}, {0, -1}, {1, -1}, {1, 0}, {1, 1}};
        for (int sx = -1; sx <= 1; sx += 2) {
            int mx = -sx;                                                         // зеркалим в зависимости от стороны
            int ccx = sx * 9, ccz = -9;
            for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) p(ccx + dx, 13, ccz + dz, B.AIR);   // люк в потолке
            for (int i = 0; i < 7; i++) {
                int[] a = base[i], b = base[i + 1];
                int ax = ccx + a[0] * mx, az = ccz + a[1];
                int adx = (b[0] - a[0]) * mx, adz = b[1] - a[1];
                for (int k = 1; k < 7 + i; k++) p(ax, k, az, B.MARBLE);
                s.stair(cx + ax, y0 + 7 + i, cz + az, adx, adz);
            }
            pillarFill(ccx, ccz, 1, 14, B.PILLAR);
            p(ccx, 15, ccz, B.LANTERN);
        }
    }

    // ------------------------------------------------------------------ терраса

    private void terrace() {
        // южные угловые башенки на крыше
        for (int sx = -1; sx <= 1; sx += 2) {
            int tx = sx * 9, tz = 9, w = 2, h = 7;
            for (int dx = -w; dx <= w; dx++) {
                for (int dz = -w; dz <= w; dz++) {
                    boolean e = Math.max(Math.abs(dx), Math.abs(dz)) == w;
                    for (int k = 14; k < 14 + h; k++) p(tx + dx, k, tz + dz, e ? B.MARBLE : B.AIR);
                }
            }
            p(tx, 17, tz - w, B.GLOW);
            p(tx, 18, tz - w, B.GLOW);
            p(tx + sx * 0, 17, tz + w, B.GLOW);
            cone(tx, 14 + h, tz, w + 1);
        }
        // сад на террасе: две грядки с цветущими деревьями
        for (int sx = -1; sx <= 1; sx += 2) {
            for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) p(sx * 8 + dx, 13, dz, B.GRASS);
            s.tree(cx + sx * 8, cz, y0 + 13);
            p(sx * 8 + 2, 14, 0, B.PETALS);
            p(sx * 8 - 2, 14, 1, B.ALLIUM);
        }
        // фонари на парапете
        for (int t = -4; t <= 4; t += 8) {
            p(t, 14, K, B.PILLAR);
            p(t, 15, K, B.PILLAR);
            p(t, 16, K, B.LANTERN);
        }
    }

    // ------------------------------------------------------------------ центральная башня

    private void centralTower() {
        int top = 52;
        for (int dx = -T; dx <= T; dx++) {
            for (int dz = -T; dz <= T; dz++) {
                int m = Math.max(Math.abs(dx), Math.abs(dz));
                boolean e = m == T;
                boolean corner = Math.abs(dx) == T && Math.abs(dz) == T;
                for (int k = 14; k <= top; k++) {
                    B b;
                    if (e) b = corner ? B.PILLAR : (k == 14 || k == 39 || k == top ? B.GOLD : (k % 6 == 0 ? B.BRICK : B.MARBLE));
                    else b = B.AIR;
                    p(dx, k, dz, b);
                }
            }
        }
        // дверь с террасы (юг), три клетки шириной
        for (int dx = -1; dx <= 1; dx++) for (int k = 14; k <= 16; k++) p(dx, k, T, B.AIR);
        p(-2, 16, T, B.LANTERN);
        // витражи по четырём сторонам: нижние узкие, верхние высокие
        B[] face = {B.GLASS_PINK, B.GLASS_PURPLE, B.GLASS_BLUE, B.GLASS_MAGENTA};
        for (int f = 0; f < 4; f++) {
            for (int t = -1; t <= 1; t++) {
                for (int k = 43; k <= 48; k++) {
                    if (k >= 47 && t != 0) continue;
                    put4(f, t, k, face[f]);
                }
            }
            for (int k = 24; k <= 28; k++) put4(f, 0, k, face[f]);
            for (int k = 32; k <= 35; k++) put4(f, 0, k, face[(f + 1) & 3]);
        }
        // лестница по периметру: кольцо радиуса 4, 26 ступеней от двери вверх против часовой
        int[][] ring = towerRing();
        for (int i = 0; i < 26; i++) {
            int[] a = ring[i], b = ring[i + 1];
            for (int k = 14; k < 14 + i; k++) p(a[0], k, a[1], B.MARBLE);
            s.stair(cx + a[0], y0 + 14 + i, cz + a[1], b[0] - a[0], b[1] - a[1]);
        }
        // пол обсерватории (и закрытые клетки кольца)
        for (int dx = -4; dx <= 4; dx++) for (int dz = -4; dz <= 4; dz++) {
            boolean ringCell = Math.max(Math.abs(dx), Math.abs(dz)) == 4;
            if (!ringCell || ringIndex(dx, dz) > 25) p(dx, 39, dz, B.MARBLE2);
        }
        // библиотека: полки у стен, ковёр, кристалл
        for (int dx = -T + 1; dx <= T - 1; dx++) {
            for (int dz = -T + 1; dz <= T - 1; dz++) {
                int m = Math.max(Math.abs(dx), Math.abs(dz));
                if (m == 5 && !(Math.abs(dx) <= 1 || Math.abs(dz) <= 1)) { p(dx, 40, dz, B.BOOKSHELF); p(dx, 41, dz, B.BOOKSHELF); }
                if (m <= 2) p(dx, 40, dz, m == 0 ? B.GOLD : B.CARPET_BLUE);
            }
        }
        p(0, 41, 0, B.CLUSTER_UP);
        // потолок и люстра
        for (int dx = -T + 1; dx <= T - 1; dx++) for (int dz = -T + 1; dz <= T - 1; dz++) p(dx, top, dz, B.MARBLE2);
        p(0, top - 1, 0, B.CHAIN);
        p(0, top - 2, 0, B.CHAIN);
        p(0, top - 3, 0, B.LANTERN_HANG);
        for (int sx = -1; sx <= 1; sx += 2) { p(sx * 3, top - 1, 0, B.CHAIN); p(sx * 3, top - 2, 0, B.LANTERN_HANG); }
        // крыша, шпиль
        int c = cone(0, top + 1, 0, T + 1);
        for (int k = c; k < c + 10; k++) p(0, k, 0, B.MARBLE);
        for (int k = 0; k < 6; k++) p(0, c + 10 + k, 0, B.CRYSTAL);
    }

    /** Ставит блок в центре стены грани f (0 юг, 1 запад, 2 север, 3 восток), t = смещение вдоль грани. */
    private void put4(int f, int t, int k, B b) {
        switch (f) {
            case 0: p(t, k, T, b); break;
            case 1: p(-T, k, t, b); break;
            case 2: p(t, k, -T, b); break;
            default: p(T, k, t, b); break;
        }
    }

    private static int[][] towerRing() {
        int[][] out = new int[33][];
        int i = 0;
        for (int x = 0; x >= -4; x--) out[i++] = new int[]{x, 4};
        for (int z = 3; z >= -4; z--) out[i++] = new int[]{-4, z};
        for (int x = -3; x <= 4; x++) out[i++] = new int[]{x, -4};
        for (int z = -3; z <= 4; z++) out[i++] = new int[]{4, z};
        for (int x = 3; x >= 1; x--) out[i++] = new int[]{x, 4};
        out[32] = out[0];
        return out;
    }

    private static int ringIndex(int dx, int dz) {
        int[][] ring = towerRing();
        for (int i = 0; i < 32; i++) if (ring[i][0] == dx && ring[i][1] == dz) return i;
        return 99;
    }

    // ------------------------------------------------------------------ двор

    private void courtyard() {
        // дорожка от ворот к входу
        for (int z = K + 1; z <= R - 2; z++) {
            for (int x = -1; x <= 1; x++) p(x, 0, z, (z & 1) == 0 ? B.MARBLE2 : B.FLOOR_B);
            if (z % 6 == 0) {
                for (int sx = -1; sx <= 1; sx += 2) { p(sx * 3, 1, z, B.PILLAR); p(sx * 3, 2, z, B.PILLAR); p(sx * 3, 3, z, B.LANTERN); }
            }
        }
        // фонтан
        int fz = 17;
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                double r = Math.sqrt(dx * dx + dz * dz);
                if (r <= 2.3) { p(dx, 0, fz + dz, B.WATER); p(dx, -1, fz + dz, B.MARBLE2); }
                else if (r <= 3.3) { p(dx, 0, fz + dz, B.MARBLE2); p(dx, 1, fz + dz, B.MARBLE); }
            }
        }
        for (int k = 0; k <= 3; k++) p(0, k, fz, B.PILLAR);
        p(0, 4, fz, B.CLUSTER_UP);
        // сад: деревья и цветы
        int[][] trees = {{-16, 14}, {16, 14}, {-16, -14}, {16, -14}, {-18, 0}, {18, 0}};
        for (int[] t : trees) s.tree(cx + t[0], cz + t[1], y0);
        for (int dx = -R + 3; dx <= R - 3; dx++) {
            for (int dz = -R + 3; dz <= R - 3; dz++) {
                if (Math.max(Math.abs(dx), Math.abs(dz)) <= K + 2) continue;
                if (Math.abs(dx) <= 2 && dz > 0) continue;
                if (Math.abs(dx) <= 3 && Math.abs(dz - fz) <= 4) continue;
                int h = hash(dx, dz, 7) % 100;
                if (h < 7) p(dx, 1, dz, B.PETALS);
                else if (h < 9) p(dx, 1, dz, B.ALLIUM);
            }
        }
    }
}
