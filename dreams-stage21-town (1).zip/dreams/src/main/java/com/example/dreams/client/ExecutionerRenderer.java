package com.example.dreams.client;

import com.example.dreams.Dreams;
import com.example.dreams.entity.ExecutionerEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;

public class ExecutionerRenderer extends HumanoidMobRenderer<ExecutionerEntity, ExecutionerModel> {

    private static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath(Dreams.MODID, "textures/entity/executioner.png");

    /** Визуальный масштаб. Хитбокс остаётся прежним (иначе не пролезет в двери и узкие улицы), поэтому растёт только модель. */
    public static final float SCALE = 1.65f;

    public ExecutionerRenderer(EntityRendererProvider.Context context) {
        super(context, new ExecutionerModel(context.bakeLayer(ExecutionerModel.LAYER)), 0.0f);
    }

    @Override
    public ResourceLocation getTextureLocation(ExecutionerEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(ExecutionerEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(SCALE, SCALE, SCALE);   // ~4.6 блока с пирамидой: нависает над игроком
    }

    /** Приглушённый свет блока: в красном тумане он тёмный силуэт, но не пропадает. */
    @Override
    protected int getBlockLightLevel(ExecutionerEntity entity, BlockPos pos) {
        return 9;
    }
}
