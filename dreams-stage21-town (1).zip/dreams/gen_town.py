"""Этап 21: строительные блоки городка Иной стороны. Нужны Pillow, numpy, scipy.
Запуск: python3 gen_town.py src/main/resources/assets/dreams

Делает (в том же стиле, что gen_city.py: 32x32, бесшовные, закопчённые):
  textures/block/town_*.png   штукатурка, зелёная штукатурка, вагонка (2 цвета), шифер, красная черепица,
                              плитка больницы (белая/зелёная), шахматный линолеум, камень церкви, доски,
                              бетонные панели, гофрированный металл
  models/block + blockstates  кубы, а также ступени и плиты для крыш, карнизов и цоколей
Семейства ступеней/плит: town_roof, town_roof_red, town_stone, town_wood, town_concrete, city_curb, city_brick.
"""
import os, sys, json
import numpy as np
from PIL import Image
from scipy.ndimage import zoom

S = 32
ROOT = sys.argv[1] if len(sys.argv) > 1 else "src/main/resources/assets/dreams"
TEX = os.path.join(ROOT, "textures", "block")
MOD = os.path.join(ROOT, "models", "block")
BST = os.path.join(ROOT, "blockstates")
for d in (TEX, MOD, BST):
    os.makedirs(d, exist_ok=True)


# ------------------------------------------------------------ инструменты (как в gen_city.py)
def tnoise(gy, gx, seed, size=S):
    r = np.random.default_rng(seed)
    g = r.random((gy, gx))
    z = zoom(g, (size / gy, size / gx), order=3, mode="grid-wrap", grid_mode=True)[:size, :size]
    return (z - z.min()) / max(1e-6, z.max() - z.min())


def fbm(seed, size=S, octs=((3, 3, 1.0), (6, 6, 0.6), (12, 12, 0.35), (24, 24, 0.2))):
    acc = np.zeros((size, size)); tot = 0
    for i, (gy, gx, w) in enumerate(octs):
        acc += tnoise(gy, gx, seed * 31 + i, size) * w; tot += w
    a = acc / tot
    return (a - a.min()) / max(1e-6, a.max() - a.min())


def save_rgb(name, arr):
    Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8), "RGB").save(os.path.join(TEX, name + ".png"))


def streaks(img, r, n, color, amt=0.5, hmin=6, hmax=20, y_lo=0, y_hi=None):
    """Потёки сверху вниз (вода, ржавчина, копоть)."""
    y_hi = S if y_hi is None else y_hi
    for _ in range(n):
        x = int(r.integers(0, S)); h = int(r.integers(hmin, hmax)); y0 = int(r.integers(y_lo, y_hi))
        for t in range(h):
            a = amt * (1 - t / h)
            p = (y0 + t) % S
            img[p, x % S] = img[p, x % S] * (1 - a) + np.array(color, float) * a


def cracks(img, r, n, color=(20, 16, 18), length=(10, 24)):
    for _ in range(n):
        x, y = int(r.integers(0, S)), int(r.integers(0, S))
        for _ in range(int(r.integers(*length))):
            img[y % S, x % S] = img[y % S, x % S] * 0.5 + np.array(color, float) * 0.5
            x += int(r.integers(-1, 2)); y += 1 if r.random() < 0.7 else 0
            if r.random() < 0.4:
                x += int(r.choice([-1, 1]))


def finish(img, r, grain=0.14, blot_seed=0, blot=0.5):
    n = fbm(blot_seed)
    img = img * ((1 - blot / 2) + blot * n)[..., None]
    img = img * (1 - grain / 2 + grain * r.random((S, S, 1)))
    return img


# ------------------------------------------------------------ текстуры
def make_plaster(name, seed, base, mold=(70, 86, 58), brick_under=True):
    r = np.random.default_rng(seed)
    img = np.zeros((S, S, 3)) + np.array(base, float)
    img = finish(img, r, 0.16, seed + 1, 0.55)
    sp = r.random((S, S))
    img = np.where((sp > 0.95)[..., None], img * 1.18, img)
    cracks(img, r, 2, (52, 46, 44))
    streaks(img, r, 7, (66, 52, 42), 0.55, 8, 26, 0, 12)               # сырость с карниза
    m = fbm(seed + 7) > 0.74                                           # плесень пятнами
    img = np.where(m[..., None], img * 0.55 + np.array(mold, float) * 0.45, img)
    if brick_under:                                                    # отвалившаяся штукатурка
        patch = fbm(seed + 11) > 0.9
        brick = np.array([104, 62, 52.0]) * (0.7 + 0.5 * r.random((S, S, 1)))
        edge = patch & (fbm(seed + 12) < 0.9)
        img = np.where(patch[..., None], brick, img)
        img = np.where((edge & (r.random((S, S)) > 0.7))[..., None], img * 0.7, img)
    save_rgb(name, img)


def make_siding(name, seed, base, bare=(112, 90, 68)):
    r = np.random.default_rng(seed)
    img = np.zeros((S, S, 3))
    board_h = 4
    for row in range(S // board_h):
        tone = 0.82 + 0.34 * r.random()
        joint = int(r.integers(0, S))
        for y in range(board_h):
            for x in range(S):
                f = tone
                if y == 0: f *= 1.16
                if y == board_h - 1: f *= 0.62
                if y == board_h - 2: f *= 0.9
                if x == joint: f *= 0.55          # стык досок
                img[row * board_h + y, x] = np.array(base, float) * f
    img = finish(img, r, 0.12, seed + 3, 0.5)
    peel = (fbm(seed + 5) > 0.80) & (r.random((S, S)) > 0.25)         # облупленная краска
    img = np.where(peel[..., None], np.array(bare, float) * (0.6 + 0.5 * r.random((S, S, 1))), img)
    streaks(img, r, 6, (40, 40, 34), 0.5, 6, 20)
    m = fbm(seed + 9) > 0.78
    img = np.where(m[..., None], img * 0.6 + np.array([60, 80, 56.0]) * 0.4, img)
    save_rgb(name, img)


def make_roof_slate(name, seed, base=(56, 56, 66)):
    r = np.random.default_rng(seed)
    img = np.zeros((S, S, 3))
    for row in range(8):
        off = 0 if row % 2 == 0 else 4
        for k in range(4):
            x0 = (k * 8 + off) % S
            col = np.array(base, float) * (0.78 + 0.44 * r.random())
            for dy in range(4):
                for dx in range(8):
                    x = (x0 + dx) % S; y = row * 4 + dy
                    f = 1.0
                    if dy == 0: f *= 1.18
                    if dy == 3: f *= 0.52
                    if dx == 7: f *= 0.62
                    if dy == 3 and dx in (0, 7): f *= 0.7   # скруглённый край
                    img[y, x] = col * f
    img = finish(img, r, 0.14, seed + 3, 0.5)
    m = fbm(seed + 5) > 0.78
    img = np.where(m[..., None], img * 0.55 + np.array([62, 84, 52.0]) * 0.45, img)   # мох
    streaks(img, r, 5, (96, 46, 26), 0.45, 6, 18)                                       # ржавые потёки гвоздей
    save_rgb(name, img)


def make_roof_tile(name, seed, base=(132, 60, 44)):
    r = np.random.default_rng(seed)
    img = np.zeros((S, S, 3))
    for row in range(4):
        for k in range(4):
            col = np.array(base, float) * (0.8 + 0.4 * r.random())
            missing = r.random() < 0.05
            for dy in range(8):
                for dx in range(8):
                    x = (k * 8 + dx + (4 if row % 2 else 0)) % S; y = row * 8 + dy
                    wave = 0.72 + 0.5 * np.sin((dx + 0.5) / 8 * np.pi)      # выпуклость черепицы
                    f = wave * (1.12 if dy < 2 else 0.58 if dy == 7 else 1.0)
                    img[y, x] = col * f * (0.35 if missing else 1.0)
    img = finish(img, r, 0.14, seed + 3, 0.5)
    m = fbm(seed + 5) > 0.76
    img = np.where(m[..., None], img * 0.6 + np.array([66, 88, 54.0]) * 0.4, img)
    streaks(img, r, 4, (30, 24, 24), 0.5, 6, 20)
    save_rgb(name, img)


def make_tile(name, seed, base, grout=(58, 56, 54), blood=False):
    r = np.random.default_rng(seed)
    img = np.zeros((S, S, 3))
    for ty in range(4):
        for tx in range(4):
            col = np.array(base, float) * (0.88 + 0.24 * r.random())
            for dy in range(8):
                for dx in range(8):
                    f = 1.0
                    if dy == 0 or dx == 0: f = 0.5          # шов
                    elif dy == 1 or dx == 1: f = 1.1
                    img[ty * 8 + dy, tx * 8 + dx] = (np.array(grout, float) if f == 0.5 else col * f)
    img = finish(img, r, 0.1, seed + 3, 0.6)
    cracks(img, r, 2, (60, 56, 54), (6, 14))
    streaks(img, r, 5, (70, 50, 40), 0.5, 5, 16)
    if blood:
        m = fbm(seed + 13) > 0.8
        img = np.where(m[..., None], img * 0.4 + np.array([92, 10, 12.0]) * 0.6, img)
    save_rgb(name, img)


def make_checker(name, seed):
    r = np.random.default_rng(seed)
    img = np.zeros((S, S, 3))
    for ty in range(4):
        for tx in range(4):
            dark = (tx + ty) % 2 == 0
            base = np.array([40, 38, 40.0] if dark else [176, 170, 158.0]) * (0.88 + 0.24 * r.random())
            img[ty * 8:ty * 8 + 8, tx * 8:tx * 8 + 8] = base
            img[ty * 8, tx * 8:tx * 8 + 8] *= 0.6
            img[ty * 8:ty * 8 + 8, tx * 8] *= 0.6
    img = finish(img, r, 0.12, seed + 3, 0.65)
    for _ in range(5):                                         # царапины
        x, y = int(r.integers(0, S)), int(r.integers(0, S))
        for t in range(int(r.integers(4, 10))):
            img[(y + t // 3) % S, (x + t) % S] *= 1.3
    m = fbm(seed + 9) > 0.8
    img = np.where(m[..., None], img * 0.45 + np.array([70, 20, 16.0]) * 0.4, img)
    save_rgb(name, img)


def make_stone(name, seed, base=(124, 118, 114)):
    r = np.random.default_rng(seed)
    img = np.zeros((S, S, 3))
    rows = [(0, 10), (10, 21), (21, 32)]
    for ri, (y0, y1) in enumerate(rows):
        x = int(r.integers(0, 8)) if ri else 0
        while x < S + 12:
            w = int(r.integers(9, 16))
            col = np.array(base, float) * (0.78 + 0.4 * r.random())
            for yy in range(y0, y1):
                for xx in range(x, x + w):
                    px = xx % S
                    f = 1.0
                    if yy == y0: f *= 0.32
                    elif yy == y0 + 1: f *= 1.16
                    if yy == y1 - 1: f *= 0.85
                    if xx == x: f *= 0.36
                    elif xx == x + 1: f *= 1.14
                    img[yy, px] = col * f
            x += w
    img = finish(img, r, 0.14, seed + 3, 0.7)
    streaks(img, r, 8, (22, 20, 22), 0.55, 8, 28, 0, 14)         # копоть
    low = np.zeros((S, S)); low[22:, :] = np.linspace(0, 1, 10)[None, :].T
    m = (fbm(seed + 5) > 0.68) & (low > 0.2)
    img = np.where(m[..., None], img * 0.55 + np.array([58, 80, 50.0]) * 0.45, img)   # мох внизу
    cracks(img, r, 1, (30, 26, 28), (8, 18))
    save_rgb(name, img)


def make_wood(name, seed, base=(74, 54, 44)):
    r = np.random.default_rng(seed)
    img = np.zeros((S, S, 3))
    for k in range(8):                                            # вертикальные доски по 4 px
        col = np.array(base, float) * (0.78 + 0.44 * r.random())
        for x in range(4):
            f = 1.0
            if x == 0: f = 0.55
            elif x == 1: f = 1.12
            img[:, k * 4 + x] = col * f
        for _ in range(3):                                         # прожилки
            y = int(r.integers(0, S)); l = int(r.integers(4, 12))
            img[y:y + l, k * 4 + int(r.integers(1, 4))] *= 0.8
    img = finish(img, r, 0.12, seed + 3, 0.5)
    for k in range(8):                                            # гвозди
        for y in (2, 29):
            img[y, k * 4 + 2] = np.array([130, 120, 110.0])
    streaks(img, r, 4, (120, 116, 108), 0.35, 8, 22)
    save_rgb(name, img)


def make_concrete(name, seed, base=(118, 116, 112)):
    r = np.random.default_rng(seed)
    img = np.zeros((S, S, 3)) + np.array(base, float)
    img = finish(img, r, 0.16, seed + 3, 0.6)
    for k in (0, 16):                                              # швы панелей
        img[k, :] *= 0.5; img[:, k] *= 0.5
        img[(k + 1) % S, :] *= 1.1; img[:, (k + 1) % S] *= 1.1
    for (x, y) in ((3, 3), (12, 3), (3, 12), (12, 12), (19, 3), (28, 3), (19, 12), (28, 12)):   # болты
        img[y, x] = np.array([40, 38, 38.0]); img[y, x + 1] = np.array([150, 144, 138.0])
        for t in range(int(r.integers(3, 10))):
            img[(y + 1 + t) % S, x] = img[(y + 1 + t) % S, x] * 0.6 + np.array([116, 52, 28.0]) * 0.4
    cracks(img, r, 2, (30, 28, 30))
    streaks(img, r, 6, (48, 42, 38), 0.5, 8, 26, 0, 10)
    save_rgb(name, img)


def make_metal_roof(name, seed, base=(118, 96, 88)):
    r = np.random.default_rng(seed)
    img = np.zeros((S, S, 3))
    for x in range(S):
        wave = 0.62 + 0.55 * (0.5 + 0.5 * np.sin(x / 4.0 * 2 * np.pi))
        img[:, x] = np.array(base, float) * wave
    img = finish(img, r, 0.14, seed + 3, 0.7)
    rust = fbm(seed + 5) > 0.58
    img = np.where(rust[..., None], img * 0.45 + np.array([132, 62, 28.0]) * 0.55 * (0.7 + 0.5 * fbm(seed + 6)[..., None]), img)
    for y in (3, 16, 28):                                          # ряды крепежа
        for x in range(1, S, 4):
            img[y, x] = np.array([36, 30, 30.0])
    streaks(img, r, 5, (96, 40, 20), 0.5, 8, 24)
    save_rgb(name, img)


TEXTURES = {
    "town_plaster": lambda: make_plaster("town_plaster", 201, (188, 176, 154)),
    "town_plaster_green": lambda: make_plaster("town_plaster_green", 202, (140, 156, 140), mold=(52, 82, 54)),
    "town_siding": lambda: make_siding("town_siding", 203, (104, 122, 130)),
    "town_siding_dark": lambda: make_siding("town_siding_dark", 204, (96, 72, 58), bare=(128, 108, 84)),
    "town_roof": lambda: make_roof_slate("town_roof", 205),
    "town_roof_red": lambda: make_roof_tile("town_roof_red", 206),
    "town_tile_white": lambda: make_tile("town_tile_white", 207, (196, 202, 198)),
    "town_tile_green": lambda: make_tile("town_tile_green", 208, (118, 154, 134), blood=True),
    "town_floor_check": lambda: make_checker("town_floor_check", 209),
    "town_stone": lambda: make_stone("town_stone", 210),
    "town_wood": lambda: make_wood("town_wood", 211),
    "town_concrete": lambda: make_concrete("town_concrete", 212),
    "town_metal_roof": lambda: make_metal_roof("town_metal_roof", 213),
}


# ------------------------------------------------------------ JSON
def wjson(path, obj):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)


def write_cube(name, tex=None):
    wjson(os.path.join(MOD, name + ".json"), {"parent": "minecraft:block/cube_all", "textures": {"all": "dreams:block/" + (tex or name)}})
    wjson(os.path.join(BST, name + ".json"), {"variants": {"": {"model": "dreams:block/" + name}}})


BASE_Y = {"east": 0, "south": 90, "west": 180, "north": 270}


def write_stairs(fam, tex):
    t = {"bottom": "dreams:block/" + tex, "top": "dreams:block/" + tex, "side": "dreams:block/" + tex}
    wjson(os.path.join(MOD, fam + "_stairs.json"), {"parent": "minecraft:block/stairs", "textures": t})
    wjson(os.path.join(MOD, fam + "_stairs_inner.json"), {"parent": "minecraft:block/inner_stairs", "textures": t})
    wjson(os.path.join(MOD, fam + "_stairs_outer.json"), {"parent": "minecraft:block/outer_stairs", "textures": t})
    variants = {}
    for facing, by in BASE_Y.items():
        for half in ("bottom", "top"):
            for shape in ("straight", "inner_left", "inner_right", "outer_left", "outer_right"):
                model = fam + "_stairs" + ("" if shape == "straight" else "_inner" if shape.startswith("inner") else "_outer")
                left = shape.endswith("left")
                right = shape.endswith("right")
                if half == "bottom":
                    y = (by + 270) % 360 if left else by
                    x = 0
                else:
                    x = 180
                    y = (by + 90) % 360 if right else by
                e = {"model": "dreams:block/" + model}
                if x: e["x"] = x
                if y: e["y"] = y
                if x or y: e["uvlock"] = True
                variants["facing=%s,half=%s,shape=%s" % (facing, half, shape)] = e
    wjson(os.path.join(BST, fam + "_stairs.json"), {"variants": variants})


def write_slab(fam, tex):
    t = {"bottom": "dreams:block/" + tex, "top": "dreams:block/" + tex, "side": "dreams:block/" + tex}
    wjson(os.path.join(MOD, fam + "_slab.json"), {"parent": "minecraft:block/slab", "textures": t})
    wjson(os.path.join(MOD, fam + "_slab_top.json"), {"parent": "minecraft:block/slab_top", "textures": t})
    wjson(os.path.join(BST, fam + "_slab.json"), {"variants": {
        "type=bottom": {"model": "dreams:block/" + fam + "_slab"},
        "type=top": {"model": "dreams:block/" + fam + "_slab_top"},
        "type=double": {"model": "dreams:block/" + tex}}})


FAMILIES = [  # имя семейства, текстура (она же имя куба)
    ("town_roof", "town_roof"), ("town_roof_red", "town_roof_red"), ("town_stone", "town_stone"),
    ("town_wood", "town_wood"), ("town_concrete", "town_concrete"), ("city_curb", "city_curb"), ("city_brick", "city_brick"),
]

if __name__ == "__main__":
    for n, f in TEXTURES.items():
        f()
        write_cube(n)
    for fam, tex in FAMILIES:
        write_stairs(fam, tex)
        write_slab(fam, tex)
    print("textures:", len(TEXTURES), "families:", len(FAMILIES))
