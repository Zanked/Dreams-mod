package com.example.dreams.client;

import com.example.dreams.DreamConfig;
import com.example.dreams.Dreams;
import com.example.dreams.dream.DreamTimeline;
import com.example.dreams.entity.ExecutionerEntity;
import com.example.dreams.entity.FigureEntity;
import com.example.dreams.entity.WatcherEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.FogRenderer;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import com.example.dreams.sound.ModSounds;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.material.FogType;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RenderGuiEvent;
import net.neoforged.neoforge.client.event.RenderGuiLayerEvent;
import net.neoforged.neoforge.client.event.ViewportEvent;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;

/**
 * Клиентская атмосфера. Две фазы:
 *  1 (SLEEP): засыпание, экран темнеет, лёгкая тревога.
 *  2 (FALSE_AWAKE): "проснулся" -> спокойное утро -> всё катится в кошмар.
 * Этап 7: психоделика (psy), чёрные вспышки от сервера, тишина перед скримом, круги сна (round).
 */
@EventBusSubscriber(modid = Dreams.MODID, bus = EventBusSubscriber.Bus.GAME, value = Dist.CLIENT)
public class NightmareClient {

    private static int phase = 0;
    private static int kind = 0;           // вид сна (DreamTimeline.KIND_*)
    private static int round = 0;          // номер круга (0 = первый)
    private static int startTicks = 0;     // с какого тика начался этот круг (ускоренный старт)
    private static int ticks = 0;          // тики внутри текущей фазы
    private static float intensity = 0f;   // 0..1: туман, красный цвет, виньетка, тряска
    private static float psy = 0f;         // 0..1: психоделика (FOV, крен, радужный туман/тон)
    private static float darkness = 0f;    // 0..1: чёрное затемнение (засыпание/пробуждение)
    private static int heartbeatCooldown = 0;
    private static int flashLeft = 0;
    // этап 8: Иная сторона
    private static boolean otherworld = false;
    private static int owTicks = 0;          // тиков с момента перехода
    private static int sirenLeft = 0;        // сирена: сколько тиков ещё
    private static float watcherDist = 99f;  // до ближайшего Смотрителя (для радио-помех)
    private static final java.util.Random RAND = new java.util.Random();
    private static final int TRANSITION_TICKS = 70;

    public static void setPhase(int p, int r, int k) {
        otherworld = false;
        owTicks = 0;
        sirenLeft = 0;
        GoodDreamClient.onPhase(p, k);
        if (p == DreamTimeline.PHASE_NONE) {
            phase = 0;
            kind = 0;
            return;
        }
        kind = k;
        if (p == DreamTimeline.PHASE_FALSE_AWAKE && phase == DreamTimeline.PHASE_FALSE_AWAKE) {
            darkness = 0.85f;   // следующий круг: экран "моргает"
        }
        round = r;
        ticks = p == DreamTimeline.PHASE_FALSE_AWAKE ? DreamTimeline.startTick(k, r) : 0;
        startTicks = ticks;
        heartbeatCooldown = 10;
        flashLeft = 0;
        if (p == DreamTimeline.PHASE_SLEEP) {
            intensity = 0f;
            darkness = 0f;
        }
        phase = p;
    }

    /** Разовый эффект от сервера. */
    public static void onFx(int type, int arg) {
        if (type == DreamTimeline.FX_FLASH) {
            if (!DreamConfig.CLIENT.flashes.get() || DreamConfig.CLIENT.reducedMotion.get()) return;
            flashLeft = Math.max(3, arg);
        } else if (type == DreamTimeline.FX_OTHERWORLD) {
            otherworld = true;
            owTicks = 0;
        } else if (type == DreamTimeline.FX_SIREN) {
            sirenLeft = Math.max(1, arg);
        } else if (type == DreamTimeline.FX_GOOD_LIGHTS || type == DreamTimeline.FX_GOOD_FINALE || type == DreamTimeline.FX_GOOD_WHALES) {
            GoodDreamClient.onFx(type, arg);
        }
    }

    /** Мерцание света в Иной стороне: изредка на 3 тика всё почти гаснет. Отключается flashes=false / reducedMotion. */
    private static float flicker() {
        if (!otherworld || !DreamConfig.CLIENT.flashes.get() || DreamConfig.CLIENT.reducedMotion.get()) return 1f;
        long h = (ticks / 3) * 2654435761L;
        h ^= h >>> 13;
        return (h & 63) < 3 ? 0.3f : 1f;
    }

    /** 1 -> 0 за время перехода. */
    private static float transition() {
        return otherworld && owTicks < TRANSITION_TICKS ? 1f - owTicks / (float) TRANSITION_TICKS : 0f;
    }

    private static void reset() {
        GoodDreamClient.reset();
        kind = 0;
        phase = 0;
        round = 0;
        ticks = 0;
        startTicks = 0;
        intensity = 0f;
        psy = 0f;
        darkness = 0f;
        flashLeft = 0;
        otherworld = false;
        owTicks = 0;
        sirenLeft = 0;
        watcherDist = 99f;
    }

    // ---------- профиль интенсивности ----------

    private static float targetIntensity() {
        if (kind == DreamTimeline.KIND_GOOD) return 0f;   // добрый сон: ни тумана, ни красного, ни тряски
        if (phase == DreamTimeline.PHASE_SLEEP) {
            return 0.35f * Mth.clamp(ticks / 80f, 0f, 1f);
        }
        if (phase == DreamTimeline.PHASE_FALSE_AWAKE) {
            float v;
            if (ticks < 40) {
                v = Mth.lerp(ticks / 40f, 0.35f, 0f);                           // проснулся, отпустило
            } else if (ticks < DreamTimeline.CALM_END) {
                v = 0f;                                                          // обычное утро
            } else if (ticks < DreamTimeline.SUN_RUSH_END) {                     // солнце убегает
                v = 0.4f * (ticks - DreamTimeline.SUN_RUSH_START)
                        / (float) (DreamTimeline.SUN_RUSH_END - DreamTimeline.SUN_RUSH_START);
            } else {
                v = Mth.lerp(Mth.clamp((ticks - DreamTimeline.SUN_RUSH_END) / 1200f, 0f, 1f), 0.4f, 0.95f);
            }
            if (otherworld) v = Math.max(v, 0.88f);
            return Math.max(v, 0.1f * round);   // в каждом новом круге тревога не отпускает полностью
        }
        return 0f;
    }

    private static float targetDarkness() {
        if (phase == DreamTimeline.PHASE_SLEEP) {
            return 0.85f * Mth.clamp(ticks / 100f, 0f, 1f);
        }
        return 0f; // в FALSE_AWAKE затемнение само плавно спадает (см. тик)
    }

    /** Тишина перед скримом: глушим сердцебиение, чтобы звук ударил сильнее. */
    private static boolean silent() {
        return phase == DreamTimeline.PHASE_FALSE_AWAKE
                && kind == DreamTimeline.KIND_NIGHTMARE
                && DreamConfig.CLIENT.scareSound.get()
                && ticks >= DreamTimeline.SCARE_TICK - DreamTimeline.SILENCE_LEAD
                && ticks < DreamTimeline.SCARE_TICK + 3;
    }

    // ---------- тик ----------

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) { reset(); return; }
        if (mc.isPaused()) return;

        if (phase != 0) {
            ticks++;
            intensity = targetIntensity();
            if (otherworld) owTicks++;
            if (sirenLeft > 0) sirenLeft--;
            watcherDist = 99f;
            if (mc.level != null) {   // чем ближе Смотритель, тем сильнее туман, тряска и сердцебиение
                float boost = 0f;
                for (Entity e : mc.level.entitiesForRendering()) {
                    if (e instanceof WatcherEntity) {
                        float d = e.distanceTo(mc.player);
                        watcherDist = Math.min(watcherDist, d);
                        boost = Math.max(boost, Mth.clamp((20f - d) / 20f, 0f, 1f) * 0.45f);
                    } else if (e instanceof ExecutionerEntity) {   // Палач давит сильнее и издалека
                        float d = e.distanceTo(mc.player);
                        watcherDist = Math.min(watcherDist, d);
                        boost = Math.max(boost, Mth.clamp((28f - d) / 28f, 0f, 1f) * 0.6f);
                    } else if (e instanceof FigureEntity f && f.isAwake()) {
                        float d = e.distanceTo(mc.player);
                        watcherDist = Math.min(watcherDist, d * 1.6f);   // проснувшаяся фигура тоже трещит в радио
                        boost = Math.max(boost, Mth.clamp((10f - d) / 10f, 0f, 1f) * 0.3f);
                    }
                }
                intensity = Math.min(1f, intensity + boost);
            }
            intensity *= DreamConfig.CLIENT.effectScale.get().floatValue();
            psy = (DreamConfig.CLIENT.psychedelic.get() && !DreamConfig.CLIENT.reducedMotion.get())
                    ? Mth.clamp((intensity - 0.4f) / 0.5f, 0f, 1f) : 0f;
            float td = targetDarkness();
            darkness = td > darkness ? td : Math.max(td, darkness - 0.03f); // пробуждение ~1 сек

            tickSounds(mc);
        } else {
            intensity = Math.max(0f, intensity - 0.05f);
            psy = Math.max(0f, psy - 0.05f);
            darkness = Math.max(0f, darkness - 0.05f);
        }

        if (flashLeft > 0) flashLeft--;
    }

    private static void tickSounds(Minecraft mc) {
        if (kind == DreamTimeline.KIND_GOOD) return;      // у доброго сна своя музыка (GoodDreamClient)
        var sm = mc.getSoundManager();

        if (phase == DreamTimeline.PHASE_SLEEP && ticks == 1) {
            sm.play(SimpleSoundInstance.forUI(ModSounds.AMBIENT.get(), 0.6f, 0.8f));
        }
        if (phase == DreamTimeline.PHASE_FALSE_AWAKE) {
            if (ticks == startTicks + 1) {   // добрый "перезвон": точно проснулся...
                sm.play(SimpleSoundInstance.forUI(ModSounds.CHIME.get(), 1.2f, 0.8f - 0.05f * round));
            }
            if (ticks == DreamTimeline.SUN_RUSH_START + 20) {
                sm.play(SimpleSoundInstance.forUI(ModSounds.AMBIENT.get(), 0.8f, 1.0f - 0.1f * round));
            }
            if (kind == DreamTimeline.KIND_NIGHTMARE && ticks == DreamTimeline.SCARE_TICK && DreamConfig.CLIENT.scareSound.get()) {
                sm.play(SimpleSoundInstance.forUI(ModSounds.SCARE.get(), 0.7f, 1.0f - 0.1f * round));
            }
        }

        // Иная сторона: радио трещит тем сильнее, чем ближе Смотритель; низкий гул раз в минуту
        if (otherworld) {
            if (watcherDist < 28f) {
                float near = 1f - watcherDist / 28f;
                if (RAND.nextFloat() < (float) Math.pow(near, 1.5) * 0.35f) {
                    sm.play(SimpleSoundInstance.forUI(ModSounds.STATIC.get(), 1.4f + RAND.nextFloat() * 0.9f, 0.3f + 0.5f * near));
                }
            }
            if (owTicks % 1200 == 40) {
                sm.play(SimpleSoundInstance.forUI(ModSounds.DRONE.get(), 0.6f, 0.7f));
            }
        }

        // Сердцебиение, когда тревога заметна (кроме окна тишины перед скримом)
        if (--heartbeatCooldown <= 0) {
            if (intensity > 0.2f && !silent()) {
                float pitch = Mth.lerp(intensity, 0.9f, 1.3f);
                sm.play(SimpleSoundInstance.forUI(ModSounds.HEARTBEAT.get(), pitch, 1.0f));
                heartbeatCooldown = (int) Mth.lerp(intensity, 34f, 12f);
            } else {
                heartbeatCooldown = 10;
            }
        }
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        reset();
    }

    // ---------- туман и цвет ----------

    @SubscribeEvent
    public static void onFog(ViewportEvent.RenderFog event) {
        if (intensity <= 0.001f) return;
        if (event.getType() != FogType.NONE) return;
        if (event.getMode() != FogRenderer.FogMode.FOG_TERRAIN) return;

        float ease = intensity * intensity * (3f - 2f * intensity);
        float target = 12f;                                               // 12: видно путь до кровати
        if (otherworld) target = sirenLeft > 0 ? 6f : 9f;                 // Иная сторона: ещё теснее
        float far = Mth.lerp(ease, event.getFarPlaneDistance(), target);
        float sceneFog = com.example.dreams.client.cutscene.CutsceneManager.fogFar();
        if (psy > 0.001f) {
            far *= 1f + 0.3f * psy * Mth.sin(ticks * 0.06f);            // туман "дышит"
            far = Math.max(far, 4f);
        }
        if (sceneFog > 0f) far = Math.max(far, sceneFog);   // катсцена показывает то, что в тумане не видно
        event.setNearPlaneDistance(Mth.lerp(ease, event.getNearPlaneDistance(), 0f));
        event.setFarPlaneDistance(far);
        event.setCanceled(true);
    }

    @SubscribeEvent
    public static void onFogColor(ViewportEvent.ComputeFogColor event) {
        if (intensity <= 0.001f) return;
        if (otherworld) {   // ржавый багрянец, багровеет и мерцает вместе с сиреной
            float f = flicker();
            float pulse = 0.85f + 0.15f * Mth.sin(ticks * 0.045f);
            float sirenK = sirenLeft > 0 ? 0.5f + 0.5f * Mth.sin(sirenLeft * 0.45f) : 0f;
            event.setRed((0.26f + 0.22f * sirenK) * pulse * f);
            event.setGreen(0.06f * pulse * f);
            event.setBlue(0.02f * f);
            return;
        }
        float k = intensity * 0.9f;
        float r = Mth.lerp(k, event.getRed(), 0.30f);
        float g = Mth.lerp(k, event.getGreen(), 0.0f);
        float b = Mth.lerp(k, event.getBlue(), 0.02f);
        if (psy > 0.001f) {   // на пике красный туман переливается всеми цветами
            int rgb = Mth.hsvToRgb((ticks * 0.004f) % 1f, 0.9f, 0.6f);
            float m = psy * 0.8f;
            r = Mth.lerp(m, r, ((rgb >> 16) & 255) / 255f);
            g = Mth.lerp(m, g, ((rgb >> 8) & 255) / 255f);
            b = Mth.lerp(m, b, (rgb & 255) / 255f);
        }
        event.setRed(r);
        event.setGreen(g);
        event.setBlue(b);
    }

    @SubscribeEvent
    public static void onCamera(ViewportEvent.ComputeCameraAngles event) {
        if (com.example.dreams.client.cutscene.CutsceneManager.isActive()) return;   // катсцена сама ведёт камеру: никакой тряски поверх
        float t = ticks + (float) event.getPartialTick();
        if (intensity > 0.001f && DreamConfig.CLIENT.cameraShake.get() && !DreamConfig.CLIENT.reducedMotion.get()) {
            float amp = 2.2f * intensity * intensity;
            event.setYaw(event.getYaw() + Mth.sin(t * 1.7f) * amp * 0.6f);
            event.setPitch(event.getPitch() + Mth.sin(t * 2.3f + 1.3f) * amp * 0.5f);
            event.setRoll(event.getRoll() + Mth.sin(t * 1.1f + 0.7f) * amp);
        }
        float tr = transition();
        if (tr > 0f && !DreamConfig.CLIENT.reducedMotion.get() && DreamConfig.CLIENT.cameraShake.get()) {
            float amp = 5f * tr;   // мир рвёт на части
            event.setYaw(event.getYaw() + Mth.sin(t * 2.9f) * amp * 0.6f);
            event.setPitch(event.getPitch() + Mth.sin(t * 3.7f + 0.4f) * amp * 0.5f);
            event.setRoll(event.getRoll() + Mth.sin(t * 2.1f + 1.1f) * amp);
        }
        if (psy > 0.001f) {   // мир медленно заваливается и "плывёт"
            event.setRoll(event.getRoll() + Mth.sin(t * 0.021f) * 16f * psy);
            event.setPitch(event.getPitch() + Mth.sin(t * 0.037f) * 3f * psy);
        }
    }

    @SubscribeEvent
    public static void onFov(ViewportEvent.ComputeFov event) {
        if (com.example.dreams.client.cutscene.CutsceneManager.isActive()) return;   // FOV в катсцене задаёт сама катсцена
        float t = ticks + (float) event.getPartialTick();
        double add = 0.0;
        if (psy > 0.001f) {
            add += (Mth.sin(t * 0.07f) * 10.0 + Mth.sin(t * 0.19f) * 3.0) * psy;
        }
        float tr = transition();
        if (tr > 0f && !DreamConfig.CLIENT.reducedMotion.get()) {
            add += 30.0 * tr * Mth.sin(owTicks * 0.35f);   // мир "растягивает" при переходе
        }
        if (add != 0.0) event.setFOV(event.getFOV() + add);
    }

    // ---------- HUD ----------

    /** Убираем ванильное синее затемнение сна, рисуем своё. */
    @SubscribeEvent
    public static void onLayerPre(RenderGuiLayerEvent.Pre event) {
        if ((phase != 0 || darkness > 0f) && event.getName().equals(VanillaGuiLayers.SLEEP_OVERLAY)) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onGui(RenderGuiEvent.Post event) {
        if (intensity <= 0.001f && darkness <= 0.001f && flashLeft <= 0 && psy <= 0.001f && !otherworld) return;
        GuiGraphics g = event.getGuiGraphics();
        int w = g.guiWidth();
        int h = g.guiHeight();

        if (intensity > 0.001f) {
            int tint = (int) (255 * 0.20f * intensity);
            g.fill(0, 0, w, h, (tint << 24) | (otherworld ? 0x401400 : 0x300000));
            drawVignette(g, w, h, intensity);
        }
        if (psy > 0.001f) {   // переливающийся тон поверх всего (в Иной стороне только ржавые оттенки)
            float hue = otherworld ? 0.02f + 0.03f * Mth.sin(ticks * 0.03f) : (ticks * 0.005f) % 1f;
            int rgb = Mth.hsvToRgb(Mth.clamp(hue, 0f, 1f), 0.8f, 1f);
            int a = (int) (255 * 0.12f * psy);
            g.fill(0, 0, w, h, (a << 24) | rgb);
        }
        if (otherworld) {
            g.fill(0, 0, w, h, 0x24A04010);   // ржавая цветокоррекция
            if (!DreamConfig.CLIENT.reducedMotion.get()) {   // зерно плёнки
                int n = (int) (260 * DreamConfig.CLIENT.effectScale.get());
                for (int i = 0; i < n; i++) {
                    int x = RAND.nextInt(Math.max(1, w));
                    int y = RAND.nextInt(Math.max(1, h));
                    int a = 14 + RAND.nextInt(30);
                    g.fill(x, y, x + 2, y + 2, (a << 24) | (RAND.nextBoolean() ? 0x6A3A1A : 0x200808));
                }
            }
            if (sirenLeft > 0) {   // сирена: пульсирующий багровый
                float pulse = DreamConfig.CLIENT.reducedMotion.get() ? 0.6f : 0.5f + 0.5f * Mth.sin(sirenLeft * 0.45f);
                g.fill(0, 0, w, h, ((int) (255 * 0.22f * pulse) << 24) | 0xA01005);
            }
            float tr = transition();
            if (tr > 0f) {   // переход: красно-чёрная пелена спадает
                g.fill(0, 0, w, h, ((int) (255 * 0.55f * tr) << 24) | 0x300800);
            }
            if (flicker() < 1f) {   // свет мигает
                g.fill(0, 0, w, h, 0x73000000);
            }
        }
        if (darkness > 0.001f) {
            g.fill(0, 0, w, h, ((int) (255 * darkness) << 24) | (kind == DreamTimeline.KIND_GOOD ? 0x0C1028 : 0x0A0000));
        }
        if (flashLeft > 0) {   // чёрное "моргание": резко гаснет и быстро возвращается
            int a = (int) (255 * Mth.clamp(flashLeft / 3f, 0f, 1f));
            g.fill(0, 0, w, h, a << 24);
        }
    }

    private static void drawVignette(GuiGraphics g, int w, int h, float i) {
        int steps = 20;
        int maxInset = (int) (Math.min(w, h) * 0.45f);
        int size = Math.max(1, maxInset / steps);
        float pulse = DreamConfig.CLIENT.reducedMotion.get() ? 1f : 0.85f + 0.15f * Mth.sin(ticks * 0.5f);
        for (int s = 0; s < steps; s++) {
            float f = 1f - (float) s / steps;
            int a = (int) (255 * 0.85f * i * pulse * f * f);
            if (a <= 0) continue;
            int color = (Mth.clamp(a, 0, 255) << 24) | 0x500000;
            int in = s * size;
            g.fill(in, in, w - in, in + size, color);
            g.fill(in, h - in - size, w - in, h - in, color);
            g.fill(in, in + size, in + size, h - in - size, color);
            g.fill(w - in - size, in + size, w - in, h - in - size, color);
        }
    }
}
