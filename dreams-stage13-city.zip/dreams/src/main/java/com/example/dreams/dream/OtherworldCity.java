package com.example.dreams.dream;

import com.example.dreams.block.ModBlocks;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Город Иной стороны. Целиком фейк: сервер ничего не меняет в мире, игроку по колонкам уходят пакеты блоков
 * (их шлёт свип в DreamManager), а при пробуждении возвращается настоящий мир.
 *
 * Сетка: улицы шириной ROAD через каждые PITCH блоков (оси X и Z), между ними кварталы 2x2 лота по LOT блоков.
 * Сетка выровнена так, что игрок начинает сон в центре перекрёстка. Всё детерминировано (seed + координаты),
 * поэтому повторная отправка чанка даёт тот же город.
 *
 * Здания ЗАПЕЧАТАНЫ: внутрь не войти (иначе сервер, который не знает о фейковых стенах, откатывал бы игрока).
 * Участок застраивается, только если под ним естественная земля (не дерево, не вода, не чужая постройка),
 * перепад невелик, и он не рядом с кроватью или стартом игрока.
 *
 * Сервер не знает и про стены для сущностей, поэтому здесь же маршрутизация по улицам для Палача и фигур
 * ({@link #steer}) и проверка линии взгляда ({@link #sightClear}).
 */
public final class OtherworldCity {

    public static final int PITCH = 40;   // период улиц
    public static final int ROAD = 8;     // ширина улицы
    public static final int LOT = 16;     // сторона лота; в квартале 2x2 лота = 32 блока
    private static final int MAX_DROP = 6;                       // допустимый перепад земли под зданием
    private static final int UNLOADED = Integer.MIN_VALUE;
    private static final int BAD = Integer.MIN_VALUE + 1;

    private final long seed;
    private final int ox, oz;                  // начало сетки
    private final int density;                 // 0..1000: шанс, что лот застроен
    private final List<int[]> clear = new ArrayList<>();    // {x, z, радиус}: здесь не строим
    private final List<int[]> keepProps = new ArrayList<>();// {x, z, радиус}: здесь без уличных украшений (печати)
    private final Long2ObjectOpenHashMap<Lot> lots = new Long2ObjectOpenHashMap<>();
    private int playerX, playerZ;
    private boolean havePlayer = false;

    public OtherworldCity(long seed, BlockPos start, @Nullable BlockPos bed, double density) {
        this.seed = seed;
        this.ox = start.getX() - ROAD / 2;     // игрок в центре коридора улицы: (x - ox) % PITCH == 4
        this.oz = start.getZ() - ROAD / 2;
        this.density = (int) Math.round(Mth.clamp(density, 0.0, 1.0) * 1000.0);
        clear.add(new int[]{start.getX(), start.getZ(), 10});
        if (bed != null) clear.add(new int[]{bed.getX(), bed.getZ(), 12});
    }

    /** Игрок сейчас здесь: участок, внутри которого он стоит, застраивать нельзя. */
    public void setPlayer(int x, int z) {
        playerX = x;
        playerZ = z;
        havePlayer = true;
    }

    /** Не ставить уличные украшения рядом с точкой (печати и т.п.). */
    public void protect(int x, int z, int radius) {
        keepProps.add(new int[]{x, z, radius});
    }

    // ------------------------------------------------------------------ хеш

    private static long mix(long z) {
        z = (z ^ (z >>> 30)) * 0xBF58476D1CE4E5B9L;
        z = (z ^ (z >>> 27)) * 0x94D049BB133111EBL;
        return z ^ (z >>> 31);
    }

    private long h(long a, long b, long c) {
        long z = mix(seed + a * 0x9E3779B97F4A7C15L);
        z = mix(z ^ (b * 0xC2B2AE3D27D4EB4FL));
        return mix(z + c * 0x165667B19E3779F9L);
    }

    /** Положительный хеш позиции (для разброса материалов). */
    private static int bh(long salt, int x, int y, int z) {
        long v = mix(salt ^ ((long) x * 73856093L) ^ ((long) y * 19349663L) ^ ((long) z * 83492791L));
        return (int) (v >>> 33);
    }

    private static long lotKey(int a, int b) {
        return ((long) a << 32) | (b & 0xFFFFFFFFL);
    }

    // ------------------------------------------------------------------ блоки

    private static BlockState plate() { return ModBlocks.RUST_PLATE.get().defaultBlockState(); }
    private static BlockState bloody() { return ModBlocks.RUST_BLOODY.get().defaultBlockState(); }
    private static BlockState grate() { return ModBlocks.RUST_GRATE.get().defaultBlockState(); }
    private static BlockState veined() { return ModBlocks.VEINED_STONE.get().defaultBlockState(); }
    private static BlockState planks() { return ModBlocks.ROTTEN_PLANKS.get().defaultBlockState(); }
    private static BlockState eye() { return ModBlocks.EYE_STONE.get().defaultBlockState(); }
    private static BlockState flesh() { return ModBlocks.FLESH.get().defaultBlockState(); }
    private static BlockState air() { return Blocks.AIR.defaultBlockState(); }
    private static BlockState glass() { return Blocks.BLACK_STAINED_GLASS.defaultBlockState(); }
    private static BlockState lamp() { return Blocks.REDSTONE_LAMP.defaultBlockState().setValue(BlockStateProperties.LIT, true); }

    /** Естественная земля, которую волна и так превращает в ржавчину: только по ней можно строить и класть дорогу. */
    static boolean isGround(BlockState s) {
        return (s.is(BlockTags.DIRT) && !s.is(Blocks.MUD)) || s.is(BlockTags.SAND) || s.is(Blocks.GRAVEL)
                || s.is(BlockTags.BASE_STONE_OVERWORLD) || s.is(BlockTags.TERRACOTTA)
                || s.is(Blocks.SNOW_BLOCK) || s.is(Blocks.SNOW);
    }

    // ------------------------------------------------------------------ лот (здание)

    public static final class Lot {
        static final Lot NONE = new Lot();

        public final boolean built;
        final int x0, z0, x1, z1;      // контур здания (включительно)
        final int floor;               // F: на этой высоте стоял бы пол первого этажа; плита пола на F-1
        final int floors;
        final int roofY;               // плита крыши
        final int lo;                  // нижняя отметка фундамента
        final int style;
        final int doorSide;            // 0=N(-z) 1=E(+x) 2=S(+z) 3=W(-x)
        final int doorU;               // положение двери вдоль стены
        final long salt;
        final boolean tank;
        final boolean antenna;
        final int antennaHeight;

        private Lot() {
            built = false;
            x0 = z0 = x1 = z1 = floor = floors = roofY = lo = style = doorSide = doorU = antennaHeight = 0;
            salt = 0L;
            tank = antenna = false;
        }

        Lot(int x0, int z0, int x1, int z1, int floor, int floors, int lo, int style, int doorSide, int doorU, long salt) {
            this.built = true;
            this.x0 = x0;
            this.z0 = z0;
            this.x1 = x1;
            this.z1 = z1;
            this.floor = floor;
            this.floors = floors;
            this.roofY = floor + 4 + 5 * (floors - 1);
            this.lo = lo;
            this.style = style;
            this.doorSide = doorSide;
            this.doorU = doorU;
            this.salt = salt;
            this.tank = ((salt >>> 8) & 3) == 0;
            this.antenna = ((salt >>> 12) & 1) == 0;
            this.antennaHeight = 3 + (int) ((salt >>> 14) & 3);
        }

        boolean contains(int x, int z) {
            return built && x >= x0 && x <= x1 && z >= z0 && z <= z1;
        }

        int top() {
            return roofY + 9;
        }

        /** Блок здания в точке или null (город ничего не говорит; действует обычная подмена). */
        @Nullable
        BlockState at(int x, int y, int z) {
            if (!built || x < x0 || x > x1 || z < z0 || z > z1 || y < lo) return null;
            boolean edge = x == x0 || x == x1 || z == z0 || z == z1;
            if (y < floor - 1) return edge ? wall(x, y, z, 0, 0, false) : null;
            if (y == floor - 1) return edge ? wall(x, y, z, 0, 0, false) : (bh(salt, x, y, z) % 9 == 0 ? bloody() : plate());
            if (y > top()) return null;
            if (y == roofY) return edge ? wall(x, y, z, 0, 0, false) : (bh(salt, x, y, z) % 8 == 0 ? veined() : plate());
            if (y > roofY) return roofTop(x, y, z, edge);
            int rel = y - floor;
            int r = rel % 5;
            if (edge) return wallCell(x, y, z, rel / 5, r);
            return r == 4 ? plate() : air();   // перекрытие между этажами / пустая комната
        }

        private BlockState roofTop(int x, int y, int z, boolean edge) {
            if (y == roofY + 1 && edge) return bh(salt, x, y, z) % 6 == 0 ? air() : veined();   // парапет с провалами
            if (edge) return null;
            if (tank) {   // водонапорный бак на ножках
                int cx = (x0 + x1) / 2, cz = (z0 + z1) / 2;
                if (Math.abs(x - cx) <= 1 && Math.abs(z - cz) <= 1) {
                    boolean leg = Math.abs(x - cx) == 1 && Math.abs(z - cz) == 1;
                    if (y == roofY + 1) return leg ? veined() : air();
                    if (y == roofY + 2 || y == roofY + 3) return plate();
                    if (y == roofY + 4) return veined();
                }
            }
            if (antenna && x == x0 + 2 && z == z0 + 2 && y >= roofY + 1 && y <= roofY + antennaHeight) {
                return Blocks.LIGHTNING_ROD.defaultBlockState();
            }
            return null;
        }

        private BlockState wallCell(int x, int y, int z, int m, int r) {
            boolean cx = x == x0 || x == x1, cz = z == z0 || z == z1;
            if (cx && cz) return wall(x, y, z, m, r, true);   // угловая колонна
            int side = z == z0 ? 0 : z == z1 ? 2 : x == x1 ? 1 : 3;
            boolean ns = side == 0 || side == 2;
            int u = ns ? x : z;
            int uStart = ns ? x0 : z0, uEnd = ns ? x1 : z1;
            int up = u - uStart, len = uEnd - uStart + 1;
            boolean doorWall = m == 0 && side == doorSide;
            if (doorWall && u >= doorU - 1 && u <= doorU + 2) {   // нарисованная дверь: внутрь не попасть
                if (r <= 2 && (u == doorU || u == doorU + 1)) return planks();
                if (r <= 3) return veined();                      // косяки и притолока
            }
            if (r == 4) return bh(salt, x, y, z) % 5 == 0 ? plate() : veined();   // пояс между этажами
            if ((r == 1 || r == 2) && up >= 2 && up <= len - 3 && ((up - 2) & 3) < 2
                    && !(doorWall && Math.abs(u - doorU) <= 3)) {
                return window(side, m, (up - 2) >> 2);
            }
            return wall(x, y, z, m, r, true);
        }

        private BlockState window(int side, int m, int idx) {
            long hv = mix(salt ^ ((long) side * 1315423911L) ^ ((long) m * 2654435761L) ^ ((long) idx * 97531L));
            int v = (int) ((hv >>> 40) % 100);
            if (v < 52) return glass();
            if (v < 72) return air();          // выбитое окно: за ним тёмная комната
            if (v < 88) return planks();       // забито досками
            if (v < 94) return grate();
            return lamp();                     // редкое горящее окно
        }

        private BlockState wall(int x, int y, int z, int m, int r, boolean holes) {
            int b = bh(salt, x, y, z);
            if (holes && y >= floor && r != 4 && b % 101 == 0) return air();    // пролом в стене
            switch (style) {
                case 0:
                    return b % 11 == 0 ? bloody() : b % 41 == 0 ? veined() : plate();
                case 1:
                    return b % 71 == 0 ? eye() : b % 5 == 0 ? plate() : veined();
                case 2:
                    return b % 7 == 0 ? planks() : b % 13 == 0 ? bloody() : plate();
                default:   // «заражённое» здание
                    return b % 6 == 0 ? flesh() : b % 9 == 0 ? bloody() : veined();
            }
        }
    }

    // ------------------------------------------------------------------ колонка

    /** Что город делает с одной колонкой (x, z). */
    public static final class Col {
        static final Col NONE = new Col(null, 0, 0, 0, null, null);

        @Nullable private final Lot lot;
        private final int x, z;
        private final int surfaceY;
        @Nullable private final BlockState road;
        @Nullable private final BlockState[] props;
        /** Диапазон высот, в котором здание может что-то менять (hi < lo: ничего). */
        public final int lo, hi;

        Col(@Nullable Lot lot, int x, int z, int surfaceY, @Nullable BlockState road, @Nullable BlockState[] props) {
            this.lot = lot;
            this.x = x;
            this.z = z;
            this.surfaceY = surfaceY;
            this.road = road;
            this.props = props;
            if (lot != null) {
                this.lo = lot.lo;
                this.hi = lot.top();
            } else {
                this.lo = Integer.MAX_VALUE;
                this.hi = Integer.MIN_VALUE;
            }
        }

        /** Фейк в точке (x, y, z) или null, если город ничего не решает и действует обычная подмена. */
        @Nullable
        public BlockState at(int y, BlockState real) {
            if (lot != null) {
                BlockState b = lot.at(x, y, z);
                if (b != null) return b;
            }
            if (road != null && y == surfaceY && isGround(real)) return road;
            if (props != null) {
                int k = y - surfaceY - 1;
                if (k >= 0 && k < props.length && props[k] != null) return props[k];
            }
            return null;
        }
    }

    /**
     * Описание колонки. null = ещё нельзя решить (чанки участка не загружены): вернись позже.
     * Для одной и той же колонки результат всегда один и тот же.
     */
    @Nullable
    public Col column(ServerLevel level, int x, int z) {
        int ax = Math.floorMod(x - ox, PITCH), az = Math.floorMod(z - oz, PITCH);
        boolean vert = ax < ROAD, horiz = az < ROAD;   // колонка в коридоре вертикальной / горизонтальной улицы
        if (!vert && !horiz) {
            int bx = Math.floorDiv(x - ox, PITCH), bz = Math.floorDiv(z - oz, PITCH);
            Lot lot = lotFor(level, bx, bz, (ax - ROAD) / LOT, (az - ROAD) / LOT);
            if (lot == null) return null;
            if (!lot.contains(x, z)) return Col.NONE;
            return new Col(lot, x, z, 0, null, null);
        }
        int sy = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z) - 1;
        if (sy < level.getMinBuildHeight()) return Col.NONE;
        BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos(x, sy, z);
        if (!isGround(level.getBlockState(mp))) return Col.NONE;       // дом, дерево, вода: не трогаем
        BlockState road = roadState(x, z, ax, az, vert, horiz);
        BlockState[] props = null;
        if (!(vert && horiz) && !nearProtected(x, z)) {
            BlockState above = level.getBlockState(mp.set(x, sy + 1, z));
            if (above.isAir() || above.canBeReplaced()) props = streetProps(x, z, ax, az, vert);
        }
        return new Col(null, x, z, sy, road, props);
    }

    private boolean nearProtected(int x, int z) {
        for (int[] p : keepProps) {
            int dx = x - p[0], dz = z - p[1];
            if (dx * dx + dz * dz <= p[2] * p[2]) return true;
        }
        return false;
    }

    private BlockState roadState(int x, int z, int ax, int az, boolean vert, boolean horiz) {
        int b = bh(seed, x, 0, z);
        if (vert && horiz) return b % 29 == 0 ? bloody() : plate();       // перекрёсток
        int across = vert ? ax : az;
        int along = Math.floorMod(vert ? z : x, 8);
        if (across == 0 || across == ROAD - 1) return veined();            // бордюр
        if (across == 3 && along < 4) return grate();                      // осевая: тлеющие штрихи
        return b % 23 == 0 ? bloody() : plate();
    }

    /** Фонари и брошенные машины. Только на проезжей части между перекрёстками. */
    @Nullable
    private BlockState[] streetProps(int x, int z, int ax, int az, boolean vert) {
        int across = vert ? ax : az;
        int off = (vert ? az : ax) - ROAD;      // 0..31 внутри квартала; <0 = перекрёсток
        if (off < 0) return null;
        long sid = h(vert ? 1 : 2, Math.floorDiv(vert ? x - ox : z - oz, PITCH), Math.floorDiv(vert ? z - oz : x - ox, PITCH));

        if ((across == 0 || across == ROAD - 1) && (off == 6 || off == 22)) {          // фонарь на тротуаре
            boolean left = (((sid >>> 3) + (off / 16)) & 1) == 0;                      // фонари через сторону
            if ((across == 0) != left) return null;
            long lh = h(sid, off, across);
            if ((int) ((lh >>> 10) % 100) >= 80) return null;
            BlockState post = Blocks.POLISHED_BLACKSTONE_WALL.defaultBlockState();
            BlockState lantern = ((lh >>> 20) % 5 == 0) ? null : Blocks.SOUL_LANTERN.defaultBlockState();   // иногда лампа разбита
            return new BlockState[]{post, post, post, post, lantern};
        }

        int lane = (across >= 1 && across <= 2) ? 0 : (across >= 5 && across <= 6) ? 1 : -1;
        if (lane >= 0) {                                                                // брошенная машина
            int slot = off / 10, o = off % 10;
            if (slot <= 2 && o >= 2 && o <= 5) {
                long ch = h(sid, slot * 2L + lane, 99);
                if ((int) ((ch >>> 12) % 100) < 14) {
                    BlockState body = ((ch >>> 30) % 5 == 0) ? bloody() : plate();
                    if (o == 3 || o == 4) return new BlockState[]{body, glass(), plate()};
                    return new BlockState[]{body};
                }
            }
        }
        return null;
    }

    // ------------------------------------------------------------------ участки

    /** null = ещё нельзя решить (не загружены чанки). */
    @Nullable
    private Lot lotFor(ServerLevel level, int bx, int bz, int i, int j) {
        long key = lotKey(bx * 2 + i, bz * 2 + j);
        Lot cached = lots.get(key);
        if (cached != null) return cached;
        long hh = h(bx * 2L + i, bz * 2L + j, 1);
        int wx = ox + bx * PITCH + ROAD + i * LOT;
        int wz = oz + bz * PITCH + ROAD + j * LOT;
        Lot made = design(level, wx, wz, i, j, hh);
        if (made != null) lots.put(key, made);
        return made;
    }

    @Nullable
    private Lot design(ServerLevel level, int wx, int wz, int i, int j, long hh) {
        if ((int) ((hh >>> 20) % 1000) >= density) return Lot.NONE;      // пустырь / площадь
        for (int[] c : clear) {                                          // кровать и старт игрока: свободно
            int dx = Math.max(Math.max(wx - c[0], c[0] - (wx + LOT - 1)), 0);
            int dz = Math.max(Math.max(wz - c[1], c[1] - (wz + LOT - 1)), 0);
            if (dx * dx + dz * dz < c[2] * c[2]) return Lot.NONE;
        }
        int inW = (int) ((hh >>> 8) % 3), inE = (int) ((hh >>> 10) % 3);
        int inN = (int) ((hh >>> 12) % 3), inS = (int) ((hh >>> 14) % 3);
        int x0 = wx + inW, x1 = wx + LOT - 1 - inE, z0 = wz + inN, z1 = wz + LOT - 1 - inS;
        if (havePlayer && playerX >= x0 - 4 && playerX <= x1 + 4 && playerZ >= z0 - 4 && playerZ <= z1 + 4) {
            return Lot.NONE;                                             // игрок стоит здесь: не замуровывать
        }
        int side = ((hh >>> 16) & 1) == 0 ? (i == 0 ? 3 : 1) : (j == 0 ? 0 : 2);   // дверь смотрит на улицу
        boolean ns = side == 0 || side == 2;
        int uStart = ns ? x0 : z0, uEnd = ns ? x1 : z1;
        int len = uEnd - uStart + 1;
        int doorU = uStart + 3 + (int) ((hh >>> 18) % (len - 6));

        BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();
        int minS = Integer.MAX_VALUE, maxS = Integer.MIN_VALUE;
        for (int a = 0; a < 5; a++) {
            for (int b = 0; b < 5; b++) {
                int s = surface(level, x0 + (x1 - x0) * a / 4, z0 + (z1 - z0) * b / 4, mp);
                if (s == UNLOADED) return null;
                if (s == BAD) return Lot.NONE;                           // дерево, вода, чужая постройка
                minS = Math.min(minS, s);
                maxS = Math.max(maxS, s);
            }
        }
        int fx = side == 1 ? x1 + 1 : side == 3 ? x0 - 1 : doorU;
        int fz = side == 0 ? z0 - 1 : side == 2 ? z1 + 1 : doorU;
        int front = surface(level, fx, fz, mp);
        if (front == UNLOADED) return null;
        if (front == BAD) return Lot.NONE;
        if (maxS - minS > MAX_DROP || front - minS > MAX_DROP || maxS - front > 4) return Lot.NONE;

        int roll = (int) ((hh >>> 30) % 100);
        int floors = roll < 28 ? 2 : roll < 56 ? 3 : roll < 78 ? 4 : roll < 92 ? 5 : 6;
        int floor = front + 1;
        if (floor + 4 + 5 * (floors - 1) + 10 >= level.getMaxBuildHeight()) return Lot.NONE;
        int lo = Math.max(level.getMinBuildHeight(), Math.min(minS, front) - 1);
        return new Lot(x0, z0, x1, z1, floor, floors, lo, (int) ((hh >>> 26) % 4), side, doorU, hh ^ 0x5DEECE66DL);
    }

    private static int surface(ServerLevel level, int x, int z, BlockPos.MutableBlockPos mp) {
        if (!level.hasChunk(x >> 4, z >> 4)) return UNLOADED;
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z) - 1;
        if (y < level.getMinBuildHeight() + 2) return BAD;
        return isGround(level.getBlockState(mp.set(x, y, z))) ? y : BAD;
    }

    /** Лот, застроенный и уже решённый, в этой колонке; иначе null. Только чтение. */
    @Nullable
    private Lot builtLot(int x, int z) {
        int ax = Math.floorMod(x - ox, PITCH), az = Math.floorMod(z - oz, PITCH);
        if (ax < ROAD || az < ROAD) return null;
        int bx = Math.floorDiv(x - ox, PITCH), bz = Math.floorDiv(z - oz, PITCH);
        Lot l = lots.get(lotKey(bx * 2 + (ax - ROAD) / LOT, bz * 2 + (az - ROAD) / LOT));
        return l != null && l.contains(x, z) ? l : null;
    }

    /** Решить участок под точкой (если можно), чтобы здание не выросло вокруг уже стоящей там сущности. */
    private void ensure(ServerLevel level, int x, int z) {
        int ax = Math.floorMod(x - ox, PITCH), az = Math.floorMod(z - oz, PITCH);
        if (ax < ROAD || az < ROAD) return;
        lotFor(level, Math.floorDiv(x - ox, PITCH), Math.floorDiv(z - oz, PITCH), (ax - ROAD) / LOT, (az - ROAD) / LOT);
    }

    // ------------------------------------------------------------------ сервер: сущности и взгляд

    /** Колонка в здании или вплотную к нему (запас на ширину сущности). Только по уже решённым участкам. */
    public boolean blocked(int x, int z) {
        return builtLot(x, z) != null || builtLot(x + 1, z) != null || builtLot(x - 1, z) != null
                || builtLot(x, z + 1) != null || builtLot(x, z - 1) != null;
    }

    /** То же, но сначала решает участок. Если участок решить нельзя (чанки не загружены), считает точку занятой. */
    public boolean blockedForce(ServerLevel level, int x, int z) {
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) ensure(level, x + dx, z + dz);
        }
        int ax = Math.floorMod(x - ox, PITCH), az = Math.floorMod(z - oz, PITCH);
        if (ax >= ROAD && az >= ROAD) {
            Lot l = lotFor(level, Math.floorDiv(x - ox, PITCH), Math.floorDiv(z - oz, PITCH), (ax - ROAD) / LOT, (az - ROAD) / LOT);
            if (l == null) return true;
        }
        return blocked(x, z);
    }

    /** Можно ли пройти по прямой по земле, не упёршись в здание. */
    private boolean walkClear(ServerLevel level, double ax, double az, double bx, double bz) {
        double dx = bx - ax, dz = bz - az;
        int n = (int) Math.ceil(Math.sqrt(dx * dx + dz * dz));
        for (int k = 0; k <= n; k++) {
            double f = n == 0 ? 0.0 : k / (double) n;
            int x = Mth.floor(ax + dx * f), z = Mth.floor(az + dz * f);
            ensure(level, x, z);
            if (blocked(x, z)) return false;
        }
        return true;
    }

    /** Видна ли точка b из точки a (здания непрозрачны; ванильная проверка о фейковых стенах не знает). */
    public boolean sightClear(Vec3 a, Vec3 b) {
        double dx = b.x - a.x, dy = b.y - a.y, dz = b.z - a.z;
        int n = (int) Math.ceil(Math.sqrt(dx * dx + dy * dy + dz * dz));
        for (int k = 1; k < n; k++) {
            double f = k / (double) n;
            double y = a.y + dy * f;
            Lot l = builtLot(Mth.floor(a.x + dx * f), Mth.floor(a.z + dz * f));
            if (l != null && y >= l.lo && y <= l.roofY + 1) return false;
        }
        return true;
    }

    private static final double INF = 1e18;

    /**
     * Куда идти существу, чтобы дойти до цели, не проходя сквозь здания.
     * null = идти напрямую (путь свободен или маршрут не нашёлся). Иначе точка на ближайшем перекрёстке по маршруту.
     * Улицы никогда не застраиваются, поэтому граф перекрёстков всегда проходим.
     */
    @Nullable
    public Vec3 steer(ServerLevel level, Vec3 from, Vec3 to) {
        if (walkClear(level, from.x, from.z, to.x, to.z)) return null;
        int iE = nodeIndex(from.x - ox), iP = nodeIndex(to.x - ox);
        int jE = nodeIndex(from.z - oz), jP = nodeIndex(to.z - oz);
        int i0 = Math.min(iE, iP) - 1, i1 = Math.max(iE, iP) + 1;
        int j0 = Math.min(jE, jP) - 1, j1 = Math.max(jE, jP) + 1;
        int w = i1 - i0 + 1, hgt = j1 - j0 + 1;
        if (w > 14 || hgt > 14) return null;
        int n = w * hgt;
        double[] dist = new double[n];
        int[] prev = new int[n];
        boolean[] done = new boolean[n];
        Arrays.fill(dist, INF);
        Arrays.fill(prev, -1);

        for (int k = 0; k < n; k++) {                                   // откуда можно сразу выйти на улицу
            double d = Math.hypot(nodeX(i0 + k % w) - from.x, nodeZ(j0 + k / w) - from.z);
            if (d <= 48.0 && walkClear(level, from.x, from.z, nodeX(i0 + k % w), nodeZ(j0 + k / w))) dist[k] = d;
        }
        for (int round = 0; round < n; round++) {                       // Дейкстра по сетке перекрёстков
            int u = -1;
            double best = INF;
            for (int k = 0; k < n; k++) {
                if (!done[k] && dist[k] < best) {
                    best = dist[k];
                    u = k;
                }
            }
            if (u < 0) break;
            done[u] = true;
            int ui = u % w, uj = u / w;
            for (int d = 0; d < 4; d++) {
                int ni = ui + (d == 0 ? 1 : d == 1 ? -1 : 0), nj = uj + (d == 2 ? 1 : d == 3 ? -1 : 0);
                if (ni < 0 || nj < 0 || ni >= w || nj >= hgt) continue;
                int v = nj * w + ni;
                if (!done[v] && dist[u] + PITCH < dist[v]) {
                    dist[v] = dist[u] + PITCH;
                    prev[v] = u;
                }
            }
        }
        int goal = -1;
        double bestTotal = INF;
        for (int k = 0; k < n; k++) {                                   // откуда цель видна напрямую
            if (dist[k] >= INF) continue;
            double d2 = Math.hypot(nodeX(i0 + k % w) - to.x, nodeZ(j0 + k / w) - to.z);
            if (d2 > 48.0 || dist[k] + d2 >= bestTotal) continue;
            if (walkClear(level, nodeX(i0 + k % w), nodeZ(j0 + k / w), to.x, to.z)) {
                bestTotal = dist[k] + d2;
                goal = k;
            }
        }
        if (goal < 0) return null;

        int[] path = new int[n];
        int len = 0;
        for (int k = goal; k >= 0 && len < n; k = prev[k]) path[len++] = k;
        for (int p = len - 1; p >= 0; p--) {                            // первый узел маршрута, до которого ещё идти
            int nx = nodeX(i0 + path[p] % w), nz = nodeZ(j0 + path[p] / w);
            if (Math.hypot(nx - from.x, nz - from.z) > 3.0) {
                int y = level.hasChunk(nx >> 4, nz >> 4)
                        ? level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, nx, nz) : Mth.floor(from.y);
                return new Vec3(nx + 0.5, y, nz + 0.5);
            }
        }
        return null;
    }

    private int nodeIndex(double rel) {
        return (int) Math.round((rel - ROAD / 2) / PITCH);
    }

    private int nodeX(int i) {
        return ox + ROAD / 2 + i * PITCH;
    }

    private int nodeZ(int j) {
        return oz + ROAD / 2 + j * PITCH;
    }
}
